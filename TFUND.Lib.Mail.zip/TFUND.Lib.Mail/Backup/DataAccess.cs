﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using TFUND.DB.Oracle;
using System.Data.OracleClient;
using TFund.Lib.Util;

namespace TFund.Lib.Mail
{
    public class DataAccess
    {
        public static DataSet GetDataTest()
        {
            string strSQl = "select  * from warndba.w_nav where rownum < 100 ";

            return OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.Text, strSQl);  
        }
        #region Job

        internal static DataSet GetJobDataList(int pageNum, int perPage, string name, string status, string username)
        {
            
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_JOB_DATA";
            OracleParameterList paramList = new OracleParameterList();



            paramList.Add("P_PAGE_NUM", pageNum, OracleType.Number, 255, ParameterDirection.Input);
            paramList.Add("P_PER_PAGE", perPage, OracleType.Number, 255, ParameterDirection.Input);


            paramList.Add("P_NAME", name, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_USER_NAME", username, OracleType.VarChar, 512, ParameterDirection.Input);
            paramList.Add("P_STATUS", status.ToString(), OracleType.VarChar, 15, ParameterDirection.Input);
           
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);

            OracleParameter[] param = paramList.ToArray();
            return OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

        }
        internal static string SetJobStatus(string jobID,Job.JobStatus status,string updBy)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_UPDATE_JOB_STATUS";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_JOB_ID", jobID , OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_JOB_STATUS", status.ToString() , OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

            if (Data.HasData(ds))
            {
                 result = Data.GetFirstValue(ds) ;
            }

            return result;
        }
        internal static string GetJobStatus(string jobID)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_JOB_STATUS";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_JOB_ID", jobID, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

            if (Data.HasData(ds))
            {
                result = Data.GetFirstValue(ds);
            }

            return result;
        }        

        internal static DataSet GetJob(string jobID, Job.JobStatus? status )
        {
            string strStatus = status.HasValue ? status.Value.ToString() : "";

            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_JOB";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_JOB_ID", jobID, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_JOB_STATUS", strStatus, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

            return ds;
        }
        internal static DataSet GetJobList(string createBy, Job.JobStatus? status)
        {
            string strStatus = status.HasValue ? status.Value.ToString() : "";
           
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_JOB_LIST";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_CREATE_BY", createBy, OracleType.VarChar, 100, ParameterDirection.Input);            
            paramList.Add("P_JOB_STATUS", strStatus, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

           
            return ds;

        }
        internal static string CheckJobBounce(string jobID)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_CHECK_JOB_BOUNCE";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_JOB_ID", jobID, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

            if (Data.HasData(ds))
            {
                result = Data.GetFirstValue(ds);
            }

            return result;
        }

        internal static string InsertJob(string P_NAME,
                                            string P_STATUS,
                                            string P_CREATE_BY,
                                            DateTime P_CREATE_DATE,
                                            string P_UPD_BY,
                                            DateTime P_UPD_DATE,
                                            string P_TEMPLATE,
                                            string P_SERVER,
                                            string P_CRM_MKT_CODE,
                                            string P_CRM_ACTION_CODE,
                                            string P_CRM_DESCRIPTION)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_INS_JOB";
            OracleParameterList paramList = new OracleParameterList();


            paramList.Add("P_NAME", P_NAME, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_CREATE_BY", P_CREATE_BY, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_CREATE_DATE", P_CREATE_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("P_TEMPLATE", P_TEMPLATE, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_SERVER", P_SERVER, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_CRM_MKT_CODE", P_CRM_MKT_CODE, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_CRM_ACTION_CODE", P_CRM_ACTION_CODE, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("P_CRM_DESCRIPTION", P_CRM_DESCRIPTION, OracleType.VarChar, 512, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);

            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
            result = param[param.Length - 1].Value.ToString();

            return result;
        }


        internal static string UpdateJob( string P_ID , string P_NAME,
                                            string P_STATUS,
                                            string P_UPD_BY,
                                            DateTime P_UPD_DATE,
                                            string P_TEMPLATE,
                                            string P_SERVER,                                            
                                            string P_CRM_MKT_CODE,
                                            string P_CRM_ACTION_CODE,
                                            string P_CRM_DESCRIPTION)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_UPD_JOB";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_ID", P_ID, OracleType.VarChar, 255, ParameterDirection.Input);            
            paramList.Add("P_NAME", P_NAME, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("P_TEMPLATE", P_TEMPLATE, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_SERVER", P_SERVER, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_CRM_MKT_CODE", P_CRM_MKT_CODE, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_CRM_ACTION_CODE", P_CRM_ACTION_CODE, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("P_CRM_DESCRIPTION", P_CRM_DESCRIPTION, OracleType.VarChar, 512, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);

            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
            result = param[param.Length - 1].Value.ToString();

            return result;
        }


        #endregion Job

        #region JobItem
        internal static DataSet GetJobItems(string jobID)
        {
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_JOB_ITEM";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_JOB_ID", jobID, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());
          
            return ds;
        }

        internal static DataSet GetJobItemsByStatus(string jobID, string status)
        {
            
            
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_JOB_ITEM_BY_STATUS";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_JOB_ID", jobID, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_JOB_ITEM_STATUS", status, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

            return ds;
        }

        internal static string SetJobItemStatus(string jobID,string jobItemID, JobItem.JobItemStatus status,string updBy)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_UPDATE_JOBITEM_STATUS";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_JOBID", jobID, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("P_JOBITEM_ID", jobItemID, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_JOBITEM_STATUS", status.ToString(), OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

            if (Data.HasData(ds))
            {
                result = Data.GetFirstValue(ds);
            }

            return result;
        }


        internal static string InsertJobItem(int P_JOB_ID, string P_MAIL_TO, string P_CIS_NO, string P_REF_NO, string P_FIRST_NAME,
                                            string P_NAME, string P_SURNAME, string P_TEXT01, string P_TEXT02, string P_TEXT03,
                                            string P_TEXT04, string P_TEXT05, string P_TEXT06, string P_TEXT07, string P_TEXT08,
                                            string P_TEXT09, string P_TEXT10, string P_TEXT11, string P_TEXT12, string P_TEXT13, string P_TEXT14,
                                            string P_TEXT15, string P_TEXT16, string P_TEXT17, string P_FILE01, string P_FILE02, string P_FILE03,
                                            string P_FILE04, string P_FILE05, string P_STATUS, string P_CREATE_BY, DateTime P_CREATE_DATE, string P_UPD_BY,
                                            DateTime P_UPD_DATE)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_INS_JOB_ITEM";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_JOB_ID", P_JOB_ID, OracleType.Number, 22, ParameterDirection.Input);
            paramList.Add("P_MAIL_TO", P_MAIL_TO, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_CIS_NO", P_CIS_NO, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("P_REF_NO", P_REF_NO, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("P_FIRST_NAME", P_FIRST_NAME, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_NAME", P_NAME, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_SURNAME", P_SURNAME, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT01", P_TEXT01, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT02", P_TEXT02, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT03", P_TEXT03, OracleType.VarChar, 255, ParameterDirection.Input);

            paramList.Add("P_TEXT04", P_TEXT04, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT05", P_TEXT05, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT06", P_TEXT06, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT07", P_TEXT07, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT08", P_TEXT08, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT09", P_TEXT09, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT10", P_TEXT10, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT11", P_TEXT11, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT12", P_TEXT12, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_TEXT13", P_TEXT13, OracleType.VarChar, 255, ParameterDirection.Input);

            paramList.Add("P_TEXT14", P_TEXT14, OracleType.VarChar, 4000, ParameterDirection.Input);
            paramList.Add("P_TEXT15", P_TEXT15, OracleType.VarChar, 4000, ParameterDirection.Input);
            paramList.Add("P_TEXT16", P_TEXT16, OracleType.VarChar, 4000, ParameterDirection.Input);
            paramList.Add("P_TEXT17", P_TEXT17, OracleType.VarChar, 4000, ParameterDirection.Input);
            paramList.Add("P_FILE01", P_FILE01, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE02", P_FILE02, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE03", P_FILE03, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE04", P_FILE04, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE05", P_FILE05, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 10, ParameterDirection.Input);

            paramList.Add("P_CREATE_BY", P_CREATE_BY, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_CREATE_DATE", P_CREATE_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("O_ITEM_ID", null, OracleType.VarChar, 100, ParameterDirection.Output);
            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);


            result = param[param.Length - 1].Value.ToString();

            return result;
        }


        internal static DataSet GetJobItemDataList(int pageNum, int perPage,string jobID,string mailTo, string cisNo ,string refNo,string firstName, string name, string surname, string status)
        {

            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_JOB_ITEM";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_PAGE_NUM", pageNum, OracleType.Number, 255, ParameterDirection.Input);
            paramList.Add("P_PER_PAGE", perPage, OracleType.Number, 255, ParameterDirection.Input);
            paramList.Add("P_JOB_ID", jobID, OracleType.VarChar, 20, ParameterDirection.Input);           
            paramList.Add("P_MAIL_TO", mailTo, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_CIS_NO", cisNo, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("P_REF_NO", refNo, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_FIRST_NAME", firstName, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_NAME", name, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_SURNAME", surname, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_STATUS", status, OracleType.VarChar, 15, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);

            OracleParameter[] param = paramList.ToArray();
            return OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

        }

        internal static DataSet GetJobItemSummary(string jobID)
        {
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_ITEM_SUMMARY";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_JOB_ID", jobID, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

            return ds;
        }

        #endregion JobItem

        #region Template
        internal static DataSet GetTemplateList(string status, string createBy)
        {
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_TEMPLATE_LIST";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_STATUS", status, OracleType.VarChar, 20, ParameterDirection.Input); 
            paramList.Add("P_CREATE_BY", createBy, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());
            return ds;
        }

        internal static DataSet GetTemplate(string TemplateName,MailTemplate.MailTemplateStatus? status)
        {
            string strStatus = "";


            if (status.HasValue)
            {
                strStatus = status.Value.ToString();
            }

            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_TEMPLATE";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_TEMPLATE_NAME", TemplateName, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_STATUS", strStatus, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());
            return ds;
        }

        internal static string InsertTemplate(string P_NAME,
                                                string P_DESCRIPTION,
                                                string P_SUBJECT,
                                                string P_BODY,
                                                string P_IS_HTML,
                                                string P_FILE01,
                                                string P_FILE02,
                                                string P_FILE03,
                                                string P_FILE04,
                                                string P_FILE05,
                                                string P_STATUS,
                                                string P_CREATE_BY,
                                                DateTime P_CREATE_DATE,
                                                string P_UPD_BY,
                                                DateTime P_UPD_DATE)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_INS_TEMPLATE";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_NAME", P_NAME, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_DESCRIPTION", P_DESCRIPTION, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_SUBJECT", P_SUBJECT, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_BODY", P_BODY, OracleType.Clob, 4000, ParameterDirection.Input);
            paramList.Add("P_IS_HTML", P_IS_HTML, OracleType.VarChar, 5, ParameterDirection.Input);
            paramList.Add("P_FILE01", P_FILE01, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE02", P_FILE02, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE03", P_FILE03, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE04", P_FILE04, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE05", P_FILE05, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_CREATE_BY", P_CREATE_BY, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_CREATE_DATE", P_CREATE_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);
            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);


            result = param[param.Length - 1].Value.ToString();

            return result;
        }


        internal static string UpdateTemplate(string P_NAME,
                                                string P_DESCRIPTION,
                                                string P_SUBJECT,
                                                string P_BODY,
                                                string P_IS_HTML,
                                                string P_FILE01,
                                                string P_FILE02,
                                                string P_FILE03,
                                                string P_FILE04,
                                                string P_FILE05,
                                                string P_STATUS,                                               
                                                string P_UPD_BY,
                                                DateTime P_UPD_DATE)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_UPD_TEMPLATE";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_NAME", P_NAME, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_DESCRIPTION", P_DESCRIPTION, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_SUBJECT", P_SUBJECT, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_BODY", P_BODY, OracleType.Clob, 4000, ParameterDirection.Input);
            paramList.Add("P_IS_HTML", P_IS_HTML, OracleType.VarChar, 5, ParameterDirection.Input);
            paramList.Add("P_FILE01", P_FILE01, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE02", P_FILE02, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE03", P_FILE03, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE04", P_FILE04, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_FILE05", P_FILE05, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 10, ParameterDirection.Input);           
            paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);
            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);


            result = param[param.Length - 1].Value.ToString();

            return result;
        }

        internal static string UpdateTemplateStatus(string P_NAME,
                                                string P_STATUS,
                                                string P_UPD_BY,
                                                DateTime P_UPD_DATE)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_UPD_TEMPLATE_STATUS";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_NAME", P_NAME, OracleType.VarChar, 50, ParameterDirection.Input);           
            paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);
            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);


            result = param[param.Length - 1].Value.ToString();

            return result;
        }


        #endregion Template

        #region Bounce
        internal static DataSet GetBounce(string id)
        {
            
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_BOUNCE_MAIL";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_ID", id, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 512, ParameterDirection.Output);

            OracleParameter[] param = paramList.ToArray();
            return  OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
           
        }


        internal static string InsertBounce(string email, DateTime bounceDate,string outboundHost,string subject
            ,string body,string reason,BounceMail.BounceMailStatus status,string messageID,string mailFrom
            ,string checkedBy,string createBy,DateTime createDate,string updateBy,DateTime updateDate)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_INSERT_BOUNCE";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_EMAIL", email, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_BOUNCE_DATE", bounceDate, OracleType.DateTime, 50, ParameterDirection.Input);
            paramList.Add("P_OUTBOUND_HOST", outboundHost, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_SUBJECT", subject, OracleType.VarChar, 512, ParameterDirection.Input);
            paramList.Add("P_BODY", body, OracleType.Clob, 65535, ParameterDirection.Input);
            paramList.Add("P_REASON", reason, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_STATUS", status.ToString(), OracleType.VarChar, 15, ParameterDirection.Input);
            paramList.Add("P_MESSAGE_ID", messageID, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_MAIL_FROM", mailFrom, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_CHECKED_BY", checkedBy, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_CREATE_BY", createBy, OracleType.VarChar, 30, ParameterDirection.Input);            
            paramList.Add("P_CREATE_DATE", createDate, OracleType.DateTime, 50, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", updateBy, OracleType.VarChar, 30, ParameterDirection.Input);            
            paramList.Add("P_UPD_DATE", updateDate, OracleType.DateTime, 50, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);

            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
            result = param[param.Length - 1].Value.ToString();

            return result;
        }

        internal static DataSet GetBounceData(int pageNum,int perPage,string email,DateTime? bounceDate,string subject
             ,string status ,string reason)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_BOUNCE_DATA";
            OracleParameterList paramList = new OracleParameterList();



            paramList.Add("P_PAGE_NUM", pageNum, OracleType.Number, 255, ParameterDirection.Input);
            paramList.Add("P_PER_PAGE", perPage, OracleType.Number, 255, ParameterDirection.Input);


            paramList.Add("P_EMAIL", email, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_BOUNCE_DATE", bounceDate.HasValue ? bounceDate.Value : (object)DBNull.Value   , OracleType.DateTime, 50, ParameterDirection.Input);
            paramList.Add("P_SUBJECT", subject, OracleType.VarChar, 512, ParameterDirection.Input);
            paramList.Add("P_STATUS", status.ToString(), OracleType.VarChar, 15, ParameterDirection.Input);
            paramList.Add("P_REASON", reason, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
         
            OracleParameter[] param = paramList.ToArray();
            return OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
            
      

        }


        internal static string UpdateBounceStatus(string id,string status, string updateBy, DateTime updateDate)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_UPDATE_BOUNCE_STATUS";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_ID", id, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("P_STATUS", status.ToString(), OracleType.VarChar, 15, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", updateBy, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", updateDate, OracleType.DateTime, 50, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);

            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
            result = param[param.Length - 1].Value.ToString();

            return result;
        }


        //PROCEDURE SP_INS_CRM_BOUNCE_MAIL(P_EMAIL VARCHAR2,O_RESULT OUT VARCHAR2)
        internal static string InsertCRMBounceMail(string email)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_INS_CRM_BOUNCE_MAIL";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_EMAIL", email, OracleType.VarChar, 255, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);

            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
            result = param[param.Length - 1].Value.ToString();

            return result;
        }

        #endregion Bounce 
        
        #region Server
        internal static DataSet GetConfig(string configName)
        {

            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_SERVER_CONFIG";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_CONFIG_NAME", configName, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());



            return ds;
        }

        internal static DataSet GetServerConfigList(string userName,string flagActive)
        {
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_SERVER_CONFIG_LIST";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_USER_NAME", userName, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_FLAG_ACTIVE", flagActive, OracleType.VarChar, 1, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());



            return ds;
        }

        internal static DataSet GetServerConfigListByType(string userName,TFund.Lib.Mail.ServerInfo.ServerType sType)
        {
            string strSQL = "CIS.PK_REG_EMAIL.SP_GET_SERVER_BY_TYPE";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_USER_NAME", userName, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_SERVER_TYPE", sType.ToString(), OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("C_RESULT", null, OracleType.Cursor, 0, ParameterDirection.Output);
            DataSet ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());



            return ds;
        }

        internal static string InsertServer(string P_NAME,
                                            string P_SERVER_HOST,
                                            string P_SERVER_PORT,
                                            string P_AUTHEN_USERNAME,
                                            string P_AUTHEN_PASSWORD,
                                            string P_PROXY_REQUIRE,
                                            string P_PROXY_USERNAME,
                                            string P_PROXY_PASSWORD,
                                            string P_MAIL_FROM,
                                            string P_MAIL_FROM_NAME,
                                            string P_MAIL_REPLY_TO,
                                            string P_DELAY_MS,
                                            string P_CREATE_BY,
                                            DateTime P_CREATE_DATE,
                                            string P_UPD_BY,
                                            DateTime P_UPD_DATE,
                                            string P_SERVER_TYPE,
                                            string P_AUTHEN_DOMAIN,
                                            string P_PROXY_ADDRESS,
                                            string P_PROXY_PORT,
                                            string P_PROXY_DOMAIN,
                                            string P_FLAG_ACTIVE)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_INS_SERVER";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_NAME", P_NAME, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_SERVER_HOST", P_SERVER_HOST, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_SERVER_PORT", P_SERVER_PORT, OracleType.VarChar, 22, ParameterDirection.Input);
            paramList.Add("P_AUTHEN_USERNAME", P_AUTHEN_USERNAME, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_AUTHEN_PASSWORD", P_AUTHEN_PASSWORD, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_PROXY_REQUIRE", P_PROXY_REQUIRE, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_PROXY_USERNAME", P_PROXY_USERNAME, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_PROXY_PASSWORD", P_PROXY_PASSWORD, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_MAIL_FROM", P_MAIL_FROM, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_MAIL_FROM_NAME", P_MAIL_FROM_NAME, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_MAIL_REPLY_TO", P_MAIL_REPLY_TO, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_DELAY_MS", P_DELAY_MS, OracleType.VarChar, 22, ParameterDirection.Input);
            paramList.Add("P_CREATE_BY", P_CREATE_BY, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_CREATE_DATE", P_CREATE_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("P_SERVER_TYPE", P_SERVER_TYPE, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_AUTHEN_DOMAIN", P_AUTHEN_DOMAIN, OracleType.VarChar, 200, ParameterDirection.Input);
            paramList.Add("P_PROXY_ADDRESS", P_PROXY_ADDRESS, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_PROXY_PORT", P_PROXY_PORT , OracleType.Number, 200, ParameterDirection.Input);
            paramList.Add("P_PROXY_DOMAIN", P_PROXY_DOMAIN, OracleType.VarChar, 200, ParameterDirection.Input);
            paramList.Add("P_FLAG_ACTIVE", P_FLAG_ACTIVE, OracleType.VarChar, 1, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);
            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);


            result = param[param.Length - 1].Value.ToString();

            return result;
        }

        internal static string UpdateServer(string P_NAME,
                                            string P_SERVER_HOST,
                                            string P_SERVER_PORT,
                                            string P_AUTHEN_USERNAME,
                                            string P_AUTHEN_PASSWORD,
                                            string P_PROXY_REQUIRE,
                                            string P_PROXY_USERNAME,
                                            string P_PROXY_PASSWORD,
                                            string P_MAIL_FROM,
                                            string P_MAIL_FROM_NAME,
                                            string P_MAIL_REPLY_TO,
                                            string P_DELAY_MS,
                                            string P_UPD_BY,
                                            DateTime P_UPD_DATE,
                                            string P_SERVER_TYPE,
                                            string P_AUTHEN_DOMAIN,
                                            string P_PROXY_ADDRESS,
                                            string P_PROXY_PORT,
                                            string P_PROXY_DOMAIN,
                                            string P_FLAG_ACTIVE)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_UPD_SERVER";
            OracleParameterList paramList = new OracleParameterList();

            paramList.Add("P_NAME", P_NAME, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_SERVER_HOST", P_SERVER_HOST, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_SERVER_PORT", P_SERVER_PORT, OracleType.VarChar, 22, ParameterDirection.Input);
            paramList.Add("P_AUTHEN_USERNAME", P_AUTHEN_USERNAME, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_AUTHEN_PASSWORD", P_AUTHEN_PASSWORD, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_PROXY_REQUIRE", P_PROXY_REQUIRE, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_PROXY_USERNAME", P_PROXY_USERNAME, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_PROXY_PASSWORD", P_PROXY_PASSWORD, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_MAIL_FROM", P_MAIL_FROM, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_MAIL_FROM_NAME", P_MAIL_FROM_NAME, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_MAIL_REPLY_TO", P_MAIL_REPLY_TO, OracleType.VarChar, 128, ParameterDirection.Input);
            paramList.Add("P_DELAY_MS", P_DELAY_MS, OracleType.VarChar, 22, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
            paramList.Add("P_SERVER_TYPE", P_SERVER_TYPE, OracleType.VarChar, 10, ParameterDirection.Input);
            paramList.Add("P_AUTHEN_DOMAIN", P_AUTHEN_DOMAIN, OracleType.VarChar, 200, ParameterDirection.Input);
            paramList.Add("P_PROXY_ADDRESS", P_PROXY_ADDRESS, OracleType.VarChar, 30, ParameterDirection.Input);
            paramList.Add("P_PROXY_PORT", P_PROXY_PORT, OracleType.VarChar, 200, ParameterDirection.Input);
            paramList.Add("P_PROXY_DOMAIN", P_PROXY_DOMAIN, OracleType.VarChar, 200, ParameterDirection.Input);
            paramList.Add("P_FLAG_ACTIVE", P_FLAG_ACTIVE, OracleType.VarChar, 1, ParameterDirection.Input);
            paramList.Add("O_RESULT", null, OracleType.VarChar, 512, ParameterDirection.Output);
            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);


            result = param[param.Length - 1].Value.ToString();

            return result;
        }

        #endregion

        #region CRM
        internal static string InsertCRM(string cisNo, string fundCode, string actionCode, string description, DateTime updDate, string updBy)
        {
            string result = "";
            string strSQL = "CIS.PK_REG_EMAIL.SP_INSERT_CRM";
            OracleParameterList paramList = new OracleParameterList();
            paramList.Add("P_CIS_NO", cisNo, OracleType.VarChar, 20, ParameterDirection.Input);
            paramList.Add("P_FUND_CODE", fundCode, OracleType.VarChar, 50, ParameterDirection.Input);
            paramList.Add("P_ACTION_CODE", actionCode, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("P_DESCRIPTION", description, OracleType.VarChar, 1024, ParameterDirection.Input);
            paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);
            paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 100, ParameterDirection.Input);
            paramList.Add("O_ORDER_INF", null, OracleType.VarChar, 100, ParameterDirection.Output);
            OracleParameter[] param = paramList.ToArray();
            OracleHelper.ExecuteNonQuery(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);


            result = param[param.Length - 1].Value.ToString();

            return result;
        }


        #endregion 
    }
}
