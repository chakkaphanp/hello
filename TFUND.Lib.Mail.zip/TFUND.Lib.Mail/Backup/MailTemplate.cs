﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using TFund.Lib.Util;
using System.Data;

namespace TFund.Lib.Mail
{
    public class MailTemplate
    {
        public enum MailTemplateStatus
        {
            ACTIVE,
            INACTIVE
        }


        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private string _description;

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        private string _subject;

        public string Subject
        {
            get { return _subject; }
            set { _subject = value; }
        }
        private string _body;

        public string Body
        {
            get { return _body.Replace("<<", "&lt;&lt;").Replace(">>", "&gt;&gt;"); }
            set { _body = value.Replace("&lt;&lt;", "<<").Replace("&gt;&gt;", ">>"); }
        }
        private bool _isHTML;

        public bool IsHTML
        {
            get { return _isHTML; }
            set { _isHTML = value; }
        }
        private string _file01;

        public string File01
        {
            get { return _file01; }
            set { _file01 = value; }
        }
        private string _file02;

        public string File02
        {
            get { return _file02; }
            set { _file02 = value; }
        }
        private string _file03;

        public string File03
        {
            get { return _file03; }
            set { _file03 = value; }
        }
        private string _file04;

        public string File04
        {
            get { return _file04; }
            set { _file04 = value; }
        }
        private string _file05;

        public string File05
        {
            get { return _file05; }
            set { _file05 = value; }
        }

        private MailTemplateStatus _status;

        public MailTemplateStatus Status
        {
            get { return _status; }
            set { _status = value; }
        }
        private string _creatBy;

        public string CreatBy
        {
            get { return _creatBy; }
            set { _creatBy = value; }
        }
        private DateTime _createDate;

        public DateTime CreateDate
        {
            get { return _createDate; }
            set { _createDate = value; }
        }
        private string _updateBy;

        public string UpdateBy
        {
            get { return _updateBy; }
            set { _updateBy = value; }
        }
        private DateTime _updateDate;

        public DateTime UpdateDate
        {
            get { return _updateDate; }
            set { _updateDate = value; }
        }

        private bool _isNew;

        public static DataSet GetMailTemplate(string status,string username)
        {
            return DataAccess.GetTemplateList(status,username);
        }

        public static List<MailTemplate> GetMailTemplateList(string username)
        {
            DataSet ds = DataAccess.GetTemplateList("",username);
            List<MailTemplate> lst = new List<MailTemplate>();

            if (Data.HasData(ds))
            {
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    lst.Add(new MailTemplate(item));
                }
            }

            return lst;

        }


        public MailTemplate(string userName)
        {
            this._isNew = true;
            this._status = MailTemplateStatus.ACTIVE;
            this._creatBy = userName;
            this._createDate = DateTime.Now;
        }
         

        public MailTemplate(string name,string userName , MailTemplateStatus? status )
        {
            DataSet dsTemplate = DataAccess.GetTemplate(name,null); 

            if(Data.HasData(dsTemplate))
            {
              /*NAME
                DESCRIPTION
                SUBJECT
                BODY
                IS_HTML
                FILE01
                FILE02
                FILE03
                FILE04
                FILE05
                STATUS
                CREATE_BY
                CREATE_DATE
                UPD_BY
                UPD_DATE*/
                this._name = name;
                this._description = Data.GetFirstValue(dsTemplate, "DESCRIPTION");
                this._subject = Data.GetFirstValue(dsTemplate,"SUBJECT");
                this._body = Data.GetFirstValue(dsTemplate, "BODY");
                this._isHTML =  bool.Parse(Data.GetFirstValue(dsTemplate, "IS_HTML"));
                this._file01 = Data.GetFirstValue(dsTemplate, "FILE01");
                this._file02 = Data.GetFirstValue(dsTemplate, "FILE02");
                this._file03 = Data.GetFirstValue(dsTemplate, "FILE03");
                this._file04 = Data.GetFirstValue(dsTemplate, "FILE04");
                this._file05 = Data.GetFirstValue(dsTemplate, "FILE05");
                this._status = (MailTemplateStatus)Enum.Parse(typeof(MailTemplateStatus), Data.GetFirstValue(dsTemplate, "STATUS"));

                this._creatBy = Data.GetFirstValue(dsTemplate, "CREATE_BY");
                this._createDate = (DateTime)Data.GetFirstValueObj(dsTemplate,"CREATE_DATE");
                this._updateBy = Data.GetFirstValue(dsTemplate, "UPD_BY");
                this._updateDate = (DateTime)Data.GetFirstValueObj(dsTemplate, "UPD_DATE");


                this._isNew = false;

                
            }else{
                throw new DataException(string.Format( "No MailTemplate name ==> {0}" ,name));

            }
        }
        
        public MailTemplate(DataRow dr)
        {            
            this._name = Data.NVL(dr["NAME"],"");
            this._description = Data.NVL(dr["DESCRIPTION"],"");
            this._subject = Data.NVL(dr["SUBJECT"],"");
            this._body = Data.NVL(dr["BODY"],"");
            this._isHTML = bool.Parse(Data.NVL(dr["IS_HTML"],""));
            this._file01 = Data.NVL(dr["FILE01"],"");
            this._file02 = Data.NVL(dr["FILE02"],"");
            this._file03 = Data.NVL(dr["FILE03"],"");
            this._file04 = Data.NVL(dr["FILE04"],"");
            this._file05 = Data.NVL(dr["FILE05"],"");
            this._status = (MailTemplateStatus)Enum.Parse(typeof(MailTemplateStatus), Data.NVL(dr["STATUS"],""));

            this._creatBy = Data.NVL(dr["CREATE_BY"],"");
            this._createDate = (DateTime)dr["CREATE_DATE"];
            this._updateBy = Data.NVL(dr["UPD_BY"],"");
            this._updateDate = (DateTime)dr["UPD_DATE"];


            this._isNew = false;
        }

        /// <summary>
        /// Get mailmessage that ready to send out. But need to fill Sender & ReplyTo 
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public Email GetMessage(JobItem item)
        {
            Email msg = new Email();


            /*
             TODO : Check the encoding when get data from HTML front end and Database.
             */
            msg.SubjectEncoding = Encoding.UTF8;
            msg.BodyEncoding = Encoding.UTF8;

                                   

            string[] strVariable = GetAllVariableInHTML(this._subject);
            string strSubject = this._subject;
            foreach (var sv in strVariable)
            {
               strSubject = strSubject.Replace(string.Format("<<{0}>>", sv), item.GetData(sv)); 
            }
            msg.Subject = strSubject;
            strVariable = GetAllVariableInHTML(this._body);
            string strBody = this._body;
            foreach (var sb in strVariable)
            {
                strBody = strBody.Replace(string.Format("<<{0}>>", sb), item.GetData(sb));
            }
            msg.Body = strBody;
            msg.IsBodyHtml = this._isHTML;
            msg.To.Clear();
                        
            //msg.To.Add(item.MailToAddresses);
            msg.To.Add(item.MailTo);

            string[] attchs = new string[] { this._file01 , this._file02 ,this._file03 , this._file04 ,this._file05 
            , item.GetData("FILE01") , item.GetData("FILE02"), item.GetData("FILE03"), item.GetData("FILE04"), item.GetData("FILE05") };
            foreach (var file in attchs)
            {
                if (Data.HasData(file))
                {
                    msg.AttachmentsPath.Add(file);
                }
            }
                 
            return msg;
        }

        public string[] GetAllVariableInHTML(string html)
        {
            List<string> lstVarName = new List<string>();
            string[] x = html.Split(new string[] { "<<" }, StringSplitOptions.None);

            foreach (var xx in x)
            {
               string[] xxx = xx.Split(new string[] { ">>" }, StringSplitOptions.None);
               if (xxx.Length > 1 && !lstVarName.Contains(xxx[0]) )
               {
                   lstVarName.Add(xxx[0]);
               }
            }

            return lstVarName.ToArray();
        }


        public bool Save(string username)
        {
            string result = "";
            this._updateBy = username;
            this._updateDate = DateTime.Now;
            if (this._isNew) //Insert 
            {
               result = DataAccess.InsertTemplate(this._name, this._description, this._subject, this._body, this._isHTML.ToString(), this._file01, this._file02
                    , this._file03, this._file04, this._file05, this._status.ToString(), this._creatBy, this._createDate, this._updateBy, this._updateDate);
               this._isNew = false;
            
            }
            else //Update
            {
               result = DataAccess.UpdateTemplate(this._name, this._description, this._subject, this._body, this._isHTML.ToString(), this._file01, this._file02
                    , this._file03, this._file04, this._file05, this._status.ToString(), this._updateBy, this._updateDate); 
            }

            if (result == "COMPLETE")
            {
                return true;
            }
            else
            {
                throw new Exception(result);
            }
        }


        public bool SetStatus(MailTemplateStatus status,string username)
        {
            if (this._isNew)
            {
                throw new Exception("Please save this template before trying to change status.");
            }

            this._updateBy = username;
            this._updateDate = DateTime.Now;
            this._status = status;
            string result = DataAccess.UpdateTemplateStatus(this._name, this._status.ToString(), this._updateBy, DateTime.Now);
            if (result == "COMPLETE")
            {
                return true;
            }
            else
            {
                throw new Exception(result);
            }
        }

    }
}
