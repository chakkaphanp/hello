﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Net.Mail;
using System.Data;

using TFund.Lib.Util;
using TFUND.DB.Oracle;
using System.Data.OracleClient;
using System.IO;


namespace TFund.Lib.Mail
{
    /// <summary>
    /// Summary description for EmailSender
    /// </summary>
    public class DUMMYSender :ISender
    {
        /*
         Current mail hose as of 06/07/2016 ==> 10.180.193.17     
         *** 10.190.194.21 IRON Port DR for External only 
         *** 10.180.193.17 Symantec SMTP Gateway for Internal + External 
         */

        private string _name;
        private int _delay_ms = 2000;


        private string _mailHost;
        private int _mailPort;

        
        private string _authUsername;
        private string _authPassword;
        private string _authDomain;

        private string _mailFrom;
        private string _mailDisplayName;
        private string _mailReplyTo;

        private MailAddress _mailFromAddress;
        private MailAddress _mailReplyToAddress;

        private SmtpClient _smtp;

        private StreamWriter _dataLogger;
        private string _filePath;

        public DUMMYSender()
        {

            _filePath = AppDomain.CurrentDomain.BaseDirectory + "\\DUMMYSenderLog" + DateTime.Today.ToString("yyyyMMdd") + ".txt";  

            _dataLogger = File.CreateText(_filePath);
            _dataLogger.WriteLine(string.Format("*************** Start Session at {0} ********************", DateTime.Now.ToString("dd/MM/yyyy hh:MI:ss")));
            _dataLogger.Flush();
            _dataLogger.Close();
            _dataLogger.Dispose();
        }

   
        /// <summary>
        /// Send a simple text message to a single recipient. 
        /// </summary>
        /// <param name="mailTo"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <returns>0 if no error</returns>
        public string SendSimpleMail(string mailTo, string subject, string body)
        {
           
            string result = "COMPLETE";
            System.Threading.Thread.Sleep(200);
            return result;          
        }

        public MailAddress GetSenderAddress()
        {
            return this._mailFromAddress;
        }

        public MailAddress GetReplyToAddress()
        {
            return this._mailReplyToAddress != null ? this._mailReplyToAddress : this._mailFromAddress;
        }


        public int GetDelayMS()
        {
            return this._delay_ms;
        }

        public string SendMail(Email msg)
        {
            System.Threading.Thread.Sleep(this.GetDelayMS());


            _dataLogger = new StreamWriter(this._filePath, true);
            _dataLogger.WriteLine(string.Format("{0} ==> Send mail to {1}", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),msg.To[0].Address));
            _dataLogger.Flush();
            _dataLogger.Close();
            _dataLogger.Dispose();
            
            return "COMPLETE";
        }

        
    }
}