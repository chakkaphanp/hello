﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using TFund.Lib.Util;
using System.Net.Mail;
using System.Net;

using System.Web.Script.Serialization;

namespace TFund.Lib.Mail
{

    /*
     * Classname : NipaAPISerder
     * Date : 2018/10/09
     * Create By : Chakkaphan
     * Description : This class provide ability to send email via NipaAPI v1.0 
     *               for more information please see https://app-b.nipamail.com/api/v1.0/standard.php
     */
    public class NipaAPISender : ISender 
    {

        private HttpWebRequest _req;
        private string _boundary;

        private string _name;
        private int _delay_ms = 100;

        private string _host_address;        

        private bool _proxyRequire;
        private string _proxyAddress;
        private int _proxyPort;
        private string _proxyUsername;
        private string _proxyPassword;
        private string _proxyDomain;

        private string _mailFrom;
        private MailAddress _mailFromAddress;
        private string _mailDisplayName;
        private string _mailReplyTo;
        private MailAddress _mailReplyToAddress;
        
        private WebProxy _proxy;

        //private string _ccMailAddress;
        //private string _bccMailAddress;

        public NipaAPISender(string name)
        {
            DataSet ds = DataAccess.GetConfig(name);

            if (Data.HasData(ds))
            {
                init(ds.Tables[0]);
            }
            else
            {
                throw new DataException(string.Format("No configuration name ==> {0}", name));
            }
        }
        
        public NipaAPISender(DataTable dt)
        {
            init(dt);
        }


        public NipaAPISender(string host, string mailFrom, string mailDisplayName, string mailReplyTo,bool proxyRequire
                            , string proxyAddress, int proxyPort, string proxyUsername, string proxyPassword,string proxyDomain
                            )
        {
            init(host, mailFrom, mailDisplayName, mailReplyTo,proxyRequire, proxyAddress,proxyPort,proxyUsername , proxyPassword, proxyDomain);
        }

        private void init(DataTable dt)
        {
            if(TFund.Lib.Util.Data.HasData(dt))
            {
                DataRow dr = dt.Rows[0];


                this._name = dr["NAME"].ToString();
                if (!TFund.Lib.Util.Data.HasData(dr["SERVER_HOST"]))
                {
                    throw new ArgumentException("Please set SERVER_HOST for this configuration.");
                }
                this._host_address  = dr["SERVER_HOST"].ToString();


                if (!Data.HasData(dr["MAIL_FROM"]))
                {
                    throw new ArgumentException("Please set MAIL_FROM for this configuration.");
                }
                this._mailFrom = dr["MAIL_FROM"].ToString();

  

                this._mailDisplayName = Data.NVL(dr["MAIL_FROM_NAME"], this._mailFrom);
                this._mailReplyTo = Data.NVL(dr["MAIL_REPLY_TO"], this._mailFrom);

                this._proxyRequire = Convert.ToBoolean(Data.NVL(dr["PROXY_REQUIRE"], "False"));                   
                this._proxyAddress = Data.NVL(dr["PROXY_ADDRESS"],"");
                if (this._proxyRequire && this._proxyAddress.Equals(string.Empty))
                {
                    throw new ArgumentException("Proxy address is required, Please check configuration in CIS.EMSMSERVER");
                }
                this._proxyPort =  Convert.ToInt32(Data.NVL(dr["PROXY_PORT"], "8080"));
                this._proxyUsername = Data.NVL(dr["PROXY_USERNAME"], "");
                this._proxyPassword = Data.NVL(dr["PROXY_PASSWORD"], "");
                this._proxyDomain = Data.NVL(dr["PROXY_DOMAIN"], "");

                this._delay_ms = Convert.ToInt32(Data.NVL(dr["DELAY_MS"], "900"));


                init(this._host_address, this._mailFrom, this._mailDisplayName, this._mailReplyTo, this._proxyRequire, this._proxyAddress
                     , this._proxyPort, this._proxyUsername, this._proxyPassword, this._proxyDomain);

            }else{
                    throw new DataException("Configuration not found.");
            }
        }

        private void init(string host, string mailFrom, string mailDisplayName, string mailReplyTo, bool proxyRequire
                            , string proxyAddress, int proxyPort, string proxyUsername, string proxyPassword,string proxyDomain
                            )
        {
            this._host_address = host;
            this._mailFrom = mailFrom;

            if (Data.HasData(mailDisplayName))
            {
                _mailFromAddress = new MailAddress(mailFrom, mailDisplayName);
            }
            else
            {
                _mailFromAddress = new MailAddress(mailFrom);
            }


            if (!mailReplyTo.Equals(string.Empty))
            {
                _mailReplyToAddress = new MailAddress(mailReplyTo);
            }
            else
            {
                _mailReplyToAddress = _mailFromAddress;
            }

            this._mailDisplayName = mailDisplayName;
            this._mailReplyTo = mailReplyTo;


            this._proxyRequire = proxyRequire;
            this._proxyAddress = proxyAddress;
            this._proxyPort = proxyPort;
            this._proxyUsername = proxyUsername;
            this._proxyPassword = proxyPassword;
            this._proxyDomain = proxyDomain;


            /*var ccMailAddress = System.Configuration.ConfigurationSettings.AppSettings["TFUND.Lib.Mail.CCMailAddress"];
            if (ccMailAddress != null && !ccMailAddress.Equals(string.Empty))
            {
                this._ccMailAddress = ccMailAddress;
            }


            var bccMailAddress = System.Configuration.ConfigurationSettings.AppSettings["TFUND.Lib.Mail.BCCMailAddress"];
            if (bccMailAddress != null && !bccMailAddress.Equals(string.Empty))
            {
                this._bccMailAddress = bccMailAddress;
            }*/

        }


        private void initWebRequest()
        {
            Uri uri = new Uri(this._host_address);
            // bypass any certificate validation error 
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            // force use TLS1.2 
            ServicePointManager.SecurityProtocol = SecurityProtocolTypeExtensions.Tls12; 
 
            this._req = (HttpWebRequest)WebRequest.Create(uri);
            this._boundary = "----------" + DateTime.Now.Ticks.ToString("x");
            this._req.ContentType = "multipart/form-data; boundary=" + this._boundary;
            this._req.Method = "POST";
            

            if (this._proxyRequire)
            {
                this._proxy = new WebProxy(this._proxyAddress, this._proxyPort);
                if (!this._proxyUsername.Equals(string.Empty))
                {
                    if (!this._proxyDomain.Equals(string.Empty))
                    {
                        this._proxy.Credentials = new NetworkCredential(this._proxyUsername, this._proxyPassword, this._proxyDomain);
                    }
                    else
                    {
                        this._proxy.Credentials = new NetworkCredential(this._proxyUsername, this._proxyPassword);
                    }
                }
                this._req.Proxy = this._proxy;
            }
        }

        public static byte[] file_get_byte_contents(Stream s)
        {
            byte[] sContents;
            BinaryReader br = new BinaryReader(s);
            sContents = br.ReadBytes(s.ReadByte());
            br.Close();
            s.Close();
            return sContents;
        }

        public static byte[] file_get_byte_contents(string fileName)
        {
            byte[] sContents;
            if (fileName.ToLower().IndexOf("http:") > -1)
            {
                // URL 
                System.Net.WebClient wc = new System.Net.WebClient();
                sContents = wc.DownloadData(fileName);
            }
            else
            {
                // Get file size
                FileInfo fi = new FileInfo(fileName);

                // Disk
                FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                sContents = br.ReadBytes((int)fi.Length);
                br.Close();
                fs.Close();
            }

            return sContents;
        }

        private static string readAll(MemoryStream ms)
        {
            long pos = ms.Position;
            ms.Position = 0;

            StreamReader sr = new StreamReader(ms);
            string strResult = sr.ReadToEnd();
            ms.Position = pos;

            return strResult;

        }

        /// <summary>
        /// Writes string to stream.
        /// </summary>
        private static void WriteToStream(Stream s, string txt)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(txt);
            s.Write(bytes, 0, bytes.Length);
        }

        /// <summary>
        /// Writes byte array to stream.
        /// </summary>
        private static void WriteToStream(Stream s, byte[] bytes)
        {
            s.Write(bytes, 0, bytes.Length);
        }


        /// <summary>
        /// Writes multi part HTTP POST request.
        /// </summary>
        private void WriteMultipartForm(Stream s, string boundary, Dictionary<string, string> data, string fileName, string fileContentType, byte[] fileData)
        {
            /// The first boundary
            byte[] boundarybytes = Encoding.UTF8.GetBytes("--" + boundary + "\r\n");
            /// the last boundary.
            byte[] trailer = Encoding.UTF8.GetBytes("\r\n--" + boundary + "--\r\n");
            /// the form data, properly formatted
            string formdataTemplate = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}";
            /// the form-data file upload, properly formatted
            string fileheaderTemplate = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n";

            /// Added to track if we need a CRLF or not.
            bool bNeedsCRLF = false;

            if (data != null)
            {
                foreach (string key in data.Keys)
                {
                    /// if we need to drop a CRLF, do that.
                    if (bNeedsCRLF)
                        WriteToStream(s, "\r\n");

                    /// Write the boundary.
                    WriteToStream(s, boundarybytes);

                    /// Write the key.
                    WriteToStream(s, string.Format(formdataTemplate, key, data[key]));
                    bNeedsCRLF = true;
                }
            }

            /// If we don't have keys, we don't need a crlf.
            if (bNeedsCRLF)
                WriteToStream(s, "\r\n");

            WriteToStream(s, boundarybytes);
           
            /// Write the file data to the stream.
            if (fileData != null)
            {
                WriteToStream(s, string.Format(fileheaderTemplate, "attachment", fileName, fileContentType));
                WriteToStream(s, fileData);
            }
            WriteToStream(s, trailer);

            s.Close();
        }


        private void WriteMultipartForm(Stream s, string boundary, Dictionary<string, string> data,AttachInfo[] files)
        {
            /// The first boundary
            byte[] boundarybytes = Encoding.UTF8.GetBytes("--" + boundary + "\r\n");
            /// the last boundary.
            byte[] trailer = Encoding.UTF8.GetBytes("\r\n--" + boundary + "--\r\n");
            /// the form data, properly formatted
            string formdataTemplate = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}";
            /// the form-data file upload, properly formatted
            string fileheaderTemplate = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n";

            /// Added to track if we need a CRLF or not.
            bool bNeedsCRLF = false;

            if (data != null)
            {
                foreach (string key in data.Keys)
                {
                    /// if we need to drop a CRLF, do that.
                    if (bNeedsCRLF)
                        WriteToStream(s, "\r\n");

                    /// Write the boundary.
                    WriteToStream(s, boundarybytes);

                    /// Write the key.
                    WriteToStream(s, string.Format(formdataTemplate, key, data[key]));
                    bNeedsCRLF = true;
                }
            }

            /// Write the file data to the stream.
            if (files.Count() >0)
            {
                foreach (var item in files)
                {
                    /// If we don't have keys, we don't need a crlf.
                    if (bNeedsCRLF)
                        WriteToStream(s, "\r\n");
                    WriteToStream(s, boundarybytes);
                    WriteToStream(s, string.Format(fileheaderTemplate, "attachment[]", item.FileName, item.FileContentType));
                    WriteToStream(s, file_get_byte_contents(item.FilePath));
                    
                }

                
            }


            WriteToStream(s, trailer);

            s.Close();


        }



        public class AttachInfo {
            
            private static IDictionary<string, string> _mappings = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase) 
            {
                {".7z", "application/x-7z-compressed"},       
                {".bmp", "image/bmp"},       
                {".cab", "application/octet-stream"},        
                {".chm", "application/octet-stream"},        
                {".css", "text/css"},
                {".csv", "text/csv"},        
                {".dat", "application/octet-stream"},       
                {".doc", "application/msword"},        
                {".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
                {".flv", "video/x-flv"},       
                {".gif", "image/gif"},       
                {".gz", "application/x-gzip"},        
                {".htm", "text/html"},
                {".html", "text/html"},        
                {".jpeg", "image/jpeg"},
                {".jpg", "image/jpeg"},       
                {".mdb", "application/x-msaccess"},       
                {".mht", "message/rfc822"},
                {".mhtml", "message/rfc822"},        
                {".mov", "video/quicktime"},
                {".movie", "video/x-sgi-movie"},       
                {".mp3", "audio/mpeg"},
                {".mp4", "video/mp4"},        
                {".pdf", "application/pdf"},        
                {".png", "image/png"},     
                {".ppt", "application/vnd.ms-powerpoint"},        
                {".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"},        
                {".rar", "application/octet-stream"},
                {".tif", "image/tiff"},
                {".tiff", "image/tiff"},      
                {".txt", "text/plain"},
                {".xls", "application/vnd.ms-excel"},    
                {".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},      
                {".xml", "text/xml"},       
                {".zip", "application/x-zip-compressed"}
            };

            private string _filePath;

            public string FilePath
            {
                get { return _filePath; }               
            }
            private string _fileName;

            public string FileName
            {
                get { return _fileName; }               
            }
            private string _fileContentType;

            public string FileContentType
            {
                get { return _fileContentType; }                
            }
            
            public AttachInfo(string filePath)
            {
                if (!System.IO.File.Exists(filePath))
                {
                    throw new FileNotFoundException(string.Format("Cannot find file ==> {0}", filePath));
                }
                
                this._filePath = filePath;
                this._fileName = System.IO.Path.GetFileName(this._filePath);
                this._fileContentType = GetFileContentType(this._filePath);

            }


            private string GetFileContentType(string filePath)
            {
                string extension = System.IO.Path.GetExtension(filePath);

                if (extension == null)
                {
                    throw new ArgumentNullException("extension");
                }

                if (!extension.StartsWith("."))
                {
                    extension = "." + extension;
                }
                string mime;
                return _mappings.TryGetValue(extension, out mime) ? mime : "application/octet-stream";

            }
        }
        
        private Dictionary<string,object> GetNipaAPIResult(string strResultJSON)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            Dictionary<string, object> result = (Dictionary<string, object>)ser.DeserializeObject(strResultJSON);          
            return result;
        }

        private void WritePerformanceLog(string message, DateTime startDate)
        {
            #if DEBUG
            TimeSpan tsElapse = DateTime.Now - startDate;
            TFund.Lib.Util.Log.WriteLog(string.Format("{0}:{1}.{2}",message,tsElapse.Seconds,tsElapse.Milliseconds)); 
            #endif            
        }


        #region ISender Members
               

        public string SendMail(Email msg)
        {
            DateTime dStartSendMail = DateTime.Now;
            
            Dictionary<string, string> data = new Dictionary<string, string>();

            WritePerformanceLog("01 Start initWebRequest()", dStartSendMail);
            initWebRequest();
            WritePerformanceLog("02 End initWebRequest()", dStartSendMail);
             
            data.Add("from_name", msg.Sender.DisplayName );
            data.Add("from_email", msg.Sender.Address );
            data.Add("to", msg.To[0].Address);
            data.Add("subject", msg.Subject );
            data.Add("message", msg.Body);
            data.Add("disable_unsubscribe","True"); 

            if (msg.CC.Count > 0)
            {
                data.Add("cc", msg.CC[0].Address);// TODO: Add support for multiple CC address
            }

            


            WritePerformanceLog("03 Start Attachment", dStartSendMail);

           
            if (msg.AttachmentsPath.Count == 1) {
                AttachInfo attach = new AttachInfo(msg.AttachmentsPath[0]); 
                WriteMultipartForm(this._req.GetRequestStream(), this._boundary, data, attach.FileName , attach.FileContentType, file_get_byte_contents(attach.FilePath));
            }
            else if (msg.AttachmentsPath.Count == 0)
            {
                WriteMultipartForm(this._req.GetRequestStream(), this._boundary, data, "", "", null);
            }
            else
            {
                List<AttachInfo> lstAttach = new List<AttachInfo>();
                foreach (var item in msg.AttachmentsPath)
	            {
            		 lstAttach.Add(new AttachInfo(item));
	            }
                WriteMultipartForm(this._req.GetRequestStream(), this._boundary, data, lstAttach.ToArray());
               

            }
            WritePerformanceLog("04 End Attachment", dStartSendMail);
            WritePerformanceLog("05 Start get response", dStartSendMail);

            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)this._req.GetResponse();
            }
            catch (WebException ex)
            {                
                response = (HttpWebResponse)ex.Response; // Handle other response code than 200 (e.g. 400 Bad request when trying to send unsubscribed address) 
            }

            Stream recvStream = response.GetResponseStream();
            StreamReader sr = new StreamReader(recvStream, Encoding.UTF8);
            WritePerformanceLog("06 End get response", dStartSendMail);
            string strResultJSON = sr.ReadToEnd();
            response.Close();
            sr.Close();

            Dictionary<string,object> result = GetNipaAPIResult(strResultJSON);

            if (result["status"].ToString() == "success")
            {
                return "COMPLETE";
            }
            else
            {
                // Unscribe will be IGNORE as complete
                if (result["status"].ToString() == "error" && result["message"].ToString() == "This email has been unsubscribed from you.")
                {
                    return "COMPLETE";
                }

                return string.Format("{0}:{1}", result["status"], result["message"]);
            }
        }

        public string SendSimpleMail(string mailTo, string subject, string body)
        {
            initWebRequest(); 
            throw new NotImplementedException();
        }

        public System.Net.Mail.MailAddress GetSenderAddress()
        {
            return this._mailFromAddress;
        }

        public System.Net.Mail.MailAddress GetReplyToAddress()
        {
            return this._mailReplyToAddress; 
        }


        public int GetDelayMS()
        {
            return this._delay_ms;
        }

        #endregion
    }
}
