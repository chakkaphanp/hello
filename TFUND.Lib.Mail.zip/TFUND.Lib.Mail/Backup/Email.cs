﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net.Mail;
using Microsoft.Exchange.WebServices.Data;
using System.Globalization;

namespace TFund.Lib.Mail
{
    public class Email : MailMessage
    {
        //private string _mailTo;

        //public string MailTo
        //{
        //    get { return _mailTo; }
        //    set { _mailTo = value; }
        //}

        //private string _mailFrom;
        //public string MailFrom
        //{
        //    get { return _mailFrom; }
        //    set { _mailFrom = value; }
        //}

        //private string _replyTo;


        //private string _subject;
        //public string Subject
        //{
        //    get { return _subject; }
        //    set { _subject = value; }
        //}
        //private string _content;

        //public string Content
        //{
        //    get { return _content; }
        //    set { _content = value; }
        //}

        //private Encoding _mailEncoding;

        //public Encoding MailEncoding
        //{
        //    get { return _mailEncoding; }
        //    set { _mailEncoding = value; }
        //}

        private List<string> _attachmentsPath = new List<string>();

        public List<string> AttachmentsPath
        {
            get { return _attachmentsPath; }
            set { _attachmentsPath = value; }
        }


        public Email() {
           
        }

        public Email(string mailTo, string mailFrom, string subject, string content)
        {                        
            //this.To.Add(new MailAddress(mailTo));
            this.To.Add(mailTo);
           
            this.Sender = new MailAddress(mailFrom);
            this.Subject = subject;
            this.Body = content;
        }

        public MailMessage GetMailMessage()
        {
            this.From = this.Sender;

            foreach (var item in this.AttachmentsPath)
            {
                System.Net.Mail.Attachment att = new System.Net.Mail.Attachment(item);
                att.Name = System.IO.Path.GetFileName(item);
                this.Attachments.Add(att) ;   
                
            }

            //this.Headers.Add("List-Unsubscribe", String.Format(
            //            CultureInfo.InvariantCulture, "<http://{0}>", "www.thanachartfund.com/unsubscribe.aspx?id=chakz_p@hotmail.com"));

            return this;
        }


        public EmailMessage GetEmailMessage(ExchangeService service)
        {
            
            EmailMessage ems = new EmailMessage(service);
            ems.Sender = Util.GetEmailAddress(this.Sender);
            ems.ReplyTo.Add(Util.GetEmailAddress(this.ReplyTo));
            ems.ToRecipients.Add(Util.GetEmailAddress(this.To[0]));
     
            ems.Body = this.Body;
            ems.Subject = this.Subject;


            foreach (var item in this.AttachmentsPath)
            {
                ems.Attachments.AddFileAttachment(item);
            }

           

            return ems;
        }


    }
}
