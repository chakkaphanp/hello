﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Exchange.WebServices.Data;
using System.Data;
using TFund.Lib.Util;

namespace TFund.Lib.Mail
{
    public class BounceMail
    {

        private string[] noUserStringList = { "The email account that you tried to reach does not exist"
                                            , "Requested action not taken: mailbox unavailable" 
                                            , "This user doesn't have a yahoo.com account" };

        public enum BounceMailStatus
        {
            INIT,
            REJECT,
            IGNORE
        }

        private EmailMessage _emailMessage;

        private string _id;

        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }


        private string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }


        private DateTime _bounceDate;

        public DateTime BounceDate
        {
            get { return _bounceDate; }
            set { _bounceDate = value; }
        }

        private string _outboundHost;

        public string OutboundHost
        {
            get { return _outboundHost; }
            set { _outboundHost = value; }
        }



        private string _reason;

        public string Reason
        {
            get { return _reason; }
            set { _reason = value; }
        }
        



        private BounceMailStatus _status;
        public BounceMailStatus Status
        {
            get { return _status; }
            set { this._status = value; }
        }


        private string _checkedByAccount;

        public string CheckedByAccount
        {
            get { return _checkedByAccount; }
            set { _checkedByAccount = value; }
        }

        private string _messageID;

        public string MessageID
        {
            get { return _messageID; }
            set { _messageID = value; }
        }



        private string _mailFrom;

        public string MailFrom
        {
            get { return _mailFrom; }
            set { _mailFrom = value; }
        }



        private string _subject;

        public string Subject
        {
            get { return _subject; }
            set { _subject = value; }
        }


        private string _body;

        public string Body
        {
            get { return _body; }
            set { _body = value; }
        }
     


        private string _createBy;

        public string CreateBy
        {
            get { return _createBy; }
            set { _createBy = value; }
        }
        private DateTime _createDate;

        public DateTime CreateDate
        {
            get { return _createDate; }
            set { _createDate = value; }
        }
        private string _updateBy;

        public string UpdateBy
        {
            get { return _updateBy; }
            set { _updateBy = value; }
        }
        private DateTime _updateDate;

        public DateTime UpdateDate
        {
            get { return _updateDate; }
            set { _updateDate = value; }
        }

        public bool isBounceMail
        {
            get { return this.CheckBounceOriginAddr(this._mailFrom); }
        }


        private bool _isNew;

        public BounceMail(EmailMessage em,string user) //Create New from EmailMessage (Automatically add from EWSSender)
        {

            try
            {
                this._emailMessage = em;

                this._email = this._emailMessage.ToRecipients.Count > 0 ? this._emailMessage.ToRecipients[0].Address : "";
                this._bounceDate = this._emailMessage.DateTimeCreated;
                this._body = this._emailMessage.Body.Text;
                this._outboundHost = getOutBoundHost();
                this._reason = getReason();
                this._messageID = this._emailMessage.InternetMessageId.Replace("<", "").Replace(">", "");
                this._mailFrom = this._emailMessage.Sender.Address;
                this._subject = this._emailMessage.Subject;



                this.CreateBy = user;
                this.CreateDate = DateTime.Now;
                this.UpdateBy = user;
                this.UpdateDate = DateTime.Now;

                this._isNew = true;
            }
            catch (Exception ex)
            {
                TFund.Lib.Util.Log.WriteLog(ex);
                TFund.Lib.Util.Log.WriteLog(this._emailMessage.ToRecipients.Count > 0 ? this._emailMessage.ToRecipients[0].Address : "");
            }
        }

        public BounceMail(string user)
        {
            this.CreateBy = user;
            this.CreateDate = DateTime.Now;
            this.UpdateBy = user;
            this.UpdateDate = DateTime.Now;

            this._isNew = true;
        }

        public BounceMail(int id)
        {
            DataSet ds = DataAccess.GetBounce(id.ToString());
            if (Data.HasData(ds))
            {
                DataRow dr = ds.Tables[0].Rows[0];
                SetData(dr);

                this._isNew = false;
            }
            else
            {
                throw new Exception(string.Format("No bounce mail ID >> {0}", id));
            }
 
        }

        public BounceMail(DataRow dr)
        {
            SetData(dr);
            this._isNew = false;
        }


        private void SetData(DataRow dr)
        {
            this._id = Data.NVL(dr["ID"], "");
            this._email = Data.NVL(dr["EMAIL"], "");
            this._outboundHost = Data.NVL(dr["OUTBOUND_HOST"], "");
            this._subject = Data.NVL(dr["SUBJECT"], "");
            this._body = Data.NVL(dr["BODY"], "");
            this._reason = Data.NVL(dr["REASON"], "");
            this._status = (BounceMailStatus)Enum.Parse(typeof(BounceMailStatus), Data.NVL(dr["STATUS"], BounceMailStatus.INIT.ToString()));
            this._messageID = Data.NVL(dr["MESSAGE_ID"], "");
            this._mailFrom = Data.NVL(dr["MAIL_FROM"], "");
            this._checkedByAccount = Data.NVL(dr["CHECKED_BY"], "");

            this._createBy = Data.NVL(dr["CREATE_BY"], "");
            this._createDate = (DateTime)dr["CREATE_DATE"];
            this._updateBy = Data.NVL(dr["UPD_BY"], "");
            this._updateDate = (DateTime)dr["UPD_DATE"];
        }

        private string getOutBoundHost()
        {
            string strServerTH = "กำลังสร้างเซิร์ฟเวอร์:";
            string strServerEN = "Generating server:";

            int idx = this.Body.IndexOf(strServerTH);
            int len = strServerTH.Length;
            if (idx < 0)
            {
                idx = this.Body.IndexOf(strServerEN);
                len = strServerEN.Length;
            }


            if (idx > 0)
            {
                int idxEnd = this.Body.IndexOf("</p>", idx + 1);

                return this.Body.Substring(idx + len, idxEnd - (idx + len)).TrimStart().TrimEnd();
            }
            else
            {
                return "";
            }
        }

        private string getReason()
        {
            string strStart = string.Format("<p>{0}<br>", this.Email);
            string strEnd = "</p>";
            int idx = this.Body.IndexOf(strStart);
            int len = strStart.Length;
            if (idx < 0) { return ""; }
            int idxEnd = this.Body.IndexOf(strEnd, idx);

            string rawReason = this.Body.Substring(idx + len, idxEnd - (idx + len));

            foreach (var item in noUserStringList)
            {
                if (rawReason.IndexOf(item) >= 0)
                {
                    return string.Format("ไม่พบ {0} ที่ปลายทาง กรุณาติดต่อลูกค้าเพื่อแก้ไขข้อมูลอีเมล์", this.Email);
                }
            }

            int x = rawReason.IndexOf("smtp;"); 
            
            if (x >= 0)
            {
                int start = x+6;
                len = 0;
                if (rawReason.EndsWith("#SMTP#", StringComparison.InvariantCultureIgnoreCase ))
                {
                    len = rawReason.Length - 11 - (start);
                }
                else
                {
                    len = rawReason.Length - (start);
                }
                return rawReason.Substring(start, len);
            }

            return rawReason;
        }


        private bool CheckBounceOriginAddr(string address)
        {
            try
            {
                return address.ToUpper().IndexOf("MAILER-DAEMON") >= 0 || address.ToUpper().IndexOf("POSTMASTER") >= 0  ;    
            }
            catch (Exception ex)
            {
                TFund.Lib.Util.Log.WriteLog(ex);
                return false;
            }
                  
        }

       

        public int Save(string user)
        {            
            if (this._isNew)
            {
                this.UpdateBy = this.CreateBy = user;
                this.UpdateDate = this.CreateDate = DateTime.Now;
                if (this.Body.Equals(string.Empty))
                {
                    this.Body = "-";
                }

                string result = DataAccess.InsertBounce(this.Email, this.BounceDate, this.OutboundHost, this.Subject, this.Body,
                                        this.Reason, this.Status, this.MessageID, this.MailFrom,this.CheckedByAccount, this._createBy, this._createDate, this._updateBy, this._updateDate);
            
                 int x = -1;
                 if (int.TryParse(result, out x))
                 {

                     if (this.Status == BounceMailStatus.REJECT)
                     DataAccess.InsertCRMBounceMail(this.Email); 

                     return x;
                 }
                 else
                 {
                     throw new Exception(result);
                 }
            }else{ // Update status
                this.UpdateBy = user;
                this.UpdateDate = DateTime.Now;

                string result = DataAccess.UpdateBounceStatus(this.Id, this.Status.ToString(), this.UpdateBy, this.UpdateDate); 
                  
                if (result == "COMPLETE")
                    {

                        if (this.Status == BounceMailStatus.REJECT)
                            DataAccess.InsertCRMBounceMail(this.Email); 

                        return int.Parse(this.Id);
                    }
                    else
                    {
                        throw new Exception(result);
                    }
            }
        }


        public bool SaveStatus(string user)
        {

            return false;
        }



        public static DataSet GetBounceData(int pageNum,int perPage,string email,DateTime? bounceDate,string subject
             ,string status ,string reason)
        {
            return DataAccess.GetBounceData(pageNum,perPage,email,bounceDate,subject,status,reason);
        }
    }
}
