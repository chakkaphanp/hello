﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using TFund.Lib.Util;

namespace TFund.Lib.Mail
{
    public class ServerInfo
    {

        public enum ServerType
        {
            SMTP,
            EWS,
            DUMMY,
            NipaAPI
        }

        public static DataSet GetServer(string userName,string flagActive)
        {
           // return null;
          return DataAccess.GetServerConfigList(userName,flagActive);
        }

        public static List<ServerInfo> GetServerList(string userName,string flagActive)
        {
            DataSet ds = DataAccess.GetServerConfigList(userName,flagActive);
            List<ServerInfo> lst = new List<ServerInfo>();

            if (Data.HasData(ds))
            {
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    lst.Add(new ServerInfo(item));
                }
            }

            return lst;
        }

        public static DataSet GetserverListByType(string userName ,ServerType sType)
        {
            return DataAccess.GetServerConfigListByType(userName, sType);
        }

        private ServerInfo()
        { }


        public ServerInfo(string userName) //For new server
        {
            this._isNew = true;
            
            this._createBy = userName;
            this._createDate = DateTime.Now;
        }
      
        public ServerInfo(DataRow dr)
        {


            this._name = Data.NVL(dr["NAME"], "");
            this._serverHost = Data.NVL(dr["SERVER_HOST"], "");
            this._serverPort = Data.NVL(dr["SERVER_PORT"], "");
            this._authenUserName = Data.NVL(dr["AUTHEN_USERNAME"], "");
            this._authenPassword = Data.NVL(dr["AUTHEN_PASSWORD"], "");
            this._proxyRequire = bool.Parse(Data.NVL(dr["PROXY_REQUIRE"], "false"));
            this._proxyUsername = Data.NVL(dr["PROXY_USERNAME"], "");
            this._proxyPassword = Data.NVL(dr["PROXY_PASSWORD"], "");
            this._mailFrom = Data.NVL(dr["MAIL_FROM"], "");
            this._mailFromName = Data.NVL(dr["MAIL_FROM_NAME"], "");
            this._mailReplyTo = Data.NVL(dr["MAIL_REPLY_TO"], "");
            this._delayMS = Data.NVL(dr["DELAY_MS"], "");
            this._createBy = Data.NVL(dr["CREATE_BY"], "");
            this._createDate = (DateTime)dr["CREATE_DATE"];
            this._updateBy = Data.NVL(dr["UPD_BY"], "");
            this._updateDate = (DateTime)dr["UPD_DATE"];

            this._serverType = (ServerType)Enum.Parse(typeof(ServerType), Data.NVL(dr["SERVER_TYPE"], "DUMMY"));
            this._authenDomain = Data.NVL(dr["AUTHEN_DOMAIN"], "");


            this._isNew = false;
          
        }

        public ServerInfo(string name, string userName) //Load from database
        {
            DataSet ds = DataAccess.GetConfig(name);

            if (Data.HasData(ds))
            {
                DataRow dr = ds.Tables[0].Rows[0];

                this._name = Data.NVL(dr["NAME"], "");
                this._serverHost = Data.NVL(dr["SERVER_HOST"], "");
                this._serverPort = Data.NVL(dr["SERVER_PORT"], "");
                this._authenUserName = Data.NVL(dr["AUTHEN_USERNAME"], "");
                this._authenPassword = Data.NVL(dr["AUTHEN_PASSWORD"], "");
                this._proxyRequire = bool.Parse(Data.NVL(dr["PROXY_REQUIRE"], "false"));
                this._proxyUsername = Data.NVL(dr["PROXY_USERNAME"], "");
                this._proxyPassword = Data.NVL(dr["PROXY_PASSWORD"], "");
                this._mailFrom = Data.NVL(dr["MAIL_FROM"], "");
                this._mailFromName = Data.NVL(dr["MAIL_FROM_NAME"], "");
                this._mailReplyTo = Data.NVL(dr["MAIL_REPLY_TO"], "");
                this._delayMS = Data.NVL(dr["DELAY_MS"], "");
                this._createBy = Data.NVL(dr["CREATE_BY"], "");
                this._createDate = Data.NVL(dr["CREATE_DATE"],DateTime.MinValue);
                this._updateBy = Data.NVL(dr["UPD_BY"], "");
                this._updateDate = Data.NVL(dr["UPD_DATE"],DateTime.MinValue);

                this._serverType = (ServerType)Enum.Parse(typeof(ServerType), Data.NVL(dr["SERVER_TYPE"], "DUMMY"));
                this._authenDomain = Data.NVL(dr["AUTHEN_DOMAIN"], "");

                this._proxyAddress = Data.NVL(dr["PROXY_ADDRESS"], "");
                this._proxyPort = Data.NVL(dr["PROXY_PORT"],"");
                this._proxyDomain = Data.NVL(dr["PROXY_DOMAIN"], "");

                this._flagActive = Data.NVL(dr["FLAG_ACTIVE"], "N");


                this._isNew = false;

            }
        }


        public bool Save(string userName)
        {
            string result = "";
            this._updateBy = userName;
            this._updateDate = DateTime.Now;

            if (this._isNew) //Insert 
            {

                result = DataAccess.InsertServer(this._name, this._serverHost, this.ServerPort, this.AuthenUserName, this.AuthenPassword
                                            , this._proxyRequire.ToString(), this._proxyUsername, this._proxyPassword, this._mailFrom
                                            , this._mailFromName, this._mailReplyTo, this.DelayMS, this.CreateBy, this.CreateDate
                                            , this._updateBy, this._updateDate,this._serverType.ToString(),this._authenDomain
                                            ,this.ProxyAddress, this.ProxyPort,this.ProxyDomain, this._flagActive);
                this._isNew = false;
            }
            else //Update
            {

                result = DataAccess.UpdateServer(this._name, this._serverHost, this.ServerPort, this.AuthenUserName, this.AuthenPassword
                                            , this._proxyRequire.ToString(), this._proxyUsername, this._proxyPassword, this._mailFrom
                                            , this._mailFromName, this._mailReplyTo, this.DelayMS, this._updateBy, this._updateDate
                                            , this._serverType.ToString(), this._authenDomain
                                            , this.ProxyAddress, this.ProxyPort, this.ProxyDomain, this._flagActive);
            }

            if (result == "COMPLETE")
            {
                return true;
            }
            else
            {
                throw new Exception(result);
            }
        }




        private bool _isNew;

        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private string _serverHost;

        public string ServerHost
        {
            get { return _serverHost; }
            set { _serverHost = value; }
        }
        private string _serverPort;

        public string ServerPort
        {
            get { return _serverPort; }
            set { _serverPort = value; }
        }
        private string _authenDomain;

        public string AuthenDomain
        {
            get { return _authenDomain; }
            set { _authenDomain = value; }
        }
        private string _authenUserName;

        public string AuthenUserName
        {
            get { return _authenUserName; }
            set { _authenUserName = value; }
        }
        private string _authenPassword;

        public string AuthenPassword
        {
            get { return _authenPassword; }
            set { _authenPassword = value; }
        }
        private bool _proxyRequire;

        public bool ProxyRequire
        {
            get { return _proxyRequire; }
            set { _proxyRequire = value; }
        }
        private string _proxyUsername;

        public string ProxyUsername
        {
            get { return _proxyUsername; }
            set { _proxyUsername = value; }
        }

        private string _proxyPassword;

        public string ProxyPassword
        {
            get { return _proxyPassword; }
            set { _proxyPassword = value; }
        }

        private string _proxyAddress;

        public string ProxyAddress
        {
            get { return _proxyAddress; }
            set { _proxyAddress = value; }
        }

        private string _proxyPort;

        public string ProxyPort
        {
            get { return _proxyPort; }
            set { _proxyPort = value; }
        }

        private string _proxyDomain;

        public string ProxyDomain
        {
            get { return _proxyDomain; }
            set { _proxyDomain = value; }
        }

       


        
        private string _mailFrom;

        public string MailFrom
        {
            get { return _mailFrom; }
            set { _mailFrom = value; }
        }
        private string _mailFromName;

        public string MailFromName
        {
            get { return _mailFromName; }
            set { _mailFromName = value; }
        }
        private string _mailReplyTo;

        public string MailReplyTo
        {
            get { return _mailReplyTo; }
            set { _mailReplyTo = value; }
        }
        private string _delayMS;

        public string DelayMS
        {
            get { return _delayMS; }
            set { _delayMS = value; }
        }
        private string _createBy;

        public string CreateBy
        {
            get { return _createBy; }
            set { _createBy = value; }
        }
        private DateTime _createDate;

        public DateTime CreateDate
        {
            get { return _createDate; }
            set { _createDate = value; }
        }
        private string _updateBy;

        public string UpdateBy
        {
            get { return _updateBy; }
            set { _updateBy = value; }
        }
        private DateTime _updateDate;

        public DateTime UpdateDate
        {
            get { return _updateDate; }
            set { _updateDate = value; }
        }
        private ServerType _serverType;

        public ServerType ServerType1
        {
            get { return _serverType; }
            set { _serverType = value; }
        }


        private string _flagActive;
        public bool isActive
        {
            get { return _flagActive == "Y"; }
            set { _flagActive = value ? "Y" : "N"; }
        }

    }
}
