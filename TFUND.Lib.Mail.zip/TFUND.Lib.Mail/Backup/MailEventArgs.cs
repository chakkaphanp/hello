﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TFund.Lib.Mail
{
    
    public delegate void MailFinishEventHandler(object sender,MailEventArgs e);
    public delegate void MailCompleteEventHandler(object sender,MailEventArgs e);
    public delegate void MailErrorEventHandler(object sender,MailEventArgs e); 

    public class MailEventArgs : EventArgs
    {

        private string _mailContent;

        public string MailContent
        {
            get { return _mailContent; }
            set { _mailContent = value; }
        }


        private DateTime _eventTime;

        public DateTime EventTime
        {
            get { return _eventTime; }
            set { _eventTime = value; }
        }
        private string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        private string _jobid;

        public string JobID
        {
            get { return _jobid; }
            set { _jobid = value; }
        }
        private string _itemid;

        public string ItemID
        {
            get { return _itemid; }
            set { _itemid = value; }
        }
        private string _result;

        public string Result
        {
            get { return _result; }
            set { _result = value; }
        }

        private int _totalItem;

        public int TotalItemCount
        {
            get { return _totalItem; }
            set { _totalItem = value; }
        }
        private int _sentItem;

        public int SentItemCount
        {
            get { return _sentItem; }
            set { _sentItem = value; }
        }
        private int _errorItem;

        public int ErrorItemCount
        {
            get { return _errorItem; }
            set { _errorItem = value; }
        }




    }
}
