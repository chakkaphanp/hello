﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Exchange.WebServices.Data;

using System.Net.Mail;
using System.Text.RegularExpressions;

namespace TFund.Lib.Mail
{
    public class Util
    {

        public static  EmailAddress GetEmailAddress(MailAddress addr)
        {
            EmailAddress result = new EmailAddress(addr.DisplayName.Equals(string.Empty) ? addr.Address : addr.DisplayName
                , addr.Address);
            return result;
        }

                
        public static bool CheckEmailFormat(string emailString)
        {
            //Email address: RFC 5322 Format 
            bool isEmail = Regex.IsMatch(emailString, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            return isEmail;
        }

    }
}
