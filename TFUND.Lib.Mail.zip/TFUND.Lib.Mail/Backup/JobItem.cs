﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using System.Net.Mail;

using TFund.Lib.Util;


namespace TFund.Lib.Mail
{
    public class JobItem
    {

        public enum JobItemStatus
        {
            READY,
            SENT,
            ERROR,
            CANCEL,
            DUPLICATE,
            INVALID,
            REJECT,
            UNSUBSCRIBE
        }


        private string _userName;

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        private string _jobID;

        public string JobID
        {
            get { return _jobID; }
            set { _jobID = value; this._itemData.Rows[0]["JOB_ID"] = value ; }
        }
        private string _itemID;

        public string ItemID
        {
            get { return _itemID; }
            set { _itemID = value; }
        }

        private string _mailTo;
        public string MailTo
        {
            get { return _mailTo; }
            set { _mailTo = value; }
        }

        public MailAddress _MailToAddress
        {
            get
            {
                if (Data.HasData(this._mailTo))
                {
                    return new MailAddress(this._mailTo);
                }
                return null;
            }
        }

        public MailAddressCollection MailToAddresses
        {
            get
            {
                MailAddressCollection ml = new MailAddressCollection();                
                if (Data.HasData(this._mailTo))
                {
                    ml.Add(this._mailTo);
                }
                return ml;
            }
        }

        private string _cisNo;
        public string CisNo
        {
            get { return _cisNo; }
            set { _cisNo = value; }
        }
        private string _refNo;

        public string RefNo
        {
            get { return _refNo; }
            set { _refNo = value; }
        }
        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private string _surname;

        public string Surname
        {
            get { return _surname; }
            set { _surname = value; }
        }


        private DataTable _itemData;
        public DataTable ItemData
        {
            get { return _itemData; }
            set { _itemData = value; }
        }

        private JobItemStatus _status = JobItemStatus.READY;

        public JobItemStatus Status
        {
            get { return _status; }
            set { _status = value; }
        }
        

        public JobItem(string jobID,string itemID)
        {

        }
        
        public JobItem(DataRow dr, DataTable dtSchema,string userName)
        {
            init(dr,dtSchema,userName);
        }

             
        private void init(DataRow dr,DataTable dtSchema,string userName)
        {
            if (!Data.HasData(dr["MAIL_TO"]))
            {
                throw new DataException("No recipient address.");
            }
            this._itemData = dtSchema.Clone();
            this._itemData.ImportRow(dr);
            this._itemData.AcceptChanges();

            this._jobID = this.GetData("JOB_ID");
            this._itemID = this.GetData("ITEM_ID");

            this._cisNo = Data.NVL(dr["CIS_NO"], "");
            this._refNo = Data.NVL(dr["REF_NO"],"");
            this._firstName = Data.NVL(dr["FIRST_NAME"],"");
            this._name = Data.NVL(dr["NAME"],"");
            this._surname = Data.NVL(dr["SURNAME"],"");

            this._mailTo = dr["MAIL_TO"].ToString();


            this._status = (JobItemStatus)Enum.Parse(typeof(JobItemStatus),Data.NVL(dr["STATUS"],""));

            

            this._userName = userName;
        }

        public string GetData(string dataName)
        {
            return Data.GetFirstValue(this._itemData, dataName); 
        }

        public string[] GetDataName()
        {
            if (Data.HasData(this._itemData))
            {
                string[] list = (from dc in this._itemData.Columns.Cast<DataColumn>()
                            select dc.ColumnName).ToArray();

                return list;
            }

            return null;
        }
        
        public void SetStatus()
        {
            string result = DataAccess.SetJobItemStatus(this.JobID, this.ItemID, this.Status,this._userName);

        }


        public bool Save()
        {

            string itemId = DataAccess.InsertJobItem(Convert.ToInt32(this._jobID), this.MailTo, this.CisNo, this.RefNo, this.FirstName, this.Name,
                                     this.Surname, this.GetData("TEXT01"), this.GetData("TEXT02"), this.GetData("TEXT03"),
                                     this.GetData("TEXT04"), this.GetData("TEXT05"), this.GetData("TEXT06"), this.GetData("TEXT07"),
                                     this.GetData("TEXT08"), this.GetData("TEXT09"), this.GetData("TEXT10"), this.GetData("TEXT11"),
                                     this.GetData("TEXT12"), this.GetData("TEXT13"), this.GetData("TEXT14"), this.GetData("TEXT15"),
                                     this.GetData("TEXT16"), this.GetData("TEXT17"), this.GetData("FILE01"), this.GetData("FILE02"),
                                     this.GetData("FILE03"), this.GetData("FILE04"), this.GetData("FILE05"), this.Status.ToString(),
                                     this.UserName, DateTime.Now, this.UserName, DateTime.Now);
            int id;
            bool result = int.TryParse(itemId,out id);
            if (result)
            {
                this.ItemID = id.ToString();
            }

            return result;

        }

    }
}
