﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace TFund.Lib.Mail
{



    public interface ISender
    {
        string SendMail(Email msg);
        string SendSimpleMail(string mailTo, string subject, string body);
        MailAddress GetSenderAddress();
        MailAddress GetReplyToAddress();
        int GetDelayMS();
       

    }
}
