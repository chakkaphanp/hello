﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Net.Mail;
using System.Data;

using TFund.Lib.Util;
using TFUND.DB.Oracle;
using System.Data.OracleClient;


namespace TFund.Lib.Mail
{
    /// <summary>
    /// Summary description for EmailSender
    /// </summary>
    public class SMTPSender :ISender
    {
        /*
         Current mail hose as of 06/07/2016 ==> 10.180.193.17     
         *** 10.190.194.21 IRON Port DR for External only 
         *** 10.180.193.17 Symantec SMTP Gateway for Internal + External 
         */

        private string _name;
        private int _delay_ms = 900;


        private string _mailHost;
        private int _mailPort;

        
        private string _authUsername;
        private string _authPassword;
        private string _authDomain;

        private bool _proxyRequire;

        private string _mailFrom;
        private string _mailDisplayName;
        private string _mailReplyTo;


        private MailAddress _mailFromAddress;
        private MailAddress _mailReplyToAddress;


        private SmtpClient _smtp;

        public SMTPSender(string name)
        {
            DataSet ds = DataAccess.GetConfig(name);

            if (Data.HasData(ds))
            {
                init(ds.Tables[0]);
            }
            else
            {
                throw new DataException(string.Format("No configuration name ==> {0}" , name));
            }
            
        }

        public SMTPSender(DataTable dt) 
        {
            init(dt);
        }

        public SMTPSender(string host, int port, string username, string password, string domain, string mailFrom, string mailDisplayName, string mailReplyTo)
        {
            init(host, port, username, password, domain, mailFrom, mailDisplayName, mailReplyTo );
        }


        private void init(DataTable dt)
        {
            if (TFund.Lib.Util.Data.HasData(dt))
            {
                /*
                 NAME, SERVER_HOST,SERVER_PORT,AUTHEN_USERNAME,AUTHEN_PASSWORD,AUTHEN_DOMAIN
                 * ,PROXY_REQUIRE,PROXY_USERNAME,PROXY_PASSWORD
                 * ,MAIL_FROM,MAIL_FROM_NAME,MAIL_REPLY_TO
                 * ,DELAY_MS 
                 */

                DataRow dr = dt.Rows[0];

                this._name = dr["NAME"].ToString();
                if (!TFund.Lib.Util.Data.HasData(dr["SERVER_HOST"]))
                {
                    throw new ArgumentException("Please set SERVER_HOST for this configuration.");
                }

                this._mailHost = dr["SERVER_HOST"].ToString();
                if (TFund.Lib.Util.Data.HasData(dr["SERVER_PORT"]))
                {
                    this._mailPort = Convert.ToInt32(dr["SERVER_PORT"]);
                }

                this._authUsername = Data.NVL(dr["AUTHEN_USERNAME"], "");
                this._authPassword = Data.NVL(dr["AUTHEN_PASSWORD"], "");
                this._authDomain = Data.NVL(dr["AUTHEN_DOMAIN"], "");

                if (!Data.HasData(dr["MAIL_FROM"]))
                {
                    throw new ArgumentException("Please set MAIL_FROM for this configuration.");
                }
                this._mailFrom = dr["MAIL_FROM"].ToString();

                this._mailDisplayName = Data.NVL(dr["MAIL_FROM_NAME"], this._mailFrom);
                this._mailReplyTo = Data.NVL(dr["MAIL_REPLY_TO"], this._mailFrom);                

                this._proxyRequire = Convert.ToBoolean(Data.NVL(dr["PROXY_REQUIRE"],"False"));               
                if (this._proxyRequire)
                {
                    throw new MissingFieldException("Sorry, Proxy is not support in SMTPSerder mode. Please check CIS.EMSMSERVER setting.");
                }




                this._delay_ms = Convert.ToInt32(Data.NVL(dr["DELAY_MS"], "900"));


                init(this._mailHost, this._mailPort, this._authUsername, this._authPassword, this._authDomain
                            , this._mailFrom, this._mailDisplayName, this._mailReplyTo );

            }
            else
            {
                throw new DataException("Configuration not found.");
            }

        }

        private void init(string host, int port, string username, string password, string domain , string mailFrom, string mailDisplayName, string mailReplyTo)
        {
            _smtp = new SmtpClient();
            _smtp.Host = host;
            _smtp.Port = port;

            this._mailHost = host;
            this._mailPort = port;


            if (Data.HasData(mailDisplayName))
            {
                _mailFromAddress = new MailAddress(mailFrom, mailDisplayName);
            }
            else
            {
                _mailFromAddress = new MailAddress(mailFrom);
            }

            if (!mailReplyTo.Equals(string.Empty))
            {
                _mailReplyToAddress = new MailAddress(mailReplyTo);
            }
            else
            {
                _mailReplyToAddress = _mailFromAddress;
            }

            if (!username.Equals(string.Empty) && !password.Equals(string.Empty))
            {
               
                this._authUsername = username;
                this._authPassword = password;

                System.Net.NetworkCredential cred = new System.Net.NetworkCredential(username, password);
                _smtp.Credentials = cred;
            }

           
        }

        /// <summary>
        /// Send a simple text message to a single recipient. 
        /// </summary>
        /// <param name="mailTo"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <returns>0 if no error</returns>
        public string SendSimpleMail(string mailTo, string subject, string body)
        {
            string result = "-1";
            try
            {
                MailAddress mailToAddress = new MailAddress(mailTo);

                MailMessage msg = new MailMessage();
                msg.Body = body;
                msg.Subject = subject;
                msg.From = _mailFromAddress;
                msg.To.Add(mailToAddress);
                if (_mailReplyToAddress != null)
                {
                    msg.ReplyTo = _mailReplyToAddress;
                }
                _smtp.Send(msg);
                result = "COMPLETE";
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }

            return result;
        }

        public MailAddress GetSenderAddress()
        {
            return this._mailFromAddress;
        }

        public MailAddress GetReplyToAddress()
        {
            return this._mailReplyToAddress != null ? this._mailReplyToAddress : this._mailFromAddress;
        }

        public int GetDelayMS()
        {
            return this._delay_ms;
        }

        public string SendMail(Email msg)
        {
            try
            {
                _smtp.Send(msg.GetMailMessage());                    
            }
            catch (Exception ex)
            {
#if DEBUG
                return ex.ToString();
#else
                return ex.Message;
#endif
            }

            return "COMPLETE";
        }

        
    }
}