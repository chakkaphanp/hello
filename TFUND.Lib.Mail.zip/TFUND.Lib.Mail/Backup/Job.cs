﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net.Mail;
using System.Data;
using TFund.Lib.Util;
using System.IO;

namespace TFund.Lib.Mail
{
    public class Job
    {

        public enum JobStatus
        {
            ACTIVE,
            INACTIVE,
            RUNNING,
            COMPLETE,
            PAUSE,
            UNKNOWN
        }

        //public static GetJobList()

        private bool _isNew;

        private List<JobItem> _items;
        private ISender _server;
        private MailTemplate _template;
        private JobStatus _status;

        public JobStatus Status
        {
            get { return _status; }
            set { _status = value; }
        }
        private string _jobID;

        public string JobID
        {
            get { return _jobID; }
            set { _jobID = value; }
        }
        private string _templateName;

        public string TemplateName
        {
            get { return _templateName; }
            set { _templateName = value; }
        }
        private string _serverName;

        public string ServerName
        {
            get { return _serverName; }
            set { _serverName = value; }
        }
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _updBy;

        public string UpdBy
        {
            get { return _updBy; }
            set { _updBy = value; }
        }
        private string _createBy;

        public string CreateBy
        {
            get { return _createBy; }
            set { _createBy = value; }
        }
        private DateTime _updDate;

        public DateTime UpdDate
        {
            get { return _updDate; }
            set { _updDate = value; }
        }
        private DateTime _createDate;

        public DateTime CreateDate
        {
            get { return _createDate; }
            set { _createDate = value; }
        }

        private string _crmMKTCode;

        public string CrmMKTCode
        {
            get { return _crmMKTCode; }
            set { _crmMKTCode = value; }
        }
        private string _crmActionCode;

        public string CrmActionCode
        {
            get { return _crmActionCode; }
            set { _crmActionCode = value; }
        }
        private string _crmSystemCode;

        public string CrmSystemCode
        {
            get { return _crmSystemCode; }
            set { _crmSystemCode = value; }
        }
        private string _crmDescription;

        public string CrmDescription
        {
            get { return _crmDescription; }
            set { _crmDescription = value; }
        }


        private string _cc;

        public string Cc
        {
            get { return _cc; }
            set { _cc = value; }
        } 


        private string _userName;

        private bool _keepRunning = true;

        private Job() { }


        public Job(string user)
        {
            this._isNew = true;

            this._createBy = user;
            this._createDate = DateTime.Now;

        }

        /// <summary>
        /// For data administrator only, This don't load JobItems.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="username"></param>
        public Job(int id, string userName)
        {
            DataSet dsJob = DataAccess.GetJob(id.ToString(),null);
            if (Data.HasData(dsJob))
            {
                this._jobID = id.ToString();
                this._serverName = Data.GetFirstValue(dsJob, "SERVER");
                this._templateName = Data.GetFirstValue(dsJob, "TEMPLATE");
                this._status = (JobStatus)Enum.Parse(typeof(JobStatus), Data.GetFirstValue(dsJob, "STATUS"));
                this._updBy = Data.GetFirstValue(dsJob, "UPD_BY");
                this._updDate = (DateTime)Data.GetFirstValueObj(dsJob, "UPD_DATE");
                this._createBy = Data.GetFirstValue(dsJob, "CREATE_BY");
                this._createDate = (DateTime)Data.GetFirstValueObj(dsJob, "CREATE_DATE");
                this._name = Data.GetFirstValue(dsJob, "NAME");

                this._crmSystemCode = Data.GetFirstValue(dsJob, "CRM_SYSTEM_CODE");
                this._crmMKTCode = Data.GetFirstValue(dsJob, "CRM_MKT_CODE");
                this._crmActionCode = Data.GetFirstValue(dsJob, "CRM_ACTION_CODE");
                this._crmDescription = Data.GetFirstValue(dsJob, "CRM_DESCRIPTION");

                this._cc = Data.GetFirstValue(dsJob, "CC_TO");

                //this._items = LoadJobItems();
                //this._template = new MailTemplate(this._templateName, this._userName, MailTemplate.MailTemplateStatus.ACTIVE);
                //this._server = GetSender(this._serverName);

                this._userName = userName;

                this._isNew = false;

            }
            else
            {
                throw new DataException(string.Format("No active job id={0}", id));
            }
        }

        
        /// <summary>
        /// Get Job with spectified ID and Load all item with specified ItemStatus
        /// </summary>
        /// <param name="id">Job Id</param>
        /// <param name="userName">Current log-on username(Will be use to update UPD_BY,CREATE_BY in all table)</param>
        /// <param name="itemStatus">Item to be load.</param>
        public Job(string id, string userName, JobItem.JobItemStatus? itemStatus)
        {
            DataSet dsJob = DataAccess.GetJob(id, null);
            if (Data.HasData(dsJob))
            {
                this._jobID = id;
                this._serverName = Data.GetFirstValue(dsJob, "SERVER");
                this._templateName = Data.GetFirstValue(dsJob, "TEMPLATE");
                this._status = (JobStatus)Enum.Parse(typeof(JobStatus), Data.GetFirstValue(dsJob, "STATUS"));
                this._updBy = Data.GetFirstValue(dsJob, "UPD_BY");
                this._updDate = (DateTime)Data.GetFirstValueObj(dsJob, "UPD_DATE");
                this._createBy = Data.GetFirstValue(dsJob, "CREATE_BY");
                this._createDate = (DateTime)Data.GetFirstValueObj(dsJob, "CREATE_DATE");
                this._name = Data.GetFirstValue(dsJob, "NAME");

                this._crmSystemCode = Data.GetFirstValue(dsJob, "CRM_SYSTEM_CODE");
                this._crmMKTCode = Data.GetFirstValue(dsJob, "CRM_MKT_CODE");
                this._crmActionCode = Data.GetFirstValue(dsJob, "CRM_ACTION_CODE");
                this._crmDescription = Data.GetFirstValue(dsJob, "CRM_DESCRIPTION");

                this._cc = Data.GetFirstValue(dsJob, "CC_TO");

                this._items = LoadJobItems(itemStatus);
                

               
                
                this._template = new MailTemplate(this._templateName, this._userName, MailTemplate.MailTemplateStatus.ACTIVE);
                this._server = GetSender(this._serverName);

                this._userName = userName;

                this._isNew = false;
            }
            else
            {
                throw new DataException(string.Format("No active job id={0}", id));
            }
        }

        /// <summary>
        /// This constructor will load all items for all status 
        /// </summary>
        /// <param name="id">Job Id (auto increment from oracle)</param>
        /// <param name="userName">Current log-on username(Will be use to update UPD_BY,CREATE_BY in all table)</param>
        public Job(string id,string userName) : this(id,userName,null)
        {
            
        }

        public static DataSet GetJobDataList(int pageNum, int perPage, string name, string status, string username)
        {
            return DataAccess.GetJobDataList(pageNum, perPage, name, status, username);
        }
        
      
        public string SetStatus(JobStatus status)
        {
            string result = DataAccess.SetJobStatus(this._jobID, status,this._userName); 
            return result;
        }

        public JobStatus CheckStatus()
        {
            string result = DataAccess.GetJobStatus(this._jobID);
            return (JobStatus)Enum.Parse(typeof(JobStatus),result);            
        }



        private List<JobItem> LoadJobItems()
        {
            

            DataSet dsItems = DataAccess.GetJobItems(this._jobID);
            List<JobItem> result = new List<JobItem>();
            
            if (Data.HasData(dsItems))
            {
                DataTable dtSchema = dsItems.Tables[0].Clone(); 
                foreach (DataRow item in dsItems.Tables[0].Rows)
                {
                    result.Add(new JobItem(item,dtSchema,this._userName));
                }
            }
            else {
                //throw new DataException("This job has no JobItem.");
            }

            return result;
        }


        private List<JobItem> LoadJobItems(JobItem.JobItemStatus? status)
        {
            string strStatus = "";
            if (status.HasValue)
            {
                strStatus = status.ToString();
            }


            //DataSet dsItems = DataAccess.GetJobItems(this._jobID);
            DataSet dsItems = DataAccess.GetJobItemsByStatus(this._jobID, strStatus);
            List<JobItem> result = new List<JobItem>();

            if (Data.HasData(dsItems))
            {
                DataTable dtSchema = dsItems.Tables[0].Clone();
                foreach (DataRow item in dsItems.Tables[0].Rows)
                {
                    result.Add(new JobItem(item, dtSchema, this._userName));
                }
            }
            else
            {
                //throw new DataException("This job has no JobItem.");
            }

            return result;


        }




        public static DataSet GetJobSummary(string jobid)
        {
            return DataAccess.GetJobItemSummary(jobid); 
        }

        public static string GetJobSummaryString(string jobid)
        {
            DataSet ds = DataAccess.GetJobItemSummary(jobid);
            StringBuilder sb = new StringBuilder();
            if (TFund.Lib.Util.Data.HasData(ds))
            {
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    string status = item["STATUS"].ToString() ;
                    string count = item["CNT"].ToString();
                    sb.AppendLine(string.Format("{0} : {1}", status, count)); 
                }
            }


            return sb.ToString();

        }


        public static ISender LoadSender(string configName)
        {
            return GetSender(configName);
        }

        private static ISender GetSender(string configName)
        {
            DataSet dsConfig = DataAccess.GetConfig(configName);

            if (Data.HasData(dsConfig))
            {

                string strConfigType = Data.GetFirstValue(dsConfig, "SERVER_TYPE");
                ServerInfo.ServerType sType = (ServerInfo.ServerType)Enum.Parse(typeof(ServerInfo.ServerType), strConfigType);

                switch (sType)
                {
                    case ServerInfo.ServerType.SMTP:
                        return new SMTPSender(dsConfig.Tables[0]);
                    case ServerInfo.ServerType.EWS:
                        return new EWSSender(dsConfig.Tables[0]);
                    case ServerInfo.ServerType.DUMMY:
                        return new DUMMYSender();
                    case ServerInfo.ServerType.NipaAPI:
                        return new NipaAPISender(dsConfig.Tables[0]);                    
                    default:
                        break;
                }
            }
            else
            {
                throw new DataException(string.Format( "No config name ==> {0}", configName));
            }

            return null;
        }


        public static string SetJobStatus(string jobid, JobStatus status,string mktCode)
        {
            return DataAccess.SetJobStatus(jobid,status,mktCode);  
        }

        public string PauseJob()
        {
           return this.SetStatus(JobStatus.PAUSE); 
        }

        public JobStatus GetStatus()
        {
           string status = DataAccess.GetJobStatus(this.JobID);

           this.Status = (JobStatus)Enum.Parse(typeof(JobStatus), status);
           return this.Status;
        }
         

        public string StartJob()
        {
            this._status = JobStatus.RUNNING;
            SetStatus(this._status);

            
            int totalItem = this._items.Count;
            int sentItemCount = 0;
            int errorItemCount = 0;
            int loopNo = 0;

            try
            {

                foreach (var item in this._items)
                {
                    loopNo++;
                    if (this._keepRunning)
                    {
                        if (item.Status == JobItem.JobItemStatus.READY || item.Status == JobItem.JobItemStatus.ERROR)
                        {
                            if (loopNo % 100 == 0)
                            {
                                JobStatus status = this.GetStatus();
                                if( !(status == JobStatus.RUNNING || status == JobStatus.ACTIVE))
                                {
                                    return "";
                                }
                            }


                            Email msg = this._template.GetMessage(item);
                            msg.Sender = this._server.GetSenderAddress();
                            msg.ReplyTo = this._server.GetReplyToAddress();


                            if (this.Cc != string.Empty)
                            {
                                msg.CC.Add(this.Cc);
                            }


                            string result = this._server.SendMail(msg);

                            MailEventArgs ev = new MailEventArgs();
                            ev.EventTime = DateTime.Now;
                            ev.Email = item.MailTo;
                            ev.ItemID = item.ItemID;
                            ev.JobID = item.JobID;
                            ev.Result = result;
                            ev.TotalItemCount = totalItem;

                            if (result == "COMPLETE")
                            {
                                //TODO: Update item status + sent date & insert CRM & insert log 
                                item.Status = JobItem.JobItemStatus.SENT;
                                item.SetStatus(); 
                                ev.MailContent = msg.Body; 
                                ev.SentItemCount = ++sentItemCount;
                                OnMailCompleteEvent(ev);
                                if (!this._crmMKTCode.Equals(string.Empty))
                                {
                                    DataAccess.InsertCRM(item.CisNo, "", this._crmActionCode, string.Format("[SUCCESS][{0}]", item.MailTo) + this._crmDescription, DateTime.Now, this._crmMKTCode);
                                }
                            }
                            else
                            {
                                //TODO: Update item status + sent date  & insert CRM & insert log
                                item.Status = JobItem.JobItemStatus.ERROR;
                                item.SetStatus();
                                
                                ev.ErrorItemCount = ++errorItemCount;
                                OnMailErrorEvent(ev);
                                if (!this._crmMKTCode.Equals(string.Empty))
                                {
                                    DataAccess.InsertCRM(item.CisNo, "", this._crmActionCode, string.Format("[FAILED][{0}]", item.MailTo) + this._crmDescription, DateTime.Now, this._crmMKTCode);
                                }
                                TFund.Lib.Util.Log.WriteLog(string.Format("Error send mail to {0} ==> {1}",item.MailTo,result));

                                //TFund.Lib.Util.Log.WriteLog(string.Format("Error send mail to {0} ==> {1}",item.MailTo, ev.Result));
                            }

                            //TFund.Lib.Util.Log.WriteLog(string.Format("Before delay {1} {0:dd/MM/yyyy hh:mm:ss.fff}",DateTime.Now,this._server.GetDelayMS())); 

                            System.Threading.Thread.Sleep(this._server.GetDelayMS());

                            //TFund.Lib.Util.Log.WriteLog(string.Format("After send mail {0:dd/MM/yyyy hh:mm:ss.fff}", DateTime.Now)); 

                        }
                        else
                        {
                            //TODO: Log data
                            MailEventArgs ev = new MailEventArgs();
                            ev.EventTime = DateTime.Now;
                            ev.Email = item.MailTo;
                            ev.ItemID = item.ItemID;
                            ev.JobID = item.JobID;
                            ev.Result = "Item already sent or has been cancelled.";
                            ev.TotalItemCount = totalItem;
                            ev.ErrorItemCount = ++errorItemCount;
                            OnMailErrorEvent(ev);
                        }


                    }
                    else {
                    
                       //End Job 
                        this._keepRunning = true;
                        this.SetStatus(JobStatus.ACTIVE);
                    }
                  
                }
            }
            catch (Exception ex)
            {
                this.SetStatus(JobStatus.ACTIVE);
                string errm;
#if DEBUG
                errm = ex.ToString();
#else
                errm = ex.Message;
#endif

                return errm; 
            } 

            MailEventArgs evf = new MailEventArgs();
            evf.EventTime = DateTime.Now;
            evf.TotalItemCount = totalItem;
            evf.SentItemCount = sentItemCount;
            evf.ErrorItemCount = errorItemCount;
            OnMailFinish(evf);

            this._status = JobStatus.COMPLETE;
            SetStatus(this._status);
            return "";
        }

        public void StopJob()
        {
            this._keepRunning = false;
        }
               

        public bool ImportJobItem(DataTable dtItem, bool checkDuplcate, string updBy)
        {
            return this.importJobItem(dtItem, checkDuplcate, updBy);
        }

        private bool importJobItem(DataTable dtItem, bool checkDuplicate, string userName)
        {
            DataTable schema = new XSD.dsJobItem.dtJobItemDataTable();

            List<string> lstEmail = new List<string>();
            List<string> lstCISEMail = new List<string>();

            foreach (DataRow item in dtItem.Rows)
            {
                JobItem ji = new JobItem(item, schema, userName);
                ji.JobID = this._jobID;

                if (Util.CheckEmailFormat(ji.MailTo))
                {
                    ji.Status = JobItem.JobItemStatus.READY;
                }
                else
                {
                    ji.Status = JobItem.JobItemStatus.INVALID;
                }

                if (!lstCISEMail.Contains(ji.CisNo + ji.MailTo))
                {
                    lstCISEMail.Add(ji.CisNo + ji.MailTo);
                }
                else
                {
                    ji.Status = JobItem.JobItemStatus.DUPLICATE;
                }

                if (checkDuplicate)
                {
                    if (!lstEmail.Contains(ji.MailTo))
                    {
                        lstEmail.Add(ji.MailTo);

                    }
                    else
                    {
                        ji.Status = JobItem.JobItemStatus.DUPLICATE;
                    }
                }


                ji.Save();
            }

            DataAccess.CheckJobBounce(this._jobID);

            return true;
        }



        public bool ImportJobItemFromExcel(Stream stream, bool checkDuplicate, string userName)
        {
            DataTable dtItem = TFund.Lib.Util.Excel.ImportExcel(stream);
            return importJobItem(dtItem, checkDuplicate, userName);
        }
        

        public bool ImportJobItemFromCSV(string strFileContent,bool checkDuplicate,string userName)
        {
            DataTable dtItem = TFund.Lib.Util.Text.GetDataTableFromCSV(strFileContent, true);
            return importJobItem(dtItem, checkDuplicate, userName); 
        }

        public int Save(string user)
        {
            if (this._isNew)
            {
                this.UpdBy = this.CreateBy = user;
                this.UpdDate = this.CreateDate = DateTime.Now;

                string result = DataAccess.InsertJob(this.Name, this.Status.ToString(), this.CreateBy, this.CreateDate, this.UpdBy
                    , this.UpdDate, this.TemplateName, this.ServerName, this.CrmMKTCode, this.CrmActionCode, this.CrmDescription);


                int x = -1;
                if (int.TryParse(result, out x))
                {
                    this.JobID = x.ToString();
                    return x;
                }
                else
                {
                    throw new Exception(result);
                }
            }
            else
            { // Update status
                this.UpdBy = user;
                this.UpdDate = DateTime.Now;

                string result = DataAccess.UpdateJob( this.JobID, this.Name, this.Status.ToString(), this.UpdBy
                  , this.UpdDate, this.TemplateName, this.ServerName, this.CrmMKTCode, this.CrmActionCode, this.CrmDescription);

                if (result == "COMPLETE")
                {
                    return int.Parse(this.JobID);
                }
                else
                {
                    throw new Exception(result);
                }
            }
        }


        public static DataSet GetJobItemData(int pageNum, int perPage, string jobID, string mailTo, string cisNo, string refNo, string firstName, string name, string surname, string status)
        {
            return DataAccess.GetJobItemDataList(pageNum, perPage, jobID, mailTo, cisNo, refNo, firstName, name, surname, status);
        }

        #region Event
        public event MailFinishEventHandler MailFinishEvent;
        public event MailCompleteEventHandler MailCompleteEvent;
        public event MailErrorEventHandler MailErrorEvent;

        protected void OnMailFinish(MailEventArgs e)
        {
            if (MailFinishEvent != null)
            {
                MailFinishEvent(this, e);
            }
        }

        protected void OnMailCompleteEvent(MailEventArgs e)
        {
            if(MailCompleteEvent != null)
            MailCompleteEvent(this, e);
        }

        protected void OnMailErrorEvent(MailEventArgs e)
        {
            if(MailErrorEvent != null) 
            MailErrorEvent(this, e);
        }
        #endregion Event
    }
}
