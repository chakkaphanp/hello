﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Exchange.WebServices.Data;

using Microsoft.Exchange.WebServices;
using Microsoft.Exchange.WebServices.Autodiscover;
using System.Net.Mail;
using System.Data;
using TFund.Lib.Util;
using System.IO;

namespace TFund.Lib.Mail
{

    public class EWSSender : ISender
    {

       

        private string _name;
        private int _delay_ms = 900;


        private string _mailHost;      

        private string _authUsername;
        private string _authPassword;
        private string _authDomain;

        private string _mailFrom;
        private string _mailDisplayName;
        private string _mailReplyTo;
        //private string _mailCcTo;

        private MailAddress _mailFromAddress;
        private MailAddress _mailReplyToAddress;
        //private MailAddress _mailCcToAddress;

        private ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP1);



        public EWSSender(string name)
        {
            DataSet ds = DataAccess.GetConfig(name);

            if (Data.HasData(ds))
            {
                init(ds.Tables[0]);
            }
            else
            {
                throw new DataException(string.Format("No configuration name ==> {0}", name));
            }
        }


        public EWSSender(DataTable dt)
        {
            init(dt);
        }

        public EWSSender(string host, string username, string password, string domain, string mailFrom, string mailDisplayName, string mailReplyTo)
        {
            init( host,  username,  password,  domain,  mailFrom,  mailDisplayName,  mailReplyTo );
        }

        private void init(DataTable dt)
        { 
            if(Data.HasData(dt))
            {

                DataRow dr = dt.Rows[0];
                this._name = dr["NAME"].ToString();
                if (!TFund.Lib.Util.Data.HasData(dr["SERVER_HOST"]))
                {
                    throw new ArgumentException("Please set SERVER_HOST for this configuration.");
                }

                this._mailHost = dr["SERVER_HOST"].ToString();
              

                this._authUsername = Data.NVL(dr["AUTHEN_USERNAME"], "");
                this._authPassword = Data.NVL(dr["AUTHEN_PASSWORD"], "");
                this._authDomain = Data.NVL(dr["AUTHEN_DOMAIN"], "");

                if (!Data.HasData(dr["MAIL_FROM"]))
                {
                    throw new ArgumentException("Please set MAIL_FROM for this configuration.");
                }
                this._mailFrom = dr["MAIL_FROM"].ToString();

                this._mailDisplayName = Data.NVL(dr["MAIL_FROM_NAME"], this._mailFrom);
                this._mailReplyTo = Data.NVL(dr["MAIL_REPLY_TO"], this._mailFrom);

                this._delay_ms = Convert.ToInt32(Data.NVL(dr["DELAY_MS"], "900"));

                

                init(this._mailHost , this._authUsername, this._authPassword, this._authDomain
                            , this._mailFrom, this._mailDisplayName, this._mailReplyTo);


            }else{
                throw new DataException("Configuration not found.");
            }
        }

        private void init(string host, string username, string password, string domain, string mailFrom, string mailDisplayName, string mailReplyTo)
        {
            service.Url = new Uri(host);
            this._mailHost = host;

            _mailFromAddress = new MailAddress(mailFrom, mailDisplayName);

           

            if (!mailReplyTo.Equals(string.Empty))
            {
                _mailReplyToAddress = new MailAddress(mailReplyTo);
            }

            if (!username.Equals(string.Empty) && !password.Equals(string.Empty))
            {
                this._authUsername = username;
                this._authPassword = password;
                WebCredentials cred = new WebCredentials(username,password);
                if (!domain.Equals(string.Empty))
                {
                    cred = new WebCredentials(username, password, domain);
                }

                service.Credentials = cred;
               
            }
        }


        #region ISender Members

        public string SendSimpleMail(string mailTo, string subject, string body)
        {
            string result = "-1";
            try
            {
                MailAddress mailToAddress = new MailAddress(mailTo);
                EmailMessage msg = new EmailMessage(service);
                
                msg.Body = body;
                msg.Subject = subject;                
                msg.From = Util.GetEmailAddress(_mailFromAddress);
                msg.ToRecipients.Add(Util.GetEmailAddress(mailToAddress));
                if (_mailReplyToAddress != null)
                {
                    msg.ReplyTo.Add(Util.GetEmailAddress(_mailReplyToAddress));
                }
                msg.Send();
                result = "COMPLETE";
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }

            return result;
        }

        public MailAddress GetSenderAddress()
        {
            return this._mailFromAddress;
        }

        public MailAddress GetReplyToAddress()
        {
            return this._mailReplyToAddress;
        }

        public int GetDelayMS()
        {
            return this._delay_ms;
        }


        /// <summary>
        /// Return "COMPLETE" when no error otherwise return error message.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public string SendMail(Email msg)
        {

            try
            {
                EmailMessage ems = msg.GetEmailMessage(service);
                ems.Send();                
            }
            catch(Exception ex)
            {
                return ex.Message;
            }

            return "COMPLETE";
        }


        public List<BounceMail> GetUndelivery(int limit)
        {
            return GetUndelivery(limit, 3650);
        }

        public List<BounceMail> GetUndelivery(int limit, int backDate)
        {
            List<BounceMail> result = new List<BounceMail>();


            /* Start */
            int offset = 0;
            int pageSize = 50;
            bool more = true;
            ItemView view = new ItemView(pageSize, offset, OffsetBasePoint.Beginning);

            view.PropertySet = PropertySet.IdOnly;
            FindItemsResults<Item> findResults;
            List<Item> emails = new List<Item>();


            List<SearchFilter> searchFilterCollection = new List<SearchFilter>();

            SearchFilter sf = new SearchFilter.IsGreaterThan(ItemSchema.DateTimeCreated, DateTime.Now.AddDays(-backDate)); 

            while (more)
            {
                findResults = service.FindItems(WellKnownFolderName.Inbox,sf, view);
                foreach (var item in findResults.Items)
                {
                    emails.Add((EmailMessage)item);
                }
                more = findResults.MoreAvailable;
                
                if (more)
                {
                    view.Offset += pageSize;
                }
            }
            //Console.WriteLine(string.Format("Total item(s) : {0}", emails.Count));
            PropertySet properties = (BasePropertySet.FirstClassProperties); //A PropertySet with the explicit properties you want goes here
            //if we need to load MIMEContents
            //properties.Add(EmailMessageSchema.MimeContent); 
            service.LoadPropertiesForItems(emails, properties);

           

            List<ItemId> delItems = new List<ItemId>();
            int x = 0;
            foreach (EmailMessage item in emails)
            {
                
                //If we need to view MIMEContent
                //string emlFilename = @"D:\temp\bounce\" + x.ToString() + ".eml";
                //try
                //{
                //    if (item.MimeContent != null)
                //    {
                //        using (FileStream fs = new FileStream(emlFilename, FileMode.Create, FileAccess.Write))
                //        {
                //            fs.Write(item.MimeContent.Content, 0, item.MimeContent.Content.Length);
                //        }
                //    }
                //}
                //catch (Exception ex)
                //{

                //}

                x++;
                BounceMail bm = new BounceMail(item, "AUTO");
                bm.CheckedByAccount = this._mailFrom;
                result.Add(bm);
            }




            return result;
        }

      

        #endregion
    }
}
