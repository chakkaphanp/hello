﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OracleClient;
using TFUND.DB.Oracle;


namespace lib.TFUND.MStar
{
    public class Data_Access
    {
        public static DataSet GetMStarRPT()
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_MSTAR_RPT";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                // paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                // paramList.Add("P_ROW_NUM", rownum, OracleType.Number, 15, ParameterDirection.Input);

                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        public static string EditMStarRPT(string rptCode, string rptName, string status, string updBY, DateTime updDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_EDIT_MSTAR_RPT";

            try
            {
                /*
                 * P_RPT_CODE VARCHAR2, 
                 * P_RPT_NAME VARCHAR2, 
                 * P_STATUS VARCHAR2, 
                 * P_UPD_BY VARCHAR2, 
                 * P_UPD_DATE DATE , 
                 * O_RESULT OUT VARCHAR2
                 */
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_RPT_CODE", rptCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_RPT_NAME", rptName, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_STATUS", status, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", updBY, OracleType.VarChar, 30 , ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);               

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }



        /* PROCEDURE SP_INSERT_MSTAR_RPT(P_RPT_CODE VARCHAR2,P_RPT_NAME VARCHAR2, P_UPD_BY VARCHAR2, P_UPD_DATE DATE, O_RESULT OUT VARCHAR2)*/
        public static string InsertMStarRpt(string rptCode,string rptName,string updBy, DateTime updDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_INSERT_MSTAR_RPT";

            try
            {
                /*
                 * P_RPT_CODE VARCHAR2, 
                 * P_RPT_NAME VARCHAR2, 
                 * P_STATUS VARCHAR2, 
                 * P_UPD_BY VARCHAR2, 
                 * P_UPD_DATE DATE , 
                 * O_RESULT OUT VARCHAR2
                 */
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_RPT_CODE", rptCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_RPT_NAME", rptName, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        public static DataSet getMStarRPTFund(string rptCode)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_MSTAR_RPT_FUND";
            DataSet ds = new DataSet();
            try
            {
                
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_RPT_CODE", rptCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);

                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet getMStarRPTFundEX(string rptCode)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_MSTAR_RPT_FUND_EX";
            DataSet ds = new DataSet();
            try
            {

                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_RPT_CODE", rptCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);

                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        
        
        /*
        PROCEDURE SP_INSERT_MSTAR_RPT_FUND(P_RPT_CODE VARCHAR2, P_COMP_CODE VARCHAR2, P_FUND_CODE VARCHAR2, P_SORT_FUND VARCHAR2,P_UPD_BY VARCHAR2,P_UPD_DATE DATE, O_RESULT OUT VARCHAR2);
        */      
        public static string InsertMStarRptFund(string rptCode, string compCode, string fundCode,string sortFund, string updBy, DateTime updDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_INSERT_MSTAR_RPT_FUND";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_RPT_CODE", rptCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_COMP_CODE", compCode, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_FUND_CODE", fundCode, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_SORT_FUND", sortFund , OracleType.VarChar, 10, ParameterDirection.Input);                
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }



        public static string RemoveMStarRptFund(string rptCode, string compCode, string fundCode, string updBy, DateTime updDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_REMOVE_MSTAR_RPT_FUND";

            try
            {

                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_RPT_CODE", rptCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_COMP_CODE", compCode, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_FUND_CODE", fundCode, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }









        #region SERIESFUND 

        public static DataSet GetSeriesFundClass()
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_SERIES_FUND_CLASS";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                // paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                // paramList.Add("P_ROW_NUM", rownum, OracleType.Number, 15, ParameterDirection.Input);

                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        public static DataSet getSeriesFundByClass(string fundClass)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_SERIES_FUND_BY_CLASS";
            DataSet ds = new DataSet();
            try
            {

                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_CLASS", fundClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);

                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet getSeriesFundByClassEX(string fundClass)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_SERIES_FUND_BY_CLASS_EX";
            DataSet ds = new DataSet();
            try
            {

                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_CLASS", fundClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);

                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }
        /*
        PROCEDURE SP_INSERT_SERIES_FUND(P_COMP_CODE VARCHAR2, P_FUND_CODE VARCHAR2, P_CLASS VARCHAR2, P_UPD_BY VARCHAR2, P_UPD_DATE DATE, O_RESULT OUT VARCHAR2);
        */
      
        public static string InsertSeriesFund(string fundClass, string compCode, string fundCode, string updBy, DateTime updDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_INSERT_SERIES_FUND";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_CLASS", fundClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_COMP_CODE", compCode, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_FUND_CODE", fundCode, OracleType.VarChar, 100, ParameterDirection.Input);              
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }

        //PROCEDURE SP_REMOVE_SERIES_FUND(P_COMP_CODE VARCHAR2, P_FUND_CODE VARCHAR2, P_CLASS VARCHAR2, P_UPD_BY VARCHAR2, P_UPD_DATE DATE  ,O_RESULT OUT VARCHAR2); 
 
        public static string RemoveSeriesFund(string fundClass, string compCode, string fundCode, string updBy, DateTime updDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_REMOVE_SERIES_FUND";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_CLASS", fundClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_COMP_CODE", compCode, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_FUND_CODE", fundCode, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }
        #endregion SERIESFUND




        #region Performance Group
        public static DataSet getPerformanceGroup(string grpClass)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_PERFORMANCE_GROUP";
            DataSet ds = new DataSet();
            try
            {

                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_GRP_CLASS", grpClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);

                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        /*
         P_GRP_CODE VARCHAR2, P_GRP_CLASS VARCHAR2, P_GRP_NAME VARCHAR2,P_STATUS VARCHAR2
             ,P_GRP_SORT VARCHAR2,P_RANK_CLASS VARCHAR2
         */
        public static string InsertPerformanceGroup(string grpCode, string grpClass, string grpName, string grpSort, string rankClass)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_INSERT_PERFORMANCE_GROUP";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_GRP_CODE", grpCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_CLASS", grpClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_NAME", grpName, OracleType.VarChar, 100, ParameterDirection.Input);
                //paramList.Add("P_STATUS", "1", OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_SORT", grpSort, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_RANK_CLASS", rankClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static string DeletePerformanceGroup(string grpCode, string grpClass)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_DELETE_PERFORMANCE_GROUP";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_GRP_CODE", grpCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_CLASS", grpClass, OracleType.VarChar, 30, ParameterDirection.Input);
                
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static string UpdatePerformanceGroup(string grpCode, string grpClass, string grpName, string grpSort, string rankClass)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_UPDATE_PERFORMANCE_GROUP";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_GRP_CODE", grpCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_CLASS", grpClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_NAME", grpName, OracleType.VarChar, 100, ParameterDirection.Input);
                paramList.Add("P_GRP_SORT", grpSort, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_RANK_CLASS", rankClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        #endregion Performance group




        #region Performance Fund
        public static DataSet getPerformanceFund(string grpClass)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_PERFORMANCE_FUND";
            DataSet ds = new DataSet();
            try
            {

                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_GRP_CLASS", grpClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);

                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        /*P_FUND_CODE VARCHAR2,P_COMP VARCHAR2, P_FUND_NAME VARCHAR2, P_GRP_CLASS VARCHAR2
                ,P_GRP_CODE  VARCHAR2, P_FUND_SORT VARCHAR2, P_UPD_BY VARCHAR2, P_UPD_DATE DATE, O_RESULT OUT VARCHAR2*/
        public static string InsertPerformanceFund(string fundCode, string comp, string fundName, string grpClass, string grpCode, string fundSort,string updBy,DateTime updDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_INSERT_PERFORMANCE_FUND";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_FUND_CODE", fundCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_COMP", comp, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_FUND_NAME", fundName, OracleType.VarChar, 255, ParameterDirection.Input);
                paramList.Add("P_GRP_CLASS", grpClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_CODE", grpCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_FUND_SORT", fundSort, OracleType.VarChar, 5, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);
               
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static string UpdatePerformanceFund(string fundCode, string comp, string fundName, string grpClass, string grpCode, string fundSort, string updBy, DateTime updDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_UPDATE_PERFORMANCE_FUND";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_FUND_CODE", fundCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_COMP", comp, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_FUND_NAME", fundName, OracleType.VarChar, 255, ParameterDirection.Input);
                paramList.Add("P_GRP_CLASS", grpClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_CODE", grpCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_FUND_SORT", fundSort, OracleType.VarChar, 5, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 0, ParameterDirection.Input);

                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        public static string DeletePerformanceFund(string fundCode, string grpClass)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_DELETE_PERFORMANCE_FUND";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_FUND_CODE", fundCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GRP_CLASS", grpClass, OracleType.VarChar, 30, ParameterDirection.Input);

                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }



        #endregion 


        #region Adjust Par

        public static DataSet getAdjustPar()
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_GET_ADJUST_PAR";
            DataSet ds = new DataSet();
            try
            {

                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);

                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        public static string InsertAdjustPar(string securityCode, DateTime startDate, object endDate, double parValue)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_INSERT_ADJUST_PAR";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_SECURITY_CODE", securityCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_START_DATE", startDate , OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("P_PAR_VALUE", parValue, OracleType.Number, 0, ParameterDirection.Input);
               
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static string UpdateAdjustPar(string securityCode, DateTime startDate, object endDate, double parValue)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_UPDATE_ADJUST_PAR";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_SECURITY_CODE", securityCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_START_DATE", startDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("P_PAR_VALUE", parValue, OracleType.Number, 0, ParameterDirection.Input);
               
                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        public static string DeleteAdjustPar(string securityCode, DateTime startDate)
        {
            string strSQL = "MKTG.PK_PERFORMANCE.SP_DELETE_ADJUST_PAR";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_SECURITY_CODE", securityCode, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_START_DATE", startDate, OracleType.DateTime, 0, ParameterDirection.Input);

                paramList.Add("O_RESULT", null, OracleType.VarChar, 1000, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteScalar(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }




        #endregion

    }
}
