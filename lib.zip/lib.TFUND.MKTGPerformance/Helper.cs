﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Management;
using System.Diagnostics;
using System.Globalization;
using errorHelper = TFUND.ErrorHelper;
using System.IO;


namespace lib.TFUND.MKTGPerformance
{
    /// <summary>
    /// Summary description for Helper
    /// </summary>
    public static class Helper
    {

        public static void WriteLog(Exception ex)
        {

            errorHelper.class_ErrorWriteLog wr = new errorHelper.class_ErrorWriteLog();
            wr.WriteLog(ex);
        }

        public static DateTime ConvertToDate(string text, string format)
        {
            CultureInfo culture = System.Globalization.CultureInfo.GetCultureInfo("en-GB");
            return DateTime.ParseExact(text, format, culture.DateTimeFormat);

        }

        public static DateTime GetModuleBuildTime()
        {
            return System.IO.File.GetLastWriteTime(System.Reflection.Assembly.GetExecutingAssembly().Location);
        }



        public static  class UI
        {
            public static void JScriptAlert(string msg, System.Web.UI.Page page)
            {
                if (page != null && page.ClientScript != null)
                {
                    string script = string.Format(@"alert('{0}');", msg);
                    ScriptManager.RegisterStartupScript(page, page.GetType(), "alert", script, true);
                }
            }


            public static void JQHideElement(string elementID, System.Web.UI.Page page)
            {
                if (page != null && page.ClientScript != null)
                {
                    string script = string.Format(@" $('#{0}').css('display','none');",elementID);
                    ScriptManager.RegisterStartupScript(page, page.GetType(), "hider", script, true);
                }
            }

            public static void JSOpenPopup(string url, string name, int width, int height, System.Web.UI.Page page)
            {

                if (page != null && page.ClientScript != null)
                {
                    string option = "width=" + width.ToString() + ",height=" + height.ToString() + ",scrollbars=no";
                    string script = string.Format(@"window.open('{0}','{1}','{2}');", url, name, option);
                    ScriptManager.RegisterStartupScript(page, page.GetType(), "popup", script, true);
                }
            }


            public static string TO_CHAR(object input, string format, string nullValue)
            {
                string result = nullValue;

                if (input != null && input != DBNull.Value)
                {
                    result = ((DateTime)input).ToString(format);
                }


                return result;
            }
        }
    }
}