﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TFUND.DB.Oracle;
using System.Data.OracleClient;
using System.Data;

namespace lib.TFUND.MKTGPerformance
{
    public class Data_Access
    {

        public static DataSet GetCOMP()
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_COMP";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
              
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        public static DataSet GetFund(string comp, string strFund)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_FUND";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_COMP", comp, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_STR_FUND", strFund, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }

        public static DataSet GetBmarkInfo(string comp, string strFund)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_BMARK_INFO";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_COMP", comp, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_STR_FUND", strFund, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet GetBmarkInfobyFund(string comp, string fund)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_BMARK_INFO_BY_FUND";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_COMP", comp, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_FUND", fund, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet GetBmarkInfobyFund2(string comp, string fund)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_BMARK_INFO_BY_FUND2";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_COMP", comp, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_FUND", fund, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet GetBmarkInfobyMList(string P_CLASS, string P_MLIST)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_BMARK_INFO_BY_MLIST";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_CLASS", P_CLASS, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_MLIST", P_MLIST, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet GetIndex(string comp,string fund)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_INDEX";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_COMP", comp, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_FUND", fund, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }



        



        /*
         PROCEDURE SP_INSERT_BMARK_INFO(P_COMP VARCHAR2, P_FUND VARCHAR2,  P_INDEX_CODE VARCHAR2, 
                            P_CURRENCY_CODE VARCHAR2, P_UPD_BY VARCHAR2, P_UPD_DATE DATE,
                            P_BMARK_TYPE VARCHAR2, P_BMARK_CHANNEL VARCHAR2, P_SORT_ORDER NUMBER
                            , O_RESULT OUT VARCHAR2)
         */
        public static string InsertBmarkInfo(string comp, string fund, string indexCode,
                                            string currencyCode, string updBy, DateTime updDate,
                                            string bmarkType, string bmarkChannel, double sortOrder)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_INSERT_BMARK_INFO";

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_COMP", comp, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_FUND", fund, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_INDEX_CODE", indexCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_CURRENCY_CODE", currencyCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 50, ParameterDirection.Input);
                paramList.Add("P_BMARK_TYPE", bmarkType, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_BMARK_CHANNEL", bmarkChannel, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_SORT_ORDER", sortOrder, OracleType.Number , 50, ParameterDirection.Input);
                
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output );


                OracleParameter[] param = paramList.ToArray(); 
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();
                
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        /*
         PROCEDURE SP_UPDATE_BMARK_INFO(P_COMP VARCHAR2, P_FUND VARCHAR2, P_BMARK_TYPE VARCHAR2, P_BMARK_CHANNEL VARCHAR2,
            P_STATUS VARCHAR2, P_INDEX_CODE VARCHAR2, P_SORT_ORDER VARCHAR2 , P_CURRENCY_CODE VARCHAR2, 
            P_UPD_BY VARCHAR2, P_UPD_DATE DATE, O_RESULT OUT VARCHAR2)
         */
        public static string UpdateBmarkInfo(string comp, string fund, string bmarkType, string bmarkChannel , string status ,
                                            string indexCode, double sortOrder ,  string currencyCode, string updBy, 
                                            DateTime updDate)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_UPDATE_BMARK_INFO";

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_COMP", comp, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_FUND", fund, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_BMARK_TYPE", bmarkType, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_BMARK_CHANNEL", bmarkChannel, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_STATUS", status, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("P_INDEX_CODE", indexCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_SORT_ORDER", sortOrder, OracleType.Number , 50, ParameterDirection.Input);
                paramList.Add("P_CURRENCY_CODE", currencyCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", updBy, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", updDate, OracleType.DateTime, 50, ParameterDirection.Input);

                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        /*        
          PROCEDURE SP_DELETE_BMARK_INFO(P_COMP VARCHAR2, P_FUND VARCHAR2, P_BMARK_TYPE VARCHAR2, P_BMARK_CHANNEL VARCHAR2 , O_RESULT OUT VARCHAR2 )
         */
        public static string DeleteBmarkInfo(string comp, string fund, string bmarkType , string bmarkChannel)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_DELETE_BMARK_INFO";

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_COMP", comp, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_FUND", fund, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_BMARK_TYPE",  bmarkType, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_BMARK_CHANNEL",  bmarkChannel, OracleType.VarChar, 50, ParameterDirection.Input);
               
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        #region MASTERDATA
        public static DataSet GetFundClass()
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_FUND_CLASS";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        public static DataSet GetFundMList()
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_FUND_MLIST";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        #endregion MASTERDATA


        #region MKTGBMARKPOLICYIINFO
        public static DataSet GetBMarkPolicyInfo(string P_FUND_CLASS, string P_FUND_LIST)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_BMARK_POLICY_INFO";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_FUND_CLASS", P_FUND_CLASS, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_FUND_LIST", P_FUND_LIST, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static string InsertBmarkPolicyInfo(string P_INDEX_CODE,
                                                    string P_FUND_CLASS,
                                                    string P_FUND_LIST,
                                                    string P_STATUS,
                                                    string P_CREATE_BY,
                                                    DateTime P_CREATE_DATE,
                                                    string P_UPD_BY,
                                                    DateTime P_UPD_DATE,
                                                    string P_BMARK_TYPE,
                                                    decimal P_SORT_ORDER)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_INSERT_BMARK_POLICY_INFO";

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_INDEX_CODE", P_INDEX_CODE, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_FUND_CLASS", P_FUND_CLASS, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_FUND_LIST", P_FUND_LIST, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("P_CREATE_BY", P_CREATE_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_CREATE_DATE", P_CREATE_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
                paramList.Add("P_BMARK_TYPE", P_BMARK_TYPE, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_SORT_ORDER", P_SORT_ORDER, OracleType.Number, 22, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }

        public static string UpdateBmarkPolicyInfo(string P_INDEX_CODE,
                                                   string P_FUND_CLASS,
                                                   string P_FUND_LIST,
                                                   string P_STATUS,
                                                   string P_CREATE_BY,
                                                   DateTime P_UPD_DATE,
                                                   string P_BMARK_TYPE,
                                                   decimal P_SORT_ORDER)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_UPDATE_BMARK_POLICY_INFO";

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_INDEX_CODE", P_INDEX_CODE, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_FUND_CLASS", P_FUND_CLASS, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_FUND_LIST", P_FUND_LIST, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", P_CREATE_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
                paramList.Add("P_BMARK_TYPE", P_BMARK_TYPE, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_SORT_ORDER", P_SORT_ORDER, OracleType.Number, 22, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        public static string DeleteBmarkPolicyInfo(string P_INDEX_CODE,
                                                   string P_FUND_CLASS,
                                                   string P_FUND_LIST,                                                  
                                                   string P_BMARK_TYPE)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_DELETE_BMARK_POLICY_INFO";

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_INDEX_CODE", P_INDEX_CODE, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_FUND_CLASS", P_FUND_CLASS, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_FUND_LIST", P_FUND_LIST, OracleType.VarChar, 20, ParameterDirection.Input);
                paramList.Add("P_BMARK_TYPE", P_BMARK_TYPE, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }



        #endregion MKTGBMARKPOLICYIINFO


        #region BMARKTYPE

        public static DataSet GetBmarkType()
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_BMARK_TYPE";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static string InsertBmarkType(string P_BMARK_TYPE,
                                             string P_DESCRIPTION,
                                             string P_STATUS,
                                             string P_UPD_BY,
                                             DateTime P_UPD_DATE,
                                             decimal P_SORT_ORDER,
                                             string P_DESCRIPTION_E)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_INS_BMARK_TYPE";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_BMARK_TYPE", P_BMARK_TYPE, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_DESCRIPTION", P_DESCRIPTION, OracleType.VarChar, 150, ParameterDirection.Input);
                paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
                paramList.Add("P_SORT_ORDER", P_SORT_ORDER, OracleType.Number, 22, ParameterDirection.Input);
                paramList.Add("P_DESCRIPTION_E", P_DESCRIPTION_E, OracleType.VarChar, 150, ParameterDirection.Input);
               
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        public static string UpdateBmarkType(string P_BMARK_TYPE,
                                             string P_DESCRIPTION,
                                             string P_STATUS,
                                             string P_UPD_BY,
                                             DateTime P_UPD_DATE,
                                             decimal P_SORT_ORDER,
                                             string P_DESCRIPTION_E)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_UPD_BMARK_TYPE";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_BMARK_TYPE", P_BMARK_TYPE, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_DESCRIPTION", P_DESCRIPTION, OracleType.VarChar, 150, ParameterDirection.Input);
                paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
                paramList.Add("P_SORT_ORDER", P_SORT_ORDER, OracleType.Number, 22, ParameterDirection.Input);
                paramList.Add("P_DESCRIPTION_E", P_DESCRIPTION_E, OracleType.VarChar, 150, ParameterDirection.Input);

                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }




        public static string DeleteBmarkType(string P_BMARK_TYPE)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_DELETE_BMARK_TYPE";

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_BMARK_TYPE", P_BMARK_TYPE, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);

                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        #endregion

        #region BMARKCHANNEL 
        public static DataSet GetBmarkChannel()
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_BMARK_CHANNEL";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        public static string InsertBmarkChannel(string P_BMARK_CHANNEL,
                                          string P_DESCRIPTION,
                                          string P_STATUS,
                                          string P_UPD_BY,
                                          DateTime P_UPD_DATE )
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_INS_BMARK_CHANNEL";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_BMARK_CHANNEL", P_BMARK_CHANNEL, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_DESCRIPTION", P_DESCRIPTION, OracleType.VarChar, 150, ParameterDirection.Input);
                paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
         
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        public static string UpdateBmarkChannel(string P_BMARK_CHANNEL,
                                         string P_DESCRIPTION,
                                         string P_STATUS,
                                         string P_UPD_BY,
                                         DateTime P_UPD_DATE )
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_UPD_BMARK_CHANNEL";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_BMARK_CHANNEL", P_BMARK_CHANNEL, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_DESCRIPTION", P_DESCRIPTION, OracleType.VarChar, 150, ParameterDirection.Input);
                paramList.Add("P_STATUS", P_STATUS, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);
      
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }

        public static string DeleteBmarkChannel(string P_BMARK_CHANNEL)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_DELETE_BMARK_CHANNEL";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_BMARK_CHANNEL", P_BMARK_CHANNEL, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);
                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }




        #endregion BMARKCHANNEL


        #region AssetClass 
        public static DataSet GetAssetClass()
        {

            /* ASSET CLASS */
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_GET_ASSET_CLASS";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet GetSecurityGroup(string assetClass)
        {
            /* ASSET_CLASS , GROUP_CODE , GROUP_DESC  */
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_GET_SECURITY_GROUP";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_ASSET_CLASS", assetClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }


        }

        public static DataSet GetSecurityGroupEXC()
        {
            /* GROUP_CODE , GROUP_DESC */
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_GET_SECURITY_GROUP_EXC";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }


        }

        public static string InsertSecurityGroup(string P_ASSET_CLASS,
                                          string P_GROUP_CODE,
                                          string P_UPD_BY,
                                          DateTime P_UPD_DATE)
        {
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_INSERT_SECURITY_GROUP";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_ASSET_CLASS", P_ASSET_CLASS, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GROUP_CODE", P_GROUP_CODE, OracleType.VarChar, 150, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);

                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


            
        public static string DeleteSecurityGroup(string P_ASSET_CLASS , string P_GROUP_CODE)
        {
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_DELETE_SECURITY_GROUP";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_ASSET_CLASS", P_ASSET_CLASS, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_GROUP_CODE", P_GROUP_CODE, OracleType.VarChar, 30, ParameterDirection.Input);               
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);
                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }



        /***** MKTGMSECURITYCLASS *****/
        public static DataSet GetSecurityClass(string assetClass)
        {
            /* ASSET_CLASS, SECURITY_CODE, SECURITY_DESC_E, SECURITY_DESC_T  */
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_GET_SECURITY_BY_CLASS";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_ASSET_CLASS", assetClass, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }


        }

        public static DataSet GetSecurityClassEXC(string securityCodeSearch)
        {
            /* SECURITY_CODE , SECURITY_DESC_E, SECURITY_DESC_T */
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_GET_SECURITY_EXC";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();

                paramList.Add("P_SECURITY_CODE_SEARCH", securityCodeSearch, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        public static string InsertSecurityClass(string P_ASSET_CLASS,
                                        string P_SECURITY_CODE,
                                        string P_UPD_BY,
                                        DateTime P_UPD_DATE)
        {
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_INSERT_SECURITY_CLASS";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_ASSET_CLASS", P_ASSET_CLASS, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_SECURITY_CODE", P_SECURITY_CODE, OracleType.VarChar, 150, ParameterDirection.Input);
                paramList.Add("P_UPD_BY", P_UPD_BY, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_UPD_DATE", P_UPD_DATE, OracleType.DateTime, 7, ParameterDirection.Input);

                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);


                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);

                return param[param.Length - 1].Value.ToString();

            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }



        public static string DeleteSecurityClass(string P_ASSET_CLASS, string P_SECURITY_CODE)
        {
            string strSQL = "MKTG.PK_ATTRIBUTION.SP_DELETE_SECURITY_CLASS";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_ASSET_CLASS", P_ASSET_CLASS, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("P_SECURITY_CODE", P_SECURITY_CODE, OracleType.VarChar, 30, ParameterDirection.Input);
                paramList.Add("O_RESULT", null, OracleType.VarChar, 100, ParameterDirection.Output);
                OracleParameter[] param = paramList.ToArray();
                OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, param);
                return param[param.Length - 1].Value.ToString();
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        


        #endregion AssetClass
    }
}
