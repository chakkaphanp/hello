﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace lib.TFUND.prospectus2013
{
    /// <summary>
    /// Summary description for CommonConst
    /// </summary>
    public class CommonConst
    {
        public const string CFG_TFUND_COMP_CODE = "THANACHART FUND";
        public const string CFG_DATE_FORMAT = "dd/MM/yyyy";
    }
}