﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using tfundOracle = TFUND.DB.Oracle;
using System.Data;
using System.Data.OracleClient;
using TFUND.DB.Oracle;


namespace lib.TFUND.prospectus2013
{
    /// <summary>
    /// Summary description for Data_Access
    /// </summary>
    public class Data_Access
    {
        public Data_Access()
        {
            //
            // TODO: Add constructor logic here
            //



        }

        /// <summary>
        /// For test only
        /// </summary>
        /// <returns></returns>
        public static DataSet GetAllCust()
        {
            string strSQL = "SELECT * FROM CIS.OPNMCUST WHERE ROWNUM < 20000 ";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                //paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                //paramList.Add("P_ROW_NUM", rownum, OracleType.Number, 15, ParameterDirection.Input);

                //paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset( Global.ActiveDBConnectionString, CommandType.Text,strSQL);

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet GetTrnDateMUF(DateTime endDate, int rownum)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_TRNDATE_MUF";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("P_ROW_NUM", rownum, OracleType.Number, 15, ParameterDirection.Input);

                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }



        public static DataSet GetAllFundMUF(string compCode)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_ALL_FUND_MUF";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_COMP", compCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }

        }


        public static DataSet GetFundMUFByDate(string compCode, DateTime endDate)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_FUND_MUF_BYDATE";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_COMP", compCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 50, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }


        public static DataSet GetFundStatistics(string compCode, string fundCode, DateTime endDate,bool isAnnualized)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_FUND_STATS";
            DataSet ds = new DataSet();

            string p_annualized = isAnnualized == true ? "Y":"N";

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_COMP", compCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_Fund", fundCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("P_ANNUALIZED", p_annualized, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        //SP_GET_RETURN_YEAR_BACK(P_COMP VARCHAR2,P_FUND VARCHAR2,P_END_DATE DATE ,P_NUM_YEAR_BACK NUMBER,c_result out sys_refcursor)
        public static DataSet GetFundPerformance(string compCode, string fundCode, DateTime endDate, int yearBack)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_RETURN_YEAR_BACK";
            DataSet ds = new DataSet();

            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_COMP", compCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_Fund", fundCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("P_NUM_YEAR_BACK", yearBack, OracleType.Number, 0, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

        //SP_GET_RETURN_YEAR_BACK(P_COMP VARCHAR2,P_FUND VARCHAR2,P_END_DATE DATE ,P_NUM_YEAR_BACK NUMBER,c_result out sys_refcursor)
        public static DataSet GetFundStatisticsWithPeerAIMC(string compCode, string fundCode, DateTime endDate, bool isAnnualized)
        {
            string strSQL = "MIS.PK_PERFORMANCE.SP_GET_FUND_STATS_PEER_RANK";
            DataSet ds = new DataSet();
            string p_annualized = isAnnualized == true ? "Y" : "N";
            try
            {
                OracleParameterList paramList = new OracleParameterList();
                paramList.Add("P_COMP", compCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_Fund", fundCode, OracleType.VarChar, 50, ParameterDirection.Input);
                paramList.Add("P_END_DATE", endDate, OracleType.DateTime, 0, ParameterDirection.Input);
                paramList.Add("P_ANNUALIZED", p_annualized, OracleType.VarChar, 1, ParameterDirection.Input);
                paramList.Add("C_RESULT", null, OracleType.Cursor, 30, ParameterDirection.Output);
                ds = OracleHelper.ExecuteDataset(Global.ActiveDBConnectionString, CommandType.StoredProcedure, strSQL, paramList.ToArray());

                return ds;
            }
            catch (Exception ex)
            {
                Helper.WriteLog(ex);
                return null;
            }
        }

    }

}