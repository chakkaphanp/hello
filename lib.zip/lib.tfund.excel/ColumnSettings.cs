﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace lib.tfund.excel
{
    public class ColumnSettings
    {

        public string FirstValueValidation { get; set; }
        public int FirstDataRow { get; set; }

        public List<ColumnSettingInfo> Columns { get; set; }

        //public ColumnSettingInfo GetColumnSetting(int i)
        //{
        //    try
        //    {
                
        //        return this.Columns[i];
        //    }
        //    catch (Exception)
        //    {
        //        return null;
        //    }
        //}


        public ColumnSettingInfo GetColumnSetting(int i)
        {
            try
            {
                foreach (var item in this.Columns)
                {
                    if (item.Index == i + 1)
                    {
                        return item;
                    }
                }

                return null;
                
            }
            catch (Exception)
            {
                return null;
            }
        }


        public ColumnSettings(string fileName)
        {
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(fileName);
            this.LoadXML(xDoc);
        }

        public ColumnSettings(XmlDocument xDoc)
        {
            this.LoadXML(xDoc);
        }

        private void LoadXML(XmlDocument xDoc)
        {
            XmlNodeList xNodes = xDoc.GetElementsByTagName("Column");
            this.Columns = new List<ColumnSettingInfo>();
            XmlNodeList xnSettings = xDoc.GetElementsByTagName("Settings");
            if (xnSettings.Count > 0)
            {
                this.FirstValueValidation = xnSettings.Item(0).Attributes["FirstValueValidation"].Value;
                if (xnSettings.Item(0).Attributes["FirstDataRow"] != null)
                {
                    this.FirstDataRow = Convert.ToInt32(xnSettings.Item(0).Attributes["FirstDataRow"].Value);
                }
                else
                {
                    this.FirstDataRow = 1;
                }
            }
            foreach (XmlNode item in xNodes)
            {
                ColumnSettingInfo col = new ColumnSettingInfo(item);
                this.Columns.Add(col);
            }
        }

    }
}
