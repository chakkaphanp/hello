﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;


namespace lib.tfund.excel
{
    public class ColumnSettingInfo
    {
        public enum DataType
        {
            Integer,
            Double,
            String,
            Date,
            DateTime,
            Boolean
        }

        public int Index { get; set; }
        public string Name { get; set; }
        public DataType Type { get; set; }
        public string Description { get; set; }
        public string DefaultValue { get; set; }
        public List<Mapping> ValueMapping { get; set; }
        //public string Skip { get; set; }

        private ColumnSettingInfo()
        {

        }


        public ColumnSettingInfo(XmlNode xNode)
        {
            ValueMapping = new List<Mapping>();
            int index = Convert.ToInt32(xNode.Attributes["Index"].Value);
            string name = Convert.ToString(xNode.Attributes["Name"].Value);
            string description = Convert.ToString(xNode.Attributes["Description"].Value);
            string type = Convert.ToString(xNode.Attributes["Type"].Value);
            //string skip = "false";

            //if (xNode.Attributes["Skip"] != null)
            //{
            //    Convert.ToString(xNode.Attributes["Skip"].Value);
            //}

            if (xNode.Attributes["DefaultValue"] != null)
            {
                this.DefaultValue = Convert.ToString(xNode.Attributes["DefaultValue"].Value);
            }

            lib.tfund.excel.ColumnSettingInfo.DataType dataType = (lib.tfund.excel.ColumnSettingInfo.DataType)Enum.Parse(typeof(lib.tfund.excel.ColumnSettingInfo.DataType), type, true);

            this.Index = index;
            this.Name = name;
            this.Description = description;
            this.Type = dataType;
            //this.Skip = skip;

            foreach (XmlNode item in xNode.ChildNodes)
	        {
                Mapping mapping = new Mapping(item);
                this.ValueMapping.Add(mapping);
	        } 

             
        }

        public string MapValue(string value)
        {
            foreach (Mapping item in this.ValueMapping)
            {
                if (value == item.objFrom)
                {
                    return item.objTo;
                }
            }
            return value;
        }
    }
}
