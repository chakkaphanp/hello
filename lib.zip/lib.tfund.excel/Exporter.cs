﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using msexcel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using DocumentFormat.OpenXml.Packaging;
using System.Web;


namespace lib.tfund.excel
{
    public class Exporter
    {

        private const string FORMAT_QUOTE_DATA = "\"{0}\"";

        private static string ExportCSV(DataTable dt)
        {
            StringWriter sw = new StringWriter();
            //write the headers.        
            int iColCount = dt.Columns.Count;
            for (int i = 0; i < iColCount; i++)
            {
                sw.Write(string.Format(FORMAT_QUOTE_DATA, dt.Columns[i]));
                if (i < iColCount - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);

            // write all the rows.
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 0; i < iColCount; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        sw.Write(string.Format(FORMAT_QUOTE_DATA, dr[i].ToString()));
                    }
                    if (i < iColCount - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            return sw.ToString();
        }


        public static void ExportCSV(string strFilePath, DataTable dt)
        {
            #region Export CSV       
            
            StreamWriter  sw = new StreamWriter(strFilePath, false , Encoding.GetEncoding(874) );
           
            sw.Write(ExportCSV(dt));            
            sw.Close();     
            #endregion
        }


        private static void DataTableToExcelWorkSheet(msexcel.Worksheet sheet, DataTable dt, string sheetName, bool includeColumnHeader)
        {
            //msexcel.Worksheet sheet = new Microsoft.Office.Interop.Excel.Worksheet();
            sheet.Name = sheetName;
            int i = 1;
            foreach (DataColumn col in dt.Columns)
            {
                sheet.Cells[1, i] = col.ColumnName;
                i++;
            }

            i = 2;
            
            foreach (DataRow row in dt.Rows)
            {
                int j = 1;
                foreach (DataColumn col  in dt.Columns)
                {
                    sheet.Cells[i, j] = row[col.ColumnName];
                    j++;
                }

                i++;
            }

            return;
        }






        public static void ExportCSVToHTTP(System.Web.HttpResponse response, DataTable dt)
        {
            System.Globalization.CultureInfo curCulture = System.Globalization.CultureInfo.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo("en-GB");  
            
            response.ClearContent();
            response.ClearHeaders();
            response.ContentEncoding = Encoding.GetEncoding(874);
            response.ContentType = "application/csv";
            response.AddHeader("Content-Disposition","attachment; filename=download.csv");
            response.Write(ExportCSV(dt));
            response.Flush();
            response.End();

            System.Threading.Thread.CurrentThread.CurrentCulture = curCulture;
        }      


        public static void ExportExcelToHTTP(System.Web.HttpResponse response, string filePath, string exportFilename,bool deleteFile)
        {
            
                response.ClearContent();
                response.ClearHeaders();
                response.ContentEncoding = Encoding.GetEncoding(874);
                response.ContentType = "application/ms-excel";
                response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}.xls", exportFilename));
                response.WriteFile(filePath);    
                //response.Flush();
                if (deleteFile)
                {
                    System.IO.File.Delete(filePath);
                }

                HttpContext.Current.ApplicationInstance.CompleteRequest();
                //response.End();         

        }

        public static string CreateExcel(string fileName)
        {
            msexcel.Application app = new msexcel.Application();
            msexcel.Workbook book = null;
            msexcel.Worksheet sheet = null;
            msexcel.Range range = null;

            try
            {
                app.Visible = false;
                app.ScreenUpdating = false;
                app.DisplayAlerts = false;
                app.UserControl = true;

                string execPath = System.AppDomain.CurrentDomain.BaseDirectory;

                book = app.Workbooks.Add( msexcel.XlWBATemplate.xlWBATWorksheet);
                sheet = (msexcel.Worksheet)book.Worksheets[1];

                string filepath = execPath + @"excel.template\excel-" + Guid.NewGuid().ToString() + ".xls";

                book.SaveAs(filepath, msexcel.XlFileFormat.xlWorkbookNormal, Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                 msexcel.XlSaveAsAccessMode.xlExclusive, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);

                return filepath;

            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
            finally
            {
                //IntPtr returnPtr;
                //IntPtr excelPtr = GetWindowThreadProcessId(app.Hwnd, out returnPtr);

                lib.tfund.excel.helper.ReleaseRCM(range);
                range = null;

                if (book != null)
                    book.Close(false, Missing.Value, Missing.Value);
                lib.tfund.excel.helper.ReleaseRCM(book);
                book = null;
                helper.KillProcessExcel(app);
                app = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();

                // if (System.IO.File.Exists(fileName))
                // {
                //     System.IO.File.Delete(fileName);
                // }

                //System.Threading.Thread.CurrentThread.CurrentCulture = oldCI;

            }


        }


        public static string GetExcelProspectus(string fileName, string fundCode, DataTable dtStats, DataTable dtPerfs, bool isTRI, bool enabledTRI)
        {
            msexcel.Application app = new msexcel.Application();
            msexcel.Workbook book = null;
            msexcel.Range range = null;


            System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture(helper.GetConfig("CultureName"));
            DateTime inceptionDate = DateTime.Today;
            DateTime endDate = DateTime.Today;
            System.Globalization.CultureInfo thCulture = System.Globalization.CultureInfo.GetCultureInfo("th-TH");

            try
            {
                app.Visible = false;
                app.ScreenUpdating = false;
                app.DisplayAlerts = false;
                app.UserControl = true;

                string execPath = System.AppDomain.CurrentDomain.BaseDirectory;

                book = app.Workbooks.Open(fileName, Missing.Value, Missing.Value, Missing.Value
                                                  , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                 , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                , Missing.Value, Missing.Value, Missing.Value);

                int _rowoffset = 2;
                int _rowoffset_tri = 0;

                //return book;
                System.Collections.Generic.Dictionary<string, int> dicPeriod = new Dictionary<string, int>();
                dicPeriod.Add("3M", 3);
                dicPeriod.Add("6M", 4);
                dicPeriod.Add("1Y", 5);
                dicPeriod.Add("3Y", 6);
                dicPeriod.Add("5Y", 7);
                dicPeriod.Add("10Y", 8);
                dicPeriod.Add("SINCE", 9);
                //dicPeriod.Add("YTD", 3);
                msexcel.Worksheet sheet = (msexcel.Worksheet)book.Worksheets[1];
                sheet.Name = fundCode;
                sheet.Cells[4 + _rowoffset, 2] = fundCode;

                bool annualizeSinceInception = true;
                bool currencyTHB = false;
                //write stats


                /* Add TRI data by Chakkaphan 28/09/2015 */
                if (enabledTRI)
                {
                    _rowoffset_tri = 2;
                    if (!isTRI)
                    {
                        ((Microsoft.Office.Interop.Excel.Range)sheet.Rows[16, Missing.Value]).Hidden = true;
                        ((Microsoft.Office.Interop.Excel.Range)sheet.Rows[10, Missing.Value]).Hidden = true;
                        ((Microsoft.Office.Interop.Excel.Range)sheet.Rows[9, Missing.Value]).Hidden = true;
                    }
                }


                foreach (DataRow item in dtStats.Rows)
                {
                    int colPos = dicPeriod[item["PERIOD"].ToString()];
                    sheet.Cells[4 + _rowoffset, colPos] = item["RTN"].ToString() == "0" ? "-" : item["RTN"];
                    sheet.Cells[5 + _rowoffset, colPos] = item["BMARK"].ToString() == "0" ? "-" : item["BMARK"];
                    sheet.Cells[6 + _rowoffset, colPos] = item["IR"].ToString() == "0" ? "-" :  string.Format("{0:0.00}",item["IR"]);
                    sheet.Cells[7 + _rowoffset + _rowoffset_tri, colPos] = item["SD"].ToString() == "0" ? "-" : item["SD"];

                    /* เพิ่ม Benchmark และ IR ของ TRI */
                    if (isTRI)
                    {
                        sheet.Cells[7 + _rowoffset, colPos] = item["BMARK_TRI"].ToString() == "0" ? "-" : item["BMARK_TRI"];
                        sheet.Cells[8 + _rowoffset, colPos] = item["IR_TRI"].ToString() == "0" ? "-" : item["IR_TRI"];
                    }
                    string strDateStart = (item["START_DATE"] == DBNull.Value) ? "-" : Convert.ToDateTime(item["START_DATE"]).ToString("d MMM yy", thCulture.DateTimeFormat);
                    //DateTime? dateStart = (item["START_DATE"] == DBNull.Value) ? null : Convert.ToDateTime(item["START_DATE"]);
                    DateTime dateEnd = Convert.ToDateTime(item["END_DATE"]);

                    string strDatePeriod = string.Format("{0} {2}ถึง {1}", strDateStart, dateEnd.ToString("d MMM yy", thCulture.DateTimeFormat), Environment.NewLine);
                    sheet.Cells[3 + _rowoffset, colPos] = strDatePeriod;

                    if (item["PERIOD"].ToString() == "1Y" && item["RTN"].ToString() == "0")
                    {
                        annualizeSinceInception = false;
                    }

                    if (item["PERIOD"].ToString() == "SINCE")
                    {
                        inceptionDate = Convert.ToDateTime(item["START_DATE"]);
                        endDate = Convert.ToDateTime(item["END_DATE"]);
                    }

                    if (!currencyTHB && item["CURRENCY_CODE"].ToString() == "THB")
                    {
                        currencyTHB = true;
                    }
                }


                if (currencyTHB)
                {
                    sheet.Cells[5 + _rowoffset, 2] = "Benchmark (บาท)";
                }

                if (!annualizeSinceInception)
                {
                    sheet.Cells[4, dicPeriod["SINCE"]] = "กองทุน";//sheet.Cells[3, dicPeriod["SINCE"]].ToString().Replace("1", "");
                }



                //Write YTD return 
                int yearStartCol = 12;
                int yearStartRow = 15 + _rowoffset;

                int fundStartCol = 12;
                int fundStartRow = 16 + _rowoffset;

                int bmarkStartCol = 12;
                int bmarkStartRow = 17 + _rowoffset;


                object[] objFundSerieValues = new object[dtPerfs.Rows.Count];
                object[] objLabelSerieValues = new object[dtPerfs.Rows.Count];
                object[] objBmarkSerieValues = new object[dtPerfs.Rows.Count];
                int i = 0;
                bool showInception = false;
                foreach (DataRow item in dtPerfs.Rows)
                {
                    int year = Convert.ToInt32(item["YEAR"]);
                    if (year <= inceptionDate.Year)
                    {
                        showInception = true;
                    }
                    sheet.Cells[yearStartRow, yearStartCol] = (Convert.ToInt32(item["YEAR"]) + 543).ToString();
                    sheet.Cells[fundStartRow, fundStartCol] = Convert.ToDouble(item["RTN"]) / 100.00;
                    sheet.Cells[bmarkStartRow, bmarkStartCol] = Convert.ToDouble(item["BMARK"]) / 100.00;

                    objLabelSerieValues[i] = sheet.Cells[yearStartRow, yearStartCol];
                    objFundSerieValues[i] = sheet.Cells[fundStartRow, fundStartCol];
                    objBmarkSerieValues[i] = sheet.Cells[bmarkStartRow, bmarkStartCol];

                    yearStartCol++;
                    fundStartCol++;
                    bmarkStartCol++;
                    i++;
                }

                msexcel.Chart c = ((msexcel.ChartObject)sheet.ChartObjects(1)).Chart;
                msexcel.SeriesCollection sc = (msexcel.SeriesCollection)c.SeriesCollection(Missing.Value);

                sc.NewSeries();

                msexcel.Series scFund = (msexcel.Series)c.SeriesCollection(1);
                msexcel.Series scBMark = (msexcel.Series)c.SeriesCollection(2);

                scFund.Name = fundCode;
                scFund.Values = objFundSerieValues;
                scFund.XValues = objLabelSerieValues;
                scBMark.Values = objBmarkSerieValues;
                scBMark.XValues = objLabelSerieValues;


                if (currencyTHB)
                {
                    scBMark.Name = "Benchmark (บาท)";
                }

                if (showInception)
                {
                    sheet.get_Range("A26", "A26").EntireRow.RowHeight = 16.5;
                    sheet.Cells[26, 2] = String.Format("* {0} จัดตั้งกองทุนเมื่อวันที่ {1}", fundCode, inceptionDate.ToString("d MMM yyyy", thCulture));
                }

                sheet.Cells[26 + _rowoffset + _rowoffset_tri, 2] = string.Format("* ผลการดำเนินงานปี {0} ข้อมูล ณ.วันที่ {1}", endDate.Year + 543, endDate.ToString("d MMM yyyy", thCulture));


                msexcel.Worksheet ws = (msexcel.Worksheet)book.Sheets.Add(Missing.Value, book.Sheets.get_Item(1), Missing.Value, Missing.Value);
                DataTableToExcelWorkSheet(ws, dtPerfs, "RETURN_BY_YEAR", true);

                msexcel.Worksheet wstats = (msexcel.Worksheet)book.Sheets.Add(Missing.Value, book.Sheets.get_Item(1), Missing.Value, Missing.Value);
                DataTableToExcelWorkSheet(wstats, dtStats, "STATISTIC", true);




                sheet.Select(Missing.Value);


                string filepath = execPath + @"excel.template\excel-" + Guid.NewGuid().ToString() + ".xls";

                //range.CopyPicture(Microsoft.Office.Interop.Excel.XlPictureAppearance.xlPrinter, Microsoft.Office.Interop.Excel.XlCopyPictureFormat.xlBitmap);
                book.SaveAs(filepath, msexcel.XlFileFormat.xlWorkbookNormal, Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                    msexcel.XlSaveAsAccessMode.xlExclusive, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                //Debug.WriteLine(@"Values for Sheet " + sheet.Index);



                return filepath;


            }
            catch (Exception e)
            {
                TFUND.ErrorHelper.class_ErrorWriteLog logger = new TFUND.ErrorHelper.class_ErrorWriteLog();
                logger.WriteLog(e);

                throw e;
            }
            finally
            {
                //IntPtr returnPtr;
                //IntPtr excelPtr = GetWindowThreadProcessId(app.Hwnd, out returnPtr);

                lib.tfund.excel.helper.ReleaseRCM(range);
                range = null;

                if (book != null)
                    book.Close(false, Missing.Value, Missing.Value);
                lib.tfund.excel.helper.ReleaseRCM(book);
                book = null;
                helper.KillProcessExcel(app);
                app = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();

                // if (System.IO.File.Exists(fileName))
                // {
                //     System.IO.File.Delete(fileName);
                // }

                System.Threading.Thread.CurrentThread.CurrentCulture = oldCI;

            }


        }

        public static string GetExcelProspectusWithPeer(string fileName,string fundCode,DataTable dtStats,DataTable dtPerfs, bool isTRI, bool enabledTRI)
        {
            msexcel.Application app = new msexcel.Application();
            msexcel.Workbook book = null;
            msexcel.Range range = null;


            System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture(helper.GetConfig("CultureName"));
            DateTime inceptionDate = DateTime.Today;
            DateTime endDate = DateTime.Today;
            System.Globalization.CultureInfo thCulture = System.Globalization.CultureInfo.GetCultureInfo("th-TH");
                   
            try
            {
                app.Visible = false;
                app.ScreenUpdating = false;
                app.DisplayAlerts = false;
                app.UserControl = true;

                string execPath = System.AppDomain.CurrentDomain.BaseDirectory;

                book = app.Workbooks.Open(fileName, Missing.Value, Missing.Value, Missing.Value
                                                  , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                 , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                , Missing.Value, Missing.Value, Missing.Value);
                
                int _rowoffset = 2;
                int _rowoffset_tri = 0;

                //return book;
                System.Collections.Generic.Dictionary<string, int> dicPeriod = new Dictionary<string, int>();
                dicPeriod.Add("3M", 4);
                dicPeriod.Add("6M", 6);
                dicPeriod.Add("1Y", 8);
                dicPeriod.Add("3Y", 10);
                dicPeriod.Add("5Y", 12);
                dicPeriod.Add("10Y", 14);                
                dicPeriod.Add("SINCE", 16);
                dicPeriod.Add("YTD", 3);
                msexcel.Worksheet sheet = (msexcel.Worksheet)book.Worksheets[1];
                sheet.Name = fundCode;
                sheet.Cells[4+_rowoffset, 2] = fundCode;           

                bool annualizeSinceInception = true;
                bool currencyTHB = false;
                //write stats


                /* Add TRI data by Chakkaphan 28/09/2015 */
                if (enabledTRI)
                {
                    _rowoffset_tri = 2;
                    if (!isTRI)
                    {
                        ((Microsoft.Office.Interop.Excel.Range)sheet.Rows[16, Missing.Value]).Hidden = true;
                       // ((Microsoft.Office.Interop.Excel.Range)sheet.Rows[10, Missing.Value]).Hidden = true;
                       // ((Microsoft.Office.Interop.Excel.Range)sheet.Rows[9, Missing.Value]).Hidden = true;
                    }
                }
               

                foreach (DataRow item in dtStats.Rows )
                {
                    int colPos = dicPeriod[item["PERIOD"].ToString()];
                    //sheet.Cells[4 + _rowoffset, colPos] = item["RTN"].ToString() == "0" ? "-" : item["RTN"];
                    //sheet.Cells[5 + _rowoffset, colPos] = item["BMARK"].ToString() == "0" ? "-" : item["BMARK"];
                    //sheet.Cells[6 + _rowoffset, colPos] = item["IR"].ToString() == "0" ? "-" :  string.Format("{0:0.00}",item["IR"]);
                    //sheet.Cells[7 + _rowoffset + _rowoffset_tri, colPos] = item["SD"].ToString() == "0" ? "-" : item["SD"];

                    /* เพิ่ม Benchmark และ IR ของ TRI */
                    //if (isTRI)
                    //{
                    //    sheet.Cells[7 + _rowoffset, colPos] = item["BMARK_TRI"].ToString() == "0" ? "-" : item["BMARK_TRI"];
                    //    sheet.Cells[8 + _rowoffset, colPos] = item["IR_TRI"].ToString() == "0" ? "-" : item["IR_TRI"];
                    //}
                    string strDateStart = (item["START_DATE"] == DBNull.Value) ? "-" : Convert.ToDateTime(item["START_DATE"]).ToString("d MMM yy", thCulture.DateTimeFormat);
                    //DateTime? dateStart = (item["START_DATE"] == DBNull.Value) ? null : Convert.ToDateTime(item["START_DATE"]);
                    DateTime dateEnd = Convert.ToDateTime(item["END_DATE"]);
                    
                    string strDatePeriod = string.Format("{0} {2}ถึง {1}", strDateStart, dateEnd.ToString("d MMM yy", thCulture.DateTimeFormat),Environment.NewLine);
                    sheet.Cells[3 + _rowoffset, colPos] = strDatePeriod;

                    if (item["PERIOD"].ToString() == "1Y" && item["RTN"].ToString() == "0")
                    {
                        annualizeSinceInception = false;
                    }

                    if (item["PERIOD"].ToString() == "SINCE")
                    {
                        inceptionDate = Convert.ToDateTime(item["START_DATE"]);
                        endDate = Convert.ToDateTime(item["END_DATE"]);
                    }

                    if ( !currencyTHB && item["CURRENCY_CODE"].ToString() == "THB")
                    {
                        currencyTHB = true;
                    }
                }


                if (currencyTHB)
                {
                    sheet.Cells[5 + _rowoffset, 2] =  "Benchmark (บาท)";
                }

                if (!annualizeSinceInception)
                {
                    sheet.Cells[4, dicPeriod["SINCE"]] = "กองทุน" ;//sheet.Cells[3, dicPeriod["SINCE"]].ToString().Replace("1", "");
                }



                //delete "STATISTIC" sheet
                //for (int k =  book.Worksheets.Count; k > 0; k--)
                //{
                //    Microsoft.Office.Interop.Excel.Worksheet wkSheet = (Microsoft.Office.Interop.Excel.Worksheet)book.Worksheets[k];
                //    if (wkSheet.Name == "STATISTIC")
                //    {
                //        wkSheet.Delete();
                //    }
                //}
                
                
                //Write YTD return 
                int yearStartCol = 19;
                int yearStartRow = 15 + _rowoffset;

                int fundStartCol = 19;
                int fundStartRow = 16 + _rowoffset;

                int bmarkStartCol = 19;
                int bmarkStartRow = 17 + _rowoffset;


                object[] objFundSerieValues = new object[dtPerfs.Rows.Count];
                object[] objLabelSerieValues = new object[dtPerfs.Rows.Count];
                object[] objBmarkSerieValues = new object[dtPerfs.Rows.Count];
                int i = 0;
                bool showInception = false;
                foreach (DataRow item in dtPerfs.Rows)
                {
                    int year = Convert.ToInt32(item["YEAR"]);
                    if (year <= inceptionDate.Year)
                    {
                        showInception = true;
                    }
                    sheet.Cells[yearStartRow, yearStartCol] = (Convert.ToInt32(item["YEAR"])+543).ToString();
                    sheet.Cells[fundStartRow, fundStartCol] = Convert.ToDouble(item["RTN"])/100.00;
                    sheet.Cells[bmarkStartRow, bmarkStartCol] = Convert.ToDouble(item["BMARK"])/100.00;

                    objLabelSerieValues[i] = sheet.Cells[yearStartRow, yearStartCol];
                    objFundSerieValues[i] = sheet.Cells[fundStartRow, fundStartCol];
                    objBmarkSerieValues[i] = sheet.Cells[bmarkStartRow, bmarkStartCol];

                    yearStartCol++;
                    fundStartCol++;
                    bmarkStartCol++;
                    i++;
                }

                msexcel.Chart c = ((msexcel.ChartObject)sheet.ChartObjects(1)).Chart;                
                msexcel.SeriesCollection sc = (msexcel.SeriesCollection)c.SeriesCollection(Missing.Value);

                sc.NewSeries();

                msexcel.Series scFund = (msexcel.Series)c.SeriesCollection(1);
                msexcel.Series scBMark = (msexcel.Series)c.SeriesCollection(2);
                scFund.Name = fundCode;
                scFund.Values = objFundSerieValues;
                scFund.XValues = objLabelSerieValues;
                scBMark.Values = objBmarkSerieValues;
                scBMark.XValues = objLabelSerieValues;


                if (currencyTHB)
                {
                    scBMark.Name = "Benchmark (บาท)";
                }

                if (showInception)
                {
                    sheet.get_Range("A26", "A26").EntireRow.RowHeight = 16.5;
                    sheet.Cells[26, 2] = String.Format("* {0} จัดตั้งกองทุนเมื่อวันที่ {1}",fundCode, inceptionDate.ToString("d MMM yyyy",thCulture));
                }

                sheet.Cells[26 + _rowoffset + _rowoffset_tri , 2] = string.Format("* ผลการดำเนินงานปี {0} ข้อมูล ณ.วันที่ {1}",endDate.Year+543,endDate.ToString("d MMM yyyy",thCulture) );
                
                               
                msexcel.Worksheet ws = (msexcel.Worksheet)book.Sheets.Add(Missing.Value, book.Sheets.get_Item(1), Missing.Value, Missing.Value);
                DataTableToExcelWorkSheet(ws, dtPerfs, "RETURN_BY_YEAR", true);
                
                //msexcel.Worksheet wstats = (msexcel.Worksheet)book.Sheets.Add(Missing.Value, book.Sheets.get_Item(1), Missing.Value, Missing.Value);


                msexcel.Worksheet wstats = null;
                for (int k = book.Worksheets.Count; k > 0; k--)
                {
                    Microsoft.Office.Interop.Excel.Worksheet wkSheet = (Microsoft.Office.Interop.Excel.Worksheet)book.Worksheets[k];
                    if (wkSheet.Name == "STATISTIC")
                    {
                        wstats = wkSheet;
                    }
                }                
                DataTableToExcelWorkSheet(wstats, dtStats, "STATISTIC", true);



               
                sheet.Select(Missing.Value);


                string filepath = execPath +  @"excel.template\excel-"+ Guid.NewGuid().ToString() +".xls";
                
                //range.CopyPicture(Microsoft.Office.Interop.Excel.XlPictureAppearance.xlPrinter, Microsoft.Office.Interop.Excel.XlCopyPictureFormat.xlBitmap);
                book.SaveAs(filepath, msexcel.XlFileFormat.xlWorkbookNormal, Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                    msexcel.XlSaveAsAccessMode.xlExclusive, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value); 
                //Debug.WriteLine(@"Values for Sheet " + sheet.Index);

              

                return filepath;


            }
            catch (Exception e)
            {
                //Debug.WriteLine(e);
                //throw new Exception("An error occured while importing excel file.", e) ;

               // if (System.IO.File.Exists(fileName))
                //{
                //    System.IO.File.Delete(fileName);
                //}

                throw e;
            }
            finally
            {
                //IntPtr returnPtr;
                //IntPtr excelPtr = GetWindowThreadProcessId(app.Hwnd, out returnPtr);

                lib.tfund.excel.helper.ReleaseRCM(range);
                range = null;

                if (book != null)
                    book.Close(false, Missing.Value, Missing.Value);
                lib.tfund.excel.helper.ReleaseRCM(book);
                book = null;
                helper.KillProcessExcel(app);
                app = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();

               // if (System.IO.File.Exists(fileName))
               // {
               //     System.IO.File.Delete(fileName);
               // }

                System.Threading.Thread.CurrentThread.CurrentCulture = oldCI;

            }


        }

            

      
    }
}
