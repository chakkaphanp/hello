﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace lib.tfund.excel
{
    public class Mapping
    {
        public string objFrom { get; set; }
        public string objTo { get; set; }

        public Mapping(XmlNode xNode)
        {
            this.objFrom = xNode.Attributes["From"].Value;
            this.objTo = xNode.Attributes["To"].Value;
        }
    }
}
