﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Data;
using Microsoft.Office.Interop;
using System.Reflection;
using Microsoft.Office.Interop.Excel;

namespace lib.tfund.excel
{
    public class Importer
    {
        

        /*public static void KillProcessExcel()
        {            
            foreach (Process proc in Process.GetProcessesByName("EXCEL"))
            {
                try
                {
                    if (proc.MainWindowTitle == string.Empty)
                    {
                        proc.Kill();
                    }
                }
                catch { }
            }           
        }*/


       

        
        
        public System.Data.DataTable ImportExcel(string fileName,int sheetIndex,string startCell,string endCell)
        {   
            Application app = new Application();
            Workbook book = null;
            Range range = null;           

            System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture(helper.GetConfig("CultureName"));
            System.Data.DataTable dt = new System.Data.DataTable();            

            try
            {
                app.Visible = false;
                app.ScreenUpdating = false;
                app.DisplayAlerts = false;
                app.UserControl = true;

                string execPath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);
                
                book = app.Workbooks.Open(fileName, Missing.Value, Missing.Value, Missing.Value
                                                  , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                 , Missing.Value, Missing.Value, Missing.Value, Missing.Value
                                                , Missing.Value, Missing.Value, Missing.Value);
                
                Worksheet sheet = (Worksheet)book.Worksheets[sheetIndex];
                
                    //Debug.WriteLine(@"Values for Sheet " + sheet.Index);

                    // get a range to work with
                    if (startCell != null && endCell != null)
                    {
                        range = sheet.get_Range(startCell, endCell);
                    }
                    else
                    {
                        range = sheet.UsedRange;
                    }

                    object[,] values = (object[,])range.Value2;
                    int colCount = values.GetLength(1);

                    for (int i = 0; i < colCount; i++)
                    {
                        dt.Columns.Add(i.ToString());
                    }

                    for (int i = 1; i <= values.GetLength(0); i++)
                    {
                        DataRow dr = dt.NewRow();

                        for (int j = 1; j <= colCount; j++)
                        {
                            if (values[i,j] != null && values[i, j].GetType() == typeof(double))
                            {
                                dr[j - 1] = ((double)values[i, j]).ToString("0");
                            }
                            else
                            {
                                dr[j - 1] = values[i, j];
                            }
                        }
                        dt.Rows.Add(dr);
                    }
                    

            }
            catch (Exception e)
            {
                //Debug.WriteLine(e);
                //throw new Exception("An error occured while importing excel file.", e) ;

                //if (System.IO.File.Exists(fileName))
                //{
                //    System.IO.File.Delete(fileName);
                //}

                TFUND.ErrorHelper.class_ErrorWriteLog logger = new TFUND.ErrorHelper.class_ErrorWriteLog();

                logger.WriteLog(e);

                throw e;
            }
            finally
            {
                //IntPtr returnPtr;
                //IntPtr excelPtr = GetWindowThreadProcessId(app.Hwnd, out returnPtr);

                lib.tfund.excel.helper.ReleaseRCM(range);
                range = null;

                if (book != null)
                    book.Close(false, Missing.Value, Missing.Value);
                lib.tfund.excel.helper.ReleaseRCM(book); 
                book = null;                
                helper.KillProcessExcel(app);
                app = null;                

                GC.Collect();
                GC.WaitForPendingFinalizers();

                //if (System.IO.File.Exists(fileName))
                //{
                //    System.IO.File.Delete(fileName);
                //}

                System.Threading.Thread.CurrentThread.CurrentCulture = oldCI;

            }

            return dt;

        }
        
    }
}
