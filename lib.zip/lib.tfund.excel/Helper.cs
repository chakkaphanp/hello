﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace lib.tfund.excel
{
    public class helper
    {

        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr GetWindowThreadProcessId(int hWnd, out IntPtr lpdwProcessId);

        public static void ReleaseRCM(object o)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(o);
            }
            catch
            {
                o = null;
            }
        }


        public static DateTime? ToDateTime(object obj)
        {
            if (obj != null)
            {
                return Convert.ToDateTime(obj);
            }
            else
            {
                return null;
            }
        }

        public static void KillProcessExcel(Microsoft.Office.Interop.Excel.Application app)
        {
            IntPtr returnPtr;
            IntPtr excelPtr = GetWindowThreadProcessId(app.Hwnd, out returnPtr);

            Process proc = Process.GetProcessById(returnPtr.ToInt32());

            if (proc != null)
            {
                if (proc.Responding)
                {                    
                    proc.Kill();
                }

            }
        }

        public static string GetConfig(string key)
        {

            System.Configuration.AppSettingsReader appSetting = new System.Configuration.AppSettingsReader();
            object o = appSetting.GetValue(key, typeof(string));

            return o.ToString();
        }

    }
}
