﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace lib.tfund.excel
{
    public class Formatter
    {
        public DataTable GetTable(DataTable dt,ColumnSettings settings)
        {


            
            DataTable result = new DataTable();
            int rowNum = 1;
            try
            {


                foreach (ColumnSettingInfo colSetting in settings.Columns)
                {
                    DataColumn col = new DataColumn(colSetting.Name, GetColumnType(colSetting.Type));
                    result.Columns.Add(col);
                }

                DataColumn col1 = new DataColumn("ROWNUM", typeof(int));
                result.Columns.Add(col1);

                
                foreach (DataRow item in dt.Rows)
                {
                    object obj = item[0];

                    if (obj != null)
                    {
                        if (ValidateValue(obj.ToString(), settings.FirstValueValidation) && rowNum >= settings.FirstDataRow)
                        {
                            DataRow dr = result.NewRow();
                            int iSkip = 0;
                            for (int i = 0; i < item.ItemArray.Length; i++)
                            {
                                if (i < item.ItemArray.Length)
                                {
                                    ColumnSettingInfo cs = settings.GetColumnSetting(i);
                                    if (cs != null)
                                    {
                                        string value = cs.MapValue(item[cs.Index - 1].ToString());
                                        dr[i - iSkip] = ConvertTo(value, result.Columns[i - iSkip].DataType);
                                    }
                                    else
                                    {
                                        iSkip++;
                                    }
                                }
                                else
                                {
                                    ColumnSettingInfo cs = settings.GetColumnSetting(i);

                                    if (cs != null)
                                    {
                                        dr[i - iSkip] = ConvertTo(cs.DefaultValue, result.Columns[cs.Index - 1].DataType);
                                    }
                                    else
                                    {
                                        iSkip++;
                                    }

                                }
                            }
                            dr[dr.ItemArray.Length - 1] = rowNum - settings.FirstDataRow + 1;
                            result.Rows.Add(dr);
                        }
                    }

                    rowNum++;
                }

            }catch(Exception ex)
            {
                throw new Exception("Error at row " + rowNum++ + " ==> Inner Exception : " + ex.ToString(), ex);
            }

            return result;
        }

        private bool ValidateValue(string val,string strRegex)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(strRegex, System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            return regex.IsMatch(val);
        }

        private Type GetColumnType(lib.tfund.excel.ColumnSettingInfo.DataType type)
        {
            switch (type)
            {
                case ColumnSettingInfo.DataType.Integer:
                    return typeof(int);
                case ColumnSettingInfo.DataType.Double:
                    return typeof(double);
                case ColumnSettingInfo.DataType.String:
                    return typeof(string);
                case ColumnSettingInfo.DataType.Date:
                    return typeof(DateTime);
                case ColumnSettingInfo.DataType.DateTime:
                    return typeof(DateTime);
                case ColumnSettingInfo.DataType.Boolean:
                    return typeof(bool);
                default:
                    return typeof(string);
            }
        }

        private object ConvertTo(object val, Type type)
        {
            string typeName = type.FullName;
            switch (typeName)
            {
                case "System.String":
                    return this.ConvertToString(val).Trim();
                case "System.DateTime":
                    return this.ConvertToDateTime(val);
                case "System.Double":
                    return this.ConvertToDouble(val);
                case "System.Boolean":
                    return this.ConvertToBoolean(val);                
                default:
                    return val;
            }

        }

        private string ConvertToString(object val)
        {
            if (val != null && val != DBNull.Value)
            {
                string result = "";
                try
                {
                    result = Convert.ToString(val).Trim();
                }
                catch 
                {
                    result = "";
                }

                return result;
            }
            else
            {
                return "";
            }
        }

        private DateTime ConvertToDateTime(object val)
        {
            if (val != null)
            {
                try
                {
                    double d = Convert.ToDouble(val);
                    DateTime result = DateTime.FromOADate(d);

                    return result;
                }
                catch (FormatException fex)
                {
                    try
                    {
                        System.Globalization.CultureInfo thaiCulture = System.Globalization.CultureInfo.GetCultureInfo("th-TH");
                        DateTime result = DateTime.ParseExact(val.ToString(), thaiCulture.DateTimeFormat.ShortDatePattern, thaiCulture.DateTimeFormat);

                        return result;
                    }
                    catch
                    {
                        return DateTime.MinValue;
                    }
                    
                }
                catch (Exception ex)
                {
                    return DateTime.MinValue;
                }
                
            }
            else
            {
                return DateTime.MinValue;
            }
        }

        private object ConvertToDouble(object val)
        {
            try
            {
                if (val != null && val != DBNull.Value && (string)val != string.Empty)
                {
                    return Convert.ToDouble(val);
                }
                else
                {
                    return DBNull.Value;
                }
            }
            catch (Exception)
            {
                return DBNull.Value;
            }
        }

        private object ConvertToInt32(object val)
        {
            try
            {
                if (val != null && val != DBNull.Value && val.ToString() != string.Empty)
                {
                    return Convert.ToInt32(val);
                }
                else
                {
                    return DBNull.Value;
                }
            }
            catch (Exception)
            {
                return DBNull.Value;
            }

        }

        private object ConvertToBoolean(object val)
        {
            try
            {
                if (val != null && val != DBNull.Value && val.ToString() != string.Empty)
                {
                    return Convert.ToBoolean(val);
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }


    }
}
