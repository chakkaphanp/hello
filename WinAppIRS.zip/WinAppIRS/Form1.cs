﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml;
using System.Text;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Drawing;
using System.Linq;
using WinSCP;
using System.Data;
using System.Xml.Serialization;
using System.Diagnostics;

namespace TFUND.App.FATCA
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }



        private void btnBrowseXml_Click(object sender, EventArgs e)
        {
            if (chkSendFolder.Checked == true)
            {
                // Select folder location that holds all 8966 XML files to process
                if (dlgOpenFolder.ShowDialog() == DialogResult.OK)
                {
                    txtXmlFile.Text = dlgOpenFolder.SelectedPath;
                }

            }
            else
            {

                // load XML
                txtXmlFile.Text = dlgOpen.ShowDialogWithFilter("XML Files (*.xml, *.pdf)|*.xml;*.pdf");

            }
        }

        private void btnBrowseCert_Click(object sender, EventArgs e)
        {
            // load certificate
            txtCert.Text = dlgOpen.ShowDialogWithFilter("Signing Certificates (*.pfx, *.p12)|*.pfx;*.p12");
        }

        private void btnBrowseKeyCert_Click(object sender, EventArgs e)
        {
            // load AES key encryption certificate
            txtKeyCert.Text = dlgOpen.ShowDialogWithFilter("Certificate Files (*.cer, *.pfx, *.p12)|*.cer;*.pfx;*.p12");
        }

        private void btnSignXML_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtXmlFile.Text))
            {
                // files validation
                MessageBox.Show("The XML file was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCert.Text))
            {
                // files validation
                MessageBox.Show("The Signing Certificate was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCertPass.Text))
            {
                // certificate password validation
                MessageBox.Show("Signing Certificate password was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtKeyCert.Text))
            {
                // files validation
                MessageBox.Show("Encryption Certificate was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (chkSchemaValidation.Checked == true && string.IsNullOrWhiteSpace(txtSchemaFolder.Text))
            {
                // files validation
                MessageBox.Show("Schema Validation selected but Schema Folder was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //this will be used as a holder for processed files if a folder is being sent
            string processedFolder = "";

            try
            {

                //if we are sending a folder, we will load up the files into an array to process
                //otherwise, we will just load our file in the array
                string[] filesToProcess;
                if (chkSendFolder.Checked == false)
                {
                    filesToProcess = new string[1];
                    filesToProcess[0] = txtXmlFile.Text;
                }
                else
                {
                    // Load all XML files in the folder into an array
                    filesToProcess = Directory.GetFiles(txtXmlFile.Text, "*.xml", SearchOption.TopDirectoryOnly);
                    processedFolder = txtXmlFile.Text + "\\Processed";

                    //if the processedFolder doesn't exist, create it
                    if (!Directory.Exists(processedFolder))
                    {
                        Directory.CreateDirectory(processedFolder);
                    }
                }

                //This will loop through all files in the array
                //This will be one file or it could be a set of files in a folder
                string currentFileToProcess = "";
                foreach (string fileName in filesToProcess)
                {
                    currentFileToProcess = fileName;


                    if (Path.GetDirectoryName(currentFileToProcess).Contains("_"))
                    {
                        MessageBox.Show("Directory path must not contain _ ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); 

                        return;
                    }


                    //if the file we are processing has an underscore we will split it off for logging
                    //this should only happen for bulk sending from a folder
                    if (currentFileToProcess.Contains("_"))
                    {
                        string[] filePart = fileName.Split('_');
                        currentFileToProcess = txtXmlFile.Text + "\\" + filePart[1];
                        //Rename the file so we can process it
                        File.Move(fileName, currentFileToProcess);
                    }

                    // perform the schema validation if we have the checkbox checked for it
                    if (chkSchemaValidation.Checked)
                    {
                        string validationError = XmlManager.CheckSchema(currentFileToProcess, txtSchemaFolder.Text);
                        if (validationError != "")
                        {
                            // Show schema validation error(s)
                            MessageBox.Show("Schema Validation Error:\r\n" + validationError, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // load XML file content
                    byte[] xmlContent = File.ReadAllBytes(currentFileToProcess);
                    string senderGIIN = Path.GetFileNameWithoutExtension(currentFileToProcess);
                    string filePath = Path.GetDirectoryName(currentFileToProcess);
                    string fileExtension = Path.GetExtension(currentFileToProcess.ToUpper()).Replace(".", "");
                    bool isXML = true;

                    if (fileExtension != "XML")
                    {
                        isXML = false;
                    }

                    // perform signature
                    byte[] envelopingSignature;
                    string envelopingFileName = "";

                    //if the file is XML we will use the enveloping digital signature for the XML
                    if (isXML == true)
                    {
                        envelopingSignature = XmlManager.Sign(XmlSignatureType.Enveloping, xmlContent, txtCert.Text, txtCertPass.Text, filePath);
                        envelopingFileName = currentFileToProcess.Replace(".xml", "_Payload.xml");
                    }
                    //if the file is NOT XML, we will convert the file data to base64 and put in XML and sign it
                    else
                    {
                        envelopingSignature = XmlManager.Sign(XmlSignatureType.NonXML, xmlContent, txtCert.Text, txtCertPass.Text, filePath);
                        envelopingFileName = currentFileToProcess.ToUpper().Replace(".PDF", "_Payload.xml");
                    }

                    string zipFileName = envelopingFileName.Replace(".xml", ".zip");

                    // save enveloping version to disk
                    File.WriteAllBytes(envelopingFileName, envelopingSignature);

                    // add enveloping signature to ZIP file
                    ZipManager.CreateArchive(envelopingFileName, zipFileName);

                    // generate AES key (32 bytes) & default initialization vector (empty)
                    byte[] aesEncryptionKey = AesManager.GenerateRandomKey(AesManager.KeySize / 8);
                    byte[] aesEncryptionVector = AesManager.GenerateRandomKey(16, radECB.Checked);

                    // encrypt file & save to disk
                    string encryptedFileName = zipFileName.Replace(".zip", "");
                    string encryptedHCTAFileName = zipFileName.Replace(".zip", "");
                    string payloadFileName = encryptedFileName + "";
                    AesManager.EncryptFile(zipFileName, encryptedFileName, aesEncryptionKey, aesEncryptionVector, radECB.Checked);

                    // encrypt key with public key of certificate & save to disk
                    encryptedFileName = Path.GetDirectoryName(zipFileName) + "\\000000.00000.TA.840_Key"; ;
                    AesManager.EncryptAesKey(aesEncryptionKey, aesEncryptionVector, txtKeyCert.Text, txtKeyCertPassword.Text, encryptedFileName, radECB.Checked);
                    //For Model1 Option2 Only, encrypt the AES Key with the HCTA Public Key
                    if (chkM1O2.Checked)
                    {
                        encryptedHCTAFileName = Path.GetDirectoryName(zipFileName) + "\\000000.00000.TA." + txtHCTACode.Text + "_Key";
                        AesManager.EncryptAesKey(aesEncryptionKey, aesEncryptionVector, txtHCTACert.Text, txtHCTACertPassword.Text, encryptedHCTAFileName, radECB.Checked);
                    }

                    // cleanup
                    envelopingSignature = null;
                    aesEncryptionKey = aesEncryptionVector = null;

                    

                    try
                    {
                        DateTime uDat = new DateTime();
                        uDat = DateTime.UtcNow;
                        string senderFile = uDat.ToString("yyyyMMddTHHmmssfffZ") + "_" + senderGIIN;
                        string metadataFileName = filePath + "\\" + senderGIIN + "_Metadata.xml";
                        XmlManager.CreateMetadataFile(metadataFileName, fileExtension, isXML, cmbTaxYear.SelectedItem.ToString(), senderGIIN,  senderFile , txtSenderEmail.Text);

                        //Check the signature to make sure it is valid, this requires the KeyInfo to be present
                        //This is controlled using the checkbox on the form
                        //This should be commented out or not selected if not using the KeyInfo in the XmlManager class
                        if (chkSignatureValidation.Checked)
                        {
                            bool result = XmlManager.CheckSignature(envelopingFileName);
                            if (result == false)
                            {
                                MessageBox.Show("Signature is not valid!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }

                        //Add the metadata, payload, and key files to the final zip package
                        // add enveloping signature to ZIP file
                        ZipManager.CreateArchive(metadataFileName, filePath + "\\" + senderFile + ".zip");
                        ZipManager.UpdateArchive(encryptedFileName, filePath + "\\" + senderFile + ".zip");
                        ZipManager.UpdateArchive(payloadFileName, filePath + "\\" + senderFile + ".zip");
                        //Add the HCTA Key file for a M1O2 packet
                        if (chkM1O2.Checked)
                        {
                            ZipManager.UpdateArchive(encryptedHCTAFileName, filePath + "\\" + senderFile + ".zip");
                        }


                        
                        if (chkAutoSendSFTP.Checked == true)
                        {
                            SessionOptions currentSFTPSession = SFTPManager.CreateSFTPSession(cmbSFTPServers.SelectedItem.ToString(), username.Text, password.Text);
                            string sftpUpName = filePath + "\\" + senderFile + ".zip";
                            string transferResult = SFTPManager.UploadFile(currentSFTPSession, sftpUpName);
                            //This can be commented out if there is no desire to see an upload confirmation
                            MessageBox.Show(transferResult, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            
                            //write to log
                            string path = @"simplelog.csv";
                            // This text is added only once to the file.
                            string lineToLog = fileName + "," + currentFileToProcess + "," + senderFile + ",IDESTRANSID,NOTIFICATIONID,NULL,ERRORCOUNT";
                            if (!File.Exists(path))
                            {
                                // Create a file to write to.
                                using (StreamWriter sw = File.CreateText(path))
                                {
                                    sw.WriteLine(lineToLog);
                                }
                            }
                            else
                            { 
                                // This text is always added, making the file longer over time
                                // if it is not deleted.
                                using (StreamWriter sw = File.AppendText(path))
                                {
                                    sw.WriteLine(lineToLog);
                                }
                            }
                        }
                        if (chkSendFolder.Checked == true)
                        { 
                        //Move the file to a processed folder so we can move on to the next
                        //This is only used when sending an entire folder
                        File.Move(currentFileToProcess, processedFolder + "\\" + Path.GetFileName(fileName));
                        }


                    }
                    catch (Exception ex)
                    {
                        ex.DisplayException(Text);
                        return;
                    }
                    finally
                    {
                       
                    }

                }
                // success
                MessageBox.Show("XML Signing and Encryption process is complete!", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                ex.DisplayException(Text);
            }
        }

        private void btnBrowseNotificationZip_Click(object sender, EventArgs e)
        {
            // load Notification Zip file
            txtNotificationZip.Text = dlgOpen.ShowDialogWithFilter("ZIP Files (*.zip)|*.zip");
        }

        private void btnBrowseRecCert_Click(object sender, EventArgs e)
        {
            // load Notification Receiver key
            txtReceiverCert.Text = dlgOpen.ShowDialogWithFilter("Certificate Files (*.cer, *.pfx, *.p12)|*.cer;*.pfx;*.p12");
        }

        private void btnDecryptZip_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtNotificationZip.Text) || string.IsNullOrWhiteSpace(txtReceiverCert.Text))
            {
                // files validation
                MessageBox.Show("Either the ZIP file or certificate was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string zipFolder = "";
            try
            {
                //Deflate the zip archive
                zipFolder = ZipManager.ExtractArchive(txtNotificationZip.Text, txtNotificationFolder.Text);

            }
            catch (Exception ex)
            {
                ex.DisplayException(Text);
                return;
            }

            //Decrypt the Payload
            string decryptedPayload = "";
            try
            {
                decryptedPayload = AesManager.DecryptNotification(zipFolder, txtReceiverCert.Text, txtRecKeyPassword.Text, radECB.Checked);
            }
            catch (Exception ex)
            {
                ex.DisplayException("Decryption Failed:" + Text);
                return;
            }

            // success
            MessageBox.Show("Decryption process is complete!", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);



        }

        private void btnBrowseOutput_Click(object sender, EventArgs e)
        {
            // load AES key encryption certificate
            if (dlgOpenFolder.ShowDialog() == DialogResult.OK)
            {
                txtNotificationFolder.Text = dlgOpenFolder.SelectedPath;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        private void MainForm_Load(object sender, EventArgs e)
        {
            lblHCTAKey.Visible = false;
            txtHCTACert.Visible = false;
            btnBrowseHCTACert.Visible = false;
            lblEncryptionHCTAPassword.Visible = false;
            txtHCTACertPassword.Visible = false;
            lblHCTACode.Visible = false;
            txtHCTACode.Visible = false;

            this.Text = Application.ProductName + " " +  Application.ProductVersion;

            this.toolStripStatusLabel1.Text = Application.ProductVersion;

            
            //Populate tax year combo box, this will contain the current year back to the first reporting year of 2014
            for (int i = DateTime.Now.Year; i >= 2014; i--)
            {
                cmbTaxYear.Items.Add(i);
            }
            cmbTaxYear.SelectedItem = DateTime.Now.Year - 1;

            //Default the CBC checkbox to on
            radCBC.Checked = true;


            //Add the SFTP Servers
            cmbSFTPServers.Items.Add("PRODUCTION: WWW.IDESGATEWAY.COM");
            cmbSFTPServers.Items.Add("TEST: WWWPSE.IDESGATEWAY.COM");
            cmbSFTPServers.Items.Add("SAT: WWWSAT.IDESGATEWAY.COM");
            cmbSFTPServers.SelectedItem = "PRODUCTION: WWW.IDESGATEWAY.COM";



            // Pre-load schema and cert path 
            txtSchemaFolder.Text = Application.StartupPath + @"\Schema";
            txtCert.Text = Application.StartupPath + @"\cert\TFUND\fatca.thanachartfund.com.private.pfx"; //TFUND cert
            txtKeyCert.Text = Application.StartupPath + @"\cert\IRS\encryption-service_services_irs_gov.cer"; //IRS cert
            txtHCTACert.Text = Application.StartupPath + @"\cert\rd\rd_th.cer"; //RD TH cert


            //populate DocTypeIndic 
            cmbDocTypeIndic.DataSource = Enum.GetNames(typeof( FatcaDocTypeIndic_EnumType));
            cmbDocTypeIndic.Text = "FATCA11"; //we default it with test mode 

        }





        private void chkM1O2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkM1O2.Checked)
            {
                this.lblHCTAKey.Location = new Point(
                this.lblHCTAKey.Location.X,
                this.lblHCTAKey.Location.Y - 40
                );
                this.btnBrowseHCTACert.Location = new Point(
                this.btnBrowseHCTACert.Location.X,
                this.btnBrowseHCTACert.Location.Y - 40
                );
                this.txtHCTACert.Location = new Point(
                this.txtHCTACert.Location.X,
                this.txtHCTACert.Location.Y - 40
                );
                this.lblEncryptionHCTAPassword.Location = new Point(
                this.lblEncryptionHCTAPassword.Location.X,
                this.lblEncryptionHCTAPassword.Location.Y - 40
                );
                this.txtHCTACertPassword.Location = new Point(
                this.txtHCTACertPassword.Location.X,
                this.txtHCTACertPassword.Location.Y - 40
                );
                this.lblHCTACode.Location = new Point(
                this.lblHCTACode.Location.X,
                this.lblHCTACode.Location.Y - 40
                );
                this.txtHCTACode.Location = new Point(
                this.txtHCTACode.Location.X,
                this.txtHCTACode.Location.Y - 40
                );
                this.btnSignXML.Location = new Point(
                this.btnSignXML.Location.X,
                this.btnSignXML.Location.Y + 140
                );


                lblHCTAKey.Visible = true;
                txtHCTACert.Visible = true;
                btnBrowseHCTACert.Visible = true;
                lblEncryptionHCTAPassword.Visible = true;
                txtHCTACertPassword.Visible = true;
                lblHCTACode.Visible = true;
                txtHCTACode.Visible = true;
            }
            else
            {
                this.lblHCTAKey.Location = new Point(
                this.lblHCTAKey.Location.X,
                this.lblHCTAKey.Location.Y + 40
                );
                this.btnBrowseHCTACert.Location = new Point(
                this.btnBrowseHCTACert.Location.X,
                this.btnBrowseHCTACert.Location.Y + 40
                );
                this.txtHCTACert.Location = new Point(
                this.txtHCTACert.Location.X,
                this.txtHCTACert.Location.Y + 40
                );
                this.lblEncryptionHCTAPassword.Location = new Point(
                this.lblEncryptionHCTAPassword.Location.X,
                this.lblEncryptionHCTAPassword.Location.Y + 40
                );
                this.txtHCTACertPassword.Location = new Point(
                this.txtHCTACertPassword.Location.X,
                this.txtHCTACertPassword.Location.Y + 40
                );
                this.lblHCTACode.Location = new Point(
                this.lblHCTACode.Location.X,
                this.lblHCTACode.Location.Y + 40
                );
                this.txtHCTACode.Location = new Point(
                this.txtHCTACode.Location.X,
                this.txtHCTACode.Location.Y + 40
                );
                this.btnSignXML.Location = new Point(
                this.btnSignXML.Location.X,
                this.btnSignXML.Location.Y - 140
                );

                lblHCTAKey.Visible = false;
                txtHCTACert.Visible = false;
                btnBrowseHCTACert.Visible = false;
                lblEncryptionHCTAPassword.Visible = false;
                txtHCTACertPassword.Visible = false;
                lblHCTACode.Visible = false;
                txtHCTACode.Visible = false;
            }

        }

        private void btnBrowseHCTACert_Click(object sender, EventArgs e)
        {
            // load AES key encryption certificate
            txtHCTACert.Text = dlgOpen.ShowDialogWithFilter("Certificate Files (*.cer, *.pfx, *.p12)|*.cer;*.pfx;*.p12");
        }

      

        private void cmdCheckSignature_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSignedPayloadFile.Text))
            {
                // files validation
                MessageBox.Show("The Signed Payload File was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // register SHA-256 and open certificate with exportable private key
            CryptoConfig.AddAlgorithm(typeof(RSAPKCS1SHA256SignatureDescription), RSAPKCS1SHA256SignatureDescription.SignatureMethod);

            //Check the signature to make sure it is valid, this requires the KeyInfo to be present
            //This should be commented out if not using the KeyInfo in the XmlManager class 
           
            try{
                bool result = XmlManager.CheckSignature(txtSignedPayloadFile.Text); 
                if (result == false)
                {
                    MessageBox.Show("Signature is not valid!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show("Signature is valid!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ex.DisplayException(Text);
                return;
            }

        }

        private void btnBrowsePayload_Click(object sender, EventArgs e)
        {
            {
                // load Signed Payload file, must be unencrypted and have KeyInfo element
                txtSignedPayloadFile.Text = dlgOpen.ShowDialogWithFilter("Signed Payload File (*.xml)|*.xml;");
            }
        }

        //this can be used to autopopulate these boxes during test periods
        private void cmdPopulateSettings_Click(object sender, EventArgs e)
        {
            txtXmlFile.Text = "";
            txtCert.Text = "";
            txtCertPass.Text = "";
            txtKeyCert.Text = "";
        }



        private void btnSchemaFile_Click(object sender, EventArgs e)
        {
            {
                // load Signed Payload file, must be unencrypted and have KeyInfo element
                txtSchemaFile.Text = dlgOpen.ShowDialogWithFilter("8966 XML File (*.xml)|*.xml;");
            }
        }

        private void btnSchemaFolder_Click(object sender, EventArgs e)
        {
            // Select folder location that holds all 8966 schema files
            if (dlgOpenFolder.ShowDialog() == DialogResult.OK)
            {
                txtSchemaFolder.Text = dlgOpenFolder.SelectedPath;
            }
        }

        private void btnCheckSchema_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSchemaFile.Text))
            {
                // files validation
                MessageBox.Show("The XML File To Validate was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtSchemaFolder.Text))
            {
                // files validation
                MessageBox.Show("The Schema Folder location was not specified!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                string validationError = XmlManager.CheckSchema(txtSchemaFile.Text, txtSchemaFolder.Text);
                if (validationError != "")
                {
                    // files validation
                    MessageBox.Show("Schema Validation Error:\r\n" + validationError, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
                else
                {
                    // files validation
                    MessageBox.Show("Validation Successful", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
             }
            catch (Exception ex)
            {
                ex.DisplayException("Schema Validation Failure: " + Text);
                return;
            }
        }


        private void chkSendFolder_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSendFolder.Checked)
            {
                lblLoadXML.Text = "XML Folder";
            }
            else
            {
                lblLoadXML.Text = "XML File";
            }
        }

        private void btnCheckNotification_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDecryptKey.Text))
            {
                // files validation
                MessageBox.Show("The Receiver's key for decryption must be set!", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Char delimiter = ',';
            Dictionary<string, string> transmissions = new Dictionary<string, string>();

            try
            {   // Open the text file using a stream reader.
                using (StreamReader sr = new StreamReader("simplelog.csv"))
                {
                    while (sr.Peek() >= 0)
                    {
                        String line = sr.ReadLine();
                        string[] strLineArray = line.Split(delimiter);
                    
                        //if there is no notification id, we will store the file name
                        if (strLineArray[4] == "NOTIFICATIONID")
                        {
                            transmissions.Add(strLineArray[2], line);
                        }
                        else
                        // otherwise, we store the notification id, and we can ignore this file if it is in the inbox
                        {
                            transmissions.Add(strLineArray[4], line);
                        }
                        Console.WriteLine(line);
                    }
                }


            }
            catch (Exception ex)
            {
                ex.DisplayException(Text);
                return;
            }

            //Connect to the Inbox and see if there are any files
            try
            {
                // Setup session options
                SessionOptions currentSFTPSession = SFTPManager.CreateSFTPSession(cmbSFTPServers.SelectedItem.ToString(), username.Text, password.Text);
                SFTPManager.DownloadInbox(currentSFTPSession, transmissions, txtDownFolder.Text);
                            
            }
            catch (Exception ex)
            {
                ex.DisplayException(Text);
                return;
            }

            //loop through the files we have downloaded and process them
            //these files will be matched to our log file to see if we have any matches

            string[] filesToProcess;
            string xmlProcessedFolder = "";
            string xmlProcessingFolder = "";
            string xmlProcessedUnmatchedFolder = "";
            string destinationFolder = "";

            // Load all XML files in the folder into the array
            filesToProcess = Directory.GetFiles(txtDownFolder.Text, "*.zip", SearchOption.TopDirectoryOnly);
            xmlProcessedFolder = txtDownFolder.Text + "\\Processed";
            xmlProcessingFolder = txtDownFolder.Text + "\\Processing";
            xmlProcessedUnmatchedFolder = txtDownFolder.Text + "\\Processed\\Unmatched";

            //if the processedFolder doesn't exist, create it
            if (!Directory.Exists(xmlProcessedFolder))
            {
                Directory.CreateDirectory(xmlProcessedFolder);
            }
            //if the processedUnmatchedFolder doesn't exist, create it
            if (!Directory.Exists(xmlProcessedUnmatchedFolder))
            {
                Directory.CreateDirectory(xmlProcessedUnmatchedFolder);
            }
            //if the processingFolder doesn't exist, create it
            if (!Directory.Exists(xmlProcessingFolder))
            {
                Directory.CreateDirectory(xmlProcessingFolder);
            }
           
            //loop through the downloaded files
            int matchCounter = 0;
            int unmatchCounter = 0;
            foreach (string fileName in filesToProcess)
            {
                try
                {
                    //clean out the processing folder, the current file will be unzipped into it
                    DirectoryInfo dir = new DirectoryInfo(xmlProcessingFolder);
                    foreach (FileInfo fi in dir.GetFiles())
                    {
                        fi.Delete();
                    }
                    //Deflate the zip archive
                    ZipManager.ExtractArchive(fileName, xmlProcessingFolder, false);
                }
                catch (Exception ex)
                {
                    ex.DisplayException(Text);
                    return;
                }

                string decryptedPayload = "";
                try
                {
                    decryptedPayload = AesManager.DecryptNotification(xmlProcessingFolder, txtDecryptKey.Text, txtDecryptPassword.Text, radECB.Checked);
                }
                catch (Exception ex)
                {
                    ex.DisplayException("Decryption Failed:" + Text);
                    return;
                }
                          
                //take a look at the decrypted payload and see if this notification matches anything we are looking for
                string[] notificationID = new string[3];
                string notificationFileName = Path.GetFileNameWithoutExtension(fileName);
                bool isFileMatched = false;
                
                //This will return three values
                //0 Ides Transmission ID
                //1 Sender FIle Id
                //2 Return Code
                notificationID = XmlManager.CheckNotification(decryptedPayload);
                
                //Check our log file dictionary and see if we can find a match
                if (transmissions.ContainsKey(notificationID[1]) == true)
                {
                    isFileMatched = true;
                    
                    //we will add a new record to reflect the updated information and remove the old record   
                    //make sure the filename is in our transmissions and return the current log data for it
                    string currentNotificationData = "";
                    transmissions.TryGetValue(notificationID[1],out currentNotificationData);

                    //update the current notification Data before we add the new record
                    //we will take fields from the decrypted notification and insert it back in
                    currentNotificationData = currentNotificationData.Replace("NOTIFICATIONID", Path.GetFileName(fileName));
                    currentNotificationData = currentNotificationData.Replace("IDESTRANSID", notificationID[0]);
                    currentNotificationData = currentNotificationData.Replace("NULL", notificationID[2]);
                    currentNotificationData = currentNotificationData.Replace("ERRORCOUNT", notificationID[3]);

                    //add new record with updated information
                    transmissions.Add(Path.GetFileName(fileName), string.Join(",", currentNotificationData));
                    
                    //we can remove the old record now
                    transmissions.Remove(notificationID[1]);

                    //we will write the current transmissions back into the log file so we keep it updated with the latest information
                    //write to log
                    string filePath = @"simplelog.csv";
                    using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
                    {
                        using (TextWriter tw = new StreamWriter(fs))

                            foreach (KeyValuePair<string, string> kvp in transmissions)
                            {
                                tw.WriteLine(string.Format("{0}", kvp.Value));
                            }
                    }
                    //processing of the file is complete
                    
                }
                //the decrypted files will be moved to the Processed folder for safekeeping
                //if no match is found, it moves to the Unmatched subfolder
                DirectoryInfo dirProcessing = new DirectoryInfo(xmlProcessingFolder);
                if (isFileMatched == true)
                {
                    destinationFolder = xmlProcessedFolder;
                    if (!Directory.Exists(xmlProcessedFolder + "\\" + notificationFileName))
                    {
                        Directory.CreateDirectory(xmlProcessedFolder + "\\" + notificationFileName);
                    }
                    matchCounter = matchCounter + 1;   
                }
                else{
                    destinationFolder = xmlProcessedUnmatchedFolder;
                    //if this non-matching file has already been pulled, remove the old and replace with the new
                    if (Directory.Exists(xmlProcessedUnmatchedFolder + "\\" + notificationFileName))
                    {
                        //clean out the folder, it will get the current decrypted contents
                        DirectoryInfo dir = new DirectoryInfo(xmlProcessedUnmatchedFolder + "\\" + notificationFileName);
                        foreach (FileInfo fi in dir.GetFiles())
                        {
                            fi.Delete();
                        }
                    }
                    else
                    {
                        Directory.CreateDirectory(xmlProcessedUnmatchedFolder + "\\" + notificationFileName);
                    }              
                    unmatchCounter = unmatchCounter + 1;   
                }
                
                //move from the processing folder
                foreach (FileInfo fi in dirProcessing.GetFiles())
                {
                    File.Move(fi.FullName, Path.Combine(destinationFolder, notificationFileName, fi.Name));
                }
                //Rename the file so we can process it
                File.Move(fileName, Path.Combine(destinationFolder, notificationFileName, Path.GetFileName(fileName)));
            }
            MessageBox.Show(matchCounter + " matching files found\n" + unmatchCounter + " non-matching files found");
        }

        private void btnBrowseDecKey_Click(object sender, EventArgs e)
        {
            // load Notification Receiver key
            txtDecryptKey.Text = dlgOpen.ShowDialogWithFilter("Certificate Files (*.cer, *.pfx, *.p12)|*.cer;*.pfx;*.p12");   
        }

        private void btnBrowseDownloadFolder_Click(object sender, EventArgs e)
        {
            // Select folder location that holds all 8966 XML files to process
            if (dlgOpenFolder.ShowDialog() == DialogResult.OK)
            {
               txtDownFolder.Text = dlgOpenFolder.SelectedPath;
            }
        }

        private void btnOpenExcel_Click(object sender, EventArgs e)
        {
            txtExcelFile.Text = dlgOpenExcel.ShowDialogWithFilter("Excel Files (*.xls, *.xlsx)|*.xls;*.xlsx");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!txtExcelFile.Text.Equals(String.Empty))
            {
                //Open excel file and load it to datatable 
                string masterColSettingFile = Application.StartupPath + @"\ColSettings\ColSettings-Master.xml";
                lib.tfund.excel.ColumnSettings masterSetting = new lib.tfund.excel.ColumnSettings(masterColSettingFile);
                string accountDataColSettingFile = Application.StartupPath + @"\ColSettings\ColSettings-AccountData.xml";
                lib.tfund.excel.ColumnSettings accountDataSetting = new lib.tfund.excel.ColumnSettings(accountDataColSettingFile);
               
                DataTable dtMaster = LoadExcel(txtExcelFile.Text,1, masterSetting);

                if (dtMaster.Rows.Count > 0)
                {
                    DataRow dr = dtMaster.Rows[0];

                    string GIIN = dr["GIIN"].ToString();
                    string ReportingPeriod = dr["ReportingPeriod"].ToString().Trim();
                    string InstitutionName = dr["InstitutionName"].ToString().Trim();
                    string InstitutionAddress = dr["InstitutionAddress"].ToString().Trim();
                    string InstitutionCountry = dr["InstitutionCountry"].ToString().Trim();


                    lblGIIN.Text = GIIN;
                    lblReportingPeriod.Text = ReportingPeriod;
                    lblInstitutionName.Text = InstitutionName;
                    lblInstitutionAddress.Text  = InstitutionAddress;
                    lblInstitutionCountry.Text = InstitutionCountry;  
                   


                }




                DataTable dtAccount = LoadExcel(txtExcelFile.Text, 2, accountDataSetting);
                gvAccountData.DataSource = dtAccount;
            }
            else
            {
                MessageBox.Show("Please select Excel file to preview", "Error"
                    , MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }



        private DataTable LoadExcel(string fileName, int sheetIndex, lib.tfund.excel.ColumnSettings cols)
        {
            try
            {
              

               

                    lib.tfund.excel.Importer imp = new lib.tfund.excel.Importer();
                    DataTable dtRaw = imp.ImportExcel(fileName, sheetIndex, null, null);

                    lib.tfund.excel.Formatter formatter = new lib.tfund.excel.Formatter();
                    DataTable dtExp = formatter.GetTable(dtRaw, cols);
                    //System.IO.File.Delete(fileName);


                    return dtExp;
               

                return null;
            }
            catch (Exception ex)
            {
              
                return null;
            }
        }

        private void btnGenXML_Click(object sender, EventArgs e)
        {
            ///TODO: Clean SQL injection -- , /* , &#
            

            Guid docRef = Guid.NewGuid();

            FATCA_OECD fatcaDoc = new FATCA_OECD();
            fatcaDoc.version = "2";
            //FATCA_OECD>MessageSpec
            fatcaDoc.MessageSpec = new MessageSpec_Type();
            /// SendingCompanyIN ==> Thai RD 000000.00000.TA.764
            fatcaDoc.MessageSpec.SendingCompanyIN = "000000.00000.TA.764"; 
            fatcaDoc.MessageSpec.TransmittingCountry = CountryCode_Type.TH;
            fatcaDoc.MessageSpec.ReceivingCountry = CountryCode_Type.US;
            fatcaDoc.MessageSpec.MessageType = MessageType_EnumType.FATCA;
            fatcaDoc.MessageSpec.MessageRefId = docRef.ToString();
            fatcaDoc.MessageSpec.ReportingPeriod = DateTime.Parse(lblReportingPeriod.Text);
            fatcaDoc.MessageSpec.Timestamp = DateTime.Now;
            fatcaDoc.MessageSpec.Contact =  txtSenderEmail.Text.RemoveSQLInjection();

            //FATCA_OECD>FATCA
            fatcaDoc.FATCA = new Fatca_Type[1];
            fatcaDoc.FATCA[0] = new Fatca_Type();
            Fatca_Type fatca = fatcaDoc.FATCA[0];

            //FATCA_OECD>FATCA>ReportingFI
            fatca.ReportingFI = new CorrectableReportOrganisation_Type();
            //

            //FATCA_OECD>FATCA>ReportingFI>NAME
            fatca.ReportingFI.Name = new NameOrganisation_Type[1];
            fatca.ReportingFI.Name[0] = new NameOrganisation_Type();
            fatca.ReportingFI.Name[0].Value = lblInstitutionName.Text.RemoveSQLInjection();
            //FATCA_OECD>FATCA>ReportingFI>TIN
            fatca.ReportingFI.TIN = new TIN_Type[1];
            fatca.ReportingFI.TIN[0] = new TIN_Type();
            fatca.ReportingFI.TIN[0].Value = lblGIIN.Text.RemoveSQLInjection();

            fatca.ReportingFI.FilerCategory = FatcaFilerCategory_EnumType.FATCA604;
            fatca.ReportingFI.FilerCategorySpecified = true;

            //FATCA_OECD>FATCA>ReportingFI>Address
            fatca.ReportingFI.Address = new Address_Type[1];
            fatca.ReportingFI.Address[0] = new Address_Type();
            fatca.ReportingFI.Address[0].CountryCode = CountryCode_Type.TH;
            fatca.ReportingFI.Address[0].Items = new string[1];
            fatca.ReportingFI.Address[0].Items[0] = lblInstitutionAddress.Text.RemoveSQLInjection(); 
            //FATCA_OECD>FATCA>ReportingFI>DocSpec
            fatca.ReportingFI.DocSpec = new DocSpec_Type();
            fatca.ReportingFI.DocSpec.DocTypeIndic = (FatcaDocTypeIndic_EnumType)Enum.Parse(typeof(FatcaDocTypeIndic_EnumType),cmbDocTypeIndic.Text);
            fatca.ReportingFI.DocSpec.DocRefId = GetDocRefID(lblGIIN.Text);


            //FATCA_OECD>FATCA>ReportingGroup
            fatca.ReportingGroup = new Fatca_TypeReportingGroup[1];
            fatca.ReportingGroup[0] = new Fatca_TypeReportingGroup();
            
            
            //FATCA_OECD>FATCA>ReportingGroup>AccountReport [*]
            List<CorrectableAccountReport_Type> accReport = new List<CorrectableAccountReport_Type>();
            string accountDataColSettingFile = Application.StartupPath + @"\ColSettings\ColSettings-AccountData.xml";
            lib.tfund.excel.ColumnSettings accountDataSetting = new lib.tfund.excel.ColumnSettings(accountDataColSettingFile);
            DataTable dtAccount = LoadExcel(txtExcelFile.Text, 2, accountDataSetting);   
            accReport = GetAccountReportList(dtAccount);
            fatca.ReportingGroup[0].Items = accReport.ToArray();


            dlgSave.FileName = lblGIIN.Text + ".xml";
            if (dlgSave.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string filePath = dlgSave.FileName;


               // using (Stream stream = File.Open( filePath, FileMode.Create))
                using (StreamWriter stream = new StreamWriter(File.Open(filePath, FileMode.Create), Encoding.UTF8))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(FATCA_OECD));

                   
                    XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                    ns.Add("iso", "urn:oecd:ties:isofatcatypes:v1");
                    ns.Add("ftc", "urn:oecd:ties:fatca:v2");
                    ns.Add("stf", "urn:oecd:ties:stf:v4");
                    ns.Add("sfa", "urn:oecd:ties:stffatcatypes:v2");


                    serializer.Serialize(stream, fatcaDoc, ns);
                    stream.Flush();
                    txtXmlFile.Text = filePath;
                    MessageBox.Show(string.Format ("Save file to  {0} complete." , filePath) ,"Complete" , MessageBoxButtons.OK,MessageBoxIcon.Information );

                    Process.Start(Path.GetDirectoryName(filePath));

                
                }
            }
        }



        private List<CorrectableAccountReport_Type> GetAccountReportList(DataTable dtAccount)
        {
            List<CorrectableAccountReport_Type> lstAccount = new List<CorrectableAccountReport_Type>();


            CorrectableAccountReport_Type lastAccount = null;
            CorrectableAccountReport_Type currAccount = null;

                      

            foreach (DataRow dr in dtAccount.Rows)
            {
                /* CIS_NO   FIRST_NAME  LAST_NAME        PERSON_TYPE	    TIN	
                 * BTH_DATE	ADDRESS 	ADDRESS_COUNTRY	 OUTSTANDING_AMT 	CURRENCY_CODE
                 * DIVIDEND_AMT 	    AcctHolderType */
                string CIS_NO = dr["CIS_NO"].ToString().RemoveSQLInjection() ; // AccountReport
                string FIRST_NAME = dr["FIRST_NAME"].ToString().RemoveSQLInjection();// AcctHolder
                string LAST_NAME = dr["LAST_NAME"].ToString().RemoveSQLInjection();// AcctHolder
                string PERSON_TYPE = dr["PERSON_TYPE"].ToString().RemoveSQLInjection();// AcctHolder
                string TIN = dr["TIN"].ToString().RemoveSQLInjection();// AcctHolder
                string BTH_DATE = dr["BTH_DATE"].ToString().RemoveSQLInjection();// AcctHolder
                string ADDRESS = dr["ADDRESS"].ToString().RemoveSQLInjection();// AcctHolder
                string ADDRESS_COUNTRY = dr["ADDRESS_COUNTRY"].ToString().RemoveSQLInjection();// AcctHolder
                string OUTSTANDING_AMT = dr["OUTSTANDING_AMT"].ToString().RemoveSQLInjection();
                string CURRENCY_CODE = dr["CURRENCY_CODE"].ToString().RemoveSQLInjection();
                string DIVIDEND_AMT = dr["DIVIDEND_AMT"].ToString().RemoveSQLInjection();
                string AcctHolderType = dr["AcctHolderType"].ToString().RemoveSQLInjection();// AcctHolder

                object objHolder = null;
                
                if(PERSON_TYPE == "Individual")
                {
                    PersonParty_Type indv = new PersonParty_Type();
                    indv.Name = new NamePerson_Type[1];
                    indv.Name[0] = new NamePerson_Type();
                    indv.Name[0].FirstName = new NamePerson_TypeFirstName();
                    indv.Name[0].FirstName.Value = FIRST_NAME;
                    indv.Name[0].LastName = new NamePerson_TypeLastName();
                    indv.Name[0].LastName.Value = LAST_NAME;
                    indv.Address = new Address_Type[1];
                    indv.Address[0] = new Address_Type();
                    indv.Address[0].CountryCode = (CountryCode_Type)Enum.Parse(typeof(CountryCode_Type), ADDRESS_COUNTRY);
                    indv.Address[0].Items = new string[1];
                    indv.Address[0].Items[0] = ADDRESS;
                    indv.TIN = new TIN_Type[1];
                    indv.TIN[0] = new TIN_Type();
                    indv.TIN[0].Value = TIN;

                    objHolder = indv;
                }
                else //Organisation
                {
                    OrganisationParty_Type org = new OrganisationParty_Type();
                    org.Name = new NameOrganisation_Type[1];
                    org.Name[0] = new NameOrganisation_Type();
                    org.Name[0].Value = (FIRST_NAME  + " " + LAST_NAME).Trim();
                    org.Address = new Address_Type[1];
                    org.Address[0] = new Address_Type();
                    org.Address[0].CountryCode = (CountryCode_Type)Enum.Parse(typeof(CountryCode_Type), ADDRESS_COUNTRY);
                    org.Address[0].Items = new string[1];
                    org.Address[0].Items[0] =  ADDRESS;
                    objHolder = org;
                }

                if (lastAccount != null && lastAccount.AccountNumber.Value == CIS_NO) //บัญชีร่วม
                {
                    List<object> lstObj = new List<object>();
                    lstObj.AddRange(currAccount.AccountHolder.Items);
                    lstObj.Add(objHolder);
                    currAccount.AccountHolder.Items = lstObj.ToArray();  
                } else
                {
                    currAccount = new CorrectableAccountReport_Type();                    
                    //.. AccountReport>DocSpec 
                    currAccount.DocSpec = new DocSpec_Type();
                    currAccount.DocSpec.DocRefId =  GetDocRefID(lblGIIN.Text);
                    currAccount.DocSpec.DocTypeIndic = (FatcaDocTypeIndic_EnumType)Enum.Parse(typeof(FatcaDocTypeIndic_EnumType), cmbDocTypeIndic.Text);
                    //.. AccountReport>AccountNumber
                    currAccount.AccountNumber = new FIAccountNumber_Type();
                    currAccount.AccountNumber.Value = CIS_NO;
                    //.. AccountReport>AccountHolder 
                    currAccount.AccountHolder = new AccountHolder_Type();
                    currAccount.AccountHolder.Items = new object[] { objHolder };

                    currAccount.AccountBalance = new MonAmnt_Type();
                    currAccount.AccountBalance.currCode = (currCode_Type)Enum.Parse(typeof(currCode_Type),CURRENCY_CODE);

                    decimal dBalance = 0;
                    decimal.TryParse(OUTSTANDING_AMT,out dBalance);                   
                    currAccount.AccountBalance.Value = dBalance;

                    decimal dDividend = 0;
                    if (decimal.TryParse(DIVIDEND_AMT, out dDividend) && dDividend != 0)
                    {
                        currAccount.Payment = new Payment_Type[1];
                        currAccount.Payment[0] = new Payment_Type();
                        currAccount.Payment[0].Type = FatcaPaymentType_EnumType.FATCA501; //เงินปันผล (Dividends) = FATCA501
                        currAccount.Payment[0].PaymentAmnt = new MonAmnt_Type();
                        currAccount.Payment[0].PaymentAmnt.currCode = currAccount.AccountBalance.currCode;
                        currAccount.Payment[0].PaymentAmnt.Value = dDividend;
                    }

                   

                    lstAccount.Add(currAccount);
                    lastAccount = currAccount;



                }
                
                           
            }
            return lstAccount;
        }

        private void cmdPopulateSettings_Click_1(object sender, EventArgs e)
        {

        }




        private string GetDocRefID(string compGIIN)
        {
            string result = "";
            result = string.Format("{0}.{1}" , compGIIN, Guid.NewGuid().ToString());
            return result;
        }
     
    }


    public static class StringEXT {
        public static string RemoveSQLInjection(this String str)
        {
            // -- , /* , &#
            return str.Replace("--", "").Replace("/*", "").Replace("&#", "");
        }    
    }
}
