Public Class pvf_show_alot
    Inherits System.Web.UI.Page
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents rdlCond As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents tbCond1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents tbCond2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents imgCal1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents imgCal2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents IbtSeach As System.Web.UI.WebControls.ImageButton
    Protected WithEvents myCalendar As PopUpCalendar

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim m1 As New MyData()
    Dim strsql As String
    Public Runno As Integer
    Dim ds As New DataSet()
    Dim dv As DataView
    Dim strWhere As String
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            myCalendar.hideCalendar()
            If mc.CheckUser(Session("user_id"), "inq_alot") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                IbtSeach.Enabled = False
                Exit Sub
            End If
            strWhere = " and  to_Char(alot_date,'yyyymmdd') =  to_Char(sysdate,'yyyymmdd') "
            GetData(strWhere)
        End If
    End Sub

    Sub GetData(ByVal strWhere As String)
        strsql = "select  d.fund_tname,t.trn_no,t.fund,nvl(t.share_amt,0) share_amt,t.trn_type, t.trn_date,nvl(t.share_amt_bf,0) share_amt_br, " & _
                        "t.alot_by,to_char(t.alot_date,'dd/mm/yyyy') alot_date,nvl(t.nav,0) nav,t.trn_flg , t.trn_alot ," & _
                        " nvl(decode(t.trn_type,'SB',t.share_amt + t.share_amt_bf,t.share_amt_bf - t.share_amt),0) share_total, nvl( t.dv_unit,0) dv_unit " & _
                        " from pv.pvmtran t , pv.funddesc d" & _
                        " where t.fund = d.fund and t.trn_alot = 'Y' " & strWhere
        'lbMsg.Text = strsql
        ds = m1.GetDataset(strsql)

        DG1.DataSource = ds
        DG1.DataBind()

    End Sub

    Sub MyRefresh()
        dv = Session("data")
        DG1.DataSource = dv  '.Tables(0).DefaultView
        DG1.DataBind()
    End Sub

    Private Sub DG1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub IbtSeach_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles IbtSeach.Click
        lbMsg.Text = ""
        Dim strCond1, strCond2 As String

        Select Case rdlCond.SelectedItem.Value
            Case "fdate"
                '      If IsDate(tbCond1.Text) And IsDate(tbCond2.Text) Then   ' check mm/dd/yyyy

                Dim strYear1, strYear2 As String
                strYear1 = Right(tbCond1.Text, 4)
                strYear2 = Right(tbCond2.Text, 4)

                If CInt(strYear1) > 2500 Then
                    strYear1 = CInt(strYear1) - 543
                End If
                If CInt(strYear2) > 2500 Then
                    strYear2 = CInt(strYear2) - 543
                End If

                strCond1 = Trim(strYear1 & Mid(tbCond1.Text, 4, 2) & Left(tbCond1.Text, 2))
                strCond2 = Trim(strYear2 & Mid(tbCond2.Text, 4, 2) & Left(tbCond2.Text, 2))
                'Else
                '    lbMsg.Text = tbCond1.Text & tbCond2.Text
                '    Exit Sub
                'End If
                strWhere = " and  (to_Char(t.alot_date,'yyyymmdd') between  '" & strCond1 & "' and '" & strCond2 & "' )"
            Case "fname"
                strWhere = " and  d.fund_tname like '%" & tbCond1.Text & "%'"
            Case "fund"
                strWhere = " and  t.fund like  '" & tbCond1.Text & "'"
        End Select

        Me.GetData(strWhere)

    End Sub

    Private Sub DG1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DG1.SortCommand
        If UCase(viewstate("field")) = UCase(e.SortExpression) Then
            If viewstate("direction") = "ASC" Then
                viewstate("direction") = "Desc"
            Else
                viewstate("direction") = "ASC"
            End If
        Else
            viewstate("field") = e.SortExpression
            viewstate("direction") = "ASC"
        End If

        dv.Sort = viewstate("field") & " " & viewstate("direction")
        DG1.CurrentPageIndex = 0
        Me.MyRefresh()
    End Sub

    Private Sub rdlCond_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlCond.SelectedIndexChanged
        Select Case rdlCond.SelectedItem.Value
            Case "fdate"
                tbCond2.Visible = True
                Label2.Visible = True
                Label3.Visible = True
                Label2.Text = " �֧ "
                imgCal1.Visible = True
                imgCal2.Visible = True
            Case "fname"
                tbCond2.Visible = False
                Label2.Visible = False
                Label3.Visible = False
                Label1.Text = "���ͧ͡�ع : "
                imgCal1.Visible = False
                imgCal2.Visible = False
            Case "fund"
                tbCond2.Visible = False
                Label2.Visible = False
                Label3.Visible = False
                Label1.Text = "���ʡͧ�ع : "
                imgCal1.Visible = False
                imgCal2.Visible = False
        End Select
        tbCond1.Text = ""
        tbCond2.Text = ""
    End Sub

    Private Sub imgCal1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgCal1.Click
        Dim dSelDate As Date

        If IsDate(tbCond1.Text) Then
            dSelDate = tbCond1.Text
        End If
        myCalendar.displayCalendar("Select a start date", dSelDate, "tbCond1", 165, 230)
    End Sub

    Private Sub imgCal2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgCal2.Click
        Dim dSelDate As Date

        If IsDate(tbCond2.Text) Then
            dSelDate = tbCond2.Text
        End If
        myCalendar.displayCalendar("Select a start date", dSelDate, "tbCond2", 165, 380)
    End Sub

    Private Sub Dg1_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles DG1.PageIndexChanged
        DG1.CurrentPageIndex = e.NewPageIndex
        Me.MyRefresh()
    End Sub
End Class
