Public Class pvf_add_alot
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Panel3 As System.Web.UI.WebControls.Panel
    Protected WithEvents chkAll As System.Web.UI.WebControls.CheckBox
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents Panel4 As System.Web.UI.WebControls.Panel
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents lbMsg2 As System.Web.UI.WebControls.Label
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents btCancel As System.Web.UI.WebControls.Button
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Public Runno As Integer
    Dim strsql As String
    Dim dv As DataView
    Dim mc As New ClassCheckUser
    Dim m1 As New MyData
    Dim ds As New DataSet
    Protected WithEvents btReject As System.Web.UI.WebControls.Button
    Dim ds2 As New DataSet

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "trn_alot") = "F" Then
                lbMsg2.Text = "*** �س������Է�� ����¡������ ���  ***"
                btSave.Enabled = False
                btCancel.Enabled = False
                chkAll.Visible = False
                Exit Sub
            End If

            GetData()
        End If
    End Sub

    Sub GetData()
        Dim dt As DataTable
        Dim dr As DataRow

        Dim strType, strFund As String
        Dim dbbalAmt, dbbalUnit, dbUnit, dbMoney, dbAmount, dbNav As Double
        Dim dcTotalUnit As Decimal

        strsql = "select  d.fund_tname,t.trn_no,t.fund,t.share_amt,t.trn_type, to_char(t.trn_date,'dd/mm/yyyy' ) trn_date,nvl(t.share_amt_bf,0) share_amt_bf, " & _
                        " t.upd_by,t.upd_date,nvl(t.nav,0) nav,t.trn_flg , t.trn_alot ," & _
                        " decode(t.trn_type,'SB',t.share_amt + t.share_amt_bf,'RD',t.share_amt_bf - t.share_amt,'CD',t.share_amt_bf - t.share_amt,share_amt_bf ) share_total ," & _
                        " nvl(share_unit_bf,0) share_unit_bf, 0 share_unit_new ,0 share_unit_h ,t.trn_type trn_type_h," & _
                        " decode(t.trn_type,'SB',t.share_amt + t.share_amt_bf,'RD',t.share_amt_bf - t.share_amt,'CD',t.share_amt_bf - t.share_amt,share_amt_bf ) share_amt_h, " & _
                        " decode(t.trn_type,'DV',0 , t.share_amt /nav ) unit_alot, " & _
                        " nvl( t.dv_unit,0) dv_unit  " & _
                        " from pv.pvmtran t , pv.funddesc d" & _
                        " where t.fund = d.fund and t.trn_alot = 'C' and trn_flg = 'A' "
        '" decode(t.trn_type,'SB', t.share_unit_bf + (t.share_amt /nav),'RD',t.share_unit_bf - (t.share_amt/nav),0 ) unit_alot_h " & _

        ds = m1.GetDataset(strsql)
        dt = ds.Tables(0)
        For Each dr In dt.Rows
            strFund = dr("fund")
            strType = dr("trn_type")
            dbAmount = dr("share_amt_bf")   ' �ʹ�Թ¡��
            dbMoney = dr("share_amt")         ' �ʹ�Թ�����觷���¡��
            dbUnit = dr("share_unit_bf")      ' ˹���¡��
            dbNav = dr("nav")

            ' **** get last Amount, Unit from fundcontl �������ӹǳ�ʹ¡件١��ͧ ���ͧ�ҡ�ա���觤������ǧ˹�ҷ���� share_amt_bf �Դ��
            strsql = " select nvl(share_unit,0) share_unit,nvl(share_amt,0) share_amt  from pv.fundcontl where fund = '" & strFund & "' "
            ds2 = m1.GetDataset(strsql)
            Dim dr2 As DataRow = ds2.Tables(0).Rows(0)
            dbAmount = CType(dr2("share_amt"), Double).ToString("##,###,###,##0.00")
            dbUnit = CType(dr2("share_unit"), Double).ToString("#,###,###,##0.0000")
            ' *****    

            'decode(t.trn_type,'SB',t.share_amt + t.share_amt_bf,
            'RD',t.share_amt_bf - t.share_amt,
            'CD',t.share_amt_bf - t.share_amt,share_amt_bf ) share_total 


            If dbNav > 0 Then
                dcTotalUnit = dbMoney / dbNav        ' �ӹǳ��˹���
                dcTotalUnit = FormatNumber(dcTotalUnit, 4)
            Else
                dcTotalUnit = 0.0
            End If

            If strType = "SB" Then
                dbbalAmt = dbAmount + dbMoney
                dbbalUnit = dbUnit + dcTotalUnit
            ElseIf strType = "RD" Or strType = "CD" Then
                dbbalAmt = dbAmount - dbMoney
                dbbalUnit = dbUnit - dcTotalUnit
            ElseIf strType = "DV" Then                       ' �׹�Ż���ª�� ����ա���ѡ�ӹǹ�������������͡
                dbbalAmt = dbAmount
                dbbalUnit = dbUnit
            End If

            dr("share_total") = FormatNumber(dbbalAmt, 2)   ' �ӹǹ�Թ������ͷ�����ԧ �. �ѹ����¡��
            dr("share_unit_bf") = FormatNumber(dbUnit, 4)    ' ˹���¡�ҷ�����ԧ �. �ѹ����¡��
            dr("share_unit_new") = FormatNumber(dbbalUnit, 4)    ' ˹��¤������
            dr("share_unit_h") = FormatNumber(dbbalUnit, 4)
            dr("share_amt_h") = FormatNumber(dbbalAmt, 2)
        Next

        dv = dt.DefaultView
        DG1.DataSource = ds
        DG1.DataBind()

    End Sub

    Private Sub DG1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemDataBound
        Dim strFlg As String = CType(DataBinder.Eval(e.Item.DataItem, "trn_type"), String)
        If strFlg = "SB" Then
            e.Item.Cells(1).ForeColor = Color.DarkGreen
            e.Item.Cells(2).ForeColor = Color.DarkGreen
            e.Item.Cells(3).ForeColor = Color.DarkGreen
            e.Item.Cells(4).ForeColor = Color.DarkGreen
            e.Item.Cells(5).ForeColor = Color.DarkGreen
            'e.Item.Cells(6).BackColor = Color.DarkGreen
            e.Item.Cells(6).ForeColor = Color.DarkGreen
            e.Item.Cells(7).ForeColor = Color.DarkGreen
        ElseIf strFlg = "RD" Or strFlg = "CD" Then
            e.Item.Cells(1).ForeColor = Color.Red
            e.Item.Cells(2).ForeColor = Color.Red
            e.Item.Cells(3).ForeColor = Color.Red
            e.Item.Cells(4).ForeColor = Color.Red
            e.Item.Cells(5).ForeColor = Color.Red
            e.Item.Cells(6).ForeColor = Color.Red
            e.Item.Cells(7).ForeColor = Color.Red

            '            e.Item.Cells(7).BackColor = Color.Brown
            '           e.Item.Cells(7).ForeColor = Color.Pink
            '          e.Item.Cells(6).ForeColor = Color.Red
        ElseIf strFlg = "DV" Then
            e.Item.Cells(1).ForeColor = Color.MediumOrchid
            e.Item.Cells(2).ForeColor = Color.MediumOrchid
            e.Item.Cells(3).ForeColor = Color.MediumOrchid
            e.Item.Cells(4).ForeColor = Color.MediumOrchid
            e.Item.Cells(5).ForeColor = Color.MediumOrchid
            e.Item.Cells(6).ForeColor = Color.MediumOrchid
            e.Item.Cells(7).ForeColor = Color.MediumOrchid
        End If
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strTrnNo, strGetTrn, strChk, strFund, strUnit, strAmt As String
        Dim dbbalAmt, dbbalUnit As Double
        Dim dgi As DataGridItem
 
        For Each dgi In DG1.Items
            Dim cb As CheckBox = dgi.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
            If cb.Checked Then
                strTrnNo = DG1.DataKeys(dgi.ItemIndex)
                Dim strFlg As String = DG1.Items(dgi.ItemIndex).Cells(14).Text
                strFund = DG1.Items(dgi.ItemIndex).Cells(0).Text.ToString
                strUnit = DG1.Items(dgi.ItemIndex).Cells(12).Text.ToString    'share_unit_h  ��ͧ hide colum �֧�д֧�������� (�����Ҵ)?????
                strAmt = DG1.Items(dgi.ItemIndex).Cells(13).Text.ToString    'share_amt_h  ��ͧ hide colum �֧�д֧�������� (�����Ҵ)?????

                dbbalUnit = CType(strUnit, Double)
                dbbalAmt = CType(strAmt, Double)

                ' Update Fund Contrl 
                If strFlg <> "DV" Then   ' DV ����ͧ update � fund control
                    If strFlg = "CD" Then ' close fund
                        strsql = " update pv.funddesc set  fund_status = 'C'  " & _
                                    ", upd_by = '" & Session("user_id") & "', upd_date=sysdate " & _
                                   "  where fund = '" & strFund & "'"
                        m1.Execute(strsql)
                    End If

                    strsql = " update pv.fundcontl set share_amt = " & dbbalAmt & ", share_unit = " & dbbalUnit & _
                                    ", upd_by = '" & Session("user_id") & "', upd_date=sysdate " & _
                                    "  where fund = '" & strFund & "'"
                    m1.Execute(strsql)
                End If
                strGetTrn &= strTrnNo & ","
                strChk = "T"    ' ������ա�� ���͡�������
                '  lbMsg.Text &= strsql & strGetTrn
            End If

        Next

        If strChk <> "T" Then
            lbMsg.Text = "��س����͡�����ŷ��зӡ�èѴ��á�͹ �������ѹ�֡"
            Exit Sub
        End If

        Dim iLen As Integer
        iLen = Len(strGetTrn)
        strGetTrn = Left(strGetTrn, iLen - 1)
        '  lbMsg.Text &= strGetTrn

        strsql = "update pv.pvmtran set trn_alot = 'Y' , alot_by = '" & Session("user_id") & "' ,alot_date = sysdate " & _
                       "where trn_no in (" & strGetTrn & ")"
        m1.Execute(strsql)
        ' lbMsg.Text &= "test"

        Response.Redirect("success.aspx?pagename=pvf_add_alot.aspx")
    End Sub

    Private Sub chkAll_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAll.CheckedChanged
        If chkAll.Checked Then
            Dim dgi As DataGridItem
            For Each dgi In DG1.Items
                Dim cb As CheckBox = dgi.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
                cb.Checked = True
            Next
        Else
            Dim dgi As DataGridItem
            For Each dgi In DG1.Items
                Dim cb As CheckBox = dgi.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
                cb.Checked = False
            Next
        End If
    End Sub

    Private Sub btCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btCancel.Click
        Response.Redirect("pvf_add_alot.aspx")
    End Sub

    Sub doUpdate(ByVal e As DataGridCommandEventArgs)
        Dim str As TextBox
        str = e.Item.Cells(1).Controls(0)
        lbMsg.Text = str.Text
    End Sub

    Sub ShareAlot(ByVal dbTrnNo As Double) '*** not use for now

        strsql = "select  trn_no,fund,share_amt,nvl(share_unit_bf,0) share_unit_bf,trn_type, trn_date, " & _
                     " nvl(share_amt_bf,0) share_amt_bf,upd_by,upd_date,nvl(nav,0) nav,trn_flg , trn_alot ," & _
                     " decode(trn_type,'SB',share_amt + nvl(share_amt_bf,0),'RD',nvl(share_amt_bf,0) - share_amt,share_amt_bf) share_total " & _
                     " from pv.pvmtran  " & _
                     " where trn_no =  '" & dbTrnNo & "'"
        ds = m1.GetDataset(strsql)

        Dim dt As DataTable = ds.Tables(0)
        Dim dr As DataRow
        Dim strType, strFund As String
        Dim dbbalAmt, dbbalUnit, dbUnit, dbMoney, dbAmount, dbNav, dbTotalUnit As Double

        For Each dr In dt.Rows
            strFund = dr("fund")
            strType = dr("trn_type")
            dbAmount = dr("share_amt_bf")
            dbMoney = dr("share_amt")
            dbUnit = dr("share_unit_bf")
            dbNav = dr("nav")

            dbTotalUnit = dbMoney / dbNav

            If strType = "SB" Then
                dbbalAmt = dbAmount + dbMoney
                dbbalUnit = dbUnit + dbTotalUnit
            ElseIf strType = "RD" Or strType = "CD" Then
                dbbalAmt = dbAmount - dbMoney
                dbbalUnit = dbUnit - dbTotalUnit
            ElseIf strType = "DV" Then                       ' �׹�Ż���ª�� ����ա���ѡ�ӹǹ�������������͡
                dbbalAmt = dbAmount
                dbbalUnit = dbUnit
            End If

        Next
    End Sub

    Private Sub btReject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btReject.Click
        Dim strTrnNo, strGetTrn, strChk, strFund, strUnit, strAmt As String
        Dim dbbalAmt, dbbalUnit As Double
        Dim dgi As DataGridItem
        '** �觡�Ѻ价ӡ�����
        For Each dgi In DG1.Items
            Dim cb As CheckBox = dgi.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
            If cb.Checked Then
                strTrnNo = DG1.DataKeys(dgi.ItemIndex)
                Dim strFlg As String = DG1.Items(dgi.ItemIndex).Cells(14).Text
                strFund = DG1.Items(dgi.ItemIndex).Cells(0).Text.ToString
                strUnit = DG1.Items(dgi.ItemIndex).Cells(12).Text.ToString    'share_unit_h  ��ͧ hide colum �֧�д֧�������� (�����Ҵ)?????
                strAmt = DG1.Items(dgi.ItemIndex).Cells(13).Text.ToString    'share_amt_h  ��ͧ hide colum �֧�д֧�������� (�����Ҵ)?????

                dbbalUnit = CType(strUnit, Double)
                dbbalAmt = CType(strAmt, Double)

                strGetTrn &= strTrnNo & ","
                strChk = "T"    ' ������ա�� ���͡�������
                '  lbMsg.Text &= strsql & strGetTrn
            End If

        Next

        If strChk <> "T" Then
            lbMsg.Text = "��س����͡�����ŷ��зӡ������䢡�͹ "
            Exit Sub
        End If

        Dim iLen As Integer
        iLen = Len(strGetTrn)
        strGetTrn = Left(strGetTrn, iLen - 1)
        '  lbMsg.Text &= strGetTrn

        strsql = "update pv.pvmtran set trn_alot ='N' " & _
                       "where trn_no in (" & strGetTrn & ")"
        m1.Execute(strsql)
        ' lbMsg.Text &= "test"
        Response.Redirect("pvf_add_alot.aspx")
    End Sub
End Class

'Private Sub btAlot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btAlot.Click
'    Dim strTrnNo As String
'    Dim dgi As DataGridItem
'    Dim txbUnitNew As TextBox

'    For Each dgi In DG1.Items
'        Dim cb As CheckBox = dgi.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
'        If cb.Checked Then
'            strTrnNo = DG1.DataKeys(dgi.ItemIndex)
'            txbUnitNew = dgi.Cells(10).Controls(1)
'            '                ShareAlot(strTrnNo)
'            txbUnitNew.Text = "7777"
'        End If
'    Next

'End Sub