Imports System.Web.Mail
Public Class pvf_approve_order
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lbMsg2 As System.Web.UI.WebControls.Label
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents btRefresh As System.Web.UI.WebControls.Button
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents btSave As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public Runno As Integer
    Dim ds As New DataSet
    Dim m1 As New MyData
    Dim strsql As String
    Dim strWhere As String
    Dim dv As DataView
    Dim mc As New ClassCheckUser

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "trn_approve") = "F" Then
                lbMsg2.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                btRefresh.Enabled = False
                Exit Sub
            End If
            strWhere = "  to_Char(trn_date,'yyyymmdd') =  to_Char(sysdate,'yyyymmdd') "
            Me.MyData(strWhere)
        Else
            dv = Session("data")
        End If
    End Sub
    Private Sub MyData(ByVal strWhere As String)
        strsql = "select p.trn_no, p.fund,p.trn_type,to_char(nvl(p.share_amt,0),'99,999,999,999.99')  share_amt , " & _
                       " to_char(nvl(p.share_amt_bf,0),'99,999,999,999.99')  share_amt_bf , to_char(p.trn_date,'dd/mm/yyyy hh24:MI' ) trn_date" & _
                       ",f.fund_tname , to_char(p.trn_date,'dd/mm/yyyy' ) trn_date2, trn_alot ,p.nav, nvl( p.dv_unit,0) dv_unit " & _
                       " from pv.pvmtran p,pv.funddesc f  " & _
                       " where p.fund = f.fund and trn_flg = 'P' and  trn_alot <> 'Y' " 'and " & strWhere
        'lbMsg.Text = strsql

        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView

        If dv.Count > 0 Then
            DG1.DataSource = dv  '.Tables(0).DefaultView
            Session("data") = dv
        Else
            DG1.DataSource = ds
            Session("data") = ds
        End If
        DG1.DataBind()
    End Sub

    Sub MyRefresh()
        dv = Session("data")
        DG1.DataSource = dv  '.Tables(0).DefaultView
        DG1.DataBind()
    End Sub

    Private Sub DG1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub DG1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DG1.SortCommand
        If UCase(viewstate("field")) = UCase(e.SortExpression) Then
            If viewstate("direction") = "ASC" Then
                viewstate("direction") = "Desc"
            Else
                viewstate("direction") = "ASC"
            End If
        Else
            viewstate("field") = e.SortExpression
            viewstate("direction") = "ASC"
        End If

        dv.Sort = viewstate("field") & " " & viewstate("direction")
        DG1.CurrentPageIndex = 0
        Me.MyRefresh()
    End Sub

    Private Sub DG1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemDataBound
        Dim strType As String = CType(DataBinder.Eval(e.Item.DataItem, "trn_type"), String)
        If strType = "SB" Then
            '      e.Item.Cells(6).BackColor = Color.DarkGreen
            '  e.Item.Cells(6).ForeColor = Color.GreenYellow
            e.Item.Cells(7).ForeColor = Color.DarkGreen
            e.Item.Cells(5).ForeColor = Color.DarkGreen
        ElseIf strType = "RD" Then
            '   e.Item.Cells(6).BackColor = Color.Brown
            ' e.Item.Cells(6).ForeColor = Color.Pink
            e.Item.Cells(7).ForeColor = Color.Red
            e.Item.Cells(5).ForeColor = Color.Red
        End If
    End Sub

    Private Sub DG1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DG1.SelectedIndexChanged
        Dim x1 As String = DG1.DataKeys(DG1.SelectedIndex)
        Dim j As Integer = DG1.SelectedIndex
    End Sub

    Private Sub DG1_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.EditCommand
        DG1.EditItemIndex = e.Item.ItemIndex
        Me.MyRefresh()
    End Sub

    Private Sub DG1_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.CancelCommand
        DG1.EditItemIndex = -1
        Me.MyRefresh()
    End Sub

    Private Sub DG1_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.UpdateCommand
        Dim strTrnNo As String
        Dim txbMoney As TextBox
        Dim txbBf As TextBox
        Dim txbType As TextBox
        Dim txbNav As TextBox
        Dim txbTrnDate As TextBox
        Dim txbDvUnit As TextBox
        Dim dbTotal, dbTotalU As Double
        Dim dbBfAmt, dbBfUnit, dbMoney, dbMoney_Old, dbSeq, dbNav, dbNav_Old As Double
        Dim dbDvUnit, dbDvUnit_Old As Double
        Dim strFund, strType As String
        Dim strTrnDate, strTrnDateUpd As String
        Dim c_date As String = Now.ToString("dd/MM/yyyy HH:mm:ss")

        lbMsg.Text = ""
        strTrnNo = DG1.DataKeys(e.Item.ItemIndex)

        strsql = "select fund,share_amt, nvl(share_amt_bf,0) share_amt_bf,nvl(share_unit_bf,0) share_unit_bf, " & _
                        " trn_type,to_char(trn_date,'dd/mm/yyyy') trn_date, nvl(nav,0) nav, nvl(dv_unit,0) dv_unit  " & _
                       "  from pv.pvmtran " & _
                       " where trn_no = '" & strTrnNo & "'"
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)

        strFund = dr("fund")
        strType = dr("trn_type")
        dbBfAmt = dr("share_amt_bf")
        dbBfUnit = dr("share_unit_bf")
        dbMoney_Old = dr("share_amt")
        strTrnDate = dr("trn_date")
        dbNav_Old = FormatNumber(dr("nav"), 4)
        dbDvUnit_Old = FormatNumber(dr("dv_unit"), 4)

        txbMoney = e.Item.Cells(7).Controls(0)
        dbMoney = CType(txbMoney.Text, Double)

        '  txbNav = e.Item.Cells(8).Controls(0)
        ' dbNav = CType(txbNav.Text, Double)

        txbTrnDate = e.Item.Cells(8).Controls(0)
        '        strTrnDateUpd = CType(txbTrnDate.Text, Date)
        strTrnDateUpd = txbTrnDate.Text

        '   txbDvUnit = e.Item.Cells(10).Controls(0)
        '  dbDvUnit = CType(txbDvUnit.Text, Double)

        If strType = "SB" Then
            dbTotal = dbBfAmt + dbMoney
            dbTotalU = dbBfUnit
        Else
            dbTotal = dbBfAmt - dbMoney
            dbTotalU = dbBfUnit
        End If

        strsql = "update pv.pvmtran set share_amt = " & dbMoney & ", " & _
                     " trn_date = to_date('" & strTrnDateUpd & "','dd/mm/yyyy')" & _
                     "  where trn_no = '" & strTrnNo & "'"
        ' lbMsg2.Text = strsql
        m1.Execute(strsql)

        Try
            strsql = "select nvl(max(seq),0)  seq  from pv.pvhtran "
            ds = m1.GetDataset(strsql)
            Dim dr1 As DataRow = ds.Tables(0).Rows(0)
            dbSeq = dr1("seq") + 1

            strsql = "insert into pv.pvhtran (seq,trn_no,fund,share_amt,upd_by,upd_date, trn_type, trn_date, nav,dv_unit ) " & _
                     "values (" & dbSeq & ",'" & strTrnNo & "','" & strFund & "'," & dbMoney_Old & ",'" & Session("user_id") & "'," & _
                     "to_date('" & c_date & "','dd/mm/yyyy HH24:MI:SS'),'" & strType & "', to_date('" & strTrnDate & "','dd/mm/yyyy') ," & _
                     dbNav_Old & "," & dbDvUnit_Old & " ) "
            m1.Execute(strsql)

            Response.Redirect("success.aspx?pagename=pvf_approve_order.aspx")
            'lbMsg.Text &= "�ѹ�֡�����䢢����� ���º����"
        Catch x1 As Exception
            lbMsg.Text &= x1.Message
        End Try

    End Sub

    Private Sub btRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btRefresh.Click
        Response.Redirect("pvf_approve_order.aspx")
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim dgi As DataGridItem
        Dim strFund, strTrnNo, strTrntype, strTrndate As String
        Dim strDocCode, strSubtype, strDocType, strRemk As String
        Dim strMsg1, strMsg2, strMsg3 As String

        strDocCode = "DOC40"
        strDocType = "TRAN"
        strSubtype = "PVTRN"

        For Each dgi In DG1.Items
            Dim cbDoc As CheckBox = dgi.Cells(9).Controls(1)
            Dim cbAppv As CheckBox = dgi.Cells(10).Controls(1)
            Dim cbCc As CheckBox = dgi.Cells(11).Controls(1)

            strTrnNo = DG1.DataKeys(dgi.ItemIndex)
            strFund = DG1.Items(dgi.ItemIndex).Cells(1).Text.ToString
            strTrntype = DG1.Items(dgi.ItemIndex).Cells(5).Text.ToString
            strTrndate = DG1.Items(dgi.ItemIndex).Cells(8).Text.ToString

            If cbDoc.Checked Then

                strsql = "insert into pv.pvtdocrecv ( Fund, Cis_no, Trn_no, Trn_date,Sub_type,Doc_type,Doc_code,Doc_remk," & _
                         " Ins_by, Ins_date ) " & _
                         " values ( '" & strFund & "', '" & strTrntype & "','" & strTrnNo & "' ,to_date('" & strTrndate & "','dd/mm/yyyy'),'" & strSubtype & "' " & _
                         " ,'" & strDocType & "','" & strDocCode & "','" & strRemk & "','" & Session("user_id") & "',sysdate )"
                m1.Execute(strsql)
                '  lbMsg.Text = strsql
                Try
                    strMsg1 = "�ѹ�֡������͡��� ..."
                Catch x1 As Exception
                    lbMsg.Text = x1.Message
                End Try
            End If

            If cbAppv.Checked Then
                strsql = "update pv.pvmtran set trn_flg = 'A', ap_by='" & Session("user_id") & "', ap_date = sysdate " & _
                         " where trn_no = '" & strTrnNo & "'"

                m1.Execute(strsql)
                Try
                    SendMail_New(strFund, strTrntype)
                    strMsg2 = "�ѹ�֡���͹��ѵ���¡�� "
                Catch x1 As Exception
                    lbMsg.Text = x1.Message
                End Try
            End If

            If cbCc.Checked Then
                strsql = "update pv.pvmtran set trn_flg = 'C' ,upd_by='" & Session("user_id") & "', upd_date = sysdate " & _
                         " where trn_no = '" & strTrnNo & "'"

                m1.Execute(strsql)
                Try
                    strMsg3 = "�ѹ�֡���¡��ԡ��¡��"
                Catch x1 As Exception
                    lbMsg.Text = x1.Message
                End Try
            End If
        Next
        lbMsg.Text = strMsg1 & "..." & strMsg2 & "..." & strMsg3 & "... ���º����"

        strWhere = "  to_Char(trn_date,'yyyymmdd') =  to_Char(sysdate,'yyyymmdd') "
        Me.MyData(strWhere)
    End Sub

    Sub SendMail_New(ByVal strFund As String, ByVal strType As String)
        '** Replace web service sendmail because WS not support since move to new server 2012
        '** Modify date : 08 Feb 2013

        Dim myMail As New MailMessage

        Dim chk As Integer
        Dim strFrom, strTo, strSubject, strBody, strFormat As String

        strFrom = "atiporn.chi@thanachartgroup.com"
        '** read from table pvmrefmisc
        strsql = " select pvref_misc1, pvref_misc2 " & _
                 " from pv.pvmrefmisc " & _
                 " where pvref_code = 'MAILTO' "
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)
        strTo = dr("pvref_misc1") & dr("pvref_misc2")
        'strTo = "harutais@thanachartfund.com"

        'strSubject = "*****TEST ----- You have new Private Fund Order."
        'strBody = " TEST TEST "

        strSubject = "*****You have new Private Fund Order."
        strBody = "Please Check . ******  FUND CODE ::  " & strFund & "  (" & strType & ")" & _
                 " This order had been approved by '" & Session("user_id") & "' "

        'Response.Write(" after : " & strTo & "   " & strBody)

        Try
            myMail.To = strTo
            myMail.From = strFrom
            myMail.Subject = strSubject
            myMail.Body = strBody

            SmtpMail.SmtpServer = System.Configuration.ConfigurationSettings.AppSettings.Get("SMTPServer")

            ' Response.Write("SmtpMail ....  " & SmtpMail.SmtpServer.ToString)

            SmtpMail.Send(myMail)
            myMail = Nothing
        Catch x1 As Exception
            lbMsg.Text = x1.Message
        End Try

    End Sub
End Class

