Imports System.Data.OleDb

Public Class ClassCheckUser
    Dim strsql As String
    Dim ds As New DataSet()
    Dim m1 As New Mydata()
    Dim i As Integer

    Public Function CheckUser(ByVal strUser As String, ByVal strMenu As String) As String
        Dim strChk As String

        strsql = "select app_code,menu_code from web.webmaccess " & _
                   " where  user_id = '" & strUser & "' and menu_code = '" & strMenu & "'"
        ds = m1.GetDataset(strsql)

        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            strChk = "T"
            'Dim dt As DataTable = ds.Tables(0)
            'Dim dr As DataRow = dt.Rows(i)
            'For Each dr In dt.Rows
            '    If dr("menu_code") = strMenu Then
            '        strChk = "T"
            '    Else
            '        strChk = "F"
            '    End If
            '    'Select Case dr("menu_code")
            '    '    Case "app_apply"
            '    '    Case "app_assign"
            '    '    Case "app_verified"
            '    '    Case "app_forgot"
            '    'End Select

            'Next
            ' Return "xxxxxx"

        End If


        If strChk = "T" Then
            Return "T"
        Else
            Return "F"
        End If

    End Function

    Public Function CheckApp(ByVal strUser As String, ByVal strApp As String) As String
        Dim strChk As String

        strsql = "select distinct(app_code) from web.webmaccess " & _
                   " where  user_id = '" & strUser & "' and app_code = '" & strApp & "'"
        ds = m1.GetDataset(strsql)

        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            strChk = "T"
        End If

        If strChk = "T" Then
            Return "T"
        Else
            Return "F"
        End If

    End Function
End Class
