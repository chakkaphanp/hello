Public Class ClassKYC
    Dim strsql As String
    Dim ds As New DataSet
    Dim m1 As New MyData
    Dim i As Integer
    Dim strChk As String

    Public Function InsKyc() As String
        '*** Insert new ccid to Kyc_customer
        'strsql = "select distinct(app_code) from web.webmaccess " & _
        '                  " where  user_id = '" & strUser & "' and app_code = '" & strApp & "'"
        'ds = m1.GetDataset(strsql)

        'Dim dc As Integer = ds.Tables(0).Rows.Count
        'If dc > 0 Then
        '    strChk = "T"
        'End If


        strsql = " INSERT INTO TKYC.KYC_CUSTOMER " & _
                 "( CC_ID, " & _
                 " INVOLVEDPARTYTYPE, " & _
                 " ID_TYPE, " & _
                 " ID_NO, " & _
                 " ID_BIRTH_DATE,  " & _
                 " NATIONALITY, " & _
                 " COUNTRY_OF_RESIDENT, " & _
                 " GENDER, " & _
                 " MARITAL_STATUS, " & _
                 " NO_OF_CHILD, " & _
                 " TITLE_CODE, " & _
                 " OTHER_TITLE_NAME, " & _
                 " FIRST_NAME_THAI, " & _
                 " LAST_NAME_THAI, " & _
                 " OCCUPATION_CODE, " & _
                 " EDUCATION_CODE, " & _
                 " TAX_ID, " & _
                 " FULL_FILL_FLAG ) " & _
        "SELECT '" & "CCID" & "'," & _
            " OPNMOCCP.KYC_CLCODE," & _
            " OPNMREFT.KYC_CLCODE," & _
            " LTRIM(RTRIM(PVMCUST.REF_NO)), " & _
            " PVMCUST.BTH_DATE, " & _
            " OPNMCNTC.KYC_CLCODE  natcode, " & _
            " OPNMCNTC.KYC_CLCODE  cntcode, " & _
            " DECODE(PVMCUST.FIRST_CODE,'1','M','2','M','3','M','4','F','5','F','6','F','7','F') GENDER, " & _
            " DECODE(PVMCUST.STATUS,'S','090001','M','090002','D','090005','W','090006'), " & _
            " null  nochild, " & _
            " OPNMTITC.KYC_CLCODE, " & _
            " PVMCUST.FIRST_NAME, " & _
            " PVMCUST.NAME, " & _
            " PVMCUST.SURNAME, " & _
            " DECODE(PVMCUST.OCC_CODE, NULL, OPNMOCCP.KYC_SUBCODE, OPNMOCCPTYPE.KYC_CLCODE) occtype, " & _
            " null  edu," & _
            " PVMCUST.TAX_ID , " & _
            " 'Y'  fillflg " & _
        " FROM PVMCUST,PVMADDR,OPNMOCCP,OPNMNATC,OPNMOCCPTYPE,OPNMREFT,OPNMTITC,OPNMCNTC" & _
        " WHERE (PVMCUST.CIS_NO = PVMADDR.CIS_NO) AND " & _
        " ( PVMADDR.CNTCODE_H = OPNMCNTC.CNT_CODE (+)) AND " & _
        " ( PVMCUST.OCC_CODE = OPNMOCCP.OCC_CODE ) AND  " & _
        " ( PVMCUST.NAT_CODE = OPNMNATC.NAT_CODE (+)) AND  " & _
        " ( PVMCUST.OCC_CODE = OPNMOCCPTYPE.OCCTYPE_CODE (+)) AND  " & _
        " ( PVMCUST.REF_TYPE = OPNMREFT.REF_TYPE ) AND  " & _
        " ( PVMCUST.FIRST_CODE = OPNMTITC.FIRST_CODE (+)) AND  " & _
        " ( PVMCUST.CIS_NO = ( SELECT MAX(MAX_CUST.CIS_NO) FROM PVMCUST MAX_CUST WHERE MAX_CUST.REF_NO = '5101400189616' )) AND " & _
        " ( PVMCUST.REF_NO = '5101400189616' )"


        '***** ��Ҵ֧�ҡ page ����� ��ǹ��
        ' "values ('" & strCisno & "','" & strFirst & "','" & strFName & "','" & Trim(tbName.Text) & "','" & Trim(tbSname.Text) & "','" & _
        'strHtype & "','" & strNat & "','" & strOcc & "','" & strRef & "','" & Trim(tbRefno.Text) & "','" & tbTaxid.Text & "', " & _
        '"to_date('" & strBthDate & "','dd/mm/yyyy'),'" & strStatus & "', 0 ,'" & Session("user_id") & "', sysdate , sysdate," & _
        '"'" & tbEmail.Text & "')"


        '*** Insert new ccid to Bkci_cust_master

        strsql = " INSERT INTO TKYC.BKCI_CUST_MASTER " & _
              "( CC_ID, " & _
              " CUST_TYPE_ID, " & _
              " THA_TNAME, " & _
              " THA_FNAME, " & _
              " THA_LNAME, " & _
              " BIRTH_DATE, " & _
              " ID_CARD, " & _
              " ENTRY_DATE, " & _
              " TAX_ID  ) "


        '*** Insert new ccid to Kyc_address

        '// ��������ҹ = 2
        strsql = " INSERT INTO TKYC.KYC_ADDRESS " & _
                 "( CC_ID, " & _
                 " ADDRESS_CODE, " & _
                 " WORKING_PLACE, " & _
                 " ADDRESS_NO, " & _
                 " BUILD_VILLAGE_NAME, " & _
                 " MOO, " & _
                 " SOI, " & _
                 " ROAD, " & _
                 " SUB_DISTRICT, " & _
                 " DISTRICT, " & _
                 " PROVINCE, " & _
                 " POSTAL_CODE, " & _
                 " PHONE_NO_1, " & _
                 " PHONE_NO_2, " & _
                 " MOBILE_NO, " & _
                 " FAX_NO_1, " & _
                 " EMAIL ) " & _
        " SELECT :KYC.M_CCID, " & _
        " 2,"
        '"values ('" & strCisno & "','" & tbHouse_o.Text & "','" & tbMoo_o.Text & "','" & tbTower_o.Text & "','" & _
        'tbSoi_o.Text & "','" & tbRoad_o.Text & "','" & tbTambon_o.Text & "','" & tbAmphur_o.Text & "','" & strProv_o & "','" & _
        'tbZip_o.Text & "','" & tbTel1_o.Text & "','" & tbTel2_o.Text & "','" & tbTel3_o.Text & "','" & tbTelm_o.Text & "','" & _
        'tbFax_o.Text & "','" & tbhouse_h.Text & "','" & tbMoo_h.Text & "','" & tbTower_h.Text & "','" & _
        'tbSoi_h.Text & "','" & tbRoad_h.Text & "','" & tbTambon_h.Text & "','" & tbAmphur_h.Text & "','" & strProv_h & "','" & _
        'tbZip_h.Text & "','" & tbTel1_h.Text & "','" & tbTel2_h.Text & "','" & tbTel3_h.Text & "','" & tbTelm_h.Text & "','" & _
        'tbFax_h.Text & "','" & Session("user_id") & "', sysdate ,'" & tbPos.Text & "','" & tbDept.Text & "','" & _
        'strCnt_o & "','" & strCnt_h & "')"


        '// ���������ӧҹ = 3

        '// �������������¹��ҹ = 1
        strsql = " INSERT INTO TKYC.KYC_ADDRESS " & _
                        "( CC_ID, " & _
                        " ADDRESS_CODE, " & _
                        " WORKING_PLACE, " & _
                        " ADDRESS_NO, " & _
                        " BUILD_VILLAGE_NAME, " & _
                        " MOO, " & _
                        " SOI, " & _
                        " ROAD, " & _
                        " SUB_DISTRICT, " & _
                        " DISTRICT, " & _
                        " PROVINCE, " & _
                        " POSTAL_CODE, " & _
                        " PHONE_NO_1, " & _
                        " PHONE_NO_2, " & _
                        " MOBILE_NO, " & _
                        " FAX_NO_1, " & _
                        " EMAIL ) " & _
               " values ( :KYC.M_CCID," & _
               "  1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL ) "

    End Function

    Public Function UpdKycAmount() As String
        '*** Update amount to Kyc_due_dilegence

    End Function
End Class
