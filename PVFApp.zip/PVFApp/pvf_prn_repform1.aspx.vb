Imports System.IO
Imports System.Xml
Imports System.Data

Public Class pvf_prn_repform1
    Inherits System.Web.UI.Page
    Protected WithEvents DG_Tran As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DG_Fee As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DG_Return As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lbFund As System.Web.UI.WebControls.Label
    Protected WithEvents lbDescT As System.Web.UI.WebControls.Label
    Protected WithEvents lbMonth As System.Web.UI.WebControls.Label
    Protected WithEvents DG_Tran2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DG_Fee2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DG_Return2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents RepChildTran1 As System.Web.UI.WebControls.Repeater
    Protected WithEvents RepChildFee As System.Web.UI.WebControls.Repeater
    Protected WithEvents RepChildReturn As System.Web.UI.WebControls.Repeater
    Protected WithEvents Rep01 As System.Web.UI.WebControls.Repeater
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public Runno As Integer = 0
    Dim strsql As String
    Dim ds As New DataSet()
    Dim dsTmp As DataSet
    Dim m1 As New MyData()
    Dim Getdate As New ClassDate()
    Dim ds2 As New DataSet()
    Dim strCMonth, strCYear, strCDate        ' current year,month
    '*** Report form for Fund type 'EQ','GF','BL','FL','SPEQ','SPBL','SPFL'   except  'SPGF'

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            'Session("Fund") = "KYMO2"
            strCMonth = Request.QueryString("cmonth")
            strCYear = Request.QueryString("cyear")   ' ��
            GetData(strCMonth)
        End If
    End Sub

    Sub GetData(ByVal strMonth As String)
        Dim strFund, strFFile As String
        Dim strDay, strDate, strTmonth, strYear, strCur, strFirst, strFindDay As String
        Dim strFile, strFile2 As String
        Dim strFundN, strTranMonth, strDescT As String   ' ����Ѻ���ҧ 2
        Dim dc As Integer

        Dim dayEndofmonth As Date = DateSerial(strCYear, strMonth + 1, 0)
        strDay = Right("00" + CType(dayEndofmonth.Day, String), 2)
        strFindDay = strCYear & strMonth & strDay

        strFund = Request.QueryString("cfund")
        strsql = "  SELECT V_PVFUND_WEB.FUND_TNAME fund_tname,   " & _
                       "   V_PVFUND_WEB.FUND_POLICY , " & _
                        " V_PVFUND_WEB.TYPE_DESC_T, " & _
                        " V_PVFUND_WEB.TRUSTEE_NAME , " & _
                        " V_PVFUND_WEB.bk_NAME regis_name, " & _
                        " V_PVFUND_WEB.FUND_TYPE , " & _
                        " V_PVFUND_WEB.sign_date , " & _
                        " nvl( V_PVFUND_WEB.FUND_AMT,0)  fund_amt, " & _
                        " nvl( V_PVFUND_WEB.SHARE_AMT,0) share_amt, " & _
                        " MKTGPVFWEB.FUND fund, " & _
                        " MKTGPVFWEB.TRANSDATE tran_date, " & _
                        " MKTGPVFWEB.RTN_1M, " & _
                        " MKTGPVFWEB.RTN_3M, " & _
                        " MKTGPVFWEB.RTN_6M, " & _
                        " MKTGPVFWEB.RTN_1Y, " & _
                        " MKTGPVFWEB.RTN_SINCE, " & _
                        " MKTGPVFWEB.BMK1_1M, " & _
                        " MKTGPVFWEB.BMK1_3M, " & _
                        " MKTGPVFWEB.BMK1_6M, " & _
                        " MKTGPVFWEB.BMK1_1Y, " & _
                        " MKTGPVFWEB.BMK1_SINCE, " & _
                        " MKTGPVFWEB.BMK2_1M, " & _
                        " MKTGPVFWEB.BMK2_3M, " & _
                        " MKTGPVFWEB.BMK2_6M, " & _
                        " MKTGPVFWEB.BMK2_1Y, " & _
                        " MKTGPVFWEB.BMK2_SINCE, " & _
                        " rpad(MKTGPVFWEB.POLICY_AIMC,2) policy_aimc, " & _
                        " MKTGPVFWEB.NAV, " & _
                        " MKTGPVFWEB.TNAV, " & _
                        " ' ' cp_tran_month , '' cp_tran_first, '' cp_tran_curr, '' cp_rmk01, '' cp_rmk02, '' cp_rmk03 ,'' cp_rep, '' cp_rep2, " & _
                        " 0 cp_firstamt, ' ' cp_dvmonth, '' cp_dvdate , 0 cp_dvamt  , 0 cp_monthamt " & _
                        "    FROM mktg.MKTGPVFWEB  ,     V_PVFUND_WEB  " & _
                        "  WHERE ( MKTGPVFWEB.FUND = V_PVFUND_WEB.FUND )  and " & _
                                                " v_pvfund_web.fund in (" & strFund & ") and " & _
                                                " to_char(transdate,'mm' ) = '" & strMonth & "' and " & _
                                                " to_char(transdate,'yyyy' ) = '" & strCYear & "'  "
        ' lbMsg.Text = "***MAS *** " & strsql
        'Exit Sub

          ' ds = m1.FillMoreTable(ds, strsql, "dataMas")
        ds = m1.GetDataset(strsql)
        ds.Tables(0).TableName = "dataMas"

        Dim dcc As Integer = ds.Tables(0).Rows.Count
        If dcc <= 0 Then
            lbMsg.Text = "*** ����բ�������§ҹ ***" 'strsql
            Exit Sub
        End If

        Dim dr As DataRow = ds.Tables(0).Rows(0)
 
        For Each dr In ds.Tables(0).Rows
            strDate = dr("tran_date")
            strTmonth = Getdate.GetThaiLongMonthName(CType(dr("tran_date"), Date).Month)
            dr("cp_tran_month") = strTmonth & " " & Right(strDate, 4) + 543          'Left(strDateR, 2)
            strYear = Year(strDate) + 543
            dr("cp_tran_curr") = Day(strDate) & " " & strTmonth & " " & strYear         'Left(strDateR, 2)  �ѹ���ŧ�ع�Ѩ�غѹ

            strDate = dr("sign_date")
            strTmonth = Getdate.GetThaiLongMonthName(CType(dr("sign_date"), Date).Month)
            strYear = Year(strDate) + 543
            dr("cp_tran_first") = Day(strDate) & "  " & strTmonth & " " & strYear   ' �ѹ���ŧ�ع�����á
            dr("cp_firstamt") = CType(FormatNumber(CType(dr("fund_amt"), Int32), 2), Integer)

            strFundN = dr("fund_tname")
            strTranMonth = dr("cp_tran_month")          ' ����Ѻ ���ҧ���2 
            strDescT = dr("type_desc_t")                           ' ����Ѻ ���ҧ���2 
            strFund = dr("fund")

            ' ***** �� �ʹ � �����͹
            strsql = "select nvl(share_amt_bf,0) share_amt_bf   " & _
                          " from pvmtran where fund  = '" & strFund & "' and trn_no = " & _
                          " (select min(trn_no) from pvmtran  where fund = '" & strFund & "' and to_char(trn_date,'mm' ) > '" & strMonth & "' and " & _
                        " to_char(trn_date,'yyyy' ) = '" & strCYear & "'  )"

            ds2 = m1.GetDataset(strsql)

            dc = ds2.Tables(0).Rows.Count
            If dc > 0 Then
                Dim dr1 As DataRow = ds2.Tables(0).Rows(0)
                dr("cp_monthamt") = dr1("share_amt_bf")
            Else
                dr("cp_monthamt") = dr("share_amt")    ' share amt �ʹ�Թŧ�ع �Ѩ�غѹ
            End If

            Select Case dr("fund_type")
                Case "EQ"   ' equity
                    dr("cp_rmk01") = ""
                    dr("cp_rmk02") = ""
                    'strFFile = "masEQ_" & Month(Now) & Year(Now) + 543
                    strFFile = "masEQ_" & strMonth & strCYear + 543
                Case "BL", "FL"  ' balance
                    dr("cp_rmk01") = "(2) �ӹǳ�ҡ�Ѫ�� �Ѫ���Ҥҵ�Ҵ������˹�� ( TBDC Government Bond Index ) "
                    dr("cp_rmk01") &= "��дѪ���ѵ�Ҵ͡�����Թ�ҡ�ͧ��Ҥ�� ( �ӹǳ�ҡ�ѵ�Ҵ͡�����Թ�ҡ��Ш� 1 �� ����¢ͧ �.��ا෾ �.��ԡ��� ��� �.�¾ҳԪ�� ) "
                    dr("cp_rmk01") &= "�¶�ǧ���˹ѡ�����º�¡��ŧ�ع �ͧ�ͧ�ع "
                    dr("cp_rmk02") = "(3) �ӹǳ�ҡ�Ѫ�յ�Ҵ��ѡ��Ѿ�� ��дѪ���ѵ�Ҵ͡���¢ͧ��Ҥ�� (�ӹǳ�ҡ�ѵ�Ҵ͡�����Թ�ҡ��Ш� 1 ������¢ͧ �.��ا෾ �.��ԡ��� ��� �.�¾ҳԪ��"
                    dr("cp_rmk02") = "�¶�ǧ���˹ѡ��� ��º�¡��ŧ�ع�ͧ�ͧ�ع"
                    'strFFile = "masBL_" & Month(Now) & Year(Now) + 543
                    strFFile = "masBL_" & strMonth & strCYear + 543
                Case Else    ' GF = fixed income
                    dr("cp_rmk01") = "(2) �ӹǳ�ҡ �Ѫ���Ҥҵ�Ҵ������˹�� ( TBDC Government Bond Index ) "
                    dr("cp_rmk01") &= "��дѪ���ѵ�Ҵ͡�����Թ�ҡ�ͧ��Ҥ�� ( �ӹǳ�ҡ�ѵ�Ҵ͡�����Թ�ҡ��Ш� 1 �� ����¢ͧ �.��ا෾ �.��ԡ��� ��� �.�¾ҳԪ�� ) �¶�ǧ���˹ѡ��Ѵ��ǹ�����ҡѹ"
                    dr("cp_rmk02") = "(3) �ӹǳ�ҡ�ѵ�Ҵ͡�����Թ�ҡ��Ш� 1 ������� �ͧ �.��ا෾ �.��ԡ��� ��� �.�¾ҳԪ�� "
                    ' strFFile = "masGF_" & Month(Now) & Year(Now) + 543
                    strFFile = "masGF_" & strMonth & strCYear + 543
            End Select
            'lbRmk01.Text = dr("cp_rmk01")
            'lbRmk02.Text = dr("cp_rmk02")

            Dim xmlDataSet As New DataSet()
            ' ***************** News by Type  " EQ,GF, BL" *********************
            strFile = Server.MapPath("XML/" & strFFile & ".xml")
            '  Response.Write(" by manager " & strFile)
            If File.Exists(strFile) Then
                xmlDataSet.ReadXml(strFile)
                Dim dr2 As DataRow = xmlDataSet.Tables(0).Rows(0)

                dr("cp_rep") = " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News1")
                If Len(dr2("News2")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News2")
                If Len(dr2("News3")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News3")
                If Len(dr2("News4")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News4")
                If Len(dr2("News5")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News5")
                If Len(dr2("News6")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News6")

                'lbCpRep.Text = dr("cp_rep")
            End If

            Dim xmlDataSet2 As New DataSet()
            ' ***************** News by Fund *********************
            ' strFFile = dr("fund") & "_" & Month(Now) & Year(Now) + 543
            strFFile = dr("fund") & "_" & strMonth & strCYear + 543
            strFile2 = Server.MapPath("XML/" & strFFile & ".xml")
            ' Response.Write(" by fund " & strFile2)
            If File.Exists(strFile2) Then
                xmlDataSet2.ReadXml(strFile2)
                Dim dr3 As DataRow = xmlDataSet2.Tables(0).Rows(0)
                '   Response.Write(dr3("News1"))
                dr("cp_rep2") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr3("News1")
                If Len(dr3("News2")) > 0 Then dr("cp_rep2") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr3("News2")
                If Len(dr3("News3")) > 0 Then dr("cp_rep2") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr3("News3")

                'lbCpRep2.Text = dr("cp_rep2")
            End If
            '  dr("cp_rep") &= strFund
            '' ***** �������/Ŵ �Թ�ع 
            'GetDataTran(strFund, strMonth, strCYear)
            'GetDataReturn(strFund, strMonth, strCYear)
            'GetDataFee(strFund, strMonth, strCYear)
        Next

        ' **** Add Relation for Tran
        strsql = "select trn_no,fund,trn_date,trn_type,trn_type_desc,share_amt,share_amt_bf,trn_date ,nav , bal_amount, trn_date_th " & _
                        " from v_pvmtran_web  where  trn_type <> 'DV'  and " & _
                        " to_char(trn_date,'yyyymmdd') <=  '" & strFindDay & "'"

        'to_char(trn_date,'yyyy') <= '" & strCYear & "' " & _
        '" and to_char(trn_date,'mm' ) <= '" & strCMonth & "'"
        '  Response.Write(strsql)

        ds = m1.FillMoreTable(ds, strsql, "dataTran")
        dc = ds.Tables("dataTran").Rows.Count
        If dc > 0 Then
            Dim dr1 As DataRow = ds.Tables("dataTran").Rows(0)

            For Each dr1 In ds.Tables("dataTran").Rows
                strDate = dr1("trn_date")
                strTmonth = Getdate.GetThaiShortMonthName(CType(dr1("trn_date"), Date).Month)
                strYear = Year(strDate) + 543
                strDay = Day(strDate)
                dr1("trn_date_th") = strDay & " " & strTmonth & " " & strYear
            Next
        End If
        'Dim dc1 As DataColumn = ds.Tables(0).Columns("fund")
        'Dim dc2 As DataColumn = ds.Tables(1).Columns("fund")
        'Dim r1 As New DataRelation("xx", dc1, dc2)
        Dim r1 As New DataRelation("relationTran", New DataColumn() {ds.Tables.Item("dataMas").Columns.Item("fund")}, New DataColumn() {ds.Tables.Item("dataTran").Columns.Item("fund")}, False)
        ds.Relations.Add(r1)
        dc = ds.Tables("dataTran").Rows.Count
        '   Response.Write("tran " & dc)

        ' **** Add Relation for Fee
        'strsql = "select fund,rep_date,pay_date, amount,' ' rep_date_th, ' ' pay_date_th , ' ' month_th" & _
        '             " from pvmfee  where to_char(rep_date,'yyyy' ) <= '" & strCYear & "' " & _
        '"  and to_char(rep_date,'mm' ) <= '" & strCMonth & "'"
        strsql = "select fund_code as fund ,data_date as rep_date,payment_date as pay_date, " & _
                        " nvl(net_amt,0) as amount,' ' rep_date_th, ' ' pay_date_th , ' ' month_th" & _
                        " from warndba.v_private_fee  " & _
                        " where    to_char(data_date,'yyyymmdd') <=  '" & strFindDay & "'"

        'to_char(data_date,'yyyy') <='" & strCYear & "' " & _
        '                    "  and to_char(data_date,'mm' ) <= '" & strCMonth & "'"

        ds = m1.FillMoreTable(ds, strsql, "dataFee")
        dc = ds.Tables("dataFee").Rows.Count
        If dc > 0 Then
            dr = ds.Tables("dataFee").Rows(0)

            For Each dr In ds.Tables("dataFee").Rows
                strDate = dr("rep_date")
                strTmonth = Getdate.GetThaiShortMonthName(CType(dr("rep_date"), Date).Month)
                strYear = Year(strDate) + 543
                strDay = Day(strDate)
                dr("rep_date_th") = strDay & " " & strTmonth & " " & strYear
                dr("month_th") = strTmonth & " " & strYear

                strDate = dr("pay_date")
                strTmonth = Getdate.GetThaiShortMonthName(CType(dr("pay_date"), Date).Month)
                strYear = Year(strDate) + 543
                strDay = Day(strDate)
                dr("pay_date_th") = strDay & " " & strTmonth & " " & strYear
            Next
        End If
        Dim r2 As New DataRelation("relationFee", New DataColumn() {ds.Tables.Item("dataMas").Columns.Item("fund")}, New DataColumn() {ds.Tables.Item("dataFee").Columns.Item("fund")}, False)
        ds.Relations.Add(r2)

        dc = ds.Tables("dataFee").Rows.Count
        '     Response.Write("fee  " & dc)


        ' **** Add Relation for Return
        Dim icount, irun As Integer
        Dim strTemp As String

        strsql = "select trn_no,fund,trn_date,trn_type,trn_type_desc,share_amt,trn_date ,nav , trn_date_th , 0 cp_runno" & _
                               " from v_pvmtran_web  where  trn_type = 'DV' and " & _
                               " to_char(trn_date,'yyyymmdd') <=  '" & strFindDay & "' " & _
                               " order by fund,trn_no "

        '"  and to_char(trn_date,'yyyy' ) = '" & strCYear & "' " & _
        '"  and to_char(trn_date,'mm' ) <= '" & strCMonth & "' order by fund,trn_no "

        ds = m1.FillMoreTable(ds, strsql, "dataReturn")
        dc = ds.Tables("dataReturn").Rows.Count
        If dc > 0 Then
            dr = ds.Tables("dataReturn").Rows(0)
            For Each dr In ds.Tables("dataReturn").Rows
                icount += 1
                strDate = dr("trn_date")
                strTmonth = Getdate.GetThaiShortMonthName(CType(dr("trn_date"), Date).Month)
                strYear = Year(strDate) + 543
                strDay = Day(strDate)
                dr("trn_date_th") = strDay & " " & strTmonth & " " & strYear

                If icount = 1 Then
                    strTemp = dr("fund")
                    irun = 0
                End If
                If strTemp = dr("fund") Then
                    irun += 1
                Else
                    strTemp = dr("fund")
                    irun = 1
                End If
                dr("cp_runno") = irun
            Next
        End If
        Dim r3 As New DataRelation("relationReturn", New DataColumn() {ds.Tables.Item("dataMas").Columns.Item("fund")}, New DataColumn() {ds.Tables.Item("dataReturn").Columns.Item("fund")}, False)
        ds.Relations.Add(r3)

        dc = ds.Tables("dataReturn").Rows.Count
        '    Response.Write("ret  " & dc)

        '  ds.Relations.Add("relationTran", ds.Tables("dataMas").Columns("fund"), ds.Tables("dataTran").Columns("fund"))

        Rep01.DataSource = ds.Tables(0)
        Rep01.DataBind()

    End Sub

    Sub GetDataTran(ByVal strFund As String, ByVal strcmonth As String, ByVal strcyear As String)
        Dim dg As DataGrid
        Dim i As Integer
        '  For i = 0 To Rep01.Items.Count - 1
        dg = Rep01.Items(i).FindControl("DG_Tran")
        strsql = "select trn_no,fund,trn_date,trn_type,trn_type_desc,share_amt,share_amt_bf,trn_date ,nav , bal_amount, trn_date_th " & _
                     " from v_pvmtran_web  where fund  = '" & strFund & "' and to_char(trn_date,'yyyy') = '" & strcyear & "' " & _
                     " and trn_type <> 'DV' " & _
                     " and to_char(trn_date,'mm' ) <= '" & strcmonth & "'"

        'lbMsg.Text &= " **** TRAN **** " & strsql
        'Exit Sub
        dsTmp = m1.GetDataset(strsql)
        Dim dc As Integer = dsTmp.Tables(0).Rows.Count
        If dc > 0 Then
            Dim dr As DataRow = dsTmp.Tables(0).Rows(0)
            Dim strDate, strDay, strTmonth, strYear As String

            For Each dr In dsTmp.Tables(0).Rows
                strDate = dr("trn_date")
                strTmonth = Getdate.GetThaiShortMonthName(CType(dr("trn_date"), Date).Month)
                strYear = Year(strDate) + 543
                strDay = Day(strDate)
                dr("trn_date_th") = strDay & " " & strTmonth & " " & strYear
            Next
        End If
        dg.DataSource = dsTmp
        dg.DataBind()
        '  Next

        'DG_Tran.DataSource = dsTmp
        'DG_Tran.DataBind()
    End Sub

    Sub GetDataReturn(ByVal strFund As String, ByVal strcmonth As String, ByVal strcyear As String)
        Dim i As Integer
        Dim dg As DataGrid
        i = 0
        For i = 0 To Rep01.Items.Count - 1
            dg = Rep01.Items(i).FindControl("DG_Return")

            strsql = "select trn_no,fund,trn_date,trn_type,trn_type_desc,share_amt,trn_date ,nav , trn_date_th , 0 cp_runno" & _
                          " from v_pvmtran_web  where fund  = '" & strFund & _
                          "' and trn_type = 'DV' " & _
                          "  and to_char(trn_date,'yyyy' ) = '" & strcyear & "' " & _
                          "  and to_char(trn_date,'mm' ) <= '" & strcmonth & "'"  ' �׹�Ż���ª��   and substring(convert(char(2),trn_date,101 ),1,2) = '" & strCmonth & "' and " & _    
            ' 101 format mm/dd/yy  , 102 format yy/mm/dd
            'lbMsg.Text &= " **** RETURN **** " & strsql
            'Exit Sub

            dsTmp = m1.GetDataset(strsql)

            Dim dc As Integer = dsTmp.Tables(0).Rows.Count

            If dc > 0 Then
                Dim dr As DataRow = dsTmp.Tables(0).Rows(0)
                Dim strDate, strDay, strTmonth, strYear As String

                For Each dr In dsTmp.Tables(0).Rows
                    strDate = dr("trn_date")
                    strTmonth = Getdate.GetThaiShortMonthName(CType(dr("trn_date"), Date).Month)
                    strYear = Year(strDate) + 543
                    strDay = Day(strDate)
                    dr("trn_date_th") = strDay & " " & strTmonth & " " & strYear
                    i = i + 1
                    dr("cp_runno") = i
                Next
            End If

            dg.DataSource = dsTmp
            dg.DataBind()
        Next
        'DG_Return.DataSource = dsTmp
        'DG_Return.DataBind()
    End Sub

    Sub GetDataFee(ByVal strFund As String, ByVal strcmonth As String, ByVal strcyear As String)
        Dim dg As DataGrid
        Dim i As Integer
        For i = 0 To Rep01.Items.Count - 1
            dg = Rep01.Items(i).FindControl("DG_Fee")
            strsql = "select fund,rep_date,pay_date, amount,' ' rep_date_th, ' ' pay_date_th , ' ' month_th" & _
                       " from pvmfee  where fund  = '" & strFund & "'  and to_char(rep_date,'yyyy' ) = '" & strcyear & "' " & _
                       "  and to_char(rep_date,'mm' ) <= '" & strcmonth & "'"

            'lbMsg.Text &= " **** FEE **** " & strsql
            'Exit Sub

            dsTmp = m1.GetDataset(strsql)
            Dim dc As Integer = dsTmp.Tables(0).Rows.Count
            If dc > 0 Then
                Dim dr As DataRow = dsTmp.Tables(0).Rows(0)
                Dim strDate, strDay, strTmonth, strYear As String

                For Each dr In dsTmp.Tables(0).Rows
                    strDate = dr("rep_date")
                    strTmonth = Getdate.GetThaiShortMonthName(CType(dr("rep_date"), Date).Month)
                    strYear = Year(strDate) + 543
                    strDay = Day(strDate)
                    dr("rep_date_th") = strDay & " " & strTmonth & " " & strYear
                    dr("month_th") = strTmonth & " " & strYear

                    strDate = dr("pay_date")
                    strTmonth = Getdate.GetThaiShortMonthName(CType(dr("pay_date"), Date).Month)
                    strYear = Year(strDate) + 543
                    strDay = Day(strDate)
                    dr("pay_date_th") = strDay & " " & strTmonth & " " & strYear
                Next
            End If

            dg.DataSource = dsTmp
            dg.DataBind()
        Next

        'DG_Fee.DataSource = ds
        'DG_Fee.DataBind()

    End Sub

    Sub GetXML()
        Dim xmlDataSet As New DataSet()
        xmlDataSet.ReadXml(Server.MapPath("testxml.xml"))
        'DG1.DataSource = xmlDataSet
        'DG1.DataBind()
        Dim dr As DataRow = xmlDataSet.Tables(0).Rows(0)
        Dim strNews
        strNews = Mid(dr("News"), 2, Len(dr("News")) - 2)    ' �Ѵ " ' "   �͡�ҡ��ͤ��� ��Ƿ���
        '    tbNews.Text = strNews

    End Sub

    Private Sub Rep01_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs)
        'Dim lb As Label
        'Dim strFund, strMonth As String
        'Dim i As Integer
        '' ***** �������/Ŵ �Թ�ع 

        'GetDataTran(strFund, strMonth, strCYear)
        'GetDataReturn(strFund, strMonth, strCYear)
        'GetDataFee(strFund, strMonth, strCYear)
    End Sub

    Private Sub Rep01_ItemCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs) Handles Rep01.ItemCommand

    End Sub
End Class
