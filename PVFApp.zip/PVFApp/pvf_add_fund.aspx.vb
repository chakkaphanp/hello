Public Class pvf_add_fund
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Protected WithEvents ddDy_d As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm_d As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd_d As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDy_s As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm_s As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd_s As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbSignAmt As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddFtype As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbFname_e As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFname As System.Web.UI.WebControls.TextBox
    Protected WithEvents lberr1 As System.Web.UI.WebControls.Label
    Protected WithEvents tbFund As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbText As System.Web.UI.WebControls.Label
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents img2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents img1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Panel_t1 As System.Web.UI.WebControls.Panel
    Protected WithEvents img3 As System.Web.UI.WebControls.ImageButton

    Protected WithEvents ddDd_r As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm_r As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDy_r As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbAuditBy As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAuditAddr As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFPolicy As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFCond As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFReturn As System.Web.UI.WebControls.TextBox
    Protected WithEvents Panel_t2 As System.Web.UI.WebControls.Panel
    Protected WithEvents tbFeeM As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFeeT As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFeeA As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddDd_e As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm_e As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDy_e As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbBFAmt As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbBFUnit As System.Web.UI.WebControls.TextBox
    Protected WithEvents Panel_t3 As System.Web.UI.WebControls.Panel
    Protected WithEvents rdDef As System.Web.UI.WebControls.RadioButton
    Protected WithEvents tbAccno As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAccName As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddAccType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkCode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkBran As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbAccno2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAccName2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddAccType2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkCode2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkBran2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbAccno3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAccName3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddAccType3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkCode3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkBran3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbAccno4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAccName4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddAccType4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkCode4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkBran4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Panel_t4 As System.Web.UI.WebControls.Panel
    Protected WithEvents img4 As System.Web.UI.WebControls.ImageButton

    Protected WithEvents tbRefNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents btSave2 As System.Web.UI.WebControls.Button
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label

    Protected WithEvents ddRegis As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lbSign As System.Web.UI.WebControls.Label
    Protected WithEvents lbDue As System.Web.UI.WebControls.Label
    Protected WithEvents lbReSign As System.Web.UI.WebControls.Label
    Protected WithEvents lbRegis As System.Web.UI.WebControls.Label
    Protected WithEvents lbAmt As System.Web.UI.WebControls.Label
    Protected WithEvents lbUnit As System.Web.UI.WebControls.Label
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents btUpd As System.Web.UI.WebControls.Button
    Protected WithEvents btCancel As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents tbMin As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbBuyNext As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbSellMin As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddAgent As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Panel_h As System.Web.UI.WebControls.Panel
    Dim mc As New ClassCheckUser()
    Dim strsql As String
    Dim FlgUpd As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Protected WithEvents ddRisk As System.Web.UI.WebControls.DropDownList
    Protected WithEvents rdlFundFlg As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents ddMkt As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Panel_t5 As System.Web.UI.WebControls.Panel
    Protected WithEvents Img5 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents chbDoc As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents rdlChkdoctype As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents tbdocremk As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddlFeeCond As System.Web.UI.WebControls.DropDownList
    'Dim m2 As New MyData_Nasset
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not Page.IsPostBack Then
            Panel_t1.Attributes.Add("style", "display:")
            Panel_t2.Attributes.Add("style", "display:none")
            Panel_t3.Attributes.Add("style", "display:none")
            Panel_t3.Attributes.Add("style", "display:none")
            Panel_t4.Attributes.Add("style", "display:none")
            Panel_t5.Attributes.Add("style", "display:none")
            Panel_h.Attributes.Add("style", "display:none")    ' �红�鹵��

            If mc.CheckUser(Session("user_id"), "reg_fund") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                btUpd.Enabled = False
                Exit Sub
            End If

            strsql = "select type_code, type_desc_t from pv.fundtype where type_flg = 'T' order by type_desc_t  "
            'type_flg ����Ѻ���������������� T = ��
            'type_code in ('EQ','GF','BL','FL','SPEQ','SPGF','SPBL','SPFL') order by type_desc_t "
            ds = m1.GetDataset(strsql)
            ddFtype.DataSource = ds
            ddFtype.DataTextField = "type_desc_t"
            ddFtype.DataValueField = "type_code"

            strsql = "select  bk_name , bk_code  from cis.opnmbank where bk_bran = 'XXX' order by bk_name "
            ds = m1.GetDataset(strsql)
            ddRegis.DataSource = ds      ' for trustee/regis
            ddRegis.DataTextField = "bk_name"
            ddRegis.DataValueField = "bk_code"

            ddBkCode.DataSource = ds                ' for accout bank
            ddBkCode.DataTextField = "bk_name"
            ddBkCode.DataValueField = "bk_code"

            ddBkCode2.DataSource = ds                ' for accout bank
            ddBkCode2.DataTextField = "bk_name"
            ddBkCode2.DataValueField = "bk_code"

            ddBkCode3.DataSource = ds                ' for accout bank
            ddBkCode3.DataTextField = "bk_name"
            ddBkCode3.DataValueField = "bk_code"

            ddBkCode4.DataSource = ds                ' for accout bank
            ddBkCode4.DataTextField = "bk_name"
            ddBkCode4.DataValueField = "bk_code"

            strsql = "select  obj_desc , obj_code  from pvmobj where obj_type = 'risk_level' order by obj_desc "
            ds = m1.GetDataset(strsql)
            ddRisk.DataSource = ds
            ddRisk.DataTextField = "obj_desc"
            ddRisk.DataValueField = "obj_code"

            'strsql = "select br_code,br_name  from cis.opnmagen where substr(br_code,4,6) = '000001' order by br_name "
            'ds = m1.GetDataset(strsql)
            'ddAgent.DataSource = ds
            'ddAgent.DataTextField = "br_name"
            'ddAgent.DataValueField = "br_code"

            strsql = "select  user_id,'('||user_id||') '||user_name||' '||user_sname as u_name " & _
                     "from sao.sawebuser where agent_id  = '000000001' and status = 'A' order by user_id "
            ds = m1.GetDataset(strsql)
            ddMkt.DataSource = ds
            ddMkt.DataTextField = "u_name"
            ddMkt.DataValueField = "user_id"

            GetDate()

            Dim str_cur As Integer
            str_cur = Now.Month
            ddDm_s.SelectedIndex = str_cur - 1
            ddDm_r.SelectedIndex = str_cur - 1
            ddDm_d.SelectedIndex = str_cur - 1
            ddDm_e.SelectedIndex = str_cur - 1

            If Not Request.QueryString("fund") Is Nothing Then
                GetData(Request.QueryString("fund"))
                tbFund.Text = Request.QueryString("fund")
            End If
            AddItem()
        End If

    End Sub

    Sub AddItem()
        ddFtype.Items.Insert(0, "*** �ä�к� ***")
        ddRegis.Items.Insert(0, "*** �ä�к� ***")
        ddBkCode.Items.Insert(0, "*** �ä�к� ***")
        ddBkCode2.Items.Insert(0, "*** �ä�к� ***")
        ddBkCode3.Items.Insert(0, "*** �ä�к� ***")
        ddBkCode4.Items.Insert(0, "*** �ä�к� ***")
        ddMkt.Items.Insert(0, "*** �ä�к� ***")

        'ddFtype.Items.Add("*** �ä�к� ***")
        'ddFtype.SelectedIndex = ddFtype.Items.Count - 1
        'ddRegis.Items.Add("*** �ä�к� ***")
        'ddRegis.SelectedIndex = ddRegis.Items.Count - 1
        ''ddAgent.Items.Add("*** �ä�к� ***")
        ''ddAgent.SelectedIndex = ddAgent.Items.Count - 1
        'ddBkCode.Items.Add("*** �ä�к� ***")
        'ddBkCode.SelectedIndex = ddBkCode.Items.Count - 1
        'ddBkCode2.Items.Add("*** �ä�к� ***")
        'ddBkCode2.SelectedIndex = ddBkCode2.Items.Count - 1
        'ddBkCode3.Items.Add("*** �ä�к� ***")
        'ddBkCode3.SelectedIndex = ddBkCode3.Items.Count - 1
        'ddBkCode4.Items.Add("*** �ä�к� ***")
        'ddBkCode4.SelectedIndex = ddBkCode4.Items.Count - 1
    End Sub

    Private Sub GetDate()
        Dim c_date As Date = Now
        Dim str_cur As String

        str_cur = c_date.Day

        Dim i As Integer
        For i = 0 To 31
            ddDd_s.Items.Add(i)
            ddDd_d.Items.Add(i)
            ddDd_r.Items.Add(i)
            ddDd_e.Items.Add(i)
        Next

        ddDd_s.SelectedIndex = str_cur
        ddDd_d.SelectedIndex = str_cur
        ddDd_r.SelectedIndex = str_cur
        ddDd_e.SelectedIndex = str_cur

        strsql = "select * from web.webmonth"
        ds = m1.GetDataset(strsql)
        ddDm_s.DataSource = ds
        ddDm_s.DataTextField = "mth_t_name"
        ddDm_s.DataValueField = "mth_code"

        ddDm_d.DataSource = ds
        ddDm_d.DataTextField = "mth_t_name"
        ddDm_d.DataValueField = "mth_code"

        ddDm_r.DataSource = ds
        ddDm_r.DataTextField = "mth_t_name"
        ddDm_r.DataValueField = "mth_code"

        ddDm_e.DataSource = ds
        ddDm_e.DataTextField = "mth_t_name"
        ddDm_e.DataValueField = "mth_code"

        'Dim yy() As Integer = {"2542", "2543", "2544", "2545", "2546", "2547", "2548", "2549", "2550"}

        Dim yy(20) As Integer ' = {"2543", "2544", "2545", "2546", "2547", "2548", "2549", "2550"}
        Dim c_year As Integer

        c_year = Now.Year - 6
        c_year = c_year + 543

        For i = 1 To 20
            yy(i) = c_year + i
        Next

        ddDy_s.DataSource = yy          ' sign date
        ddDy_d.DataSource = yy          ' due date
        ddDy_r.DataSource = yy           ' resign date
        ddDy_e.DataSource = yy          ' expire date

        ddDy_s.SelectedIndex = 6
        ddDy_d.SelectedIndex = 6
        ddDy_r.SelectedIndex = 6
        ddDy_e.SelectedIndex = 6

        'str_cur = c_date.Year + 543
        'Label1.Text = str_cur
        'dddy.SelectedIndex = str_cur
        Me.DataBind()

        '           Dim m2 As Class_GetDate
        '       Dim ddd As DropDownList = dddd.NamingContainer
        '            m2.Getday("dddd")
    End Sub

    Sub Init_page(ByVal strChk As String)
        If strChk = "0" Then
            tbFund.Text = ""
        End If

        ClearText()

        tbSignAmt.Text = "0"
        tbBuyNext.Text = "0"
        tbMin.Text = "0"
        tbSellMin.Text = "0"

        tbBFAmt.Text = "0"
        tbBFUnit.Text = "0"
        lbAmt.Text = ""
        lbUnit.Text = ""

        Me.GetDate()

        Dim str_cur As Integer
        str_cur = Now.Month
        ddDm_s.SelectedIndex = str_cur - 1
        ddDm_r.SelectedIndex = str_cur - 1
        ddDm_d.SelectedIndex = str_cur - 1
        ddDm_e.SelectedIndex = str_cur - 1
        ddDy_s.SelectedIndex = 6
        ddDy_r.SelectedIndex = 6
        ddDy_d.SelectedIndex = 6
        ddDy_e.SelectedIndex = 6

        ddFtype.SelectedIndex = ddFtype.Items.Count - 1
        ddRegis.SelectedIndex = ddRegis.Items.Count - 1
        'ddFtype.SelectedIndex = -1
        'ddRegis.SelectedIndex = -1
        ddBkCode.SelectedIndex = -1
        ddBkBran.SelectedIndex = -1
        ddMkt.SelectedIndex = -1

    End Sub

    Sub GetData(ByVal strFund As String)
        Label1.Text = ""
        strsql = "select  fund,fund_tname, nvl(fund_ename,' ') fund_ename,nvl(fund_policy,' ') fund_policy, " & _
            "nvl(fund_cond,' ') fund_cond, nvl(fund_return,' ') fund_return, nvl(fund_amt,0) fund_amt ,nvl(to_char(sign_date,'dd/mm/yyyy'),' ') sign_date, " & _
            "nvl(to_char(due_date,'dd/mm/yyyy'),' ') due_date,nvl(to_char(resign_date,'dd/mm/yyyy'),' ') resign_date, " & _
            "nvl(to_char(regis_date,'dd/mm/yyyy'),' ') regis_date, " & _
            "nvl(balance_amt,0) balance_amt , nvl(balance_unit,0) balance_unit , fund_type, nvl(regis_name,' ') regis_name,trustee_name, nvl(mkt_agent,' ') mkt_agent,  " & _
             "nvl(mkt_code,' ') mkt_code,nvl(audit_by,' ') audit_by, nvl(audit_addr,' ') audit_addr ," & _
            " nvl(management_feetxt,' ') management_fee, nvl(trustee_feetxt,' ') trustee_fee, nvl(audit_feetxt,' ') audit_fee, nvl(ref_no,' ') ref_no " & _
            " from pv.funddesc where fund  = '" & strFund & "'"
        ds = m1.GetDataset(strsql)

        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            ' lbText.Text = "  ��䢢����šͧ�ع  "
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            tbFname.Text = dr("fund_tname")
            tbFname_e.Text = dr("fund_ename")
            tbSignAmt.Text = dr("fund_amt")
            tbFPolicy.Text = dr("fund_policy")
            tbFCond.Text = dr("fund_cond")
            tbFReturn.Text = dr("fund_return")
            tbBFAmt.Text = dr("balance_amt")
            tbBFUnit.Text = dr("balance_unit")

            lbSign.Text = dr("sign_date")
            lbDue.Text = dr("due_date")
            lbReSign.Text = dr("resign_date")
            lbRegis.Text = dr("regis_date")
            ddDd_s.Visible = False
            ddDm_s.Visible = False
            ddDy_s.Visible = False
            ddDd_d.Visible = False
            ddDm_d.Visible = False
            ddDy_d.Visible = False
            ddDd_r.Visible = False
            ddDm_r.Visible = False
            ddDy_r.Visible = False
            ddDd_e.Visible = False
            ddDm_e.Visible = False
            ddDy_e.Visible = False

            tbAuditBy.Text = dr("audit_by")
            tbAuditAddr.Text = dr("audit_addr")
            tbFeeM.Text = dr("management_fee")
            tbFeeT.Text = dr("trustee_fee")
            tbFeeA.Text = dr("audit_fee")
            tbRefNo.Text = dr("ref_no")

            Dim strFtype As String = dr("fund_type")
            Dim strTrustee As String = dr("regis_name")
            Dim strAgent As String = dr("mkt_agent")
            Dim strMkt As String = dr("mkt_code")
            Dim dd1 As ListItem = ddFtype.SelectedItem
            Dim dd2 As ListItem
            Dim index1 As Integer

            dd2 = ddFtype.Items.FindByValue(strFtype)
            index1 = ddFtype.Items.IndexOf(dd2)
            ddFtype.SelectedIndex = index1

            dd2 = ddRegis.Items.FindByValue(strTrustee)
            index1 = ddRegis.Items.IndexOf(dd2)
            ddRegis.SelectedIndex = index1

            ''dd2 = ddAgent.Items.FindByValue(strAgent)
            ''index1 = ddAgent.Items.IndexOf(dd2)
            ''ddAgent.SelectedIndex = index1

            dd2 = ddMkt.Items.FindByValue(strMkt)
            index1 = ddMkt.Items.IndexOf(dd2)
            ddMkt.SelectedIndex = index1

            'ddDd_s.SelectedIndex = CType(Left(dr("sign_date"), 2), Integer)
            'ddDm_s.SelectedIndex = CType(Mid(dr("sign_date"), 3, 2), Integer) - 1
            ''dd2 = ddDy_s.Items.FindByValue(CType(Right(dr("sign_date"), 4), Integer))
            ''index1 = ddDy_s.Items.IndexOf(dd2)
            ''ddDy_s.SelectedIndex = index1 + 1

            'ddDd_d.SelectedIndex = CType(Left(dr("due_date"), 2), Integer)
            'ddDm_d.SelectedIndex = CType(Mid(dr("due_date"), 3, 2), Integer) - 1

            'ddDd_r.SelectedIndex = CType(Left(dr("resign_date"), 2), Integer)
            'ddDm_r.SelectedIndex = CType(Mid(dr("resign_date"), 3, 2), Integer) - 1

            strsql = "select  nvl(min_bath,0) min_bath ,nvl(buy_next_bath,0) buy_next_bath,nvl(sell_min_bath,0) sell_min_bath, " & _
                          " nvl(share_unit,0) share_unit, nvl(share_amt,0) share_amt " & _
                         "  from pv.fundcontl  where fund  = '" & strFund & "'"
            ds = m1.FillMoreTable(ds, strsql, "Fundcontl")
            Dim dr2 As DataRow = ds.Tables(1).Rows(0)
            tbMin.Text = dr2("min_bath")
            tbBuyNext.Text = dr2("buy_next_bath")
            tbSellMin.Text = dr2("sell_min_bath")
            lbUnit.Text = CType(dr2("share_unit"), Double).ToString("###,###,##0.0000")
            lbAmt.Text = CType(dr2("share_amt"), Double).ToString("###,###,##0.00")

            btSave.Visible = False
            'btUpd.Visible = True

            Clear2()
        Else
            lbSign.Text = ""
            lbDue.Text = ""
            lbReSign.Text = ""
            lbRegis.Text = ""
            lbText.Text = "  ���������šͧ�ع����  "
            ddDd_s.Visible = True
            ddDm_s.Visible = True
            ddDy_s.Visible = True
            ddDd_d.Visible = True
            ddDm_d.Visible = True
            ddDy_d.Visible = True
            ddDd_r.Visible = True
            ddDm_r.Visible = True
            ddDy_r.Visible = True
            ddDy_e.Visible = True
            ddDd_e.Visible = True
            ddDm_e.Visible = True
            ddDy_e.Visible = True

            btSave.Visible = True
            btUpd.Visible = False
            Init_page("1")
            lberr1.Text = ""
        End If
    End Sub

    Private Sub btCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btCancel.Click
        Init_page("0")
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        '   Dim strFtype As String = ddFtype.SelectedItem.Value
        Dim strSignDate As String = ddDd_s.SelectedItem.Value & "/" & ddDm_s.SelectedItem.Value & "/" & ddDy_s.SelectedItem.Value - 543
        Dim strReSignDate As String = ddDd_r.SelectedItem.Value & "/" & ddDm_r.SelectedItem.Value & "/" & ddDy_r.SelectedItem.Value - 543
        Dim strDueDate As String = ddDd_d.SelectedItem.Value & "/" & ddDm_d.SelectedItem.Value & "/" & ddDy_d.SelectedItem.Value - 543
        Dim strEntDate As String = ddDd_e.SelectedItem.Value & "/" & ddDm_e.SelectedItem.Value & "/" & ddDy_e.SelectedItem.Value - 543
        Dim dbSignAmt As Double = CType(tbSignAmt.Text, Double)
        'Dim dbMin As Double = CType(tbMin.Text, Double)
        'Dim dbSellMin As Double = CType(tbSellMin.Text, Double)
        'Dim dbBuyNext As Double = CType(tbBuyNext.Text, Double)
        Dim dbBfAmt As Double = CType(tbBFAmt.Text, Double)
        Dim dbBfUnit As Double = CType(tbBFUnit.Text, Double)
        Dim strRisk As String = ddRisk.SelectedItem.Value
        Dim strRegis As String
        Dim strMkt As String

        If ddFtype.SelectedItem.Text = "*** �ä�к� ***" Then
            lberr1.Text = "��س��кػ����� �ͧ�ع "
            Exit Sub
            'ElseIf ddAgent.SelectedItem.Text = "*** �ä�к� ***" Then
            '    lberr1.Text = "��س��к� ���᷹ "
            '    Exit Sub
            'ElseIf ddMkt.SelectedItem.Text = "*** �ä�к� ***" Then
            '    lberr1.Text = "��س��к� Marketting "
            '    Exit Sub
            'ElseIf ddRegis.SelectedItem.Text = "*** �ä�к� ***" Then
            '    lberr1.Text = "��س��к� ����Ѻ�ҡ��Ѿ���Թ"
            '    Exit Sub
        End If

        If ddRegis.SelectedItem.Text = "*** �ä�к� ***" Then
            strRegis = ""
        Else
            strRegis = ddRegis.SelectedItem.Value
        End If

        If ddDd_r.SelectedItem.Value = "0" Then
            strReSignDate = "null , "
        Else
            strReSignDate = "to_date('" & strReSignDate & "','dd/mm/yyyy'), "
        End If

        If ddDd_d.SelectedItem.Value = "0" Then
            strDueDate = "null ,"
        Else
            strDueDate = "to_date('" & strDueDate & "','dd/mm/yyyy'), "
        End If

        If ddMkt.SelectedItem.Text = "*** �ä�к� ***" Then
            strMkt = ""
        Else
            strMkt = ddMkt.SelectedItem.Value
        End If

        strsql = "insert into pv.FundDesc (fund,fund_tname,fund_ename_short,fund_type,sign_date,resign_date,due_date,fund_amt, " & _
                   "regis_name,trustee_name,fund_policy,fund_cond, fund_return,fund_flg,regis_date,balance_amt,balance_unit, " & _
                   "mkt_agent,mkt_code,audit_by, audit_addr,management_feetxt, trustee_feetxt,audit_feetxt , " & _
                   "upd_by, ref_no,risk_level,fund_status, cond_fee)  " & _
                   " values ( '" & _
                   tbFund.Text & "','" & tbFname.Text & "','" & tbFname_e.Text & "','" & ddFtype.SelectedItem.Value & "'," & _
                   "to_date('" & strSignDate & "','dd/mm/yyyy'), " & strReSignDate & _
                   strDueDate & dbSignAmt & ",'" & strRegis & "', '' , '" & _
                   tbFPolicy.Text & "','" & tbFCond.Text & "','" & tbFReturn.Text & "','" & _
                   rdlFundFlg.SelectedValue & "',to_date('" & strEntDate & "','dd/mm/yyyy') , " & _
                   dbBfAmt & "," & dbBfUnit & ",'000000001','" & strMkt & "','" & _
                   tbAuditBy.Text & "','" & tbAuditAddr.Text & "','" & tbFeeM.Text & "','" & tbFeeT.Text & "','" & tbFeeA.Text & "','" & _
                   Session("user_id") & "' , '" & tbRefNo.Text & "','" & strRisk & "','A','" & _
                   ddlFeeCond.SelectedValue & "')"

        Try
            m1.Execute(strsql)

            'strsql = "insert into pv.FundExpenses (fund, management_fee,trustee_fee,audit_fee) values ( '" & _
            '           tbFund.Text & "'," & tbFeeM.Text & "," & tbFeeT.Text & "," & tbFeeA.Text & ")"
            'm1.Execute(strsql)

            strsql = "insert into pv.FundContl (fund,class_code,type_code,holder, upd_date, upd_by,share_amt,share_unit) values ( '" & _
                             tbFund.Text & "','P','','0000000',sysdate,'" & Session("user_id") & "', " & dbSignAmt & "," & dbSignAmt / 10 & " )  "
            '& dbSignAmt & ",0 )"
            '& dbMin & "," & dbBuyNext & _         "," & dbSellMin & ",0,0)"
            m1.Execute(strsql)

            '**** insert transaction into pvmtran
            Dim strOrdNo
            strsql = "select max(trn_no) trn_no from pv.pvmtran"
            ds = m1.GetDataset(strsql)
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            strOrdNo = dr("trn_no") + 1

            strsql = "insert into pv.pvmtran(trn_no,fund,share_amt,trn_type, trn_date,share_amt_bf,share_unit_bf, " & _
                           "upd_by,upd_date,nav,trn_flg,trn_alot, dv_unit ,alot_by,alot_date ) " & _
                           " values ('" & strOrdNo & "','" & tbFund.Text & "'," & dbSignAmt & ",'NW',sysdate,0,0,'" & _
                              Session("user_id") & "',sysdate,10.0000,'A','Y',0,'" & Session("user_id") & "',sysdate  )"

            m1.Execute(strsql)
            Try
                Add_Acct(tbFund.Text)
                Add_Doc(tbFund.Text)
                Response.Redirect("success.aspx?pagename=pvf_add_fund.aspx")
            Catch x1 As Exception
                Label1.Text &= x1.Message
                Label1.Text &= strsql
            End Try
        Catch x1 As Exception
            Label1.Text &= x1.Message
            Label1.Text &= strsql
        End Try
    End Sub

    Sub Add_Acct(ByVal strFund As String)
        Dim strAccNo(5) As String
        Dim strAccType(5), strAccName(5) As String
        Dim strBkCode(5), strBkBran(5) As String
        Dim i, iCount As Integer
        Dim strDefault(5) As String
        '  strAccNo(iCount) = tbAccno.Text

        'Dim strAccNo As String
        'Dim strAccType As String
        'Dim strBkCode, strBkBran As String

        'strAccType = ddAccType.SelectedItem.Value
        'strBkCode = ddBkCode.SelectedItem.Value
        'strBkBran = ddBkBran.SelectedItem.Value

        If tbAccno.Text.Length > 5 Then
            If ddBkCode.SelectedItem.Text = "*** �ä�к� ***" Then
                Label1.Text = "��س��к� ��Ҥ��"
                Exit Sub
            End If
            If ddBkBran.SelectedItem.Text = "*** �ä�к� ***" Then
                Label1.Text = "��س��к� �Ң�"
                Exit Sub
            End If

            iCount += 1
            strAccNo(iCount) = tbAccno.Text
            strAccName(iCount) = tbAccName.Text
            strAccType(iCount) = ddAccType.SelectedItem.Value
            strBkCode(iCount) = ddBkCode.SelectedItem.Value
            strBkBran(iCount) = ddBkBran.SelectedItem.Value
            strDefault(iCount) = "Y"
            If tbAccno2.Text.Length > 5 Then
                If ddBkCode2.SelectedItem.Text = "*** �ä�к� ***" Then
                    Label1.Text = "��س��к� ��Ҥ��"
                    Exit Sub
                End If
                If ddBkBran2.SelectedItem.Text = "*** �ä�к� ***" Then
                    Label1.Text = "��س��к� �Ң�"
                    Exit Sub
                End If

                iCount += 1
                strAccNo(iCount) = tbAccno2.Text
                strAccName(iCount) = tbAccName2.Text
                strAccType(iCount) = ddAccType2.SelectedItem.Value
                strBkCode(iCount) = ddBkCode2.SelectedItem.Value
                strBkBran(iCount) = ddBkBran2.SelectedItem.Value
                strDefault(iCount) = "N"
                If tbAccno3.Text.Length > 5 Then
                    If ddBkCode3.SelectedItem.Text = "*** �ä�к� ***" Then
                        Label1.Text = "��س��к� ��Ҥ��"
                        Exit Sub
                    End If
                    If ddBkBran3.SelectedItem.Text = "*** �ä�к� ***" Then
                        Label1.Text = "��س��к� �Ң�"
                        Exit Sub
                    End If

                    iCount += 1
                    strAccNo(iCount) = tbAccno3.Text
                    strAccName(iCount) = tbAccName3.Text
                    strAccType(iCount) = ddAccType3.SelectedItem.Value
                    strBkCode(iCount) = ddBkCode3.SelectedItem.Value
                    strBkBran(iCount) = ddBkBran3.SelectedItem.Value
                    strDefault(iCount) = "N"
                    If tbAccno4.Text.Length > 5 Then
                        If ddBkCode4.SelectedItem.Text = "*** �ä�к� ***" Then
                            Label1.Text = "��س��к� ��Ҥ��"
                            Exit Sub
                        End If
                        If ddBkBran4.SelectedItem.Text = "*** �ä�к� ***" Then
                            Label1.Text = "��س��к� �Ң�"
                            Exit Sub
                        End If
                        iCount += 1
                        strAccNo(iCount) = tbAccno4.Text
                        strAccName(iCount) = tbAccName4.Text
                        strAccType(iCount) = ddAccType4.SelectedItem.Value
                        strBkCode(iCount) = ddBkCode4.SelectedItem.Value
                        strBkBran(iCount) = ddBkBran4.SelectedItem.Value
                        strDefault(iCount) = "N"
                    End If
                End If
            End If
        End If

        If iCount > 0 Then
            For i = 1 To iCount
                strsql = "insert into pv.FundAcct (seq_no,fund,rec_flg,acct_flg,acct_name,acct_no,acct_type,bk_code,bk_bran,upd_by )" & _
                  " values ( '" & i & "','" & strFund & "', 'TR','" & strDefault(i) & "' ,'" & strAccName(i) & "','" & _
                      strAccNo(i) & "','" & strAccType(i) & "','" & strBkCode(i) & "','" & strBkBran(i) & "','" & Session("user_id") & "' )"
                m1.Execute(strsql)
            Next
        End If
        ' Label1.Text = strsql
        'Response.Write(strAccNo(iCount) & " - xxxx - " & iCount)
        'iCount += 1
        'Response.Write(iCount)

    End Sub

    Sub Add_Doc(ByVal strFund As String)
        Dim strDocCode, strSubtype, strDocType, strRemk As String
        Dim Item As ListItem
        Dim dbseq As Double

        strDocType = rdlChkdoctype.SelectedItem.Value()
        strRemk = tbdocremk.Text

        For Each Item In chbDoc.Items
            If Item.Selected Then
                strDocCode = Item.Value
                lbMsg.Text &= strDocCode

                strsql = "insert into pv.pvtdocrecv ( Fund, Cis_no, Trn_no, Trn_date,Sub_type,Doc_type,Doc_code,Doc_remk," & _
                         " Ins_by, Ins_date ) " & _
                         " values ( '" & strFund & "', 'NEW','REG' ,to_date(sysdate,'dd/mm/yyyy'),'PVREG'" & _
                         " ,'" & strDocType & "','" & strDocCode & "','" & strRemk & "','" & Session("user_id") & "',sysdate )"
                m1.Execute(strsql)

                '*** insert log history
                strsql = "select nvl(max(log_seq),0)  log_seq  from pv.pvhdocrecv "
                ds = m1.GetDataset(strsql)
                Dim dr1 As DataRow = ds.Tables(0).Rows(0)
                dbseq = dr1("log_seq") + 1
                strsql = "insert into pv.pvhdocrecv (log_seq,Fund,Cis_no, Trn_no, Trn_date, Sub_type,Doc_code,Doc_type,Doc_remk,log_type,log_by,log_date) " & _
               " values ( " & dbseq & ",'" & strFund & "','NEW','REG',to_date(sysdate,'dd/mm/yyyy'),'PVREG','" & strDocCode & "', " & _
               "'" & strDocType & "','" & strRemk & "','ADD','" & Session("user_id") & "',sysdate )"
                m1.Execute(strsql)

            End If
        Next
    End Sub

    Private Sub tbMin_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If IsNumeric(tbMin.Text) Then
            Label1.Text = ""
            If CType(tbMin.Text, Double) Then
                tbMin.Text = CType(tbMin.Text, Double).ToString("##,###,##0.00")
            End If
        Else
            Label1.Text = "�ä�кبӹǹ�繵���Ţ"
            tbMin.Text = "0"
        End If
    End Sub

    Private Sub tbBuyNext_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If IsNumeric(tbBuyNext.Text) Then
            Label1.Text = ""
            If CType(tbBuyNext.Text, Double) Then
                tbBuyNext.Text = CType(tbBuyNext.Text, Double).ToString("##,###,##0.00")
            End If
        Else
            Label1.Text = "�ä�кبӹǹ�繵���Ţ"
            tbBuyNext.Text = "0"
        End If
    End Sub

    Private Sub tbSellMin_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If IsNumeric(tbSellMin.Text) Then
            Label1.Text = ""
            If CType(tbSellMin.Text, Double) Then
                tbSellMin.Text = CType(tbSellMin.Text, Double).ToString("##,###,##0.00")
            End If
        Else
            Label1.Text = "�ä�кبӹǹ�繵���Ţ"
            tbSellMin.Text = "0"
        End If
    End Sub

    Private Sub tbSignAmt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSignAmt.TextChanged
        If IsNumeric(tbSignAmt.Text) Then
            Label1.Text = ""
            If CType(tbSignAmt.Text, Double) Then
                tbSignAmt.Text = CType(tbSignAmt.Text, Double).ToString("##,###,##0.00")
            End If
        Else
            Label1.Text = "�ä�кبӹǹ�繵���Ţ"
            tbSignAmt.Text = "0"
        End If
    End Sub

    Private Sub tbFund_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbFund.TextChanged
        ''lbText.Text = tbFund.Text
        GetData(tbFund.Text)
    End Sub

    Private Sub ddAgent_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim strAgent As String = Left(ddAgent.SelectedItem.Value, 3)
        Dim strBran As String = Right(ddAgent.SelectedItem.Value, 6)

        strsql = "select mkt_code,mkt_name  from cis.opnmmakt where  mkt_agen = '" & strAgent & "' " & _
                       "and mkt_branch = '" & strBran & "' order by mkt_name "

        ds = m1.GetDataset(strsql)
        ddMkt.DataSource = ds
        ddMkt.DataTextField = "mkt_name"
        ddMkt.DataValueField = "mkt_code"
        Me.DataBind()

        ddMkt.Items.Add("*** �ä�к� ***")
        ddMkt.SelectedIndex = ddMkt.Items.Count - 1
        'Label1.Text = strsql
    End Sub

    Private Sub img1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles img1.Click
        Panel_t1.Attributes.Add("style", "display:")
        Panel_t2.Attributes.Add("style", "display:none")
        Panel_t3.Attributes.Add("style", "display:none")
        Panel_t4.Attributes.Add("style", "display:none")
        Panel_t5.Attributes.Add("style", "display:none")
        Label1.Text = ""
        img1.ImageUrl = "Images/pvf_tap_fund1_b.gif"
        img2.ImageUrl = "Images/pvf_tap_fund2.gif"
        img3.ImageUrl = "Images/pvf_tap_fund3.gif"
        img4.ImageUrl = "Images/pvf_tap_fund4.gif"
        Img5.ImageUrl = "Images/pvf_tap_fund5.gif"
        'btSave.Visible = True
        'btCancel.Visible = True
    End Sub

    Private Sub img2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles img2.Click
        Panel_t1.Attributes.Add("style", "display:none")
        Panel_t2.Attributes.Add("style", "display:")
        Panel_t3.Attributes.Add("style", "display:none")
        Panel_t4.Attributes.Add("style", "display:none")
        Panel_t5.Attributes.Add("style", "display:none")
        Label1.Text = ""
        img1.ImageUrl = "Images/pvf_tap_fund1.gif"
        img2.ImageUrl = "Images/pvf_tap_fund2_b.gif"
        img3.ImageUrl = "Images/pvf_tap_fund3.gif"
        img4.ImageUrl = "Images/pvf_tap_fund4.gif"
        Img5.ImageUrl = "Images/pvf_tap_fund5.gif"
    End Sub

    Private Sub img3_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles img3.Click
        Panel_t1.Attributes.Add("style", "display:none")
        Panel_t2.Attributes.Add("style", "display:none")
        Panel_t3.Attributes.Add("style", "display:")
        Panel_t4.Attributes.Add("style", "display:none")
        Panel_t5.Attributes.Add("style", "display:none")
        Label1.Text = ""
        img1.ImageUrl = "Images/pvf_tap_fund1.gif"
        img2.ImageUrl = "Images/pvf_tap_fund2.gif"
        img3.ImageUrl = "Images/pvf_tap_fund3_b.gif"
        img4.ImageUrl = "Images/pvf_tap_fund4.gif"
        Img5.ImageUrl = "Images/pvf_tap_fund5.gif"
    End Sub

    Private Sub img4_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles img4.Click
        Panel_t1.Attributes.Add("style", "display:none")
        Panel_t2.Attributes.Add("style", "display:none")
        Panel_t3.Attributes.Add("style", "display:none")
        Panel_t4.Attributes.Add("style", "display:")
        Panel_t5.Attributes.Add("style", "display:none")
        Label1.Text = ""
        img1.ImageUrl = "Images/pvf_tap_fund1.gif"
        img2.ImageUrl = "Images/pvf_tap_fund2.gif"
        img3.ImageUrl = "Images/pvf_tap_fund3.gif"
        img4.ImageUrl = "Images/pvf_tap_fund4_b.gif"
        Img5.ImageUrl = "Images/pvf_tap_fund5.gif"
    End Sub

    Private Sub img5_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles Img5.Click
        Panel_t1.Attributes.Add("style", "display:none")
        Panel_t2.Attributes.Add("style", "display:none")
        Panel_t3.Attributes.Add("style", "display:none")
        Panel_t4.Attributes.Add("style", "display:none")
        Panel_t5.Attributes.Add("style", "display:")
        Label1.Text = ""
        img1.ImageUrl = "Images/pvf_tap_fund1.gif"
        img2.ImageUrl = "Images/pvf_tap_fund2.gif"
        img3.ImageUrl = "Images/pvf_tap_fund3.gif"
        img4.ImageUrl = "Images/pvf_tap_fund4.gif"
        Img5.ImageUrl = "Images/pvf_tap_fund5_b.gif"
    End Sub

    Sub ClearText()
        'Dim myForm As Control = Page.FindControl("form1")
        'Dim ctl As Control
        'For Each ctl In myForm.Controls
        '    If ctl.GetType().ToString().Equals("System.Web.UI.WebControls.textbox") Then
        '        CType(ctl, TextBox).Text = ""
        '    End If
        'Next ctl

        tbFname.Text = ""
        tbFname_e.Text = ""
        tbSignAmt.Text = ""
        tbFPolicy.Text = ""
        tbFCond.Text = ""
        tbFReturn.Text = ""

        tbAuditBy.Text = ""
        tbAuditAddr.Text = ""
        tbFeeM.Text = ""
        tbFeeT.Text = ""
        tbFeeA.Text = ""
        tbRefNo.Text = ""

    End Sub

    Sub Clear2()
        tbAccno.Text = ""
        tbAccName.Text = ""
        tbAccno2.Text = ""
        tbAccName2.Text = ""
        tbAccno3.Text = ""
        tbAccName3.Text = ""
        tbAccno4.Text = ""
        tbAccName4.Text = ""
    End Sub

    Private Sub ddBkCode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddBkCode.SelectedIndexChanged
        strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
                  " where bk_code ='" & ddBkCode.SelectedItem.Value & "' order by bk_name "
        ds = m1.GetDataset(strsql)
        ddBkBran.DataSource = ds
        ddBkBran.DataTextField = "bk_name"
        ddBkBran.DataValueField = "bk_bran"

        Me.DataBind()

        ddBkBran.Items.Insert(0, "*** �ä�к� ***")
        'ddBkBran.Items.Add("*** �ä�к� ***")
        'ddBkBran.SelectedIndex = ddBkBran.Items.Count - 1
    End Sub

    Private Sub ddBkCode2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddBkCode2.SelectedIndexChanged
        strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
          " where bk_code ='" & ddBkCode2.SelectedItem.Value & "' order by bk_name "
        ds = m1.GetDataset(strsql)
        ddBkBran2.DataSource = ds
        ddBkBran2.DataTextField = "bk_name"
        ddBkBran2.DataValueField = "bk_bran"

        Me.DataBind()

        ddBkBran2.Items.Insert(0, "*** �ä�к� ***")
        'ddBkBran2.Items.Add("*** �ä�к� ***")
        'ddBkBran2.SelectedIndex = ddBkBran2.Items.Count - 1
    End Sub

    Private Sub ddBkCode3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddBkCode3.SelectedIndexChanged
        strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
          " where bk_code ='" & ddBkCode3.SelectedItem.Value & "' order by bk_name "
        ds = m1.GetDataset(strsql)
        ddBkBran3.DataSource = ds
        ddBkBran3.DataTextField = "bk_name"
        ddBkBran3.DataValueField = "bk_bran"

        Me.DataBind()

        ddBkBran3.Items.Insert(0, "*** �ä�к� ***")
        'ddBkBran3.Items.Add("*** �ä�к� ***")
        'ddBkBran3.SelectedIndex = ddBkBran3.Items.Count - 1
    End Sub

    Private Sub ddBkCode4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddBkCode4.SelectedIndexChanged
        strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
          " where bk_code ='" & ddBkCode4.SelectedItem.Value & "' order by bk_name "
        ds = m1.GetDataset(strsql)
        ddBkBran4.DataSource = ds
        ddBkBran4.DataTextField = "bk_name"
        ddBkBran4.DataValueField = "bk_bran"

        Me.DataBind()

        ddBkBran4.Items.Insert(0, "*** �ä�к� ***")
        'ddBkBran4.Items.Add("*** �ä�к� ***")
        'ddBkBran4.SelectedIndex = ddBkBran4.Items.Count - 1
    End Sub

    Private Sub btUpd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btUpd.Click
        ' ����������� ���䢷��˹�� update fund ᷹

        Dim strSignDate As String = ddDd_s.SelectedItem.Value & "/" & ddDm_s.SelectedItem.Value & "/" & ddDy_s.SelectedItem.Value - 543
        Dim strReSignDate As String = ddDd_r.SelectedItem.Value & "/" & ddDm_r.SelectedItem.Value & "/" & ddDy_r.SelectedItem.Value - 543
        Dim strDueDate As String = ddDd_d.SelectedItem.Value & "/" & ddDm_d.SelectedItem.Value & "/" & ddDy_d.SelectedItem.Value - 543
        Dim m1 As New MyData
        Dim dbBfAmt As Double = CType(tbBFAmt.Text, Double)
        Dim dbBfUnit As Double = CType(tbBFUnit.Text, Double)
        Dim strEntDate As String = ddDd_e.SelectedItem.Value & "/" & ddDm_e.SelectedItem.Value & "/" & ddDy_e.SelectedItem.Value - 543
        Dim strAccNo As String
        Dim strAccType As String
        Dim strBkCode, strBkBran As String

        '   Label1.Text = tbFund.Text

        If ddFtype.SelectedItem.Text = "*** �ä�к� ***" Then
            lberr1.Text = "��س��кػ����� �ͧ�ع "
            Exit Sub
            'ElseIf ddAgent.SelectedItem.Text = "*** �ä�к� ***" Then
            '    lberr1.Text = "��س��к� ���᷹ "
            '    Exit Sub
            'ElseIf ddMkt.SelectedItem.Text = "*** �ä�к� ***" Then
            '    lberr1.Text = "��س��к� Marketting "
            '    Exit Sub
        ElseIf ddRegis.SelectedItem.Text = "*** �ä�к� ***" Then
            lberr1.Text = "��س��к� ����Ѻ�ҡ��Ѿ���Թ"
            Exit Sub
        End If

        If ddDd_r.SelectedItem.Value = "0" Then
            strReSignDate = "null  "
        Else
            strReSignDate = "to_date('" & strReSignDate & " ','dd/mm/yyyy') "
        End If

        If ddDd_d.SelectedItem.Value = "0" Then
            strDueDate = "null "
        Else
            strDueDate = "to_date('" & strDueDate & " ','dd/mm/yyyy')  "
        End If

        'strAccType = ddAccType.SelectedItem.Value
        'strBkCode = ddBkCode.SelectedItem.Value
        'strBkBran = ddBkBran.SelectedItem.Value
        'If ddBkCode.SelectedItem.Text = "*** �ä�к� ***" Then
        '    lberr1.Text = "��س��к� ��Ҥ��"
        '    Exit Sub
        'End If
        'If ddBkBran.SelectedItem.Text = "*** �ä�к� ***" Then
        '    lberr1.Text = "��س��к� �Ң�"
        '    Exit Sub
        'End If


        strsql = "update pv.funddesc set fund_tname= '" & tbFname.Text & "' , " & _
                        "fund_ename = '" & tbFname_e.Text & "'," & _
                        "fund_type = '" & ddFtype.SelectedItem.Value & "'," & _
                        "sign_date = to_date('" & strSignDate & "','dd/mm/yyyy')," & _
                        "resign_date = " & strReSignDate & " , " & _
                        "due_date = " & strDueDate & " ," & _
                        "regis_name= '" & ddRegis.SelectedItem.Value & "'," & _
                        "fund_amt = " & CType(tbSignAmt.Text, Double) & ", " & _
                        "fund_policy = '" & tbFPolicy.Text & "', " & _
                        "fund_cond = '" & tbFCond.Text & "', " & _
                        "fund_return = '" & tbFReturn.Text & "', " & _
                        "balance_unit = " & dbBfUnit & ", " & _
                        "balance_amt = " & dbBfAmt & ", " & _
                        "regis_date =  to_date('" & strEntDate & "','dd/mm/yyyy') ," & _
                        "audit_by = '" & tbAuditBy.Text & "' ," & _
                        "audit_addr = '" & tbAuditAddr.Text & "', " & _
                        "management_feetxt = '" & tbFeeM.Text & "', " & _
                        "trustee_feetxt = '" & tbFeeT.Text & "', " & _
                        "audit_feetxt = '" & tbFeeA.Text & "', " & _
                        " upd_by = '" & Session("user_id") & "', " & _
                        " upd_date = sysdate ,  " & _
                        " ref_no = '" & tbRefNo.Text & "' " & _
                        " where fund = '" & tbFund.Text & "'"

        ' Label1.Text &= strsql

        ' Exit Sub
        m1.Execute(strsql)

        'strsql = "update pv.FundContl set  upd_date=sysdate," & _
        '         " upd_by = '" & Session("userid") & "', " & _
        '         " buy_next_bath = " & CType(tbBuyNext.Text, Double) & "," & _
        '         " min_bath = " & CType(tbMin.Text, Double) & "," & _
        '         " sell_min_bath = " & CType(tbSellMin.Text, Double) & _
        '         "  where fund = '" & tbFund.Text & "'"
        'm1.Execute(strsql)

        Label1.Text &= "�ѹ�֡�����䢢��������º����"
        Init_page("0")
        Panel_t1.Attributes.Add("style", "display:")
        Panel_t2.Attributes.Add("style", "display:none")
        Panel_t3.Attributes.Add("style", "display:none")
        Panel_t3.Attributes.Add("style", "display:none")
        Panel_t4.Attributes.Add("style", "display:none")
        img1.ImageUrl = "Images/pvf_tap_fund1_b.gif"
        img2.ImageUrl = "Images/pvf_tap_fund2.gif"
        img3.ImageUrl = "Images/pvf_tap_fund3.gif"
        img4.ImageUrl = "Images/pvf_tap_fund4.gif"

        btSave.Visible = True
        btUpd.Visible = False
    End Sub

    Private Sub btSave2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave2.Click
        ' not user ... visible=true
        If Len(tbFund.Text) > 0 Then
            'Label1.Text = "xxxx"
            Add_Acct(tbFund.Text)
            Label1.Text = "�ѹ�֡����Ѻ�Ż���ª�����º����"
        Else
            Label1.Text = "��س����͡�ͧ�ع��͹�ӡ�úѹ�֡"
        End If
    End Sub

    Sub GetDoc()
        strsql = "select a.doc_code,b.doc_desc||' ( '||a.doc_code||' )' doc_desc from pv.pvmdsubtype a, sas.sasmdocument b " & _
                      " where a.doc_code = b.doc_code and a.sub_type = 'PVREG' " & _
                      " and a.doc_type = '" & rdlChkdoctype.SelectedItem.Value & "' "
        ds = m1.GetDataset(strsql)

        Dim dc As Integer = ds.Tables(0).Rows.Count
        chbDoc.DataSource = ds
        chbDoc.DataTextField = "doc_desc"
        chbDoc.DataValueField = "doc_code"
        Me.DataBind()
    End Sub

    Private Sub rdlChkdoctype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlChkdoctype.SelectedIndexChanged
        GetDoc()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' for test insert doc   
        If Len(tbFund.Text) > 0 Then
            Add_Doc(tbFund.Text)
        End If
    End Sub
End Class

'Dim strdm As String
'        strdm = ddDm_s.SelectedItem.Value
'Dim getdm As String = DateTime.DaysInMonth(DateTime.Now.Year.ToString, strdm) ' return days in month
'        If ddDd_s.SelectedItem.Value > getdm Then
'            Label1.Text &= "��͹����� " & getdm & " �ѹ "
'        Else
'            Label1.Text = ""
'        End If