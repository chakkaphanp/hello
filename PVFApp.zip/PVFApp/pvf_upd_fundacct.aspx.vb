Public Class pvf_upd_fundacct
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Panel_t2 As System.Web.UI.WebControls.Panel
    Protected WithEvents tbAccno As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAccName As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddAccType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkCode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkBran As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Panel_t4 As System.Web.UI.WebControls.Panel
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents imgSave As System.Web.UI.WebControls.ImageButton
    Protected WithEvents tbFund As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFname As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents cbDef As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbCancel As System.Web.UI.WebControls.CheckBox
    Protected WithEvents tbSeqno As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbChkNew As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents btAddAcct As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim FlgUpd As String
    Dim ds As New DataSet
    Dim m1 As New MyData
    Dim strsql As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            Dim mc As New ClassCheckUser
            If mc.CheckUser(Session("user_id"), "reg_updfundacct") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                imgSave.Visible = False
                tbFund.Enabled = False
                Exit Sub
            End If

            '      Panel_t4.Attributes.Add("style", "display:none")
            strsql = "select  bk_name , bk_code  from cis.opnmbank where bk_bran = 'XXX' order by bk_name "
            ds = m1.GetDataset(strsql)
            ddBkCode.DataSource = ds                ' for accout bank
            ddBkCode.DataTextField = "bk_name"
            ddBkCode.DataValueField = "bk_code"

            GetAcct(" ")
            lbMsg.Text = ""

            Me.DataBind()
            ddBkCode.Items.Insert(0, "�ä�к�")
        End If

    End Sub
    Private Sub GetFund(ByVal strFund As String)
        strsql = "select  fund,fund_tname " & _
            " from pv.funddesc where fund  = '" & strFund & "'"
        ds = m1.GetDataset(strsql)
        ' lbMsg.Text = strsql
        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            tbFname.Text = dr("fund_tname")
            GetAcct(tbFund.Text)
        Else
            lbMsg.Text = "*** ��������ʡͧ�ع��� ***"
            btAddAcct.Visible = False
            ClearText()
            GetAcct(" ")
        End If
    End Sub
    Private Sub GetAcct(ByVal strFund As String)
        strsql = " SELECT FUNDACCT.FUND fund,  FUNDACCT.BK_CODE,  FUNDACCT.BK_BRAN , " & _
                        "OPNMBANK_A.BK_NAME bk_name,OPNMBANK_B.BK_NAME br_name, FUNDACCT.SEQ_NO, " & _
                        "decode(FUNDACCT.ACCT_FLG,'Y','Y','-') acct_flg,  FUNDACCT.REC_FLG rec_flg, FUNDACCT.ACCT_NAME acct_name,  " & _
                        "FUNDACCT.ACCT_NO acct_no, FUNDACCT.ACCT_TYPE acct_type, FUNDACCT.ACCT_STATUS " & _
                        "FROM CIS.OPNMBANK OPNMBANK_A , FUNDACCT,   CIS.OPNMBANK  OPNMBANK_B " & _
                        "WHERE ( FUNDACCT.BK_CODE = OPNMBANK_A.BK_CODE  ) and  " & _
                        "( FUNDACCT.BK_CODE = OPNMBANK_B.BK_CODE ) and  " & _
                        "(FUNDACCT.BK_BRAN = OPNMBANK_B.BK_BRAN ) and  " & _
                        "( (OPNMBANK_A.BK_BRAN = 'XXX' ) )   and  " & _
                        "FUNDACCT.Fund = '" & strFund & "' order by FUNDACCT.seq_no "

        ds = m1.GetDataset(strsql)
        DG1.DataSource = ds
        DG1.DataBind()
        If ds.Tables(0).Rows.Count < 1 And strFund = " " Then
            If lbMsg.Text = "" Then
                lbMsg.Text &= "*** ����բ����� ����Ѻ�Թ�Ż���ª�� ***"
            End If
            btAddAcct.Visible = False
            ClearText()
        Else
            lbMsg.Text = ""
            btAddAcct.Visible = True
            '    lbMsg.Text = " �ӹǹ�����ŷ���� = " & ds.Tables(0).Rows.Count & " ��¡�� "
        End If
    End Sub

    Sub GetEditAcct(ByVal strFund As String, ByVal strSeqno As String)
        Dim strdd As String
        Dim dsBkbran As DataSet

        strsql = " SELECT FUND,  nvl(BK_CODE,' ') bk_code, nvl(BK_BRAN,' ') bk_bran , " & _
                 "nvl(ACCT_FLG,' ') acct_flg, nvl(REC_FLG,' ') rec_flg, nvl(ACCT_NAME,' ') acct_name,  " & _
                 "nvl(ACCT_NO,' ') acct_no,nvl(ACCT_TYPE,' ') acct_type, acct_status " & _
                 "FROM FUNDACCT " & _
                 "WHERE FUNDACCT.Fund = '" & strFund & "' and " & _
                 "      seq_no = '" & strSeqno & "'"

        ds = m1.GetDataset(strsql)
        Dim dt As DataTable = ds.Tables(0)
        Dim dr As DataRow = dt.Rows(0)
        If ds.Tables(0).Rows.Count > 0 Then
            tbSeqno.Text = strSeqno
            tbAccno.Text = Trim(dr("acct_no"))
            tbAccName.Text = Trim(dr("acct_name"))

            ' *** Set data into dropdrow
            Dim dd2 As ListItem
            Dim index1 As Integer
            strdd = dr("acct_type")
            dd2 = ddAccType.Items.FindByValue(strdd)
            index1 = ddAccType.Items.IndexOf(dd2)
            ddAccType.SelectedIndex = index1

            strdd = dr("bk_code")
            dd2 = ddBkCode.Items.FindByValue(strdd)
            index1 = ddBkCode.Items.IndexOf(dd2)
            ddBkCode.SelectedIndex = index1

            strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
             " where bk_code ='" & strdd & "' order by bk_name "
            dsBkbran = m1.GetDataset(strsql)
            ddBkBran.DataSource = dsBkbran                ' for accout bank
            ddBkBran.DataTextField = "bk_name"
            ddBkBran.DataValueField = "bk_bran"
            ddBkBran.DataBind()

            strdd = dr("bk_bran")
            dd2 = ddBkBran.Items.FindByValue(strdd)
            index1 = ddBkBran.Items.IndexOf(dd2)
            ddBkBran.SelectedIndex = index1

            ' *** check account default  Y/N
            strdd = dr("acct_flg")
            If strdd = "Y" Then
                cbDef.Checked = True    ' Default
            Else
                cbDef.Checked = False
            End If

            ' *** check account status  A=active, C=cancel
            strdd = dr("acct_status")
            If strdd = "A" Then
                cbCancel.Checked = False   ' Active
            Else
                cbCancel.Checked = True     ' Cancel
            End If
        End If

    End Sub
    Private Sub ClearText()
        tbFname.Text = ""
        tbSeqno.Text = ""
        tbAccno.Text = ""
        tbAccName.Text = ""
        cbDef.Checked = False
        cbCancel.Checked = False
    End Sub
    Private Sub DG1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DG1.SelectedIndexChanged
        Dim strSno As String = DG1.DataKeys(DG1.SelectedIndex)
        Dim strF As String
        strF = tbFund.Text
        ClearText()
        lbChkNew.Text = ""
        GetEditAcct(strF, strSno)
    End Sub
    Private Sub tbFund_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbFund.TextChanged
        lbChkNew.Text = ""
        GetFund(tbFund.Text)
    End Sub
    Private Sub ddBkCode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddBkCode.SelectedIndexChanged
        Dim dsdd As DataSet
        strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
                  " where bk_code ='" & ddBkCode.SelectedItem.Value & "' order by bk_name "
        dsdd = m1.GetDataset(strsql)
        ddBkBran.DataSource = dsdd
        ddBkBran.DataTextField = "bk_name"
        ddBkBran.DataValueField = "bk_bran"

        ddBkBran.DataBind()
        ddBkBran.Items.Insert(0, "�ä�к�")
    End Sub
    Function ChkBfSave()
        If tbSeqno.Text = "" Then
            lbMsg.Text = "*** ��س����͡�ѭ�շ���ͧ������ ***"
            Return -1
        End If
        If Trim(tbAccno.Text) = "" Then
            lbMsg.Text = "*** ��س��к��Ţ���ѭ�� ***"
            Return -1
        End If
        If Trim(tbAccName.Text) = "" Then
            lbMsg.Text = "*** ��س��кت��ͺѭ�� ***"
            Return -1
        End If
        If ddBkCode.SelectedIndex = "0" Then
            lbMsg.Text = "*** ��س��к� ��Ҥ�� ***"
            Return -1
        End If
        If ddBkBran.SelectedIndex = "0" Then
            lbMsg.Text = "*** ��س��к� �Ң� ***"
            Return -1
        End If
        Return 0
    End Function
    Private Sub imgSave_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgSave.Click
        Dim strSeqno, strAcctNo, strAcctName, strAcctType As String
        Dim strBkcode, strBkbran, strStatus, strAcctFlg, strRecFlg As String
        Dim strChkDef, strChkCancel As String

        If ChkBfSave() = -1 Then
            Exit Sub
        End If

        If cbDef.Checked Then
            strChkDef = "Y"         ' default
        Else
            strChkDef = "N"
        End If

        If cbCancel.Checked Then
            strChkCancel = "C"      ' cancle
        Else
            strChkCancel = "A"      ' active
        End If

        '*** Save Data
        Dim strFund, strUpd, strChkAddNew As String
        Dim dbRunno As Double
        '** select max run no from masterref
        strsql = "Select mas_ref From cis.MasterRef Where mas_code = 'pvhfmas' "
        ds = m1.GetDataset(strsql)
        Dim dr1 As DataRow = ds.Tables(0).Rows(0)
        dbRunno = dr1("mas_ref") + 1    ' for next runno from masref
        strFund = tbFund.Text
        strSeqno = tbSeqno.Text
        strRecFlg = "TR"

        If lbChkNew.Text = " *New" Then
            strUpd = "PV_F08"  ' �����Ţ���ѭ��  pvmupdf
            strChkAddNew = "T"
        Else
            strUpd = "PV_F07"  ' ����Ţ���ѭ��  pvmupdf
            strChkAddNew = "F"
        End If

        ' **** Insert into hMas ****
        strsql = "insert into pv.fundhmas(run_no,fund,upd_flg,upd_by,upd_date )" & _
                 "values (" & dbRunno & ",'" & strFund & "','" & strUpd & "','" & Session("user_id") & "', sysdate )"
        m1.Execute(strsql)
        '  lbMsg.Text = strUpd & strsql & "  *********  "

        If strChkAddNew = "F" Then   ' Update 
            '*** Select data before change for insert to pvhfundacct
            strsql = " SELECT FUND,  nvl(BK_CODE,' ') bk_code, nvl(BK_BRAN,' ') bk_bran , " & _
                     "nvl(ACCT_FLG,' ') acct_flg, nvl(REC_FLG,' ') rec_flg, nvl(ACCT_NAME,' ') acct_name,  " & _
                     "nvl(ACCT_NO,' ') acct_no,nvl(ACCT_TYPE,' ') acct_type, acct_status " & _
                     "FROM FUNDACCT " & _
                     "WHERE FUNDACCT.Fund = '" & strFund & "' and " & _
                     "      seq_no = '" & strSeqno & "'"

            ds = m1.GetDataset(strsql)
            Dim dt As DataTable = ds.Tables(0)
            Dim dr As DataRow = dt.Rows(0)
            If ds.Tables(0).Rows.Count > 0 Then
                strAcctNo = Trim(dr("acct_no"))
                strAcctName = Trim(dr("acct_name"))
                strAcctType = dr("acct_type")
                strBkcode = dr("bk_code")
                strBkbran = dr("bk_bran")
                strAcctFlg = dr("acct_flg")  ' flag Default
                strStatus = dr("acct_status")  ' flag Active/Cancel
                strRecFlg = dr("rec_flg")  ' TR
                '*** Insert data to pvhfundacct
                strsql = "insert into pv.pvhfundacct(run_no,fund,seq_no,acct_flg, " & _
                         " rec_flg,acct_no,acct_name,acct_type,bk_code,bk_bran, " & _
                         " acct_status )" & _
                         " values (" & dbRunno & ",'" & strFund & "','" & strSeqno & "','" & _
                           strAcctFlg & "','" & strRecFlg & "','" & strAcctNo & "','" & _
                           strAcctName & "','" & strAcctType & "','" & strBkcode & "','" & _
                           strBkbran & "','" & strStatus & "')"
                m1.Execute(strsql)
                'lbMsg.Text &= strsql & "  *********  "
            End If

            '*** �����ŷ��١������� read data from feild
            strAcctNo = Trim(tbAccno.Text)
            strAcctName = Trim(tbAccName.Text)
            strAcctType = ddAccType.SelectedItem.Value
            strBkcode = ddBkCode.SelectedItem.Value
            strBkbran = ddBkBran.SelectedItem.Value

            '*** update data into fundacct
            strsql = "update pv.fundacct set acct_no= '" & strAcctNo & "' , " & _
                       "acct_name = '" & strAcctName & "'," & _
                       "acct_type = '" & strAcctType & "' ," & _
                       "bk_code = '" & strBkcode & "', " & _
                       "bk_bran = '" & strBkbran & "', " & _
                       "acct_flg = '" & strChkDef & "', " & _
                       "acct_status = '" & strChkCancel & "', " & _
                       " upd_by = '" & Session("user_id") & "', " & _
                       " upd_date = sysdate   " & _
                       " where fund = '" & strFund & "' and seq_no = '" & strSeqno & "'"
            '    lbMsg.Text &= strsql
            m1.Execute(strsql)
        Else        '***** Add New Account

            '*** �����ŷ�� ��������
            strAcctNo = Trim(tbAccno.Text)
            strAcctName = Trim(tbAccName.Text)
            strAcctType = ddAccType.SelectedItem.Value
            strBkcode = ddBkCode.SelectedItem.Value
            strBkbran = ddBkBran.SelectedItem.Value
            ' *** insert into pvhfundacct with new data
            strsql = "insert into pv.pvhfundacct(run_no,fund,seq_no,acct_flg, " & _
                     " rec_flg,acct_no,acct_name,acct_type,bk_code,bk_bran, " & _
                     " acct_status,upd_by,upd_date )" & _
                     " values (" & dbRunno & ",'" & strFund & "','" & strSeqno & "','" & _
                                 strChkDef & "','" & strRecFlg & "','" & strAcctNo & "','" & _
                                 strAcctName & "','" & strAcctType & "','" & strBkcode & "','" & _
                                 strBkbran & "','" & strChkCancel & "','" & Session("user_id") & "',sysdate)"
            m1.Execute(strsql)
            'lbMsg.Text &= strsql & "  *********  "

            ' *** insert into fundacct with new data
            strsql = "insert into pv.fundacct(fund,seq_no,acct_flg, " & _
                     " rec_flg,acct_no,acct_name,acct_type,bk_code,bk_bran, " & _
                     " acct_status,upd_by,upd_date )" & _
                     " values ('" & strFund & "','" & strSeqno & "','" & _
                                 strChkDef & "','" & strRecFlg & "','" & strAcctNo & "','" & _
                                 strAcctName & "','" & strAcctType & "','" & strBkcode & "','" & _
                                 strBkbran & "','" & strChkCancel & "','" & Session("user_id") & "',sysdate)"
            m1.Execute(strsql)
            'lbMsg.Text &= strsql & "  *********  "
        End If


        '*** update max run no
        strsql = "update cis.MasterRef set mas_ref ='" & dbRunno & "' where mas_code='pvhfmas' "
        Try
            m1.Execute(strsql)
        Catch x1 As Exception
            lbMsg.Text = x1.Message
        End Try

        Response.Redirect("success.aspx?pagename=pvf_upd_fundacct.aspx")

    End Sub
    Private Sub DG1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemCreated
        'If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
        '    If e.Item.Cells(0).Text = "Y" Then
        '        e.Item.Cells(0).Font.Bold = True
        '    Else
        '        e.Item.Cells(0).Font.Bold = False
        '    End If
        'End If
    End Sub

    'Private Sub DG1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemDataBound
    '    If e.Item.ItemType = ListItemType.Item OrElse e.Item.ItemType = ListItemType.AlternatingItem Then
    '        Dim dr As DataRowView = CType(e.Item.DataItem, DataRowView)

    '        If CType(dr("acct_flg"), String) = "Y" Then
    '            e.Item.ForeColor = Color.Blue

    '            'ElseIf CType(dr("SubType"), String) = "XD" Then
    '            '    e.Item.ForeColor = Color.White
    '            '    e.Item.BackColor = Color.White
    '            '    e.Item.ForeColor = Color.Black
    '            '    e.Item.Cells(4).ForeColor = Color.White
    '            '    e.Item.Cells(5).BackColor = Color.FromArgb(204, 204, 255)
    '            '    e.Item.Cells(6).BackColor = Color.FromArgb(204, 204, 255)
    '            '    e.Item.Cells(7).BackColor = Color.FromArgb(204, 204, 255)
    '            '    e.Item.Cells(8).BackColor = Color.FromArgb(204, 204, 255)
    '            '    e.Item.Cells(9).BackColor = Color.FromArgb(204, 204, 255)

    '            'Else
    '            '    e.Item.ForeColor = Color.White
    '        End If
    '    End If
    'End Sub

    Private Sub cbCancel_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbCancel.CheckedChanged
        If cbCancel.Checked Then
            cbDef.Checked = False
        End If
    End Sub
    Private Sub btAddAcct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btAddAcct.Click
        lbChkNew.Text = " *New"
        tbSeqno.Text = DG1.Items.Count + 1
        tbAccno.Text = ""
        tbAccName.Text = ""
        ddBkCode.SelectedIndex = 0
        ddBkBran.SelectedIndex = 0
    End Sub

End Class
'Private Sub GetAcct1(ByVal strFund As String, ByVal strRunno As Double)
'    Dim strAccno, strAccno2, strAccno3, strAccno4, strAccName, strAccName2, strAccName3, strAccName4 As String
'    Dim strAcctype, strAcctype2, strAcctype3, strAcctype4 As String
'    Dim strBkcode, strBkcode2, strBkcode3, strBkcode4, strBkbran, strBkbran2, strBkbran3, strBkbran4 As String
'    Dim arAccno(4), arAccName(4), arAcctype(4), arBkcode(4), arBkbran(4)

'    strsql = " SELECT FUND,  nvl(BK_CODE,' ') bk_code, nvl(BK_BRAN,' ') bk_bran , " & _
'                    "nvl(ACCT_FLG,' ') acct_flg, nvl(REC_FLG,' ') rec_flg, nvl(ACCT_NAME,' ') acct_name,  " & _
'                    "nvl(ACCT_NO,' ') acct_no,nvl(ACCT_TYPE,' ') acct_type " & _
'                    "FROM FUNDACCT " & _
'                    "WHERE FUNDACCT.Fund = '" & strFund & "'"

'    ds = m1.GetDataset(strsql)
'    If ds.Tables(0).Rows.Count > 0 Then
'        Dim i As Integer
'        Dim dt As DataTable = ds.Tables(0)
'        Dim dr As DataRow = dt.Rows(i)
'        For Each dr In dt.Rows
'            i = +1
'            arAccno(i) = Trim(dr("acct_no"))
'            arAccName(i) = Trim(dr("acct_name"))
'            arAcctype(i) = Trim(dr("acct_type"))
'            arBkcode(i) = Trim(dr("bk_code"))
'            arBkbran(i) = Trim(dr("bk_bran"))
'        Next

'        strAccno = arAccno(1)
'        strAccName = arAccName(1)
'        strAccno2 = arAccno(2)
'        strAccName2 = arAccName(2)
'        strAccno3 = arAccno(3)
'        strAccName3 = arAccName(3)
'        strAccno4 = arAccno(4)
'        strAccName4 = arAccName(4)
'        strAcctype = arAcctype(1)
'        strBkcode = arBkcode(1)
'        strBkbran = arBkbran(1)
'        strAcctype2 = arAcctype(2)
'        strBkcode2 = arBkcode(2)
'        strBkbran2 = arBkbran(2)
'        strAcctype3 = arAcctype(3)
'        strBkcode3 = arBkcode(3)
'        strBkbran3 = arBkbran(3)
'        strAcctype4 = arAcctype(4)
'        strBkcode4 = arBkcode(4)
'        strBkbran4 = arBkbran(4)
'    End If
'End Sub
