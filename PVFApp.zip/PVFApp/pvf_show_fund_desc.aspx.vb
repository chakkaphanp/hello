Public Class pvf_show_fund_desc
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim FlgUpd As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Dim strsql As String
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents lbText As System.Web.UI.WebControls.Label
    Protected WithEvents tbFund As System.Web.UI.WebControls.TextBox
    Protected WithEvents lberr1 As System.Web.UI.WebControls.Label
    Protected WithEvents tbFname As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFname_e As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFType As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbSignAmt As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbDd_s As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbDd_d As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbDd_r As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAgent As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbMkt As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbAmt As System.Web.UI.WebControls.Label
    Protected WithEvents lbUnit As System.Web.UI.WebControls.Label
    Protected WithEvents tbAuditBy As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAuditAddr As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbBank As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFPolicy As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFCond As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFReturn As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFeeM As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFeeT As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFeeA As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbDd_e As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbBFAmt As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbBFUnit As System.Web.UI.WebControls.TextBox
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents DG_cis As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lbMsg2 As System.Web.UI.WebControls.Label
    Protected WithEvents lbStatus As System.Web.UI.WebControls.Label
    Public Runno As Integer

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            GetData(Request.QueryString("fund"))
            tbFund.Text = Request.QueryString("fund")
            '   GetDate()
        End If
    End Sub

    Sub GetData(ByVal strFund As String)
        strsql = "select  fund,fund_tname, nvl(fund_ename,' ') fund_ename,nvl(fund_policy,' ') fund_policy, " & _
            "nvl(fund_cond,' ') fund_cond, nvl(fund_return,' ') fund_return, nvl(fund_amt,0) fund_amt ,nvl(to_char(sign_date,'dd/mm/yyyy'),'00/01/0000') sign_date, " & _
            "nvl(to_char(due_date,'dd/mm/yyyy'),'00/01/0000') due_date,nvl(to_char(resign_date,'dd/mm/yyyy'),'00/01/0000') resign_date, " & _
            "nvl(to_char(regis_date,'dd/mm/yyyy'),'00/01/0000') regis_date, " & _
            "nvl(balance_amt,0) balance_amt , nvl(balance_unit,0) balance_unit , fund_type, nvl(regis_name,' ') regis_name,trustee_name, nvl(mkt_agent,' ') mkt_agent,  " & _
             "nvl(mkt_code,'0000') mkt_code,nvl(audit_by,' ') audit_by, nvl(audit_addr,' ') audit_addr ," & _
            " nvl(management_feetxt,' ') management_fee, nvl(trustee_feetxt,' ') trustee_fee, nvl(audit_feetxt,' ') audit_fee, " & _
            " decode(fund_status,'A','Active','Close') fund_status " & _
            " from pv.funddesc where fund  = '" & strFund & "'"
        '   "nvl(rec_flg,'0') rec_flg,nvl(acct_no,' ') acct_no, nvl(acct_type,' ') acct_type, nvl(bk_code,' ') bk_code, nvl(bk_bran,' ') bk_bran, " & _

        ds = m1.GetDataset(strsql)

        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            tbFname.Text = dr("fund_tname")
            tbFname_e.Text = dr("fund_ename")
            lbStatus.Text = dr("fund_status")
            tbSignAmt.Text = FormatNumber(dr("fund_amt"), 2)
            tbFPolicy.Text = dr("fund_policy")
            tbFCond.Text = dr("fund_cond")
            tbFReturn.Text = dr("fund_return")
            tbBFAmt.Text = FormatNumber(dr("balance_amt"), 2)
            tbBFUnit.Text = FormatNumber(dr("balance_unit"), 4)

            tbFType.Text = dr("fund_type")
            tbBank.Text = dr("regis_name")
            tbAgent.Text = dr("mkt_agent")

            tbAuditBy.Text = dr("audit_by")
            tbAuditAddr.Text = dr("audit_addr")

            tbFeeM.Text = dr("management_fee")
            tbFeeT.Text = dr("trustee_fee")
            tbFeeA.Text = dr("audit_fee")

            strsql = "select type_code, type_desc_t from pv.fundtype where type_code='" & tbFType.Text & "'"
            ds = m1.GetDataset(strsql)
            Dim dr1 As DataRow = ds.Tables(0).Rows(0)
            tbFType.Text = dr1("type_desc_t")


            strsql = " select  user_id,'('||user_id||') '||user_name||' '||user_sname  as u_name " & _
                     " from sao.sawebuser where agent_id  = '" & tbAgent.Text & "' and user_id ='" & dr("mkt_code") & "' "
            ds = m1.GetDataset(strsql)
            If ds.Tables(0).Rows.Count > 0 Then
                dr1 = ds.Tables(0).Rows(0)
                tbMkt.Text = dr1("u_name")
            End If

            'Dim strFtype As String = dr("fund_type")
            'Dim strTrustee As String = dr("trustee_name")
            'Dim strAgent As String = dr("mkt_agent")
            'Dim strMkt As String = dr("mkt_code")
            ''Dim dd1 As ListItem = ddFtype.SelectedItem
            ''Dim dd2 As ListItem
            'Dim index1 As Integer

            'dd2 = ddFtype.Items.FindByValue(strFtype)
            'index1 = ddFtype.Items.IndexOf(dd2)
            'ddFtype.SelectedIndex = index1

            'dd2 = ddBank.Items.FindByValue(strTrustee)
            'index1 = ddBank.Items.IndexOf(dd2)
            'ddBank.SelectedIndex = index1

            'dd2 = ddAgent.Items.FindByValue(strAgent)
            'index1 = ddAgent.Items.IndexOf(dd2)
            'ddAgent.SelectedIndex = index1

            'dd2 = ddMkt.Items.FindByValue(strMkt)
            'index1 = ddMkt.Items.IndexOf(dd2)
            'ddMkt.SelectedIndex = index1
            ''Label1.Text = strFtype & " " & dd2.Value & " - " & dd2.Selected & " + " & ddFtype.Items.IndexOf(dd2)
            Dim Getdate As New ClassDate
            Dim strTmonth, strDate As String
            strDate = dr("sign_date")
            If strDate <> "00/01/0000" Then
                strTmonth = Getdate.GetThaiLongMonthName(Mid(strDate, 4, 2))
                tbDd_s.Text = Left(strDate, 2) & " " & strTmonth & " " & Right(strDate, 4) + 543          'Left(strDateR, 2)
            Else
                tbDd_s.Text = ""
            End If

            strDate = dr("due_date")
            If strDate <> "00/01/0000" Then
                strTmonth = Getdate.GetThaiLongMonthName(Mid(strDate, 4, 2))
                tbDd_d.Text = Left(strDate, 2) & " " & strTmonth & " " & Right(strDate, 4) + 543          'Left(strDateR, 2)
            Else
                tbDd_d.Text = ""
            End If

            strDate = dr("resign_date")
            If strDate <> "00/01/0000" Then
                strTmonth = Getdate.GetThaiLongMonthName(Mid(strDate, 4, 2))
                tbDd_r.Text = Left(strDate, 2) & " " & strTmonth & " " & Right(strDate, 4) + 543          'Left(strDateR, 2)
            Else
                tbDd_r.Text = ""
            End If

            strDate = dr("regis_date")
            If strDate <> "00/01/0000" Then
                strTmonth = Getdate.GetThaiLongMonthName(Mid(strDate, 4, 2))
                tbDd_e.Text = Left(strDate, 2) & " " & strTmonth & " " & Right(strDate, 4) + 543          'Left(strDateR, 2)
            Else
                tbDd_e.Text = ""
            End If

            strsql = "select  nvl(min_bath,0) min_bath ,nvl(buy_next_bath,0) buy_next_bath,nvl(sell_min_bath,0) sell_min_bath, " & _
                          " nvl(share_unit,0) share_unit, nvl(share_amt,0) share_amt " & _
                         "  from pv.fundcontl  where fund  = '" & strFund & "'"
            ds = m1.FillMoreTable(ds, strsql, "Fundcontl")
            Dim dr2 As DataRow = ds.Tables(1).Rows(0)
            lbUnit.Text = CType(dr2("share_unit"), Double).ToString("###,###,##0.0000")
            lbAmt.Text = CType(dr2("share_amt"), Double).ToString("###,###,##0.00")

            GetAcct(strFund)
            GetCis(strFund)
        End If
    End Sub

    Private Sub GetAcct(ByVal strFund As String)
        strsql = " SELECT FUNDACCT.FUND fund,  FUNDACCT.BK_CODE,  FUNDACCT.BK_BRAN , " & _
                        "OPNMBANK_A.BK_NAME bk_name,OPNMBANK_B.BK_NAME br_name, FUNDACCT.SEQ_NO, " & _
                        "FUNDACCT.ACCT_FLG acct_flg,  FUNDACCT.REC_FLG rec_flg, FUNDACCT.ACCT_NAME acct_name,  " & _
                        "FUNDACCT.ACCT_NO acct_no, FUNDACCT.ACCT_TYPE acct_type " & _
                        "FROM CIS.OPNMBANK OPNMBANK_A , FUNDACCT,   CIS.OPNMBANK  OPNMBANK_B " & _
                        "WHERE ( FUNDACCT.BK_CODE = OPNMBANK_A.BK_CODE  ) and  " & _
                        "( FUNDACCT.BK_CODE = OPNMBANK_B.BK_CODE ) and  " & _
                        "(FUNDACCT.BK_BRAN = OPNMBANK_B.BK_BRAN ) and  " & _
                        "( (OPNMBANK_A.BK_BRAN = 'XXX' ) )   and  " & _
                        "FUNDACCT.Fund = '" & strFund & "'"

        ds = m1.GetDataset(strsql)
        DG1.DataSource = ds
        DG1.DataBind()
        If ds.Tables(0).Rows.Count < 1 Then
            lbMsg.Text = "*** ����բ����� ����Ѻ�Թ�Ż���ª�� ***"
            'Else
            '    lbMsg.Text = " �ӹǹ�����ŷ���� = " & ds.Tables(0).Rows.Count & " ��¡�� "
        End If
    End Sub

    Private Sub GetCis(ByVal strFund As String)
        strsql = " SELECT cis_no,  cp_name " & _
                  "FROM v_pvmhold_web " & _
                   "WHERE Fund = '" & strFund & "'"

        ds = m1.GetDataset(strsql)
        DG_cis.DataSource = ds
        DG_cis.DataBind()
        If ds.Tables(0).Rows.Count < 1 Then
            lbMsg2.Text = "*** ����բ����� �١���㹡ͧ�ع ***"
            'Else
            '    lbMsg.Text = " �ӹǹ�����ŷ���� = " & ds.Tables(0).Rows.Count & " ��¡�� "
        End If
    End Sub

    Sub MyRefresh()
        DG1.DataSource = ds
        DG1.DataBind()
    End Sub

    Private Sub GetDate()
        Dim c_date As Date = Now
        Dim str_cur As String

        str_cur = c_date.Day

        Dim i As Integer
        'For i = 0 To 31
        '    ddDd_s.Items.Add(i)
        '    ddDd_d.Items.Add(i)
        '    ddDd_r.Items.Add(i)
        '    ddDd_e.Items.Add(i)
        'Next

        'ddDd_s.SelectedIndex = str_cur
        'ddDd_d.SelectedIndex = str_cur
        'ddDd_r.SelectedIndex = str_cur
        'ddDd_e.SelectedIndex = str_cur

        'strsql = "select * from web.webmonth"
        'ds = m1.GetDataset(strsql)
        'ddDm_s.DataSource = ds
        'ddDm_s.DataTextField = "mth_t_name"
        'ddDm_s.DataValueField = "mth_code"

        'ddDm_d.DataSource = ds
        'ddDm_d.DataTextField = "mth_t_name"
        'ddDm_d.DataValueField = "mth_code"

        'ddDm_r.DataSource = ds
        'ddDm_r.DataTextField = "mth_t_name"
        'ddDm_r.DataValueField = "mth_code"

        'ddDm_e.DataSource = ds
        'ddDm_e.DataTextField = "mth_t_name"
        'ddDm_e.DataValueField = "mth_code"

        'Dim yy() As String = {"2542", "2543", "2544", "2545", ",2546", "2547", "2548", "2549", "2550"}
        'ddDy_s.DataSource = yy
        'ddDy_d.DataSource = yy
        'ddDy_r.DataSource = yy
        'ddDy_e.DataSource = yy
        'Me.DataBind()

    End Sub

    Private Sub DG_cis_ItemCreated(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub DG_cis_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DG_cis.SelectedIndexChanged
        Dim strCisno As String = DG_cis.SelectedItem.Cells(0).Text   ' Get from Hidden column
        Response.Redirect("pvf_show_cust_desc.aspx?cis_no=" & strCisno)
    End Sub

End Class
