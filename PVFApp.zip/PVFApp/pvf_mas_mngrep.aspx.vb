Imports System.Xml
Imports System.IO

Public Class pvf_mas_mngrep
    Inherits System.Web.UI.Page
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents rdlType As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents tbR1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbR2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbR3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbR4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbR5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbR6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents imgSave As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ddDm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents ddDy As System.Web.UI.WebControls.DropDownList

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strsql As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "mas_manager") = "F" Then
                lbMsg.Text = "�س������Է�� ����¡������ ��� "
                imgSave.Enabled = False
                rdlType.Enabled = False
                Exit Sub
            End If
            '   Panel2.Attributes.Add("style", "display:none")
            GetDate()
        End If
    End Sub

    Private Sub rdlType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlType.SelectedIndexChanged
        tbR1.Text = ""
        tbR2.Text = ""
        tbR3.Text = ""
        tbR4.Text = ""
        'tbR5.Text = ""
        'tbR6.Text = ""

        Dim strMonth As String = ddDm.SelectedItem.Value
        Dim strYear As String = ddDy.SelectedItem.Value
        Dim strType As String = "mas" & rdlType.SelectedItem.Value & "_" & strMonth & strYear
        Dim xmlDataSet As New DataSet()
        Dim strfile As String
        Dim strWhere As String

        '**** Get data from XML
        strfile = Server.MapPath("XML/" & strType & ".xml")
        If File.Exists(strfile) Then
            ' Session("masEdit") = "True"
            xmlDataSet.ReadXml(Server.MapPath("XML/" & strType & ".xml"))
            Dim dr2 As DataRow = xmlDataSet.Tables(0).Rows(0)
            Dim strNews
            tbR1.Text = dr2("News1")
            tbR2.Text = dr2("News2")
            tbR3.Text = dr2("News3")
            tbR4.Text = dr2("News4")
            ' tbR5.Text = dr2("News5")
            'tbR6.Text = dr2("News6")

            tbR1.Text = Mid(dr2("News1"), 2)
            tbR2.Text = Mid(dr2("News2"), 3)
            tbR3.Text = Mid(dr2("News3"), 3)
            tbR4.Text = Mid(dr2("News4"), 3)
            ''tbR5.Text = Mid(dr2("News5"), 11)
            ''tbR6.Text = Mid(dr2("News6"), 11)
        Else
            tbR1.Text = "����բ�������§ҹ�ͧ�������ͧ�ع"
            ' Session("masEdit") = "False"
        End If

        ' **** Get data from Oracle
        'strsql = "select nvl(rep_line1,' ') rep_line1, nvl(rep_line2,' ') rep_line2, " & _
        '         " nvl(rep_line3,' ') rep_line3, nvl(rep_line4,' ') rep_line4 " & _
        '         " from pvrfundmas " & _
        '         " where fund_type = '" & rdlType.SelectedItem.Value & "' " & _
        '         " and rep_month = '" & strMonth & "' and rep_year = '" & strYear & "'"

        'Dim dr As DataRow
        'ds = m1.GetDataset(strsql)
        'If ds.Tables(0).Rows.Count < 1 Then
        '    tbR1.Text = "����բ�������§ҹ�ͧ�������ͧ�ع"
        '    Session("masEdit") = "False"
        'Else
        '    dr = ds.Tables(0).Rows(0)
        '    tbR1.Text = dr("rep_line1")
        '    tbR2.Text = dr("rep_line2")
        '    tbR3.Text = dr("rep_line3")
        '    tbR4.Text = dr("rep_line4")
        '    Session("masEdit") = "True"
        'End If


    End Sub

    Private Sub imgSave_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgSave.Click

        Dim strMonth As String = ddDm.SelectedItem.Value
        Dim strYear As String = ddDy.SelectedItem.Value
        Dim strFund As String = "mas" & rdlType.SelectedItem.Value & "_" & strMonth & strYear
        Dim w1 As XmlTextWriter
        Dim xfile As String = Server.MapPath("XML/" & strFund & ".xml")
        Dim strTag1, strTag2 As String

        'If Session("masEdit") = "True" Then
        '    strTag1 = "&#09;"  '"&#38" + "#09;"
        '    strTag2 = "&#13;&#09;"
        'Else
        '    strTag1 = ""
        '    strTag2 = ""
        'End If

        'w1 = New XmlTextWriter(xfile, Nothing)
        'w1.WriteStartDocument()
        'w1.Formatting = Formatting.Indented
        'w1.Indentation = 3
        'w1.WriteStartElement("FundReport")
        'w1.WriteStartElement("Data")
        'w1.WriteAttributeString("Fund", " Master File")
        'w1.WriteElementString("News1", strTag1 + tbR1.Text)
        'w1.WriteElementString("News2", strTag2 + tbR2.Text)
        'w1.WriteElementString("News3", strTag2 + tbR3.Text)
        'w1.WriteElementString("News4", strTag2 + tbR4.Text)
        'w1.WriteElementString("News5", strTag2 + tbR5.Text)
        'w1.WriteElementString("News6", strTag2 + tbR6.Text)
        'w1.WriteEndElement()
        'w1.WriteEndElement()
        'w1.Close()

        Dim t1 As New StreamWriter(xfile)
        Dim ln As String
        ' If Session("masEdit") = "True" Then
        strTag1 = "&#09;"
        strTag2 = "&#13;&#09;"
        ' Else
        '    strTag1 = ""
        '    strTag2 = ""
        'End If
        ln = "<?xml version='1.0'?>"
        ln &= "<FundReport>"
        ln &= "<Data Fund='Master File'>"
        ln &= "<News1>" & strTag1 + tbR1.Text & "</News1>"
        ln &= "<News2>" & strTag2 + tbR2.Text & "</News2>"
        ln &= "<News3>" & strTag2 + tbR3.Text & "</News3>"
        ln &= "<News4>" & strTag2 + tbR4.Text & "</News4>"
        ln &= "<News5></News5>"
        ln &= "<News6></News6>"
        ln &= " </Data> "
        ln &= " </FundReport> "
        t1.WriteLine(ln)
        t1.Close()

        ' **** Save data to Oracle
        'If Session("masEdit") = "False" Then   ' Insert new data
        '    strsql = " insert into pvrfundmas (fund_type,rep_month,rep_year, " & _
        '             " rep_line1, rep_line2, rep_line3 ,rep_line4 ) " & _
        '             " values ( '" & rdlType.SelectedItem.Value & "','" & strMonth & "','" & _
        '             strYear & "','" & tbR1.Text & "','" & tbR2.Text & "','" & tbR3.Text & _
        '             "','" & tbR4.Text & "' )"

        'Else   ' Edit data
        '    strsql = " update pvrfundmas set ( " & _
        '             " rep_line1 = '" & tbR1.Text & "', " & _
        '             " rep_line2 = '" & tbR2.Text & "', " & _
        '             " rep_line3 = '" & tbR3.Text & "', " & _
        '             " rep_line4 = '" & tbR4.Text & "' ) " & _
        '             " where fund_type = '" & rdlType.SelectedItem.Value & "' " & _
        '             " and rep_month ='" & strMonth & "'" & _
        '             " and rep_year = '" & strYear & "'"
        'End If

        'lbMsg.Text = strsql
        'm1.Execute(strsql)
        Response.Redirect("success.aspx?pagename=pvf_mas_mngrep.aspx")
    End Sub

    Private Sub GetDate()
        Dim c_date As Date = Now
        Dim str_cur As String

        str_cur = c_date.Day

        strsql = "select * from web.webmonth"
        ds = m1.GetDataset(strsql)
        ddDm.DataSource = ds
        ddDm.DataTextField = "mth_t_name"
        ddDm.DataValueField = "mth_code"

        Dim i As Integer
        Dim yy(2) As String '= {"2546", "2547"}
        For i = 0 To 1
            yy(i) = Now.Year - i + 543
            ddDy.Items.Add(yy(i))
        Next

        'Dim yy() As String = {"2546", "2547"}
        'ddDy.DataSource = yy
        'str_cur = c_date.Year + 543
        'lbmsg.Text = str_cur
        'dddy.SelectedIndex = str_cur
        Me.DataBind()

        str_cur = c_date.Month
        ddDm.SelectedIndex = str_cur - 1
    End Sub

End Class
