Public Class pvf_upd_cust
    Inherits System.Web.UI.Page
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents tbCisno As System.Web.UI.WebControls.TextBox
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents tbEmail As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTaxid As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbRefno As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddRefType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddOccCode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddNatCode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDy As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddStatus As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddHType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbSname As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbName As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFirst As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddFirst As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbFax_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTelm_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel3_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel2_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel1_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddCnt_o As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbZip_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddProv_o As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbAmphur_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTambon_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbRoad_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbSoi_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTower_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbMoo_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbHouse_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbDept As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbPos As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFax_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTelm_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel3_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel2_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel1_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddCnt_h As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbZip_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddProv_h As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbAmphur_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTambon_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbRoad_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbSoi_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTower_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbMoo_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents cblSelect As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents tbBthDay As System.Web.UI.WebControls.TextBox
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents btCancel As System.Web.UI.WebControls.Button
    Protected WithEvents btEdit As System.Web.UI.WebControls.Button
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel
    Protected WithEvents Panel3 As System.Web.UI.WebControls.Panel
    Protected WithEvents ddSelect_Hide As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbhouse_h As System.Web.UI.WebControls.TextBox

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strSql As String
    Dim dv As DataView
    Dim m1 As New MyData()
    Dim ds As DataSet
    Dim ds_n As DataSet
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "reg_updcust") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                tbCisno.Enabled = False
                btEdit.Enabled = False
                Exit Sub
            End If
            lbMsg.Text = ""
            SetInit()

        Else
            dv = Session("data")
        End If
 
    End Sub

    Sub SetInit()
        strSql = "select first_name, first_code from cis.opnmtitc where first_code !='0' "
        ds = m1.GetDataset(strSql)
        ddFirst.DataSource = ds
        ddFirst.DataTextField = "first_name"
        ddFirst.DataValueField = "first_code"

        strsql = "select holder_type, holder_desc  from cis.opnmhtyp "
        ds = m1.GetDataset(strsql)
        ddHType.DataSource = ds
        ddHType.DataTextField = "holder_desc"
        ddHType.DataValueField = "holder_type"

        strsql = "select nat_code, nat_name  from cis.opnmnatc order by nat_name "
        ds = m1.GetDataset(strsql)
        ddNatCode.DataSource = ds
        ddNatCode.DataTextField = "nat_name"
        ddNatCode.DataValueField = "nat_code"

        strsql = "select occ_code, occ_name  from cis.opnmoccp order by occ_name"
        ds = m1.GetDataset(strsql)
        ddOccCode.DataSource = ds
        ddOccCode.DataTextField = "occ_name"
        ddOccCode.DataValueField = "occ_code"

        strsql = "select ref_type, ref_desc  from cis.opnmreft  order by ref_type "
        ds = m1.GetDataset(strsql)
        ddRefType.DataSource = ds
        ddRefType.DataTextField = "ref_desc"
        ddRefType.DataValueField = "ref_type"

        strsql = "select distinct(prov_name) prov_name  from cis.opnmprov  order by prov_name"
        ds = m1.GetDataset(strsql)
        ddProv_h.DataSource = ds
        ddProv_h.DataTextField = "prov_name"
        ddProv_h.DataValueField = "prov_name"

        ddProv_o.DataSource = ds
        ddProv_o.DataTextField = "prov_name"
        ddProv_o.DataValueField = "prov_name"

        strsql = "select *  from cis.opnmcntc order by cnt_code"
        ds = m1.GetDataset(strsql)
        ddCnt_h.DataSource = ds
        ddCnt_h.DataTextField = "cnt_name"
        ddCnt_h.DataValueField = "cnt_code"

        ddCnt_o.DataSource = ds
        ddCnt_o.DataTextField = "cnt_name"
        ddCnt_o.DataValueField = "cnt_code"

        Me.DataBind()

    End Sub

    Private Sub tbCisno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbCisno.TextChanged
        tbCisno.Text = Right("0000000000" + tbCisno.Text, 10)
        GetData(tbCisno.Text)
    End Sub

    Sub GetData(ByVal strCis As String)
        tbCisno.Text = strCis
        Dim strFirst, strNat, strOcc, strRef, strHtype, strStatus As String
        Dim strProvH, strCntH, strProvO, strCntO As String
        Dim strTemp, strBthD As String
        Dim dr As DataRow

        ' **********  Get Data from PVmCust and Get Description from Table Referent ********
        'strSql = "select  cis_no,c.first_name,name||'  '||surname name,to_char(bth_date,'dd/mm/yyyy') bth_date,c.ref_no,c.tax_id, " & _
        '                "nvl(ref_type,' ') ref_type,nvl(nat_code,' ') nat_code,nvl(c.occ_code,' ') occ_code,  " & _
        '                "nvl(c.holder_type,' ') holder_type,c.email  " & _
        '"from v_pvmcust   where c.cis_no = '" & strCis & "'"
        strSql = "SELECT nvl(FIRST_CODE,'') first_code, nvl(FIRST_NAME,' ') first_name,  nvl(NAME,' ') name, nvl(SURNAME,' ') sname,   " & _
               "nvl(OCC_CODE,' ') occ_code,nvl( HOLDER_TYPE,' ') holder_type,nvl( NAT_CODE,' ') nat_code,nvl(REF_TYPE,' ') ref_type,   " & _
              "nvl(REF_NO,' ') ref_no,nvl(TAX_ID,' ') tax_id,  nvl(to_char(bth_date,'dd/mm/yyyy'),null) bth_date, STATUS, nvl(EMAIL,' ') email,   " & _
               "nvl(HOUSE_NO_H,' ') house_no_h,nvl(MOO_H,' ') moo_h, nvl(TOWER_H,' ') tower_h, nvl(SOI_H,' ') soi_h, nvl(ROAD_H,' ') road_h,   " & _
               "nvl(TAMBON_H,' ') tambon_h, nvl(AMPHUR_H,' ') amphur_h,nvl(PROVINCE_H,' ') province_h, nvl(ZIPCODE_H,' ') zipcode_h,   " & _
               "nvl(CNTCODE_H,' ') cntcode_h,nvl(TEL1_H,' ') tel1_h, nvl(TEL2_H,' ') tel2_h,nvl(TEL3_H,' ') tel3_h,nvl(TELM_H,' ') telm_h, nvl(FAX_H,' ') fax_h,   " & _
               "nvl(HOUSE_NO_O,' ') house_no_o,nvl(MOO_O,' ') moo_o, nvl(TOWER_O,' ') tower_o, nvl(SOI_O,' ') soi_o, nvl(ROAD_O,' ') road_o,   " & _
               "nvl(TAMBON_O,' ') tambon_o, nvl(AMPHUR_O,' ') amphur_o,nvl(PROVINCE_O,' ') province_o, nvl(ZIPCODE_O,' ') zipcode_o,   " & _
               "nvl(CNTCODE_O,' ') cntcode_o,nvl(TEL1_O,' ') tel1_o, nvl(TEL2_O,' ') tel2_o,nvl(TEL3_O,' ') tel3_o,nvl(TELM_O,' ') telm_o, nvl(FAX_O,' ') fax_o,   " & _
                "nvl(POSITION,' ') position, nvl(DEPT,' ') dept " & _
                "FROM V_PVMCUST  " & _
                "where cis_no = '" & strCis & "'"
        '        lbMsg.Text = strSql

        ds = m1.GetDataset(strSql)
        'Try
        ''     Panel1.Attributes.Add("style", "display:")

        'Dim strBthDate As String = Left(strBthD, 2) & "/" & Mid(strBthD, 4, 2) & "/" & Right(strBthD, 4) + 543
        'dr("bth_date") = strBthDate
        If ds.Tables(0).Rows.Count > 0 Then
            lbMsg.Text = ""
            dr = ds.Tables(0).Rows(0)

            '*** Set data into text box
            tbEmail.Text = dr("email")
            tbTaxid.Text = dr("tax_id")
            tbRefno.Text = dr("ref_no")

            tbSname.Text = dr("sname")
            tbName.Text = dr("name")
            tbFirst.Text = dr("first_name")
            tbBthDay.Text = dr("bth_Date")

            tbAmphur_h.Text = dr("amphur_h")
            tbTambon_h.Text = dr("tambon_h")
            tbRoad_h.Text = dr("road_h")
            tbSoi_h.Text = dr("soi_h")
            tbTower_h.Text = dr("tower_h")
            tbMoo_h.Text = dr("moo_h")
            tbhouse_h.Text = dr("house_no_h")
            tbFax_h.Text = dr("fax_h")
            tbTelm_h.Text = dr("telm_h")
            tbTel3_h.Text = dr("tel3_h")
            tbTel2_h.Text = dr("tel2_h")
            tbTel1_h.Text = dr("tel1_h")
            tbZip_h.Text = dr("zipcode_h")


            tbAmphur_o.Text = dr("amphur_o")
            tbTambon_o.Text = dr("tambon_o")
            tbRoad_o.Text = dr("road_o")
            tbSoi_o.Text = dr("soi_o")
            tbTower_o.Text = dr("tower_o")
            tbMoo_o.Text = dr("moo_o")
            tbHouse_o.Text = dr("house_no_o")
            tbFax_o.Text = dr("fax_o")
            tbTelm_o.Text = dr("telm_o")
            tbTel3_o.Text = dr("tel3_o")
            tbTel2_o.Text = dr("tel2_o")
            tbTel1_o.Text = dr("tel1_o")
            tbZip_o.Text = dr("zipcode_o")
            tbDept.Text = dr("dept")
            tbPos.Text = dr("position")

            ' *** Set data into dropdrow
            Dim dd2 As ListItem
            Dim index1 As Integer
            strFirst = dr("first_code")
            strNat = dr("nat_code")
            strOcc = dr("occ_code")
            strRef = dr("ref_type")
            strHtype = dr("holder_type")
            strStatus = dr("status")
            strBthD = dr("bth_date")
            If strBthD = Now() Then
                strBthD = ""
            End If
            strCntH = dr("cntcode_h")
            strProvH = dr("province_h")
            strCntO = dr("cntcode_o")
            strProvO = dr("province_o")

            'ddDy.text()
            'ddDm.text()
            'ddDd.text()
            dd2 = ddFirst.Items.FindByValue(strFirst)
            index1 = ddFirst.Items.IndexOf(dd2)
            ddFirst.SelectedIndex = index1

            dd2 = ddNatCode.Items.FindByValue(strNat)
            index1 = ddNatCode.Items.IndexOf(dd2)
            ddNatCode.SelectedIndex = index1

            dd2 = ddOccCode.Items.FindByValue(strOcc)
            index1 = ddOccCode.Items.IndexOf(dd2)
            ddOccCode.SelectedIndex = index1

            dd2 = ddRefType.Items.FindByValue(strRef)
            index1 = ddRefType.Items.IndexOf(dd2)
            ddRefType.SelectedIndex = index1

            dd2 = ddHType.Items.FindByValue(strHtype)
            index1 = ddHType.Items.IndexOf(dd2)
            ddHType.SelectedIndex = index1

            dd2 = ddStatus.Items.FindByValue(strStatus)
            index1 = ddStatus.Items.IndexOf(dd2)
            ddStatus.SelectedIndex = index1

            dd2 = ddProv_h.Items.FindByValue(strProvH)
            index1 = ddProv_h.Items.IndexOf(dd2)
            ddProv_h.SelectedIndex = index1
            dd2 = ddCnt_h.Items.FindByValue(strCntH)
            index1 = ddCnt_h.Items.IndexOf(dd2)
            ddCnt_h.SelectedIndex = index1

            dd2 = ddProv_o.Items.FindByValue(strProvO)
            index1 = ddProv_o.Items.IndexOf(dd2)
            ddProv_o.SelectedIndex = index1
            dd2 = ddCnt_o.Items.FindByValue(strCntO)
            index1 = ddCnt_o.Items.IndexOf(dd2)
            ddCnt_o.SelectedIndex = index1
            cblSelect.Enabled = True
        Else
            SetEnable("T")
            cblSelect.Enabled = False
            lbMsg.Text = " *** ����բ������١��� *** "
        End If
        'Catch x1 As Exception
        '    SetClear()
        '    lbMsg.Text &= " *** ����բ������١��� ***"
        '    Panel1.Attributes.Add("style", "display:none")
        'End Try

    End Sub

    Private Sub cblSelect_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cblSelect.SelectedIndexChanged
        Dim Item As ListItem
        Dim strUpd, strChk As String
        For Each Item In cblSelect.Items
            strUpd = Item.Value
            If Item.Selected Then
                strChk = "T"
                Select Case strUpd
                    Case "PV_C01"
                        ddFirst.Enabled = True
                        tbFirst.Enabled = True
                        tbName.Enabled = True
                        tbSname.Enabled = True
                    Case "PV_C02"
                        ddHType.Enabled = True
                        ddStatus.Enabled = True
                    Case "PV_C03"
                        tbBthDay.Enabled = True
                        ddNatCode.Enabled = True
                        ddOccCode.Enabled = True
                    Case "PV_C04"
                        ddRefType.Enabled = True
                        tbRefno.Enabled = True
                        tbTaxid.Enabled = True
                    Case "PV_C05"
                        tbEmail.Enabled = True
                    Case "PV_A01"
                        tbAmphur_h.Enabled = True
                        tbTambon_h.Enabled = True
                        tbRoad_h.Enabled = True
                        tbSoi_h.Enabled = True
                        tbTower_h.Enabled = True
                        tbMoo_h.Enabled = True
                        tbhouse_h.Enabled = True
                        tbDept.Enabled = True
                        tbPos.Enabled = True
                        tbFax_h.Enabled = True
                        tbTelm_h.Enabled = True
                        tbTel3_h.Enabled = True
                        tbTel2_h.Enabled = True
                        tbTel1_h.Enabled = True
                        tbZip_h.Enabled = True
                        ddCnt_h.Enabled = True
                        ddProv_h.Enabled = True
                    Case "PV_A02"
                        tbAmphur_o.Enabled = True
                        tbTambon_o.Enabled = True
                        tbRoad_o.Enabled = True
                        tbSoi_o.Enabled = True
                        tbTower_o.Enabled = True
                        tbMoo_o.Enabled = True
                        tbHouse_o.Enabled = True
                        tbDept.Enabled = True
                        tbPos.Enabled = True
                        tbFax_o.Enabled = True
                        tbTelm_o.Enabled = True
                        tbTel3_o.Enabled = True
                        tbTel2_o.Enabled = True
                        tbTel1_o.Enabled = True
                        tbZip_o.Enabled = True
                        ddCnt_o.Enabled = True
                        ddProv_o.Enabled = True
                End Select
            Else
                Select Case strUpd
                    Case "PV_C01"
                        ddFirst.Enabled = False
                        tbFirst.Enabled = False
                        tbName.Enabled = False
                        tbSname.Enabled = False
                    Case "PV_C02"
                        ddHType.Enabled = False
                        ddStatus.Enabled = False
                    Case "PV_C03"
                        tbBthDay.Enabled = False
                        ddNatCode.Enabled = False
                        ddOccCode.Enabled = False
                    Case "PV_C04"
                        ddRefType.Enabled = False
                        tbRefno.Enabled = False
                        tbTaxid.Enabled = False
                    Case "PV_C05"
                        tbEmail.Enabled = False
                    Case "PV_A01"
                        tbAmphur_h.Enabled = False
                        tbTambon_h.Enabled = False
                        tbRoad_h.Enabled = False
                        tbSoi_h.Enabled = False
                        tbTower_h.Enabled = False
                        tbMoo_h.Enabled = False
                        tbhouse_h.Enabled = False
                        tbFax_h.Enabled = False
                        tbTelm_h.Enabled = False
                        tbTel3_h.Enabled = False
                        tbTel2_h.Enabled = False
                        tbTel1_h.Enabled = False
                        tbZip_h.Enabled = False
                        ddCnt_h.Enabled = False
                        ddProv_h.Enabled = False
                    Case "PV_A02"
                        tbAmphur_o.Enabled = False
                        tbTambon_o.Enabled = False
                        tbRoad_o.Enabled = False
                        tbSoi_o.Enabled = False
                        tbTower_o.Enabled = False
                        tbMoo_o.Enabled = False
                        tbHouse_o.Enabled = False
                        tbDept.Enabled = False
                        tbPos.Enabled = False
                        tbFax_o.Enabled = False
                        tbTelm_o.Enabled = False
                        tbTel3_o.Enabled = False
                        tbTel2_o.Enabled = False
                        tbTel1_o.Enabled = False
                        tbZip_o.Enabled = False
                        ddCnt_o.Enabled = False
                        ddProv_o.Enabled = False
                End Select
            End If
        Next

        If strChk = "T" Then
            btSave.Enabled = True
        Else
            btSave.Enabled = False
        End If
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strBthDate, strFirst, strHtype, strNat, strOcc, strRef, strStatus As String
        Dim strProvH, strProvO, strCntH, strCntO As String
        Dim strFname, strName, strSname, strCisno, strRefno, strTaxid, strEmail As String
        Dim strAmphurH, strTambonH, strRoadH, strSoiH, strTowerH, strMooH, strHouseH As String
        Dim strFaxH, strTelmH, strTel3H, strTel2H, strTel1H, strZipH As String
        Dim strAmphurO, strTambonO, strRoadO, strSoiO, strTowerO, strMooO, strHouseO As String
        Dim strFaxO, strTelmO, strTel3O, strTel2O, strTel1O, strZipO, strDept, strPos As String
        Dim strUpdFlg, strChkA01, strChkA02, strChkC As String
        Dim dbRunno As Double

        strCisno = tbCisno.Text
        Select Case ddFirst.SelectedItem.Value
            Case "3", "7"
                strFname = tbFirst.Text
            Case Else
                strFname = ddFirst.SelectedItem.Text
        End Select

        strSql = "Select mas_ref From cis.MasterRef Where mas_code = 'pvhmas' "
        ds = m1.GetDataset(strSql)
        Dim dr1 As DataRow = ds.Tables(0).Rows(0)
        dbRunno = dr1("mas_ref") + 1

        Dim Item As ListItem
        Dim strUpd As String
        For Each Item In ddSelect_Hide.Items
            '            For Each Item In cblSelect.Items
            strUpd = Item.Value
            ' **** Insert into hMas ****
            strSql = "insert into pv.pvhmas(run_no,cis_no,upd_flg,upd_by,upd_date )" & _
                          "values (" & dbRunno & ", '" & strCisno & "','" & strUpd & "','" & Session("user_id") & "', sysdate )"
            m1.Execute(strSql)
            Select Case strUpd
                Case "PV_C01", "PV_C02", "PV_C03", "PV_C04", "PV_C05"
                    strChkC = "T"
                Case "PV_A01"
                    strChkA01 = "T"
                Case "PV_A02"
                    strChkA02 = "T"
            End Select
        Next
        '     lbMsg.Text = "test = " & strSql

        ' *** Select data before change
        strSql = "SELECT nvl(FIRST_CODE,'') first_code, nvl(FIRST_NAME,' ') first_name,  nvl(NAME,' ') name, nvl(SURNAME,' ') sname,   " & _
    "nvl(OCC_CODE,'') occ_code,nvl( HOLDER_TYPE,'') holder_type,nvl( NAT_CODE,'') nat_code,nvl(REF_TYPE,'') ref_type,   " & _
    "nvl(REF_NO,' ') ref_no,nvl(TAX_ID,' ') tax_id,  nvl(BTH_DATE,sysdate) bth_date, STATUS, nvl(EMAIL,' ') email,   " & _
    "nvl(HOUSE_NO_H,' ') house_no_h,nvl(MOO_H,' ') moo_h, nvl(TOWER_H,' ') tower_h, nvl(SOI_H,' ') soi_h, nvl(ROAD_H,' ') road_h,   " & _
    "nvl(TAMBON_H,' ') tambon_h, nvl(AMPHUR_H,' ') amphur_h,nvl(PROVINCE_H,' ') province_h, nvl(ZIPCODE_H,' ') zipcode_h,   " & _
    "nvl(CNTCODE_H,' ') cntcode_h,nvl(TEL1_H,' ') tel1_h, nvl(TEL2_H,' ') tel2_h,nvl(TEL3_H,' ') tel3_h,nvl(TELM_H,' ') telm_h, nvl(FAX_H,' ') fax_h,   " & _
    "nvl(HOUSE_NO_O,' ') house_no_o,nvl(MOO_O,' ') moo_o, nvl(TOWER_O,' ') tower_o, nvl(SOI_O,' ') soi_o, nvl(ROAD_O,' ') road_o,   " & _
    "nvl(TAMBON_O,' ') tambon_o, nvl(AMPHUR_O,' ') amphur_o,nvl(PROVINCE_O,' ') province_o, nvl(ZIPCODE_O,' ') zipcode_o,   " & _
    "nvl(CNTCODE_O,' ') cntcode_o,nvl(TEL1_O,' ') tel1_o, nvl(TEL2_O,' ') tel2_o,nvl(TEL3_O,' ') tel3_o,nvl(TELM_O,' ') telm_o, nvl(FAX_O,' ') fax_o,   " & _
     "nvl(POSITION,' ') position, nvl(DEPT,' ') dept " & _
     "FROM V_PVMCUST  " & _
     "where cis_no = '" & strCisno & "'"
        '   lbMsg.Text = strSql

        ds = m1.GetDataset(strSql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)

        For Each Item In ddSelect_Hide.Items
            '            For Each Item In cblSelect.Items
            strUpd = Item.Value
            Select Case strUpd
                Case "PV_C01"
                    strFirst = dr("first_code")
                    strFname = Trim(dr("first_name"))
                    strName = Trim(dr("name"))
                    strSname = Trim(dr("sname"))
                Case "PV_C02"
                    strHtype = dr("holder_type")
                    strStatus = dr("status")
                Case "PV_C03"
                    strBthDate = dr("bth_date")
                    strNat = dr("nat_code")
                    strOcc = dr("occ_code")
                Case "PV_C04"
                    strRef = Trim(dr("ref_type"))
                    strRefno = Trim(dr("ref_no"))
                    strTaxid = Trim(dr("tax_id"))
                Case "PV_C05"
                    strEmail = Trim(dr("email"))
                Case "PV_A01"
                    strAmphurH = Trim(dr("amphur_h"))
                    strTambonH = Trim(dr("tambon_h"))
                    strRoadH = Trim(dr("road_h"))
                    strSoiH = Trim(dr("soi_h"))
                    strTowerH = Trim(dr("tower_h"))
                    strMooH = Trim(dr("moo_h"))
                    strHouseH = Trim(dr("house_no_h"))
                    strFaxH = Trim(dr("fax_h"))
                    strTelmH = Trim(dr("telm_h"))
                    strTel3H = Trim(dr("tel3_h"))
                    strTel2H = Trim(dr("tel2_h"))
                    strTel1H = Trim(dr("tel1_h"))
                    strZipH = Trim(dr("zipcode_h"))
                    strCntH = dr("cntcode_h")
                    strProvH = Trim(dr("province_h"))
                Case "PV_A02"
                    strAmphurO = Trim(dr("amphur_o"))
                    strTambonO = Trim(dr("tambon_o"))
                    strRoadO = Trim(dr("road_o"))
                    strSoiO = Trim(dr("soi_o"))
                    strTowerO = Trim(dr("tower_o"))
                    strMooO = Trim(dr("moo_o"))
                    strHouseO = Trim(dr("house_no_o"))
                    strFaxO = Trim(dr("fax_o"))
                    strTelmO = Trim(dr("telm_o"))
                    strTel3O = Trim(dr("tel3_o"))
                    strTel2O = Trim(dr("tel2_o"))
                    strTel1O = Trim(dr("tel1_o"))
                    strZipO = Trim(dr("zipcode_o"))
                    strCntO = dr("cntcode_o")
                    strProvO = Trim(dr("province_o"))
                    strDept = Trim(dr("dept"))
                    strPos = Trim(dr("position"))
            End Select
        Next

        If strChkC = "T" Then
            ' **** Insert data before change into pvHcust
            strSql = "insert into pv.pvhcust(run_no,cis_no,first_code,first_name,name,surname,holder_type,nat_code,occ_code, " & _
                                  "ref_type,ref_no,tax_id,bth_date,status, email )" & _
                                "values (" & dbRunno & ", '" & strCisno & "','" & strFirst & "','" & strFname & "','" & strName & "','" & strSname & "','" & _
                                strHtype & "','" & strNat & "','" & strOcc & "','" & strRef & "','" & strRefno & "','" & strTaxid & "', " & _
                                "to_date('" & strBthDate & "','dd/mm/yyyy'),'" & strStatus & "', '" & strEmail & "')"
            '                        "to_date('" & strBthDate & "','dd/mm/yyyy'),'" & 
            m1.Execute(strSql)
        End If

        'lbMsg.Text = "test = " & strSql

        ' **** Insert into hAddr ****
        If strChkA01 = "T" Or strChkA02 = "T" Then
            If strChkA01 <> "T" Then
                strAmphurH = ""
                strTambonH = ""
                strRoadH = ""
                strSoiH = ""
                strTowerH = ""
                strMooH = ""
                strHouseH = ""
                strFaxH = ""
                strTelmH = ""
                strTel3H = ""
                strTel2H = ""
                strTel1H = ""
                strZipH = ""
                strCntH = ""
                strProvH = ""
            ElseIf strChkA02 <> "T" Then
                strAmphurO = ""
                strTambonO = ""
                strRoadO = ""
                strSoiO = ""
                strTowerO = ""
                strMooO = ""
                strHouseO = ""
                strFaxO = ""
                strTelmO = ""
                strTel3O = ""
                strTel2O = ""
                strTel1O = ""
                strZipO = ""
                strCntO = ""
                strProvO = ""
                strDept = ""
                strPos = ""
            End If

            strSql = "insert into pv.pvhaddr(run_no,cis_no,house_no_o, moo_o, tower_o,soi_o,road_o , tambon_o,amphur_o,province_o,zipcode_o, " & _
                           "tel1_o,tel2_o,tel3_o,telm_o ,fax_o, house_no_h,moo_h,tower_h,soi_h,road_h,tambon_h,amphur_h,province_h,zipcode_h," & _
                           "tel1_h,tel2_h,tel3_h, telm_h ,fax_h, position, dept ,cntcode_o,cntcode_h) " & _
                            "values (" & dbRunno & ", '" & strCisno & "','" & strHouseO & "','" & strMooO & "','" & strTowerO & "','" & _
                            strSoiO & "','" & strRoadO & "','" & strTambonO & "','" & strAmphurO & "','" & strProvO & "','" & _
                            strZipO & "','" & strTel1O & "','" & strTel2O & "','" & strTel3O & "','" & strTelmO & "','" & _
                             strFaxO & "','" & strHouseH & "','" & strMooH & "','" & strTowerH & "','" & _
                             strSoiH & "','" & strRoadH & "','" & strTambonH & "','" & strAmphurH & "','" & strProvH & "','" & _
                             strZipH & "','" & strTel1H & "','" & strTel2H & "','" & strTel3H & "','" & strTelmH & "','" & _
                             strFaxH & "','" & strPos & "','" & strDept & "','" & _
                             strCntO & "','" & strCntH & "')"
            m1.Execute(strSql)
            'lbMsg.Text &= " =======test = " & strSql
        End If

        ' *** Read data from Field
        strBthDate = Trim(tbBthDay.Text)   '= ddDd.SelectedItem.Value & "/" & ddDm.SelectedItem.Value & "/" & ddDy.SelectedItem.Value - 543
        strFirst = ddFirst.SelectedItem.Value
        strHtype = ddHType.SelectedItem.Value
        strNat = ddNatCode.SelectedItem.Value
        strOcc = ddOccCode.SelectedItem.Value
        strRef = ddRefType.SelectedItem.Value
        strStatus = ddStatus.SelectedItem.Value
        strProvH = ddProv_h.SelectedItem.Value
        strProvO = ddProv_o.SelectedItem.Value
        strCntH = ddCnt_h.SelectedItem.Value
        strCntO = ddCnt_o.SelectedItem.Value
        strFname = Trim(tbFirst.Text)
        strName = Trim(tbName.Text)
        strSname = Trim(tbSname.Text)
        strCisno = Trim(tbCisno.Text)
        strRefno = Trim(tbRefno.Text)
        strTaxid = Trim(tbTaxid.Text)
        strEmail = Trim(tbEmail.Text)
        strAmphurH = Trim(tbAmphur_h.Text)
        strTambonH = Trim(tbTambon_h.Text)
        strRoadH = Trim(tbRoad_h.Text)
        strSoiH = Trim(tbSoi_h.Text)
        strTowerH = Trim(tbTower_h.Text)
        strMooH = Trim(tbMoo_h.Text)
        strHouseH = Trim(tbhouse_h.Text)
        strFaxH = Trim(tbFax_h.Text)
        strTelmH = Trim(tbTelm_h.Text)
        strTel3H = Trim(tbTel3_h.Text)
        strTel2H = Trim(tbTel2_h.Text)
        strTel1H = Trim(tbTel1_h.Text)
        strZipH = Trim(tbZip_h.Text)
        strAmphurO = Trim(tbAmphur_o.Text)
        strTambonO = Trim(tbTambon_o.Text)
        strRoadO = Trim(tbRoad_o.Text)
        strSoiO = Trim(tbSoi_o.Text)
        strTowerO = Trim(tbTower_o.Text)
        strMooO = Trim(tbMoo_o.Text)
        strHouseO = Trim(tbHouse_o.Text)
        strFaxO = Trim(tbFax_o.Text)
        strTelmO = Trim(tbTelm_o.Text)
        strTel3O = Trim(tbTel3_o.Text)
        strTel2O = Trim(tbTel2_o.Text)
        strTel1O = Trim(tbTel1_o.Text)
        strZipO = Trim(tbZip_o.Text)
        strDept = Trim(tbDept.Text)
        strPos = Trim(tbPos.Text)

        '*** Update Data into PvMcust
        If strChkC = "T" Then
            strSql = " update pvmcust set first_code = '" & strFirst & "' ," & _
                            " first_name = '" & strFname & "' ," & _
                            "name = '" & strName & "' ," & _
                            " surname = '" & strSname & "' ," & _
                            " holder_type = '" & strHtype & "' ," & _
                            " nat_code = '" & strNat & "' ," & _
                            " occ_code = '" & strOcc & "' ," & _
                            " ref_type = '" & strRef & "' ," & _
                            " ref_no = '" & strRefno & "' ," & _
                            " tax_id = '" & strTaxid & "' ," & _
                            " bth_date = to_date('" & strBthDate & "','dd/mm/yyyy') ," & _
                            " status = '" & strStatus & "' ," & _
                            " email = '" & strEmail & "' ," & _
                            " upd_by = '" & Session("user_id") & "' " & _
                            " where cis_no = '" & strCisno & "'"
            m1.Execute(strSql)
            'lbMsg.Text &= " ********** test = " & strSql

        End If

        '*** Update Data into PvMaddr
        If strChkA01 = "T" Or strChkA02 = "T" Then
            strSql = " update pvmaddr set house_no_o = '" & strHouseO & "' ," & _
                            " moo_o = '" & strMooO & "' , tower_o= '" & strTowerO & "' ," & _
                            " soi_o = '" & strSoiO & "' , road_o= '" & strRoadO & "' ," & _
                            " tambon_o= '" & strTambonO & "' , amphur_o= '" & strAmphurO & "' ," & _
                            " province_o = '" & strProvO & "' , zipcode_o = '" & strZipO & "' ," & _
                           " tel1_o = '" & strTel1O & "' ,tel2_o = '" & strTel2O & "' ," & _
                           " tel3_o = '" & strTel3O & "' ,telm_o= '" & strTelmO & "' ,fax_o = '" & strFaxO & "' , " & _
                           " cntcode_o= '" & strCntO & "',cntcode_h = '" & strCntH & "' ," & _
                           " position = '" & strPos & "', dept= '" & strDept & "' ," & _
                           " house_no_h = '" & strHouseH & "' ,moo_h = '" & strMooH & "' ," & _
                           " tower_h = '" & strTowerH & "' ,soi_h = '" & strSoiH & "' ," & _
                           " road_h = '" & strRoadH & "' ,tambon_h= '" & strTambonH & "' ," & _
                           " amphur_h = '" & strAmphurH & "' ,province_h= '" & strProvH & "' ," & _
                           " zipcode_h= '" & strZipH & "' ,tel1_h = '" & strTel1H & "' ," & _
                           " tel2_h = '" & strTel2H & "' ,tel3_h = '" & strTel3H & "' ," & _
                           " telm_h = '" & strTelmH & "',fax_h= '" & strFaxH & "' ," & _
                           " upd_by =  '" & Session("user_id") & "' " & _
                           " where cis_no = '" & strCisno & "'"

            m1.Execute(strSql)
            'lbMsg.Text &= "++++++++++test = " & strSql
        End If

        strSql = "update cis.MasterRef set mas_ref ='" & dbRunno & "' where mas_code='pvhmas' "
        m1.Execute(strSql)

        Try
            m1.Execute(strSql)
        Catch x1 As Exception
            lbMsg.Text = x1.Message
        End Try

        Response.Redirect("success.aspx?pagename=pvf_upd_cust.aspx")
    End Sub

    Sub SetEnable(ByVal strChkCls)
        '        tbCisno.Text = ""

        ddFirst.Enabled = False
        tbFirst.Enabled = False
        tbName.Enabled = False
        tbSname.Enabled = False
        ddHType.Enabled = False
        ddStatus.Enabled = False
        tbBthDay.Enabled = False
        ddNatCode.Enabled = False
        ddOccCode.Enabled = False
        ddRefType.Enabled = False
        tbRefno.Enabled = False
        tbTaxid.Enabled = False
        tbEmail.Enabled = False
        tbAmphur_h.Enabled = False
        tbTambon_h.Enabled = False
        tbRoad_h.Enabled = False
        tbSoi_h.Enabled = False
        tbTower_h.Enabled = False
        tbMoo_h.Enabled = False
        tbhouse_h.Enabled = False
        tbFax_h.Enabled = False
        tbTelm_h.Enabled = False
        tbTel3_h.Enabled = False
        tbTel2_h.Enabled = False
        tbTel1_h.Enabled = False
        tbZip_h.Enabled = False
        ddCnt_h.Enabled = False
        ddProv_h.Enabled = False
        tbAmphur_o.Enabled = False
        tbTambon_o.Enabled = False
        tbRoad_o.Enabled = False
        tbSoi_o.Enabled = False
        tbTower_o.Enabled = False
        tbMoo_o.Enabled = False
        tbHouse_o.Enabled = False
        tbDept.Enabled = False
        tbPos.Enabled = False
        tbFax_o.Enabled = False
        tbTelm_o.Enabled = False
        tbTel3_o.Enabled = False
        tbTel2_o.Enabled = False
        tbTel1_o.Enabled = False
        tbZip_o.Enabled = False
        ddCnt_o.Enabled = False
        ddProv_o.Enabled = False

        If strChkCls = "T" Then
            tbFirst.Text = ""
            tbName.Text = ""
            tbSname.Text = ""
            tbBthDay.Text = ""
            tbRefno.Text = ""
            tbTaxid.Text = ""
            tbEmail.Text = ""
            tbAmphur_h.Text = ""
            tbTambon_h.Text = ""
            tbRoad_h.Text = ""
            tbSoi_h.Text = ""
            tbTower_h.Text = ""
            tbMoo_h.Text = ""
            tbhouse_h.Text = ""
            tbFax_h.Text = ""
            tbTelm_h.Text = ""
            tbTel3_h.Text = ""
            tbTel2_h.Text = ""
            tbTel1_h.Text = ""
            tbZip_h.Text = ""
            tbAmphur_o.Text = ""
            tbTambon_o.Text = ""
            tbRoad_o.Text = ""
            tbSoi_o.Text = ""
            tbTower_o.Text = ""
            tbMoo_o.Text = ""
            tbHouse_o.Text = ""
            tbDept.Text = ""
            tbPos.Text = ""
            tbFax_o.Text = ""
            tbTelm_o.Text = ""
            tbTel3_o.Text = ""
            tbTel2_o.Text = ""
            tbTel1_o.Text = ""
            tbZip_o.Text = ""

        End If
        cblSelect.SelectedIndex = -1
        btSave.Enabled = False
    End Sub

    Private Sub btCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btCancel.Click
        Dim strCis
        strCis = tbCisno.Text

        btSave.Enabled = False
        cblSelect.Enabled = True
        GetData(strCis)
        SetEnable("F")
    End Sub

    Private Sub btEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btEdit.Click
        Dim Item As ListItem
        Dim strUpd, strChk As String
        If tbCisno.Text <> "" Then

            For Each Item In cblSelect.Items
                '            For Each Item In cblSelect.Items
                strUpd = Item.Value
                If Item.Selected Then
                    strChk = "T"
                    Select Case strUpd
                        Case "PV_C01"
                            ddFirst.Enabled = True
                            tbFirst.Enabled = True
                            tbName.Enabled = True
                            tbSname.Enabled = True
                        Case "PV_C02"
                            ddHType.Enabled = True
                            ddStatus.Enabled = True
                        Case "PV_C03"
                            tbBthDay.Enabled = True
                            ddNatCode.Enabled = True
                            ddOccCode.Enabled = True
                        Case "PV_C04"
                            ddRefType.Enabled = True
                            tbRefno.Enabled = True
                            tbTaxid.Enabled = True
                        Case "PV_C05"
                            tbEmail.Enabled = True
                        Case "PV_A01"
                            tbAmphur_h.Enabled = True
                            tbTambon_h.Enabled = True
                            tbRoad_h.Enabled = True
                            tbSoi_h.Enabled = True
                            tbTower_h.Enabled = True
                            tbMoo_h.Enabled = True
                            tbhouse_h.Enabled = True
                            tbDept.Enabled = True
                            tbPos.Enabled = True
                            tbFax_h.Enabled = True
                            tbTelm_h.Enabled = True
                            tbTel3_h.Enabled = True
                            tbTel2_h.Enabled = True
                            tbTel1_h.Enabled = True
                            tbZip_h.Enabled = True
                            ddCnt_h.Enabled = True
                            ddProv_h.Enabled = True
                        Case "PV_A02"
                            tbAmphur_o.Enabled = True
                            tbTambon_o.Enabled = True
                            tbRoad_o.Enabled = True
                            tbSoi_o.Enabled = True
                            tbTower_o.Enabled = True
                            tbMoo_o.Enabled = True
                            tbHouse_o.Enabled = True
                            tbDept.Enabled = True
                            tbPos.Enabled = True
                            tbFax_o.Enabled = True
                            tbTelm_o.Enabled = True
                            tbTel3_o.Enabled = True
                            tbTel2_o.Enabled = True
                            tbTel1_o.Enabled = True
                            tbZip_o.Enabled = True
                            ddCnt_o.Enabled = True
                            ddProv_o.Enabled = True
                    End Select
                Else
                    Select Case strUpd
                        Case "PV_C01"
                            ddFirst.Enabled = False
                            tbFirst.Enabled = False
                            tbName.Enabled = False
                            tbSname.Enabled = False
                        Case "PV_C02"
                            ddHType.Enabled = False
                            ddStatus.Enabled = False
                        Case "PV_C03"
                            tbBthDay.Enabled = False
                            ddNatCode.Enabled = False
                            ddOccCode.Enabled = False
                        Case "PV_C04"
                            ddRefType.Enabled = False
                            tbRefno.Enabled = False
                            tbTaxid.Enabled = False
                        Case "PV_C05"
                            tbEmail.Enabled = False
                        Case "PV_A01"
                            tbAmphur_h.Enabled = False
                            tbTambon_h.Enabled = False
                            tbRoad_h.Enabled = False
                            tbSoi_h.Enabled = False
                            tbTower_h.Enabled = False
                            tbMoo_h.Enabled = False
                            tbhouse_h.Enabled = False
                            tbFax_h.Enabled = False
                            tbTelm_h.Enabled = False
                            tbTel3_h.Enabled = False
                            tbTel2_h.Enabled = False
                            tbTel1_h.Enabled = False
                            tbZip_h.Enabled = False
                            ddCnt_h.Enabled = False
                            ddProv_h.Enabled = False
                        Case "PV_A02"
                            tbAmphur_o.Enabled = False
                            tbTambon_o.Enabled = False
                            tbRoad_o.Enabled = False
                            tbSoi_o.Enabled = False
                            tbTower_o.Enabled = False
                            tbMoo_o.Enabled = False
                            tbHouse_o.Enabled = False
                            tbDept.Enabled = False
                            tbPos.Enabled = False
                            tbFax_o.Enabled = False
                            tbTelm_o.Enabled = False
                            tbTel3_o.Enabled = False
                            tbTel2_o.Enabled = False
                            tbTel1_o.Enabled = False
                            tbZip_o.Enabled = False
                            ddCnt_o.Enabled = False
                            ddProv_o.Enabled = False
                    End Select
                End If
            Next

            If strChk = "T" Then
                btSave.Enabled = True
                cblSelect.Enabled = False
                GetSelect()
            Else
                btSave.Enabled = False
                cblSelect.Enabled = True
            End If
        Else
            lbMsg.Text = "*** ��س��к������١��� ***"
        End If
    End Sub

    Sub GetSelect()
        Dim HashS As New Hashtable
        Dim Item As ListItem
        Dim strUpd As String
        Dim i As Integer

        For Each Item In cblSelect.Items
            strUpd = Item.Value
            If Item.Selected Then
                i += 1
                HashS.Add(i, strUpd)
            End If
        Next
        ddSelect_Hide.DataSource = HashS
        ddSelect_Hide.DataTextField = "value"
        ddSelect_Hide.DataValueField = "value"
        ddSelect_Hide.DataBind()

    End Sub

End Class
