Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Public Class Mydata2
    Dim strcon As String = _
     " server=202.57.163.153;uid=nassetfund;pwd=webnasset01;database=nassetfund"
    ' "server=Nasset2;uid=sa;pwd=;database=web"
    ' 
    Public Function GetDataset(ByVal strsql As String) As DataSet
        Dim DA As New SqlDataAdapter(strsql, strcon)
        Dim ds As New DataSet()
        DA.Fill(ds)
        Return ds
    End Function

    Public Function GetConnection() As SqlConnection
        Dim cn As New SqlConnection(strcon)
        cn.Open()
        Return cn
    End Function

    Public Function FillMoreTable(ByVal ds As DataSet, ByVal strsql As String, ByVal tbName As String) As DataSet
        Dim da As New SqlDataAdapter(strsql, strcon) ' OleDbDataAdapter(strsql, strcon)
        da.Fill(ds, tbName)
        Return ds
    End Function

    Public Function Execute(ByVal strsql As String) As Integer
        Dim cn As New SqlConnection(strcon) ' OleDbConnection(strcon)
        Dim cmd As New SqlCommand(strsql, cn) ' OleDbCommand(strsql, cn)
        cn.Open()
        Dim Y As Integer = cmd.ExecuteNonQuery
        cn.Close()
        cn = Nothing
        cmd = Nothing
        Return Y
    End Function

End Class

' ��Ѻ App private 
Public Class MyData
    Dim Strcon As String = System.Configuration.ConfigurationSettings.AppSettings.Get("ConnectionString")
    
    '*** use for my com
    '** Dim Strcon As String = "Provider=MSDAORA;Password=pvf2003;User ID=pv;Data Source=NassetDB;Persist Security Info=True"

    '*Dim Strcon As String = "Provider=MSDAORA;Password=pvf2003;User ID=pv;Data Source=testDB;Persist Security Info=True"

    '*** use for new DB connection
    'Dim Strcon As String = "Provider=MSDAORA.1;Password=pvf2003;User ID=pv;Data Source=NEWDB;Persist Security Info=True"

    '***  use for nassetintra
    'Dim Strcon As String = "Provider=oraoledb.oracle;Data Source=ORAWEB;User id=pv;Password=pvf2003;oledb.net=true;"
    'Dim Strcon As String = "Provider=oraoledb.oracle;Data Source=NASSETDB;User id=pv;Password=pvf2003;oledb.net=true;"

    ' Dim Strcon As String = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
    '       "data source=c:\inetpub\wwwroot\aspnet02\nwind.mdb"


    Public Function GetDataset(ByVal strsql As String) As DataSet
        Dim DA As New OleDbDataAdapter(strsql, Strcon)
        Dim ds As New DataSet
        DA.Fill(ds)
        Return ds
    End Function

    Public Function FillMoreTable(ByVal ds As DataSet, _
        ByVal strsql As String, ByVal tbName As String) _
        As DataSet
        Dim da As New OleDbDataAdapter(strsql, Strcon)
        da.Fill(ds, tbName)
        Return ds
    End Function

    Public Function Execute(ByVal strsql As String) As Integer
        Dim cn As New OleDbConnection(Strcon)
        Dim cmd As New OleDbCommand(strsql, cn)

        'Try
        cn.Open()
        Dim Y As Integer = cmd.ExecuteNonQuery
        cn.Close()
        cn = Nothing
        cmd = Nothing
        Return Y

        ' Public Function Execute(ByVal strsql As String) As Integer
        '    Dim trTrn As OleDbTransaction
        '    Dim cn As New OleDbConnection(Strcon)
        '    Dim cmd As New OleDbCommand(strsql, cn)
        '    cn.Open()
        '    '   trTrn = cn.BeginTransaction(IsolationLevel.ReadCommitted)

        '    Dim Y As Integer
        '    Try
        '        Y = cmd.ExecuteNonQuery
        '        '      trTrn.Commit()
        '    Catch ex As Exception
        '        trTrn.Rollback()
        '    End Try

        '    cn.Close()
        '    cn = Nothing
        '    cmd = Nothing
        '    Return Y
        ' *******
        'Dim cn As New OleDbConnection(Strcon)
        'Dim cmd As New OleDbCommand(strsql, cn)

        ''Try
        'cn.Open()
        'Dim Y As Integer = cmd.ExecuteNonQuery
        'cn.Close()
        'cn = Nothing
        'cmd = Nothing
        'Return Y
        ''Catch e As OleDbException
        ''    Dim errorMessages As String
        ''    Dim i As Integer

        ''    For i = 0 To e.Errors.Count - 1
        ''        errorMessages += "Index #" & i.ToString() & ControlChars.Cr _
        ''                       & "Message: " & e.Errors(i).Message & ControlChars.Cr _
        ''                       & "NativeError: " & e.Errors(i).NativeError & ControlChars.Cr _
        ''                       & "Source: " & e.Errors(i).Source & ControlChars.Cr _
        ''                       & "SQLState: " & e.Errors(i).SQLState & ControlChars.Cr
        ''    Next i
        ''    Return errorMessages
        ''Dim log As System.Diagnostics.EventLog = New System.Diagnostics.EventLog()
        ''log.Source = "My Application"
        ''log.WriteEntry(errorMessages)
        ''Console.WriteLine("An exception occurred. Please contact your system administrator.")
        ''End Try
    End Function

    Public Function GetConnection() As OleDbConnection
        Dim cn As New OleDbConnection(Strcon)
        cn.Open()
        Return cn
    End Function
End Class

Public Class MyData_Nasset 'no use
    '*** use for new DB connection
    '    Dim Strcon As String = "Provider=MSDAORA.1;Password=pvf2003;User ID=pv;Data Source=NEWDB;Persist Security Info=True"

    '*** previous connection
    Dim Strcon As String = "Provider=MSDAORA.1;Password=pvf2003;User ID=pv;Data Source=NassetPV;Persist Security Info=True"
    ' Dim Strcon As String = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
    '       "data source=c:\inetpub\wwwroot\aspnet02\nwind.mdb"
    Public Function GetDataset(ByVal strsql As String) As DataSet
        Dim DA As New OleDbDataAdapter(strsql, Strcon)
        Dim ds As New DataSet
        DA.Fill(ds)
        Return ds
    End Function

    Public Function FillMoreTable(ByVal ds As DataSet, _
        ByVal strsql As String, ByVal tbName As String) _
        As DataSet
        Dim da As New OleDbDataAdapter(strsql, Strcon)
        da.Fill(ds, tbName)
        Return ds
    End Function

    Public Function Execute(ByVal strsql As String) _
       As Integer
        Dim cn As New OleDbConnection(Strcon)
        Dim cmd As New OleDbCommand(strsql, cn)

        'Try
        cn.Open()
        Dim Y As Integer = cmd.ExecuteNonQuery
        cn.Close()
        cn = Nothing
        cmd = Nothing
        Return Y

    End Function

    Public Function GetConnection() As OleDbConnection
        Dim cn As New OleDbConnection(Strcon)
        cn.Open()
        Return cn
    End Function
End Class

Public Class MyData_web 'no use 
    'Dim Strcon As String = "Provider=MSDAORA.1;Password=webadmin;User ID=web;Data Source=NassetWeb;Persist Security Info=True"
    Dim Strcon As String = "Provider=oraoledb.oracle;Data Source=NASSETDB;User id=pv;Password=pvf2003;oledb.net=true;"

    ' Dim Strcon As String = "Provider=MSDAORA.1;Password=webadmin;User ID=web;Data Source=testDBweb;Persist Security Info=True"

    ' Dim Strcon As String = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
    '       "data source=c:\inetpub\wwwroot\aspnet02\nwind.mdb"
    Public Function GetDataset(ByVal strsql As String) As DataSet
        Dim DA As New OleDbDataAdapter(strsql, Strcon)
        Dim ds As New DataSet
        DA.Fill(ds)
        Return ds
    End Function

    Public Function FillMoreTable(ByVal ds As DataSet, _
        ByVal strsql As String, ByVal tbName As String) _
        As DataSet
        Dim da As New OleDbDataAdapter(strsql, Strcon)
        da.Fill(ds, tbName)
        Return ds
    End Function

    Public Function Execute(ByVal strsql As String) _
       As Integer
        Dim cn As New OleDbConnection(Strcon)
        Dim cmd As New OleDbCommand(strsql, cn)
        cn.Open()
        Dim Y As Integer = cmd.ExecuteNonQuery
        cn.Close()
        cn = Nothing
        cmd = Nothing
        Return Y
    End Function

    Public Function GetConnection() As OleDbConnection
        Dim cn As New OleDbConnection(Strcon)
        cn.Open()
        Return cn
    End Function
End Class

