Public Class pvf_mas_fundremk
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents rdlUpd As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents imgSave As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents ddFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents chbFund As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents tbR1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbR2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents lbRemk01 As System.Web.UI.WebControls.Label
    Protected WithEvents lbRemk02 As System.Web.UI.WebControls.Label
    Protected WithEvents cbRemk01 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbRemk02 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lbErr As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strsql As String
    Dim ds As New DataSet
    Dim m1 As New MyData
    Dim mc As New ClassCheckUser
    Dim dv As DataView

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "mas_fundremk") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                imgSave.Enabled = False
                Exit Sub
            End If

            SetInit()
            rdlUpd.SelectedIndex = 0
            ddFund.Items.Insert(0, "�ä�кءͧ�ع")
            ddFund.SelectedIndex = 0
        End If
    End Sub
    Sub SetInit()
        strsql = "select fund,fund_tname||' ( '||fund||' )' fund_tname from pv.v_fund where class_code='P' order by fund_tname"
        ds = m1.GetDataset(strsql)
        ddFund.DataSource = ds
        ddFund.DataTextField = "fund_tname"
        ddFund.DataValueField = "fund"

        strsql = "select fund,fund_tname||' ( '||fund||' )' fund_tname from pv.v_fund where class_code='P' order by fund"
        ds = m1.GetDataset(strsql)
        chbFund.DataSource = ds
        chbFund.DataTextField = "fund"
        chbFund.DataValueField = "fund"

        Me.DataBind()

    End Sub

    Function fChkData(ByVal strFund As String, ByVal strRCode As String)
        strsql = " select fund,remk_code,remk_desc,remk_flg  from pvrfundremk " & _
                        " where fund = '" & strFund & "' and remk_code = '" & strRCode & "' "
        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView
        If dv.Count > 0 Then
            Return 1
        Else
            Return 0
        End If

    End Function
    Private Sub rdlUpd_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlUpd.SelectedIndexChanged
        If rdlUpd.SelectedItem.Value = "add" Then
            ddFund.Enabled = False
            chbFund.Enabled = True
        Else
            ddFund.Enabled = True
            chbFund.Enabled = False
        End If
        ddFund.SelectedIndex = 0
        lbErr.Text = ""
        'tbR1.Text = ""
        'tbR2.Text = ""
    End Sub

    Private Sub ddFund_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddFund.SelectedIndexChanged
        tbR1.Text = ""
        tbR2.Text = ""
        lbErr.Text = ""

        strsql = " select fund,remk_code,remk_desc,remk_flg  from pvrfundremk " & _
                 " where fund = '" & ddFund.SelectedItem.Value & "' "
        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView
        If dv.Count > 0 Then
            Dim dt As DataTable = ds.Tables(0)
            Dim dr As DataRow = dt.Rows(0)
            For Each dr In dt.Rows
                If dr("remk_code") = "01" Then
                    tbR1.Text = dr("remk_desc")
                    If dr("remk_flg") = "T" Then
                        cbRemk01.Checked = True
                    Else
                        cbRemk01.Checked = False
                    End If
                Else
                    tbR2.Text = dr("remk_desc")
                    If dr("remk_flg") = "T" Then
                        cbRemk02.Checked = True
                    Else
                        cbRemk02.Checked = False
                    End If

                End If
            Next
        Else
            lbErr.Text = "**** �ѧ����բ����� �����˵� ����Ѻ�ͧ�ع��� ��س����������š�͹ "
        End If
    End Sub

    Private Sub imgSave_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgSave.Click
        Dim strFund As String
        Dim strRCode, strRDesc, strRFlg As String
        Dim strRCode2, strRDesc2, strRFlg2 As String
        Dim i As Integer

        If rdlUpd.SelectedItem.Value = "add" Then
            Dim Item As ListItem
            For Each Item In chbFund.Items
                If Item.Selected Then
                    strFund = Item.Text
                    Try
                        For i = 0 To 1
                            strRFlg = "F"
                            If i = 0 Then
                                ' remk 1 
                                strRCode = "01"
                                strRDesc = Trim(tbR1.Text)
                                If cbRemk01.Checked Then
                                    strRFlg = "T"
                                End If
                            Else
                                ' remk 2 
                                strRCode = "02"
                                strRDesc = Trim(tbR2.Text)
                                If cbRemk02.Checked Then
                                    strRFlg = "T"
                                End If
                            End If

                            If fChkData(strFund, strRCode) = 1 Then   ' update
                                strsql = "update pv.pvrfundremk set remk_desc = '" & strRDesc & "' , " & _
                                               "remk_flg = '" & strRFlg & "' , " & _
                                               "upd_by = '" & Session("user_id") & "',upd_date = sysdate " & _
                                         "where fund = '" & strFund & "' " & _
                                         "and remk_code ='" & strRCode & "'"
                            Else   ' insert
                                strsql = "insert into pv.pvrfundremk (fund,remk_code,remk_desc,remk_flg ,upd_by,upd_date ) " & _
                                        " values ('" & strFund & "','" & strRCode & "','" & strRDesc & "','" & strRFlg & "','" & Session("user_id") & "',sysdate )"
                            End If
                            m1.Execute(strsql)

                        Next
                    Catch x1 As Exception
                        lbMsg.Text &= x1.Message
                        lbMsg.Text &= strsql
                    End Try
                End If
            Next
        Else    ' update data
            strRCode = "01"
            strFund = ddFund.SelectedValue
            strRDesc = Trim(tbR1.Text)
            If cbRemk01.Checked Then
                strRFlg = "T"
            Else
                strRFlg = "F"
            End If

            If fChkData(strFund, strRCode) = 0 Then   ' not found
                lbErr.Text = "**** �ѧ����բ����� �����˵� ����Ѻ�ͧ�ع��� ��س����������š�͹ "
                Exit Sub
            End If
            strsql = "update pv.pvrfundremk set remk_desc = '" & strRDesc & "' , " & _
                                                "remk_flg = '" & strRFlg & "' , " & _
                                                "upd_by = '" & Session("user_id") & "',  " & _
                                                "upd_date = sysdate " & _
                                                "where fund = '" & strFund & "' " & _
                                                "and remk_code ='" & strRCode & "'"
            m1.Execute(strsql)
            'lbErr.Text = strsql

            strRCode = "02"
            strRDesc = Trim(tbR2.Text)
            If strRDesc <> "" Then
                If cbRemk02.Checked Then
                    strRFlg = "T"
                Else
                    strRFlg = "F"
                End If
                strsql = "update pv.pvrfundremk set remk_desc = '" & strRDesc & "' , " & _
                                                    "remk_flg = '" & strRFlg & "' , " & _
                                                    "upd_by = '" & Session("user_id") & "',  " & _
                                                    "upd_date = sysdate " & _
                                                    "where fund = '" & strFund & "' " & _
                                                    "and remk_code ='" & strRCode & "'"
                m1.Execute(strsql)

            End If
            '            lbErr.Text = lbErr.Text & " ======= " & strsql
        End If
        Response.Redirect("success.aspx?pagename=pvf_mas_fundremk.aspx")
    End Sub
End Class
