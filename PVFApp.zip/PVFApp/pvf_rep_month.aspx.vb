Imports System.IO
Imports System.Xml

Public Class pvf_rep_month
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strsql As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label16 As System.Web.UI.WebControls.Label
    Protected WithEvents Label17 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Dim Getdate As New ClassDate()
    Protected WithEvents Rep01 As System.Web.UI.WebControls.Repeater
    Dim ds2 As New DataSet()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            Session("prn_fund") = "'BUNRIT','SUPAPAN'"
            GetData()
        End If
    End Sub

    Sub GetData()
        'strsql = "select  fund,fund_tname, isnull(fund_ename ,' ') as fund_ename " & _
        '" from v_pvfund_web where fund  = '" & strFund & "'"

        strsql = "  SELECT V_PVFUND_WEB.FUND_TNAME fund_tname,   " & _
                       "   V_PVFUND_WEB.FUND_POLICY , " & _
                        " V_PVFUND_WEB.TYPE_DESC_T, " & _
                        " V_PVFUND_WEB.TRUSTEE_NAME , " & _
                        " V_PVFUND_WEB.REGIS_NAME , " & _
                        " V_PVFUND_WEB.FUND_TYPE , " & _
                        " nvl( V_PVFUND_WEB.FUND_AMT,0)  fund_amt, " & _
                        " nvl( V_PVFUND_WEB.SHARE_AMT,0) share_amt, " & _
                        " MKTG.MKTGPVFWEB.FUND, " & _
                        " MKTG.MKTGPVFWEB.TRANSDATE tran_date, " & _
                        " MKTG.MKTGPVFWEB.RTN_1M, " & _
                        " MKTG.MKTGPVFWEB.RTN_3M, " & _
                        " MKTG.MKTGPVFWEB.RTN_6M, " & _
                        " MKTG.MKTGPVFWEB.RTN_1Y, " & _
                        " MKTG.MKTGPVFWEB.RTN_SINCE, " & _
                        " MKTG.MKTGPVFWEB.BMK1_1M, " & _
                        " MKTG.MKTGPVFWEB.BMK1_3M, " & _
                        " MKTG.MKTGPVFWEB.BMK1_6M, " & _
                        " MKTG.MKTGPVFWEB.BMK1_1Y, " & _
                        " MKTG.MKTGPVFWEB.BMK1_SINCE, " & _
                        " MKTG.MKTGPVFWEB.BMK2_1M, " & _
                        " MKTG.MKTGPVFWEB.BMK2_3M, " & _
                        " MKTG.MKTGPVFWEB.BMK2_6M, " & _
                        " MKTG.MKTGPVFWEB.BMK2_1Y, " & _
                        " MKTG.MKTGPVFWEB.BMK2_SINCE, " & _
                        " rpad(MKTG.MKTGPVFWEB.POLICY_AIMC,2) policy_aimc, " & _
                        " MKTG.MKTGPVFWEB.NAV, " & _
                        " MKTG.MKTGPVFWEB.TNAV, " & _
                        " ' ' cp_tran_month , '' cp_tran_first, '' cp_tran_curr, '' cp_rmk01, '' cp_rmk02, '' cp_rmk03 ,'' cp_rep, '' cp_rep2, " & _
                        " 0 cp_firstamt, ' ' cp_dvmonth, '' cp_dvdate , 0 cp_dvamt  " & _
                        "    FROM MKTG.MKTGPVFWEB  ,     V_PVFUND_WEB  " & _
                        "  WHERE ( MKTG.MKTGPVFWEB.FUND = V_PVFUND_WEB.FUND )  and v_pvfund_web.fund in (" & Session("prn_fund") & ")"
        lbMsg.Text = strsql

        ds = m1.GetDataset(strsql)
        Dim dcc As Integer = ds.Tables(0).Rows.Count
        If dcc <= 0 Then
            lbMsg.Text = strsql
            Exit Sub
        End If

        Dim dr As DataRow = ds.Tables(0).Rows(0)

        Dim strDate, strTmonth, strYear, strCur, strFirst As String
        Dim strFile, strFile2, strFund As String

        For Each dr In ds.Tables(0).Rows
            strDate = dr("tran_date")
            strTmonth = Getdate.GetThaiLongMonthName(CType(dr("tran_date"), Date).Month)
            dr("cp_tran_month") = strTmonth & " " & Right(strDate, 4) + 543          'Left(strDateR, 2)
            strYear = Year(strDate) + 543
            dr("cp_tran_curr") = Day(strDate) & " " & strTmonth & " " & strYear         'Left(strDateR, 2)  �ѹ���ŧ�ع�Ѩ�غѹ

            strFund = dr("fund")
            ' ***** ���ŧ�ع������á
            strsql = "select  nvl(share_amt,0) share_amt , trn_date " & _
                            " from v_pvmtran_web  where fund  = '" & strFund & "' and trn_date = " & _
                            " (select min(trn_date) from v_pvmtran_web  where fund = '" & strFund & "' and trn_type = 'SB' )"

            ds2 = m1.GetDataset(strsql)
            Dim dc As Integer = ds2.Tables(0).Rows.Count
            If dc > 0 Then
                Dim dr1 As DataRow = ds2.Tables(0).Rows(0)
                dr("cp_firstamt") = dr1("share_amt")    ' �Թŧ�ع�����á
                strDate = dr1("trn_date")
                strTmonth = Getdate.GetThaiLongMonthName(CType(dr1("trn_date"), Date).Month)
                strYear = Year(strDate) + 543
                dr("cp_tran_first") = Day(strDate) & "  " & strTmonth & " " & strYear   ' �ѹ���ŧ�ع�����á
            End If

            ' ***** ��è��¤׹�š���
            strsql = "select  nvl(share_amt,0) share_amt , trn_date " & _
                            " from v_pvmtran_web  where fund  = '" & strFund & "' and trn_date = " & _
                            " (select min(trn_date) from v_pvmtran_web  where fund = '" & strFund & "' and trn_type = 'DV' )"

            ds2 = m1.GetDataset(strsql)
            Dim dc2 As Integer = ds2.Tables(0).Rows.Count
            If dc2 > 0 Then
                Dim dr1 As DataRow = ds2.Tables(0).Rows(0)
                dr("cp_dvamt") = dr1("share_amt")    ' ���÷����
                strDate = dr1("trn_date")
                strTmonth = Getdate.GetThaiLongMonthName(CType(dr1("trn_date"), Date).Month)
                strYear = Year(strDate) + 543
                dr("cp_dvdate") = Day(strDate) & "  " & strTmonth & " " & strYear   ' �ѹ���ŧ�ع�����á
                dr("cp_dvmonth") = strTmonth & " " & Right(strYear, 2)
            Else
                dr("cp_dvmonth") = "-"
                dr("cp_dvdate") = "-"
            End If

            Select Case dr("fund_type")
                Case "EQ"   ' equity
                    dr("cp_rmk01") = ""
                    dr("cp_rmk02") = ""
                    strFund = "masEQ_" & Month(Now) & Year(Now) + 543
                Case "BL"   ' balance
                    dr("cp_rmk01") = "(2) �ӹǳ�ҡ�Ѫ�� �Ѫ���Ҥҵ�Ҵ������˹�� ( TBDC Government Bond Index ) "
                    dr("cp_rmk01") &= "��дѪ���ѵ�Ҵ͡�����Թ�ҡ�ͧ��Ҥ�� ( �ӹǳ�ҡ�ѵ�Ҵ͡�����Թ�ҡ��Ш� 1 �� ����¢ͧ �.��ا෾ �.��ԡ��� ��� �.�¾ҳԪ�� )  ��Ѵ��ǹ�����ҡѹ"
                    dr("cp_rmk02") = "(3) �ӹǳ�ҡ�ѵ�Ҵ͡�����Թ�ҡ��Ш� 1 ������¢ͧ �.��ا෾ �.��ԡ��� ��� �.�¾ҳԪ��"
                    strFund = "masBL_" & Month(Now) & Year(Now) + 543
                Case Else    ' GF = fixed income
                    dr("cp_rmk01") = "(2) �ӹǳ�ҡ �Ѫ���Ҥҵ�Ҵ������˹�� ( TBDC Government Bond Index ) "
                    dr("cp_rmk01") &= "��дѪ���ѵ�Ҵ͡�����Թ�ҡ�ͧ��Ҥ�� ( �ӹǳ�ҡ�ѵ�Ҵ͡�����Թ�ҡ��Ш� 1 �� ����¢ͧ �.��ا෾ �.��ԡ��� ��� �.�¾ҳԪ�� ) �¶�ǧ���˹ѡ�����º�¡��ŧ�ع�ͧ�ͧ�ع"
                    dr("cp_rmk02") = "(3) �ӹǳ�ҡ�Ѫ�յ�Ҵ��ѡ��Ѿ����觻��������дѪ���ѵ�Ҵ͡�����Թ�ҡ�ͧ��Ҥ��"
                    dr("cp_rmk02") &= "( �ӹǳ�ҡ�ѵ�Ҵ͡�����Թ�ҡ��Ш� 1 ������� �ͧ �.��ا෾ �.��ԡ��� ��� �.�¾ҳԪ�� ) ��Ѵ��ǹ�����ҡѹ"
                    strFund = "masGF_" & Month(Now) & Year(Now) + 543
            End Select


            Dim xmlDataSet As New DataSet()
            ' ***************** News by Type  " EQ,GF, BL" *********************
            strFile = Server.MapPath("XML/" & strFund & ".xml")
            '  Response.Write(" by manager " & strFile)
            If File.Exists(strFile) Then
                xmlDataSet.ReadXml(strFile)
                Dim dr2 As DataRow = xmlDataSet.Tables(0).Rows(0)

                dr("cp_rep") = " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News1")
                If Len(dr2("News2")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News2")
                If Len(dr2("News3")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News3")
                If Len(dr2("News4")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News4")
                If Len(dr2("News5")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News5")
                If Len(dr2("News6")) > 0 Then dr("cp_rep") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr2("News6")

            End If

            Dim xmlDataSet2 As New DataSet()
            ' ***************** News by Fund *********************
            strFund = dr("fund") & "_" & Month(Now) & Year(Now) + 543
            strFile2 = Server.MapPath("XML/" & strFund & ".xml")
            ' Response.Write(" by fund " & strFile2)
            If File.Exists(strFile2) Then
                xmlDataSet2.ReadXml(strFile2)
                Dim dr3 As DataRow = xmlDataSet2.Tables(0).Rows(0)
                '   Response.Write(dr3("News1"))
                dr("cp_rep2") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr3("News1")
                If Len(dr3("News2")) > 0 Then dr("cp_rep2") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr3("News2")
                If Len(dr3("News3")) > 0 Then dr("cp_rep2") &= " <br>&nbsp;&nbsp;&nbsp;&nbsp; " & dr3("News3")
            End If
            '  dr("cp_rep") &= strFund
        Next

        Rep01.DataSource = ds
        Rep01.DataBind()
        'lbMsg.Text = strsql

    End Sub

    Sub GetXML()
        Dim xmlDataSet As New DataSet()
        xmlDataSet.ReadXml(Server.MapPath("testxml.xml"))
        'DG1.DataSource = xmlDataSet
        'DG1.DataBind()
        Dim dr As DataRow = xmlDataSet.Tables(0).Rows(0)
        Dim strNews
        strNews = Mid(dr("News"), 2, Len(dr("News")) - 2)    ' �Ѵ " ' "   �͡�ҡ��ͤ��� ��Ƿ���
        '    tbNews.Text = strNews

    End Sub

End Class
