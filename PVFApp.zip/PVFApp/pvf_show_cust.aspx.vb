Public Class pvf_show_cust
    Inherits System.Web.UI.Page


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim dv As DataView
    Dim strsql As String
    Dim strWhere As String
    Dim m1 As New MyData()
    Dim ds As DataSet
    Public Runno As Integer

    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents tbCond1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents rdlCond As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents IbtSeach As System.Web.UI.WebControls.ImageButton
    Protected WithEvents tbCond2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents imgCal1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents myCalendar As PopUpCalendar
    Protected WithEvents imgCal2 As System.Web.UI.WebControls.ImageButton
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            myCalendar.hideCalendar()
            If mc.CheckUser(Session("user_id"), "inq_cust") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                IbtSeach.Enabled = False
                Exit Sub
            End If
            strWhere = "where to_char(first_date,'dd/mm/yyyy') = to_char(sysdate,'dd/mm/yyyy') "
            Me.MyDataBind(strWhere)
            lbMsg.Text = ""
        Else
            dv = Session("data")
        End If
    End Sub

    Sub MyDataBind(ByVal strWhere As String)
        strsql = "select  cis_no,name,surname, ref_no,tax_id,to_char(first_date,'dd/mm/yyyy') first_date ," & _
                       "upd_by,to_char(upd_date,'dd/mm/yyyy hh24:mi') upd_date " & _
                       " from pv.pvmcust  " & strWhere & _
                       " order by cis_no"          'from pv.v_private_cust
        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView
        Me.MyRefresh()
        Session("data") = dv
        If ds.Tables(0).Rows.Count < 1 Then
            lbMsg.Text = "*** ����բ����� ������ ***"
        Else
            lbMsg.Text = " �ӹǹ�����ŷ���� = " & ds.Tables(0).Rows.Count & " ��¡�� "
        End If

        'lbMsg.Text = strsql
    End Sub

    Sub MyRefresh()
        DataGrid1.DataSource = dv
        DataGrid1.DataBind()
    End Sub

    Private Sub DataGrid1_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles DataGrid1.PageIndexChanged
        DataGrid1.CurrentPageIndex = e.NewPageIndex
        Me.MyRefresh()
    End Sub

    Private Sub DataGrid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged
        Dim x1 As String = DataGrid1.DataKeys(DataGrid1.SelectedIndex)
        Dim j As Integer = DataGrid1.SelectedIndex
        Dim dr As DataRow = dv.Table.Rows(j)   'ds.Tables(0).Rows(j) 

        Dim strCisno As String = DataGrid1.SelectedItem.Cells(0).Text   ' Get from Hidden column
        Response.Redirect("pvf_show_cust_desc.aspx?cis_no=" & strCisno)

        'Dim strUserName As String = DataGrid1.SelectedItem.Cells(2).Text
        'Dim strUserSname As String = DataGrid1.SelectedItem.Cells(3).Text
        'Dim strLogin As String = DataGrid1.SelectedItem.Cells(4).Text
        'Dim strPwd As String = DataGrid1.SelectedItem.Cells(5).Text
        'Dim strPos As String = DataGrid1.SelectedItem.Cells(6).Text
        'Dim strAgent As String = DataGrid1.SelectedItem.Cells(7).Text
        'Dim strLevel As String = DataGrid1.SelectedItem.Cells(8).Text

        'Session("ChkUpd") = "T"
        'Response.Redirect("web_upd_user.aspx?user_id=" & strUserID & "&user_name=" & strUserName & _
        '"&user_sname=" & strUserSname & "&user_login=" & strLogin & "&user_pwd=" & strPwd & _
        '"&user_position=" & strPos & "&agent_bran=" & strAgent & "&level_id=" & strLevel & "")

        'DG1.Attributes.Add("style", "display:")
        '  Me.MyDataBind_DG1(strUserID)
        'strsql = "select * from webmlevel "
        'ds2 = m1.GetDataset(strsql)
    End Sub

    Private Sub DataGrid1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DataGrid1.SortCommand
        If UCase(viewstate("field")) = UCase(e.SortExpression) Then
            If viewstate("direction") = "ASC" Then
                viewstate("direction") = "Desc"
            Else
                viewstate("direction") = "ASC"
            End If
        Else
            viewstate("field") = e.SortExpression
            viewstate("direction") = "ASC"
        End If

        dv.Sort = viewstate("field") & " " & viewstate("direction")
        DataGrid1.CurrentPageIndex = 0
        Me.MyRefresh()
    End Sub

    Private Sub rdlCond_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlCond.SelectedIndexChanged
        Select Case rdlCond.SelectedItem.Value
            Case "fdate"
                tbCond2.Visible = True
                Label2.Visible = True
                Label3.Visible = True
                Label2.Text = " �֧ "
                imgCal1.Visible = True
                imgCal2.Visible = True
            Case "name"
                tbCond2.Visible = True
                Label2.Visible = True
                Label2.Text = " ʡ�� "
                Label3.Visible = False
                Label1.Text = "���ͷ����� : "
                imgCal1.Visible = False
                imgCal2.Visible = False
            Case "cisno"
                tbCond2.Visible = False
                Label2.Visible = False
                Label1.Text = "���� : "
                imgCal1.Visible = False
                imgCal2.Visible = False
            Case "refno"
                tbCond2.Visible = False
                Label2.Visible = False
                Label1.Text = "�Ţ��� : "
                imgCal1.Visible = False
                imgCal2.Visible = False
        End Select
        tbCond1.Text = ""
        tbCond2.Text = ""
    End Sub

    Private Sub IbtSeach_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles IbtSeach.Click
        Select Case rdlCond.SelectedItem.Value
            Case "fdate"
                Dim strCond1, strCond2 As String
                'If IsDate(tbCond1.Text) And IsDate(tbCond1.Text) Then  ' check mm/dd/yyyy
                strCond1 = Right(tbCond1.Text, 4) & Mid(tbCond1.Text, 4, 2) & Left(tbCond1.Text, 2)
                strCond2 = Right(tbCond2.Text, 4) & Mid(tbCond2.Text, 4, 2) & Left(tbCond2.Text, 2)
                'Else
                '    Exit Sub
                'End If
                strWhere = "where to_char(first_date,'yyyymmdd') between '" & strCond1 & "' And  '" & strCond2 & "'"
            Case "name"
                strWhere = "where name like '" & tbCond1.Text & "%' and surname like '" & tbCond2.Text & "%'"
            Case "cisno"
                strWhere = "where cis_no = '" & tbCond1.Text & "'"
            Case "refno"
                strWhere = "where ref_no = '" & tbCond1.Text & "'"
        End Select

        Me.MyDataBind(strWhere)

    End Sub

    Private Sub tbCond1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbCond1.TextChanged
        Select Case rdlCond.SelectedItem.Value
            Case "cisno"
                If Not IsNumeric(tbCond1.Text) Then
                    lbMsg.Text = "*** ��س����������繵���Ţ ***"
                    Exit Sub
                End If
                tbCond1.Text = Right("0000000000" + tbCond1.Text, 10)
        End Select
    End Sub

    Private Sub imgCal1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgCal1.Click
        Dim dSelDate As Date

        If IsDate(tbCond1.Text) Then
            dSelDate = tbCond1.Text
        End If
        myCalendar.displayCalendar("Select a start date", dSelDate, "tbCond1", 130, 355)
    End Sub

    Private Sub imgCal2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgCal2.Click
        Dim dSelDate As Date

        If IsDate(tbCond2.Text) Then
            dSelDate = tbCond2.Text
        End If
        myCalendar.displayCalendar("Select an end date", dSelDate, "tbCond2", 130, 510)
    End Sub

    Private Sub DataGride1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DataGrid1.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

End Class
