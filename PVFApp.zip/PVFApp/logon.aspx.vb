Public Class logon
    Inherits System.Web.UI.Page
    Protected WithEvents CompareValidator1 As System.Web.UI.WebControls.CompareValidator
    Protected WithEvents tblogin As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbpwd As System.Web.UI.WebControls.TextBox
    Protected WithEvents lberr As System.Web.UI.WebControls.Label
    Protected WithEvents RequiredFieldValidator1 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents img_logout As System.Web.UI.WebControls.ImageButton
    Protected WithEvents btlogin As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strsql As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            '   Dim m1 As New Mydata2()
            '  Dim strsql As String
            ' strsql = "select * from webuser "
            'Dim ds As New DataSet()
            'ds = m1.GetDataset(strsql)

        End If
    End Sub

    Private Sub btlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btlogin.Click
        Dim strPwd, strPwd2 As String
        Dim i As Integer
        Dim strFlg, strDecrp, strAgent, strLevel, strUserId As String
        lberr.Text = ""

        strsql = "select user_login,  user_pwd,user_id, agent_bran, nvl( level_id ,'') level_id from web.webmuser " & _
                        " where  user_login = '" & tblogin.Text & "' and user_status = 'A' "
        ds = m1.GetDataset(strsql)
        Try
            DataGrid1.DataSource = ds
            DataGrid1.DataBind()

            Dim dc As Integer = ds.Tables(0).Rows.Count
            If dc > 0 Then

                Dim dt As DataTable = ds.Tables(0)
                Dim dr As DataRow = dt.Rows(i)
                For Each dr In dt.Rows
                    strUserId = Trim(dr("user_id"))
                    strPwd2 = Trim(dr("user_pwd"))
                    strDecrp = Decrypt(strPwd2)
                    If tbpwd.Text <> strDecrp Then
                        strFlg = "F"
                    Else
                        strAgent = Trim(dr("agent_bran"))
                        strFlg = "T"
                        Exit For
                    End If
                Next

                strLevel = Trim(dr("level_id"))

                'lberr.Text = "test1- " & strFlg
            Else
                lberr.Text = "����ժ��ͼ������к� ��سҵ�Ǩ�ͺ"
                Exit Sub
            End If

            'lberr.Text &= "test 2 - " & strFlg
            'Exit Sub

            If strFlg = "F" Then
                lberr.Text = "���ʼ�������١��ͧ ��سҵ�Ǩ�ͺ"
            ElseIf strFlg = "T" Then
                Dim mc As New ClassCheckUser
                'lberr.Text &= mc.CheckApp(tblogin.Text, "PVFNet")
                If mc.CheckApp(strUserId, "PVFApp") = "F" Then
                    lberr.Text = "�س������Է�� ����¡�� ��� "
                Else
                    Session("user_id") = strUserId 'tblogin.Text
                    Session("agent_code") = strAgent

                    If Session("user_id") <> "6196" Then
                        AddLog()
                    End If

                    If strLevel = "01" And Request.QueryString("chkadm") = "T" Then
                        '   Response.Redirect("web_show_user.aspx")
                    Else
                        Response.Redirect("pvf_add_fund.aspx")
                    End If

                End If
                '  lberr.Text = Request.QueryString("chkadm")
                End If
        Catch x1 As Exception
            lberr.Text = "xxx " & strsql
        End Try
    End Sub

    Sub AddLog()
        Dim dbNo As Double

        strsql = "select nvl(max(seq),0) seq  from pv.pvmlog "
        ds = m1.GetDataset(strsql)
        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            dbNo = dr("seq") + 1
        End If

        strsql = "insert into pv.pvmlog (seq,user_id ) " & _
                               " values ('" & dbNo & "','" & Session("user_id") & "') "
        m1.Execute(strsql)

        Try
            'lberr.Text = "test add log"
        Catch x As Exception
            lberr.Text = "error add log"
        End Try
    End Sub

    Function Decrypt(ByVal strPwd As String) As String
        If strPwd = "" Then
            Return ""
        End If
        Dim P2, P3, P4 As String
        Dim i, j As Integer
        Dim SecKey As String = "712431971507607"
        For i = 1 To strPwd.Length
            P3 = Val(SecKey.Substring(i - 1, 1))
            P2 &= Chr(Asc(strPwd.Substring(i - 1, 1)) - P3)
        Next
        Return P2
    End Function

    Private Sub img_logout_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles img_logout.Click
        Session("user_id") = ""
        Session("agent_code") = ""
        Response.Redirect("http://nassetintra/nasnet/wbappmain.aspx")
    End Sub
End Class
