Imports System.Web.Mail

Public Class pvf_add_order
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Panel3 As System.Web.UI.WebControls.Panel
    Protected WithEvents Panel4 As System.Web.UI.WebControls.Panel
    Dim strsql As String
    Dim mc As New ClassCheckUser()
    Protected WithEvents lbFund As System.Web.UI.WebControls.Label
    Protected WithEvents lbNav As System.Web.UI.WebControls.Label
    Protected WithEvents lbMsg2 As System.Web.UI.WebControls.Label
    Protected WithEvents rdlOrder As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents ddFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDy As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lbholder As System.Web.UI.WebControls.Label
    Protected WithEvents tbAmount As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbUnitA As System.Web.UI.WebControls.Label
    Protected WithEvents tbMoney As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbDiv As System.Web.UI.WebControls.Label
    Protected WithEvents tbDvUnit As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTotal As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbUnitT As System.Web.UI.WebControls.Label
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents btCancel As System.Web.UI.WebControls.Button
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents tbCisno As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbName As System.Web.UI.WebControls.Label
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents tbNewNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel
    Protected WithEvents lkChgPay As System.Web.UI.WebControls.LinkButton
    Protected WithEvents rdlChkPay As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents Panel5 As System.Web.UI.WebControls.Panel
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents tbPayOth As System.Web.UI.WebControls.TextBox
    Protected WithEvents Panel6 As System.Web.UI.WebControls.Panel
    Dim dv As DataView

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            Panel2.Attributes.Add("style", "display:none")
            Panel3.Attributes.Add("style", "display:none")
            Panel5.Attributes.Add("style", "display:none")
            Panel6.Attributes.Add("style", "display:none")

            If mc.CheckUser(Session("user_id"), "trn_order") = "F" Then
                lbMsg2.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                Exit Sub
            End If

            strsql = "select fund,fund_tname,(fund||' --  '|| fund_tname )  fund_name from pv.v_fund where class_code='P' order by fund"
            ds = m1.GetDataset(strsql)
            ddFund.DataSource = ds
            ddFund.DataTextField = "fund_name"
            ddFund.DataValueField = "fund"

            'ddBkCode.DataSource = ds                ' for accout bank
            'ddBkCode.DataTextField = "bk_name"
            'ddBkCode.DataValueField = "bk_code"

            'strsql = "select * from sas.sasmobj "
            'ds = m1.GetDataset(strsql)

            'ddExctype.DataSource = ds
            'ddExctype.DataTextField = "obj_desc"
            'ddExctype.DataValueField = "obj_id"

            'strsql = "select * from sas.sasmordertype order by order_type "
            'ds = m1.GetDataset(strsql)

            'ddOrdType.DataSource = ds
            'ddOrdType.DataTextField = "description"
            'ddOrdType.DataValueField = "order_type"

            Me.GetDate()
            '     Me.DataBind()
            ddFund.Items.Insert(0, "�ä�кءͧ�ع")
            ddFund.SelectedIndex = 0

            'ddFund.Items.Add("*** �ä�к� ***")
            'ddFund.SelectedIndex = ddFund.Items.Count - 1
            rdlOrder.SelectedIndex = 0

            'Else
            '   ds = Session("data")
        End If
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strFund As String = ddFund.SelectedItem.Value
        Dim strTrnDate As String = GetTrnDate() '& " " & Now.ToString("HH:mm:ss")
        Dim dbMoney, dbAmount, dbUnit, dbDvUnit As Double
        Dim strOrd As String = rdlOrder.SelectedItem.Value
        Dim c_date As String = Now.ToString("dd/MM/yyyy HH:mm:ss")  ' date from client 
        Dim strFlg, strNewNo, strYear As String
        Dim mc As New Class_RunNo()
        Dim dbBal As Double

        Dim dbNav As Decimal = CType(lbNav.Text, Decimal)
        If dbNav = 0 Then
            lbMsg.Text = "����� NAV ��سҵ�Ǩ�ͺ"
            Exit Sub
        End If

        ''' ***** Check IPO , Gen Order No
        'strsql = "select fund,flg_new from cis.opncontl where fund = '" & strFund & "'"
        'ds = m1.GetDataset(strsql)
        'Dim dr As DataRow = ds.Tables(0).Rows(0)
        'strFlgNew = dr("flg_new")
        'If strFlgNew = "Y" Then
        '    strNewNo = mc.GetIPO(strFund)
        'Else   
        'End If
        'strNewNo = 1

        strYear = ddDy.SelectedItem.Value
        lbMsg.Text = strFund & "=" & Session("agent_code") & "=" & strTrnDate & "=" & strOrd
        strNewNo = mc.GetOrdno("0000000000", strFund, Session("agent_code"), strYear, strOrd)
        strNewNo = Right("00000000" + strNewNo, 8)
        tbNewNo.Text = strNewNo

        If tbMoney.Text = "" Then
            tbMoney.Text = "0"
        End If

        strFlg = rdlOrder.SelectedItem.Value
        dbMoney = CType(tbMoney.Text, Double)     ' �ӹǹ����-���
        dbAmount = CType(tbAmount.Text, Decimal)  ' �ӹǹ�Թ¡��
        dbUnit = CType(lbUnitA.Text, Decimal)   ' �ӹǹ˹���¡��
        If rdlOrder.SelectedItem.Value = "DV" Then
            If Not IsNumeric(tbDvUnit.Text) Then
                lbMsg.Text = "*** ��س��������żŻ���ª����˹����繵���Ţ ***"
                Exit Sub
            End If
            dbDvUnit = CType(tbDvUnit.Text, Decimal) ' ���. ���˹���
        End If

        If dbMoney <= 0 Then
            lbMsg.Text = "��س����ӹǹ�Թ"
            Exit Sub
        End If

        strsql = "insert into pv.pvmtran(trn_no,fund,share_amt,trn_type, trn_date,share_amt_bf,share_unit_bf,upd_by,upd_date,nav,trn_flg,trn_alot, dv_unit ) " & _
                       " values ('" & strNewNo & "','" & strFund & "'," & dbMoney & ",'" & strFlg & "',to_date('" & strTrnDate & "','dd/mm/yyyy')," & _
                       dbAmount & "," & dbUnit & ", '" & Session("user_id") & "',sysdate," & lbNav.Text & ",'P','N' ," & _
                       dbDvUnit & ") "

        m1.Execute(strsql)
        Try
            If strFlg <> "SB" Then
                Dim i, iRun As Integer
                Dim strAcctName, strAcctNo, strAcctType, strBkcode, strBkbran, strAmt, strSeqno As String

                If rdlChkPay.SelectedValue = "N" Then   ' ����кغѭ��
                    iRun = 1
                    strAcctName = tbPayOth.Text
                    strsql = "insert into pv.pvmpay (fund,trn_no,run_no,rec_flg,acct_name,acct_no,acct_type,bk_code,bk_bran,amount,seq_no,upd_by ) " & _
                                           " values ('" & strFund & "','" & strNewNo & "','" & iRun & "','N','" & strAcctName & "','" & strAcctNo & "','" & _
                                           strAcctType & "','" & strBkcode & "','" & strBkbran & "'," & dbBal & ",'" & strSeqno & "','" & Session("user_id") & "' )"

                    m1.Execute(strsql)
                    ' lbMsg.Text &= strAmt & " -- "  'strAcctNo & " ---- " & strAcctName
                    Try
                        lbMsg.Text &= "�ѹ�֡������  ���º����"
                    Catch x1 As Exception
                        lbMsg.Text = x1.Message
                    End Try
                Else   ' �кغѭ��

                    Dim dgi As DataGridItem

                    For Each dgi In DG1.Items
                        i += 1
                        Dim cb As CheckBox = dgi.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
                        ' Dim txb As TextBox = dgi.Cells(7).Controls(0)

                        'Dim xx As Label = dgi.Cells(2).Controls(0)
                        ' Dim x As Integer = dgi.DataSetIndex

                        If cb.Checked Then
                            strAcctNo = DG1.DataKeys(dgi.ItemIndex)

                            'strAmt = txb.Text
                            '   strAcctName = CType(DataBinder.Eval(dgi.DataItem, "acct_name"), String) 'dgi.Cells(3).Text
                            '  strAcctName = CType(dgi.Cells(2).Controls(0), Label).Text
                            '  strAcctName = CType(dgi.FindControl("acct_name"), Label).Text
                            'strAcctName = DG1.Items(dgi.ItemIndex).Cells(3).Text.ToString    Ẻ�����ҹ�� ���ͧ set visible field = false ??
                            ' �ѧ���Ը���ҹ�����Ũҡ Datagrid �µç����� ��ͧ�ӡ�� Select �������������� ᷹��͹  -----
                            strsql = " select fund,rec_flg,acct_name,acct_no,acct_type,bk_code,bk_bran, seq_no " & _
                                     " from pv.fundacct " & _
                                     " where fund = '" & strFund & "' and acct_no = '" & strAcctNo & "'"
                            ds = m1.GetDataset(strsql)
                            Dim dr As DataRow = ds.Tables(0).Rows(0)
                            strAcctName = dr("acct_name")
                            strAcctType = dr("acct_type")
                            strBkcode = dr("bk_code")
                            strBkbran = dr("bk_bran")
                            strSeqno = dr("seq_no")
                            iRun += 1

                            strsql = "insert into pv.pvmpay (fund,trn_no,run_no,rec_flg,acct_name,acct_no,acct_type,bk_code,bk_bran,amount,seq_no,upd_by ) " & _
                           " values ('" & strFund & "','" & strNewNo & "','" & iRun & "','TR','" & strAcctName & "','" & strAcctNo & "','" & _
                           strAcctType & "','" & strBkcode & "','" & strBkbran & "'," & dbBal & ",'" & strSeqno & "','" & Session("user_id") & "' )"

                            m1.Execute(strsql)
                            ' lbMsg.Text &= strAmt & " -- "  'strAcctNo & " ---- " & strAcctName
                            Try
                                lbMsg.Text &= "�ѹ�֡������  ���º����"
                            Catch x1 As Exception
                                lbMsg.Text = x1.Message
                            End Try
                        End If
                    Next
                End If
            End If
            '���ŧ history ���������¡�� ������ŧ�͹ ��䢢����� update order
            'strsql = "insert into pv.pvhtran(trn_no,fund,share_amt,trn_type, trn_date,upd_by,upd_date,nav ) " & _
            '          " values ('" & strNewNo & "','" & strFund & "'," & dbMoney & ",'" & strFlg & "',to_date('" & strTrnDate & "','dd/mm/yyyy HH24:MI:SS')," & _
            '          ", '" & Session("user_id") & "',to_date('" & c_date & "','dd/mm/yyyy HH24:MI:SS')," & lbNav.Text & " ) "
            ''   lbMsg.Text = strsql

            lbMsg.Text &= "*** �ѹ�֡���������º�������� ***"
        Catch x1 As Exception
            lbMsg.Text &= x1.Message
            lbMsg.Text &= strsql
        End Try
        ' SendMail_New(strFund, strFlg)  ' ��觵͹ approve ��¡��
        Panel1.Attributes.Add("style", "display:none")
        Panel3.Attributes.Add("style", "display:none")
        Panel5.Attributes.Add("style", "display:none")
        Panel6.Attributes.Add("style", "display:none")
        Panel2.Attributes.Add("style", "display:")
    End Sub

    Sub SendMail(ByVal strFund As String, ByVal strType As String)
        'Dim Send As New nassetintra.MailService
        Dim Send As New PVFApp.sendmail.MailService

        Dim chk As Integer
        Dim strFrom, strTo, strSubject, strBody, strFormat As String

        strFrom = "pvfund@thanachartfund.com"
        '** read from table pvmrefmisc
        'strTo = "harutais@thanachartfund.com;" & _
        '        "vallapas@thanachartfund.com;pitsudaa@thanachartfund.com;" & _
        '        "ornanongn@thanachartfund.com;teerayutl@thanachartfund.com;" & _
        '        "kanokwana@thanachartfund.com;duangjait@thanachartfund.com;" & _
        '        "vipasirik@thanachartfund.com;amphonk@thanachartfund.com"
        'Response.Write(" before : " & strTo)

        strsql = " select pvref_misc1, pvref_misc2 " & _
                 " from pv.pvmrefmisc " & _
                 " where pvref_code = 'MAILTO' "
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)
        strTo = dr("pvref_misc1") & dr("pvref_misc2")      
        ' strTo = "harutais@thanachartfund.com"

        strSubject = "*****You have new Private Fund Order."
        strBody = "Please Check by PVF Web Application. ******  FUND CODE ::  " & strFund & "  (" & strType & ")"

        'Response.Write(" after : " & strTo & "   " & strBody)

        Try          
            send.SendMail(strFrom, strTo, strSubject, strBody, "text")
        Catch x1 As Exception
            lbMsg.Text = x1.Message
        End Try
        'chk = Send.SendMail(strFrom, strTo, strSubject, strBody, "text")

        ' Response.Write(chk)

    End Sub

    Sub SendMail_New(ByVal strFund As String, ByVal strType As String)
        '** Replace web service sendmail because WS not support since move to new server 2012
        '** Modify date : 08 Feb 2013

        Dim myMail As New MailMessage

        Dim chk As Integer
        Dim strFrom, strTo, strSubject, strBody, strFormat As String

        strFrom = "pvfund@thanachartfund.com"
        '** read from table pvmrefmisc
        strsql = " select pvref_misc1, pvref_misc2 " & _
                 " from pv.pvmrefmisc " & _
                 " where pvref_code = 'MAILTO' "
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)
        '*** strTo = dr("pvref_misc1") & dr("pvref_misc2")  ' ���������ҡ�Ѻ��
        strTo = "harutais@thanachartfund.com"   ' ����Ѻ���ͺ

        strSubject = "*****You have new Private Fund Order."
        strBody = "Please Check by PVF Web Application. ******  FUND CODE ::  " & strFund & "  (" & strType & ")"

        'Response.Write(" after : " & strTo & "   " & strBody)

        Try
            myMail.To = strTo
            myMail.From = strFrom
            myMail.Subject = strSubject
            myMail.Body = strBody

            SmtpMail.SmtpServer = System.Configuration.ConfigurationSettings.AppSettings.Get("SMTPServer")

            ' Response.Write("SmtpMail ....  " & SmtpMail.SmtpServer.ToString)

            SmtpMail.Send(myMail)
            myMail = Nothing
        Catch x1 As Exception
            lbMsg.Text = x1.Message
        End Try

    End Sub

    Private Sub tbMoney_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbMoney.TextChanged

        If IsNumeric(tbMoney.Text) Then
            Dim dbMoney As Double = CType(tbMoney.Text, Double)
            lbMsg.Text = ""
            If CType(tbMoney.Text, Double) Then
                tbMoney.Text = CType(tbMoney.Text, Double).ToString("##,###,##0.00")
                'If ChkMinMax(dbMoney) = "F" Then   ' �礢�鹵��
                '    btSave.Enabled = False
                'Else
                Dim dbTotal, dbAmt As Double
                dbTotal = GetUnit()
                dbAmt = GetAmt()
                If dbTotal = -1 Then
                    lbMsg.Text = "�������ö�ӹǳ�����ͧ�ҡ NAV �����"
                    Exit Sub
                End If
                Select Case rdlOrder.SelectedItem.Value
                    Case "SB", "RD", "CD" ' Sell
                        tbTotal.Text = dbAmt.ToString("##,###,##0.00")
                        lbUnitT.Text = dbTotal.ToString("##,###,##0.0000")
                    Case "DV"
                        tbTotal.Text = tbAmount.Text
                        lbUnitT.Text = lbUnitA.Text
                End Select
                btSave.Enabled = True
                'End If
            End If
        Else
            lbMsg.Text = "*** �ä�кبӹǹ�繵���Ţ ***"
            tbMoney.Text = ""
        End If
    End Sub

    Function GetTrnDate() As String
        Dim strtrndate As String
        strtrndate = ddDd.SelectedItem.Value & "/" & ddDm.SelectedItem.Value & "/" & ddDy.SelectedItem.Value - 543
        Return strtrndate
    End Function

    Private Sub GetDate()
        Dim c_date As Date = Now
        Dim str_cur As String

        str_cur = c_date.Day

        Dim i As Integer
        For i = 1 To 31
            ddDd.Items.Add(i)
        Next

        ddDd.SelectedIndex = str_cur - 1

        strsql = "select * from web. webmonth"
        ds = m1.GetDataset(strsql)
        ddDm.DataSource = ds
        ddDm.DataTextField = "mth_t_name"
        ddDm.DataValueField = "mth_code"

        Dim yy(2) As String '= {"2547", "2548"}
        'ddDy.DataSource = yy
        str_cur = c_date.Year + 543
        For i = 1 To 2
            yy(i) = str_cur
            ddDy.Items.Add(yy(i))
            str_cur += 1
        Next

        'str_cur = c_date.Year + 543
        'lbmsg.Text = str_cur
        'dddy.SelectedIndex = str_cur
        Me.DataBind()

        str_cur = c_date.Month
        ddDm.SelectedIndex = str_cur - 1

        '           Dim m2 As Class_GetDate
        '       Dim ddd As DropDownList = dddd.NamingContainer
        '            m2.Getday("dddd")
    End Sub

    Function GetUnit() As Double
        Dim dbTotal As Double
        Dim dbAmt As Double = CType(tbAmount.Text, Double)
        Dim dbMoney As Double = CType(tbMoney.Text, Double)
        Dim dbNav As Decimal = CType(lbNav.Text, Decimal)

        If dbNav <= 0 Then
            Return -1
        End If

        dbTotal = dbMoney / dbNav
        Select Case rdlOrder.SelectedItem.Value
            Case "SB"
                dbTotal = CType(lbUnitA.Text, Double) + dbTotal
            Case "RD", "CD"
                dbTotal = CType(lbUnitA.Text, Double) - dbTotal
            Case "DV"
                dbTotal = CType(lbUnitA.Text, Double) - dbTotal
        End Select
        '     lbmsg.Text = dbNavB & "=" & dbNavS & "=" & dbTotal
        Return dbTotal

    End Function

    Function GetAmt() As Double
        Dim dbTotal As Double
        Dim dbAmt As Double = CType(tbAmount.Text, Double)
        Dim dbMoney As Double = CType(tbMoney.Text, Double)
        Dim dbNav As Decimal = CType(lbNav.Text, Decimal)

        Select Case rdlOrder.SelectedItem.Value
            Case "SB"
                dbTotal = dbAmt + dbMoney
            Case "RD", "CD"
                dbTotal = dbAmt - dbMoney
            Case "DV"
                dbTotal = dbAmt
        End Select
        '     lbmsg.Text = dbNavB & "=" & dbNavS & "=" & dbTotal
        Return dbTotal

    End Function

    Function ChkMinMax(ByVal dbMoney As Double) As String
        Dim dbTotal As Double
        Dim dbAmt As Double = CType(tbAmount.Text, Double)
        Dim dbBuyNext As Integer
        Dim dbSellMin As Integer
        Dim dbMin As Integer

        strsql = " select nvl(buy_next_bath,0) buy_next_bath,nvl(sell_min_bath,0) sell_min_bath,nvl(min_bath,0) min_bath from pv.fundcontl " & _
                        " where fund = '" & ddFund.SelectedItem.Value & "'"
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)
        dbBuyNext = dr("buy_next_bath")
        dbSellMin = dr("sell_min_bath")
        dbMin = dr("min_bath")
        tbTotal.Text = ""
        lbUnitT.Text = ""

        Select Case rdlOrder.SelectedItem.Value
            Case "RD"   ' Sell
                If dbMoney < dbSellMin Then
                    lbMsg.Text = "***  �ӹǹ������Ŵ�ع ��ͧ�ҡ���Ң�鹵�ӷ���˹� (" & dbSellMin & ") ***"
                    Return "F"
                End If
                dbTotal = dbAmt - dbMoney
                If dbTotal <= 0 Then
                    lbMsg.Text = "*** �ӹǹ�Թ������� <= 0        ��سҵ�Ǩ�ͺ ***"
                    Return ("F")
                ElseIf dbTotal < dbMin Then
                    lbMsg.Text = "*** �ӹǹ�Թ������� ��ͧ�ҡ���Ң�鹵��㹡���ѡ�Һѭ�� " & dbMin & "  ��سҵ�Ǩ�ͺ ***"
                    Return ("F")
                End If
            Case "DV"  ' Div
                dbTotal = dbAmt
            Case "SB"    'Buy
                If dbMoney < dbBuyNext Then
                    lbMsg.Text = "***  �ӹǹ�����������ع ��ͧ�ҡ���Ң�鹵�ӷ���˹� (" & dbBuyNext & ") ***"
                    Return "F"
                End If
                dbTotal = dbAmt + dbMoney
        End Select

        tbTotal.Text = dbTotal.ToString("##,###,##0.00")
        Return ("T")
    End Function

    Private Sub btCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btCancel.Click
        'tbFund.Text = ""
        tbAmount.Text = ""
        tbMoney.Text = ""
        tbTotal.Text = ""
        lbUnitA.Text = ""
        lbUnitT.Text = ""
    End Sub

    Private Sub ddFund_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddFund.SelectedIndexChanged
        Dim strFund As String = ddFund.SelectedItem.Value
        lbMsg.Text = ""
        tbMoney.Text = ""
        'strsql = " select share_uni,nvl(share_amt,0) share_amt  from cis.opnmhold where cis_no = '" & tbCisno.Text & "' and " & _
        '                " fund_code = '" & strFund & "'"
        strsql = " select nvl(share_unit,0) share_unit,nvl(share_amt,0) share_amt  from pv.fundcontl where fund = '" & strFund & "' "
        ds = m1.GetDataset(strsql)
        Try
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            tbAmount.Text = CType(dr("share_amt"), Double).ToString("##,###,###,##0.00")
            lbUnitA.Text = CType(dr("share_unit"), Double).ToString("#,###,###,##0.0000")

            ' **** ����ͧ�ӹǳ�����ʴ��Ż���ª�����١�����
            ' ****** Get NAV ****
            strsql = " select  fund_code, data_date, nvl(nav,0) nav from warndba.v_mis_nav_current " & _
                             " where fund_code = '" & ddFund.SelectedItem.Value & "' and data_date =  " & _
                             " (select max(data_date) from warndba.v_mis_nav_current where fund_code = '" & ddFund.SelectedItem.Value & "')"
            '   ��� select �ҡ  warndba.v_mis_nav_current  ����¹�� cis.v_mis_nav_current �� ����� ��� synonym ���� user cis ��� replicate �ҡ NassetDB 
            ds = m1.GetDataset(strsql)
            lbFund.Text = ddFund.SelectedItem.Value
            Try
                Dim dbNav As Double

                dr = ds.Tables(0).Rows(0)
                dbNav = dr("nav")
                lbNav.Text = dbNav
                'tbFund.Text = strFund
                '     ' **** ����ͧ�ʴ�
                '     'If rdlOrder.SelectedItem.Value = "DV" Then
                '     '    Dim dbDiv As Double
                '     '    Dim dbDivT As Double
                '     '    Dim dbAmt As Double = CType(tbAmount.Text, Double)
                '     '    dbDiv = CType(lbUnitA.Text, Double) * dbNav      ' �ӹǳ���Թ�ع�ط��
                '     '    dbDivT = dbDiv - dbAmt
                '     '    ' lbMsg.Text = "dbDiv " & dbDiv & " == " & dbAmt
                '     '    lbDiv.Text = "�š�����ǹ�Թ�ع = " & dbDivT.ToString("##,###,##0.00") & " �ҷ"
                '     'End If

            Catch x1 As Exception
                lbNav.Text = "10.0000"
                lbMsg.Text = " ����բ����� NAV �ͧ�ͧ�ع��� ��سҵ�Ǩ�ͺ "
                'Exit Sub
            End Try

            If rdlOrder.SelectedItem.Value <> "SB" Then      ' �����ع
                GetAcct(strFund)     ' ���͡�͹��Һѭ�������Ѻ�Թ ���Ŵ�ع/�Ż���ª��
            End If

            btSave.Enabled = True
            lbMsg.Text &= ""

        Catch x1 As Exception
            lbMsg.Text = " *** ��س����͡�ͧ�ع ***"
            'lbMsg.Text &= strsql
            tbAmount.Text = "0.00"
            lbNav.Text = "0.0000"
            btSave.Enabled = False
        End Try
        tbMoney.Text = "0.00"
        tbTotal.Text = "0.00"
        lbUnitT.Text = "0.0000"

    End Sub

    Private Sub rdlOrder_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlOrder.SelectedIndexChanged
        tbAmount.Text = ""
        tbMoney.Text = ""
        tbTotal.Text = ""
        lbUnitA.Text = ""
        lbUnitT.Text = ""
        lbDiv.Text = ""
        tbDvUnit.Text = "0"
        ddFund.SelectedIndex = 0

        If rdlOrder.SelectedItem.Value = "DV" Then
            tbDvUnit.Enabled = True
            tbDvUnit.BackColor = Color.White
        Else
            tbDvUnit.Enabled = False
            tbDvUnit.BackColor = Color.Linen
        End If
        Panel3.Attributes.Add("style", "display:none")
        Panel5.Attributes.Add("style", "display:none")
        Panel6.Attributes.Add("style", "display:none")
        rdlChkPay.SelectedIndex = 0
    End Sub

    Private Sub ddDm_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim strdm As String
        strdm = ddDm.SelectedItem.Value
        Dim getdm As String = DateTime.DaysInMonth(DateTime.Now.Year.ToString, strdm) ' return days in month
        If ddDd.SelectedItem.Value > getdm Then
            lbMsg.Text &= "��͹����� " & getdm & " �ѹ "
        Else
            lbMsg.Text = ""
        End If
    End Sub

    Private Sub GetAcct(ByVal strFund As String)
        'strsql = "select  seq_no,fund,rec_flg,acct_name,acct_no,acct_type,bk_code,bk_bran,'' type_desc, '' bk_desc, '' br_desc " & _
        '                      " from pv.fundacct " & _
        '                     " where fund = '" & strFund & "' "
        Panel3.Attributes.Add("style", "display:")
        Panel6.Attributes.Add("style", "display:")
        Panel5.Attributes.Add("style", "display:none")
        rdlChkPay.SelectedIndex = 0

        ' select ��Ҥ�������ش �ҡ����Ѻ�Թ��������ش� pvmpay ���繤�� default
        strsql = "SELECT p.FUND , p.TRN_NO,  p.BK_CODE,  p.BK_BRAN ,'' acct_flg, p.rec_flg,0 share_amt, " & _
                        "  OPNMBANK_A.BK_NAME bk_name,OPNMBANK_B.BK_NAME br_name,  " & _
                        "   p.ACCT_NAME, p.ACCT_NO, p.ACCT_TYPE " & _
                        "    FROM CIS.OPNMBANK OPNMBANK_A , PVMPAY p,   CIS.OPNMBANK  OPNMBANK_B  " & _
                        "    WHERE ( p.BK_CODE = OPNMBANK_A.BK_CODE  ) and " & _
                        "    ( p.BK_CODE = OPNMBANK_B.BK_CODE ) and " & _
                        "     (p.BK_BRAN = OPNMBANK_B.BK_BRAN ) and   " & _
                        "    ( (OPNMBANK_A.BK_BRAN = 'XXX' ) )   and " & _
                        "     p.Fund = '" & strFund & "' and p.trn_no = (select max(trn_no) from pvmpay where fund = '" & strFund & "') "
        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView
        If dv.Count > 0 Then
            DG1.DataSource = dv  '.Tables(0).DefaultView
            Session("data") = dv
            lbMsg.Text = ""
            btSave.Enabled = True

        Else  ' �ó�����դ������ش ���֧��Ҩҡ fundacct ����˹�������ʴ�
            strsql = " SELECT FUNDACCT.FUND fund,  FUNDACCT.BK_CODE,  FUNDACCT.BK_BRAN , " & _
                "OPNMBANK_A.BK_NAME bk_name,OPNMBANK_B.BK_NAME br_name, FUNDACCT.SEQ_NO, " & _
                "FUNDACCT.ACCT_FLG acct_flg,  FUNDACCT.REC_FLG rec_flg, FUNDACCT.ACCT_NAME acct_name,  " & _
                "FUNDACCT.ACCT_NO acct_no, FUNDACCT.ACCT_TYPE acct_type , 0 share_amt " & _
                "FROM CIS.OPNMBANK OPNMBANK_A , FUNDACCT,   CIS.OPNMBANK  OPNMBANK_B " & _
                "WHERE ( FUNDACCT.BK_CODE = OPNMBANK_A.BK_CODE  ) and  " & _
                "( FUNDACCT.BK_CODE = OPNMBANK_B.BK_CODE ) and  " & _
                "(FUNDACCT.BK_BRAN = OPNMBANK_B.BK_BRAN ) and  " & _
                "( (OPNMBANK_A.BK_BRAN = 'XXX' ) )   and  " & _
                "FUNDACCT.Fund = '" & strFund & "' and fundacct.acct_status = 'A' "
            ds = m1.GetDataset(strsql)
            dv = ds.Tables(0).DefaultView

            If dv.Count > 0 Then
                DG1.DataSource = dv  '.Tables(0).DefaultView
                Session("data") = dv
                '              lbMsg.Text = ""
                btSave.Enabled = True
            Else
                lbMsg.Text = "*** ����բ����� ����Ѻ�Թ�Ż���ª�� ***"
                btSave.Enabled = False
                DG1.DataSource = ds
                Session("data") = ds
            End If

        End If
        'lbMsg.Text = strsql

        DG1.DataBind()
    End Sub

    Private Sub DG1_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)
        'Dim tbAcctFlg As String = e.Item.Cells(0).Text

        '' Dim drv As DataRowView = e.Item.DataItem
        ''  strFlg = drv("acct_flg")
        ''strFlg = e.Item.Cells(0).Controls(0)
        'Dim strFlg As String = CType(DataBinder.Eval(e.Item.DataItem, "acct_flg"), String)
        'Dim dgi As DataGridItem
        'Dim cb As CheckBox = dgi.Cells(1).Controls(1)

        'cb.Checked = True
        'If strFlg = "Y" Then           ' Default Account
        '    'Dim dgi As DataGridItem
        '    'Dim cb As CheckBox = dgi.Cells(1).Controls(1)
        '    'cb.Checked = True
        '    e.Item.Cells(2).ForeColor = Color.Gray
        '    e.Item.Cells(3).ForeColor = Color.Gray
        '    e.Item.Cells(4).ForeColor = Color.Gray
        '    e.Item.Cells(5).ForeColor = Color.Gray
        '    e.Item.Cells(6).ForeColor = Color.Gray
        'Else
        '    e.Item.Cells(2).ForeColor = Color.DarkBlue
        '    e.Item.Cells(3).ForeColor = Color.DarkBlue
        '    e.Item.Cells(4).ForeColor = Color.DarkBlue
        '    e.Item.Cells(5).ForeColor = Color.DarkBlue
        '    e.Item.Cells(6).ForeColor = Color.DarkBlue
        'End If

    End Sub

    Private Sub tbDvUnit_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Not IsNumeric(tbDvUnit.Text) Then
            lbMsg.Text = "*** ��س����������繵���Ţ ***"
        End If
    End Sub

    Private Sub DG1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemCreated
        If (e.Item.ItemType = ListItemType.Item) Or (e.Item.ItemType = ListItemType.AlternatingItem) Then
            'Dim dgi As DataGridItem
            'Dim cb As CheckBox = dgi.Cells(1).Controls(1)
            'cb.Checked = True
            '    AddCheckBox(e)
        End If
    End Sub

    Private Sub AddCheckBox(ByVal e As DataGridItemEventArgs)
        Dim cb As New CheckBox
        Dim cell As TableCell = e.Item.Cells(1)
        Dim dgi As DataGridItem
        cb.EnableViewState = True
        cb.AutoPostBack = True
        cb.ID = e.Item.ItemIndex
        cell.HorizontalAlign = HorizontalAlign.Right
        '        cb = CType(dgi.Cells(0).Controls(0), CheckBox)
        AddHandler cb.CheckedChanged, AddressOf OnCheckedChangedEvent
        cell.Controls.Add(cb)
    End Sub

    Private Sub OnCheckedChangedEvent(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim cb As CheckBox
        Dim dgi As DataGridItem

        For Each dgi In DG1.Items
            cb = CType(dgi.Cells(1).Controls(0), CheckBox)
            If cb.Checked Then
                DG1.EditItemIndex = cb.ID - 1
                Response.Write("nnn")
                'Else
                '    DG1.EditItemIndex = -1
                '    Response.Write("yyy")
            End If
        Next

        '     AddCheckBox(e)
        'doEdit()
    End Sub

    Sub doEdit(ByVal s As Object, ByVal e As DataGridCommandEventArgs)
        'Dim idx As Integer
        'idx = DG1.DataKeys(e.Item.ItemIndex)
        DG1.EditItemIndex = 0
    End Sub

    Sub MyRefresh()
        dv = Session("data")
        DG1.DataSource = dv  '.Tables(0).DefaultView
        DG1.DataBind()
    End Sub

    Private Sub DG1_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.EditCommand
        DG1.EditItemIndex = e.Item.ItemIndex
        Me.MyRefresh()
    End Sub

    Private Sub DG1_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.CancelCommand
        DG1.EditItemIndex = -1
        Me.MyRefresh()
    End Sub

    Private Sub DG1_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.UpdateCommand
        Dim strTrnNo As String
        Dim dbMoney As String
        Dim dgi As DataGridItem

        'strTrnNo = DG1.DataKeys(e.Item.ItemIndex)
        '        dbMoney = DG1.Items(e.Item.iItemIndex).Cells(6).Text
        ' dbMoney = e.Item.Cells(7).Text.ToString
        'Response.Write(dbMoney)

        Dim tbAmt As TextBox = CType(e.Item.Cells(7).Controls(0), TextBox)

        Dim dr As DataRow
        '        dr = dv.Table.Rows(e.Item.DataSetIndex)
        dr = ds.Tables(0).Rows(e.Item.DataSetIndex)
        '        dr("share_amt") = tbAmt.Text
        'dr = DG1.DataKeys(e.Item.ItemIndex)
        dr("share_amt") = tbAmt.Text

        '        DG1.EditItemIndex = -1
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'SendMail("FUND", "CHECK")
        SendMail_New("FUND", "CHECK")
        'Dim dgi As DataGridItem
        'Dim i, iRun As Integer
        'Dim strAcctName, strAcctNo, strAcctType, strBkcode, strBkbran, strAmt As String

        'For Each dgi In DG1.Items
        '    i += 1
        '    Dim cb As CheckBox = dgi.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
        '    Dim txb As TextBox = dgi.Cells(7).Controls(1)

        '    Dim CurrentTextBox As TextBox

        '    If cb.Checked Then
        '        strAmt = txb.Text
        '        lbMsg.Text = strAmt & " - "
        '        CurrentTextBox = dgi.Cells(7).Controls(0)
        '        Dim ColValue As String = CurrentTextBox.Text
        '        Response.Write(ColValue)
        '    End If
        'Next
    End Sub

    Private Sub lkChgPay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lkChgPay.Click
        Dim strFund As String
        strFund = ddFund.SelectedItem.Value

        strsql = " SELECT FUNDACCT.FUND fund,  FUNDACCT.BK_CODE,  FUNDACCT.BK_BRAN , " & _
               "OPNMBANK_A.BK_NAME bk_name,OPNMBANK_B.BK_NAME br_name, FUNDACCT.SEQ_NO, " & _
               "FUNDACCT.ACCT_FLG acct_flg,  FUNDACCT.REC_FLG rec_flg, FUNDACCT.ACCT_NAME acct_name,  " & _
               "FUNDACCT.ACCT_NO acct_no, FUNDACCT.ACCT_TYPE acct_type , 0 share_amt " & _
               "FROM CIS.OPNMBANK OPNMBANK_A , FUNDACCT,   CIS.OPNMBANK  OPNMBANK_B " & _
               "WHERE ( FUNDACCT.BK_CODE = OPNMBANK_A.BK_CODE  ) and  " & _
               "( FUNDACCT.BK_CODE = OPNMBANK_B.BK_CODE ) and  " & _
               "(FUNDACCT.BK_BRAN = OPNMBANK_B.BK_BRAN ) and  " & _
               "( (OPNMBANK_A.BK_BRAN = 'XXX' ) )   and  " & _
               "FUNDACCT.Fund = '" & strFund & "' and fundacct.acct_status = 'A' "
        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView

        If dv.Count > 0 Then
            DG1.DataSource = dv  '.Tables(0).DefaultView
            Session("data") = dv
            '              lbMsg.Text = ""
            btSave.Enabled = True
        Else
            lbMsg.Text = "*** ����բ����� ����Ѻ�Թ�Ż���ª�� ***"
            btSave.Enabled = False
            DG1.DataSource = ds
            Session("data") = ds
        End If
        DG1.DataBind()
    End Sub

    Private Sub rdlChkPay_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlChkPay.SelectedIndexChanged
        If rdlChkPay.SelectedValue = "TR" Then
            Panel3.Attributes.Add("style", "display:")
            Panel5.Attributes.Add("style", "display:none")
        Else
            Panel3.Attributes.Add("style", "display:none")
            Panel5.Attributes.Add("style", "display:")
        End If

    End Sub
End Class



'Private Sub tbCisno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbCisno.TextChanged
'    If Not IsNumeric(tbCisno.Text) Then
'        lbMsg.Text = "*** ��س����������繵���Ţ ***"
'        Exit Sub
'    End If

'    Dim dr As DataRow
'    lbMsg.Text = ""
'    tbCisno.Text = Right("0000000000" + tbCisno.Text, 10)
'    strsql = "select holder_id,first_name,name,surname from pv.v_private_cust where cis_no = '" & tbCisno.Text & "'"
'    ds = m1.GetDataset(strsql)
'    Try
'        dr = ds.Tables(0).Rows(0)
'        lbName.Text = dr("first_name") & " " & dr("name") & "  " & dr("surname")
'        lbholder.Text = dr("holder_id")
'        lbMsg.Text = ""

'    Catch x1 As Exception
'        '            lbmsg.Text = x1.Message
'        lbMsg.Text = "����բ������١��� 㹰ҹ������ �ͧ��·���¹ "
'        Exit Sub
'    End Try
'End Sub

