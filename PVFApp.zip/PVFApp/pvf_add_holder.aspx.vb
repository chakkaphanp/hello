Public Class pvf_add_holder
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents btCancel As System.Web.UI.WebControls.Button
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents tbName As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbCisno As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAccName As System.Web.UI.WebControls.TextBox
    Protected WithEvents rdlTaxtype As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents tbAccNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddAgent As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddAddrFlg As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddMkt As System.Web.UI.WebControls.DropDownList
    Protected WithEvents rdlBankFlg As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel
    Protected WithEvents tbNewNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddBkCode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkBran As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lberr As System.Web.UI.WebControls.Label
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Dim strsql As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            Panel2.Attributes.Add("style", "display:none")
            SetInit()
        Else
            Label1.Text = ""
            lberr.Text = ""
        End If
    End Sub

    Sub SetInit()
        Dim dt As DataTable
        Dim dr As DataRow

        'strsql = "select fund,fund_name||' ( '||fund||' )' fund_name from opncontl where class_code='P' order by fund_name"
        strsql = "select fund,fund_tname||' ( '||fund||' )' fund_tname from cis.v_fund where class_code='P' order by fund_tname"
        ds = m1.GetDataset(strsql)
        ddFund.DataSource = ds
        ddFund.DataTextField = "fund_tname"
        ddFund.DataValueField = "fund"

        strsql = "select bk_code,bk_name  from cis.opnmbank where bk_bran = 'XXX' order by bk_name"
        ds = m1.GetDataset(strsql)
        ddBkCode.DataSource = ds
        ddBkCode.DataTextField = "bk_name"
        ddBkCode.DataValueField = "bk_code"

        strsql = "select br_code,br_name  from cis.opnmagen where substr(br_code,4,6) = '000001' order by br_name "
        ds = m1.GetDataset(strsql)
        ddAgent.DataSource = ds
        ddAgent.DataTextField = "br_name"
        ddAgent.DataValueField = "br_code"

        strsql = "select sub_code,sub_desc  from cis.opnsubtype where sub_type = 'tax_type' order by sub_code "
        ds = m1.GetDataset(strsql)
        rdlTaxtype.DataSource = ds
        rdlTaxtype.DataTextField = "sub_desc"
        rdlTaxtype.DataValueField = "sub_code"

        strsql = "select sub_code,sub_desc  from cis.opnsubtype where sub_type = 'bank_flg' order by sub_code "
        ds = m1.GetDataset(strsql)
        rdlBankFlg.DataSource = ds
        rdlBankFlg.DataTextField = "sub_desc"
        rdlBankFlg.DataValueField = "sub_code"

        strsql = "select sub_code,sub_desc  from cis.opnsubtype where sub_type = 'addr_flg' order by sub_code "
        ds = m1.GetDataset(strsql)
        ddAddrFlg.DataSource = ds
        ddAddrFlg.DataTextField = "sub_desc"
        ddAddrFlg.DataValueField = "sub_code"

        rdlTaxtype.SelectedIndex = 0
        rdlBankFlg.SelectedIndex = 0
        Me.DataBind()

        ddFund.Items.Add("*** �ä�к� ***")
        ddFund.SelectedIndex = ddFund.Items.Count - 1
        ddBkCode.Items.Add("*** �ä�к� ***")
        ddBkCode.SelectedIndex = ddBkCode.Items.Count - 1
        ddAgent.Items.Add("*** �ä�к� ***")
        ddAgent.SelectedIndex = ddAgent.Items.Count - 1
        ddAddrFlg.Items.Add("*** �ä�к� ***")
        ddAddrFlg.SelectedIndex = ddAddrFlg.Items.Count - 1
    End Sub

    Function ChkBfSave() As String
        Dim strReturn As String
        If Len(tbCisno.Text) <= 0 Then
            strReturn = "F" + "��س���������١���"
        End If
        Return strReturn
    End Function

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strCisno As String = Right("0000000000" + tbCisno.Text, 10)
        Dim strHolder As String
        Dim strFcode As String = ddFund.SelectedItem.Value
        Dim mc As New Class_GenNo()
        Dim strChk As String

        If Len(tbCisno.Text) <= 0 Then
            Label1.Text = "��س���������١���"
            Exit Sub
        ElseIf ddFund.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� �ͧ�ع "
            Exit Sub
        ElseIf ddBkCode.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� ��Ҥ�� "
            Exit Sub
        ElseIf ddBkBran.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к��ҢҸ�Ҥ��"
            Exit Sub
        ElseIf ddAgent.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� ���᷹ "
            Exit Sub
        ElseIf ddMkt.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� Marketting "
            Exit Sub
        ElseIf ddAddrFlg.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� ʶҹ����Ѻ�͡��� "
            Exit Sub
        End If

        strsql = "select holder_id, fund_code from cis.opnmhold  where cis_no = '" & strCisno & "' and fund_code = '" & strFcode & "'"
        ds = m1.GetDataset(strsql)
        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            strHolder = dr("holder_id")
            Label1.Text = "�١�������¡�âͧ�ͧ�ع������� ��سҵ�Ǩ�ͺ ���� Holder = " & strHolder
            Exit Sub
        End If

        'strHolder = mc.GenHolder(strFcode)
        strHolder = "0000014"
        ' **** Insert into OpnmHold ****
        strsql = "insert into cis.opnmhold(cis_no,fund_code,holder_id,share_uni,ret_flg,ar_flg,upd_by,upd_date ," & _
                        "first_date,tax_type,bank_flg,bk_code,bk_bran,acct_no,acct_name,addr_flg," & _
                        "br_code,mkt_code,share_amt)" & _
                        "values ('" & strCisno & "','" & strFcode & "','" & strHolder & "',0,'0','N','" & _
                        Session("userid") & "',sysdate , sysdate,'" & rdlTaxtype.SelectedItem.Value & "','" & _
                        rdlBankFlg.SelectedItem.Value & "','" & ddBkCode.SelectedItem.Value & "','" & ddBkBran.SelectedItem.Value & "','" & _
                        tbAccNo.Text & "','" & tbAccName.Text & "','" & ddAddrFlg.SelectedItem.Value & "','" & _
                        ddAgent.SelectedItem.Value & "','" & ddMkt.SelectedItem.Value & "' ,0)"
        m1.Execute(strsql)
        Try

            strsql = "insert into cis.opnhhold(upd_flg,cis_no,fund_code,holder_id,share_uni,ret_flg,ar_flg,upd_by,upd_date ," & _
                      "first_date,tax_type,bank_flg,bk_code,bk_bran,acct_no,acct_name,addr_flg," & _
                      "br_code,mkt_code)" & _
                      "values (''NEW'," & strCisno & "','" & strFcode & "','" & strHolder & "',0,'0','N','" & _
                      Session("userid") & "',sysdate , sysdate,'" & rdlTaxtype.SelectedItem.Value & "','" & _
                      rdlBankFlg.SelectedItem.Value & "','" & ddBkCode.SelectedItem.Value & "','" & ddBkBran.SelectedItem.Value & "','" & _
                      tbAccNo.Text & "','" & tbAccName.Text & "','" & ddAddrFlg.SelectedItem.Value & "','" & _
                      ddAgent.SelectedItem.Value & "','" & ddMkt.SelectedItem.Value & "' )"
            m1.Execute(strsql)
            '            Label1.Text &= strsql
            Panel1.Attributes.Add("style", "display:none")
            Panel2.Attributes.Add("style", "display:")
            tbNewNo.Text = strHolder
        Catch x1 As Exception
            Label1.Text &= x1.Message
            Label1.Text &= strsql
        Finally
        End Try
    End Sub

    Private Sub ddBkCode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddBkCode.SelectedIndexChanged
        strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
                       " where bk_code ='" & ddBkCode.SelectedItem.Value & "' order by bk_name "
        ds = m1.GetDataset(strsql)
        ddBkBran.DataSource = ds
        ddBkBran.DataTextField = "bk_name"
        ddBkBran.DataValueField = "bk_bran"

        Me.DataBind()

        ddBkBran.Items.Add("*** �ä�к� ***")
        ddBkBran.SelectedIndex = ddBkBran.Items.Count - 1
    End Sub

    Private Sub ddAgent_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddAgent.SelectedIndexChanged
        Dim strAgent As String = Left(ddAgent.SelectedItem.Value, 3)
        Dim strBran As String = Right(ddAgent.SelectedItem.Value, 6)

        strsql = "select mkt_code,mkt_name  from cis.opnmmakt where  mkt_agen = '" & strAgent & "' " & _
                       "and mkt_branch = '" & strBran & "' order by mkt_name "

        ds = m1.GetDataset(strsql)
        ddMkt.DataSource = ds
        ddMkt.DataTextField = "mkt_name"
        ddMkt.DataValueField = "mkt_code"
        Me.DataBind()

        ddMkt.Items.Add("*** �ä�к� ***")
        ddMkt.SelectedIndex = ddMkt.Items.Count - 1
        'Label1.Text = strsql
    End Sub

    Private Sub tbCisno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbCisno.TextChanged
        lberr.Text = ""
        Dim strCisno As String

        strCisno = Right("0000000000" + tbCisno.Text, 10)
        strsql = "select  name||' '||surname name from cis.opnmcust  where cis_no = '" & strCisno & "' "
        ds = m1.GetDataset(strsql)
        Try
            Dim dc As Integer = ds.Tables(0).Rows.Count
            If dc > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                tbName.Text = dr("name")
            Else
                lberr.Text = "����բ����������١��ҹ�� ��سҵ�Ǩ�ͺ"
                Exit Sub
            End If
        Catch x1 As Exception
            lberr.Text = x1.Message
            lberr.Text &= strsql
        End Try
        tbCisno.Text = strCisno
    End Sub

    Private Sub ddAddrFlg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddAddrFlg.SelectedIndexChanged
        'Dim strAddrFlg As String = ddAddrFlg.SelectedItem.Value
        'Dim strAgent As String = Left(ddAgent.SelectedItem.Value, 3)
        'Dim strBran As String = Right(ddAgent.SelectedItem.Value, 6)

        'If strAddrFlg = "0" Then
        '    strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
        '                        " where bk_code ='" & ddBkCode.SelectedItem.Value & "' order by bk_name "
        '    ds = m1.GetDataset(strsql)
        '    ddSend.DataSource = ds
        '    ddSend.DataTextField = "bk_name"
        '    ddSend.DataValueField = "bk_bran"
        'ElseIf strAddrFlg = "2" Then
        '    strsql = "select mkt_code,mkt_name  from cis.opnmmakt where  mkt_agen = '" & strAgent & "' " & _
        '                     "and mkt_branch = '" & strBran & "' order by mkt_name "

        '    ds = m1.GetDataset(strsql)
        '    ddSend.DataSource = ds
        '    ddSend.DataTextField = "mkt_name"
        '    ddSend.DataValueField = "mkt_code"
        'Else


        'End If
        'Me.DataBind()
    End Sub

    Private Sub rdlBankFlg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlBankFlg.SelectedIndexChanged
        Select Case rdlBankFlg.SelectedItem.Value
            Case "0"
                ddBkCode.Enabled = False
                ddBkBran.Enabled = False
                tbAccNo.Enabled = False
                tbAccName.Enabled = False
                ddBkCode.BackColor = Color.WhiteSmoke
                ddBkBran.BackColor = Color.WhiteSmoke
                tbAccNo.BackColor = Color.WhiteSmoke
                tbAccName.BackColor = Color.WhiteSmoke
            Case Else
                ddBkCode.Enabled = True
                ddBkBran.Enabled = True
                tbAccNo.Enabled = True
                tbAccName.Enabled = True
                ddBkCode.BackColor = Color.White
                ddBkBran.BackColor = Color.White
                tbAccNo.BackColor = Color.White
                tbAccName.BackColor = Color.White
        End Select
    End Sub
End Class
