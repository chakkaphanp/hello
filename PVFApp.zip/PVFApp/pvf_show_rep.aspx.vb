Imports System.Web
Imports System.Xml
Imports CrystalDecisions
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.ReportSource

Public Class pvf_show_rep
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents CrystalReportViewer1 As CrystalDecisions.Web.CrystalReportViewer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Const strServerName As String = "NASSETDB"
    Private Const strUserID As String = "pv"
    Private Const strPassword As String = "pvf2003"

    'private report as New order
    Private arrayParameterName As New ArrayList
    Private arrayParameterValue As New ArrayList
    Private FType As String
    Private Cmonth As String
    Private Cyear As String
    Private CyearT As String
    Private CFund As String
    Private CdateM As String


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InitData()
        If FType = "SPGF" Then    ' Specific General Fixed Income Fund
            showReport(Server.MapPath("rptSpecificReport.rpt"))
        Else
            showReport(Server.MapPath("rptPVFNormalReports.rpt"))
            'showReport(Server.MapPath("rpttest.rpt"))
        End If
    End Sub

    Private Sub InitData()

        'If Not IsNothing(Session.Item("Type")) Then
        '    FType = Session.Item("Type")
        'End If
        'If Not IsNothing(Session.Item("StartDate")) Then
        '    Cmonth = Session.Item("StartDate")
        'End If
        'If Not IsNothing(Session.Item("EndDate")) Then
        '    Cyear = Session.Item("EndDate")
        'End If
        'If Not IsNothing(Session.Item("FundCode")) Then
        '    CFund = Session.Item("FundCode")
        'End If
        FType = Request.QueryString("Ftype")
        CFund = Request.QueryString("cfund")
        Cmonth = Request.QueryString("cmonth")
        Cyear = Request.QueryString("cyear")
        CdateM = Request.QueryString("cdateM")
        CyearT = Request.QueryString("cyearT")

        If FType = "SPGF" Then    ' Specific General Fixed Income Fund
            AddParameter("Fund_Code", CFund)
            AddParameter("pMonth", Cmonth)
            AddParameter("pYear", Cyear)
            AddParameter("pDate", CdateM)
        Else
            AddParameter("Fund_Code", CFund)
            AddParameter("pMonth", Cmonth)
            AddParameter("pYear", Cyear)
            AddParameter("pDate", CdateM)
            AddParameter("pYearT", CyearT)
            AddParameter("pUnder", "_")
        End If


        '   AddParameter("ftype", FType)
        'AddParameter("cmonth", Cmonth)
        'AddParameter("cyear", Cyear)
        'AddParameter("cFund", "'" & CFund & "'")


        'AddParameter("Fund_Code", "'" & CFund & "'")

    End Sub

    Sub showReport(ByVal ReportName As String)

        'Dim crTableLogonInfo As New CrystalDecisions.Shared.TableLogOnInfo
        'Dim crTableLogonInfos As New CrystalDecisions.Shared.TableLogOnInfos
        'Dim crConnectionInfo As New CrystalDecisions.Shared.ConnectionInfo
        Dim myReportdocument As New ReportDocument
        Dim crParameterFieldDefinitions As CrystalReports.Engine.ParameterFieldDefinitions
        Dim crParameterFieldDefinition As CrystalReports.Engine.ParameterFieldDefinition
        Dim crParameterValues As New CrystalDecisions.Shared.ParameterValues
        Dim crParameterDiscreteValue As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim crDiskFileDestinationOptions As DiskFileDestinationOptions
        'Dim crExportOptions As CrystalDecisions.Shared.ExportOptions
        'Dim crDiskFileDestinationOptions As CrystalDecisions.Shared.DiskFileDestinationOptions
        'Dim crExportFile As String
        'Dim crReport As New Web_Pri
        Dim i As Int16
        ' * ------------------------- Data Init ----------------------- *
        ' crConnectionInfo.ServerName = strServerName
        ' crConnectionInfo.UserID = strUserID
        ' crConnectionInfo.Password = strPassword
        'crConnection()
        'crTableLogonInfo.ConnectionInfo = crConnectionInfo
        'Dim DatabaseInfo As CrystalDecisions.Shared.TableLogOnInfo
        'For Each DatabaseInfo In Me.CrystalReportViewer1.LogOnInfo
        '    With DatabaseInfo.ConnectionInfo
        '        .ServerName = Me.strServerName
        '        .DatabaseName = "ABC"
        '        .UserID = Me.strUserID
        '        .Password = Me.strPassword

        '    End With
        'Next
        myReportdocument.Load(ReportName)
        myReportdocument.SetDatabaseLogon(strUserID, strPassword, strServerName, "")

        myReportdocument.DataDefinition.ParameterFields.Reset()
        'myreportdocument.SetParameterValue(
        '' ��ǹ�������ǹ�ͧ Parameter
        For i = 0 To arrayParameterName.Count - 1
            myReportdocument.SetParameterValue(arrayParameterName.Item(i), arrayParameterValue.Item(i))
            'crParameterFieldDefinitions = myReportdocument.DataDefinition.ParameterFields()
            '' Set Parameter
            'crParameterFieldDefinition = crParameterFieldDefinitions.Item(arrayParameterName.Item(i))
            'crParameterValues = crParameterFieldDefinition.CurrentValues
            'crParameterDiscreteValue = New CrystalDecisions.Shared.ParameterDiscreteValue
            'crParameterDiscreteValue.Value = arrayParameterValue.Item(i)
            'crParameterValues.Add(crParameterDiscreteValue)
            'crParameterFieldDefinition.ApplyCurrentValues(crParameterValues)
            'myReportdocument.Database.Tables(0).ApplyLogOnInfo(crTableLogonInfo)
        Next
        'Get Collection
        CrystalReportViewer1.DisplayGroupTree = False

        'myReportdocument.ReportOptions.EnableUseDummyData = True
        'myReportdocument.ExportOptions.ExportDestinationType = ExportDestinationType.DiskFile
        'myReportdocument.ExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat
        ''myReportdocument.ExportOptions.DestinationOptions = crDiskFileDestinationOptions

        CrystalReportViewer1.ReportSource = myReportdocument

        'If Not (CrystalReportViewer1.Page.IsValid) Then
        '    lbMsg.Text = "Error"
        'End If
    End Sub

    Private Sub AddParameter(ByVal ParameterName As String, ByVal ParameterValue As String)
        ' �ѧ���蹹���˹�ҷ�� �����觼�ҹ����Ѻ����� Show Report
        arrayParameterName.Add(ParameterName)
        arrayParameterValue.Add(ParameterValue)
    End Sub
End Class
