Imports System.Data.OleDb

Public Class Class_RunNo
    Dim strsql As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()

    Public Function GetOrdno(ByVal strcisno As String, ByVal strfund As String, ByVal strbrcode As String, ByVal stryear As String, ByVal strord As String) As String
        Dim strOrdNo As String
        Dim strRunNo As String
        Dim strNewNo As String
        Dim strErr As String

        'Select Case strord
        '    Case "SB"
        '        strsql = "select max(order_no) order_no from sastbuy where fund = '" & strfund & "' and cis_no = '" & strcisno & "' " & _
        '                       " and   to_char(tran_date,'dd/mm/yyyy') =  '" & strtrndate & "'"
        'Case "RD", "SO"

        strsql = "select max(trn_no) trn_no from pv.pvmtran " & _
                 "where substr(trn_no,1,2) = substr('" & stryear & "',3,2) "

        ds = m1.GetDataset(strsql)
        Try
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            strOrdNo = dr("trn_no")
        Catch
            strOrdNo = ""
        End Try

        strRunNo = 1

        If strOrdNo = "" Then
            strNewNo = Right(stryear, 2)
            strNewNo = strNewNo + Right("00000000" + strRunNo, 6)

            'strsql = "update cis.opnmagen set new_order = '" & strNewNo & "' where br_code = '" & strbrcode & "'"

            'Dim m2 As New MyData()
            'Dim cn As New OleDbConnection()
            'cn = m2.GetConnection
            'Dim cmd As New OleDbCommand(strsql, cn)

            'Try
            '    cmd.ExecuteNonQuery()
            'Catch x1 As Exception
            '    strErr = x1.Message()
            'End Try
        Else
            strNewNo = Right(stryear, 2)
            strNewNo = strNewNo + Right("000000" + (strOrdNo + 1), 6)
            'strNewNo = Right("00000000" + (strOrdNo + 1), 8)
        End If

        Return strNewNo
    End Function

    Public Function GetIPO(ByVal strfund As String) As String
        Dim strOrdNo As String
        Dim dbOrdNo As Double
        Dim strNewNo As String

        strsql = "select ipo_ord from ipo  where fund = '" & strfund & "'"
        ds = m1.GetDataset(strsql)

        Try
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            strOrdNo = dr("ipo_ord")
        Catch
            strOrdNo = ""
        End Try

        strOrdNo = Right(strOrdNo, 5) + 1
        strNewNo = "IPO" + Right("00000" + strOrdNo, 5)
        Return strNewNo
    End Function

End Class
