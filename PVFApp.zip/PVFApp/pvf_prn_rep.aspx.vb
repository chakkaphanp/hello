Public Class pvf_prn_rep
    Inherits System.Web.UI.Page
    Protected WithEvents ddDm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDy As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents chbFund As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents chkAll As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lbCount As System.Web.UI.WebControls.Label
    Protected WithEvents rdlFType As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents imgView As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strsql As String
    Dim ds As New DataSet()
    Dim m1 As New MyData
    Dim mc As New ClassCheckUser

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "rep_perf") = "F" Then
                Label1.Text = "*** �س������Է�� ����¡������ ��� ***"
                imgView.Enabled = False
                Exit Sub
            End If
            GetFtype()
            GetDate()
        End If
    End Sub

    Sub GetFund()
        strsql = "select fund,fund_tname||' ( '||fund||' )' fund_tname from pv.v_fund " & _
                      " where class_code='P' and share_amt > 0 " & _
                      " and fund_type = '" & rdlFType.SelectedItem.Value & "' " & _
                      " order by fund"
        ds = m1.GetDataset(strsql)
        Dim dc As Integer = ds.Tables(0).Rows.Count
        lbCount.Text = " �ӹǹ������   " & dc & "  �ͧ�ع "
        chbFund.DataSource = ds
        chbFund.DataTextField = "fund"
        chbFund.DataValueField = "fund"

        Me.DataBind()
    End Sub

    Sub GetFtype()
        strsql = "select type_code, type_desc_t from pv.fundtype where type_flg = 'T' order by type_desc_t "
        ' type_code in ('EQ','GF','BL','FL','SPEQ','SPGF','SPBL','SPFL') order by type_desc_t "
        ds = m1.GetDataset(strsql)
        rdlFType.DataSource = ds
        rdlFType.DataTextField = "type_desc_t"
        rdlFType.DataValueField = "type_code"

    End Sub

    Private Sub GetDate()
        Dim c_date As Date = Now
        Dim str_cur As String

        str_cur = c_date.Day

        strsql = "select * from web. webmonth"
        ds = m1.GetDataset(strsql)
        ddDm.DataSource = ds
        ddDm.DataTextField = "mth_t_name"
        ddDm.DataValueField = "mth_code"

        Dim i As Integer
        Dim yy(2) As String '= {"2546", "2547"}
        For i = 0 To 1
            yy(i) = Now.Year - i + 543
            ddDy.Items.Add(yy(i))
        Next

        Me.DataBind()

        str_cur = c_date.Month
        ddDm.SelectedIndex = str_cur - 1

    End Sub

    Private Sub chkAll_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAll.CheckedChanged
        Dim Item As ListItem
        If chkAll.Checked Then
            For Each Item In chbFund.Items
                Item.Selected = True
            Next
        Else
            For Each Item In chbFund.Items
                Item.Selected = False
            Next
        End If
    End Sub

    Private Sub imgView_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgView.Click
        Dim strFund, strFtype As String
        Dim Item As ListItem
        For Each Item In chbFund.Items
            If Item.Selected Then
                strFund &= "'" & Item.Text & "',"
                '       strFund &= Item.Text + " "
            End If
        Next

        Dim iLen As Integer
        iLen = Len(strFund)
        strFund = Left(strFund, iLen - 1)
        Session("prn_fund") = Trim(strFund)

        strFtype = rdlFType.SelectedItem.Value
        Dim strMonth, strYear, strYearT As String

        strMonth = ddDm.SelectedItem.Value
        '     strMonth = Mid(strMonth, 4, 2)
        strYear = ddDy.SelectedItem.Value - 543

        Dim dayEndofmonth As Date = DateSerial(strYearT, strMonth + 1, 0)
        Dim strDay, strFindDay As String
        strDay = Right("00" + CType(dayEndofmonth.Day, String), 2)
        strYearT = ddDy.SelectedItem.Value    ' �.� �����觴֧ xml file
        strFindDay = strYear & strMonth & strDay

        Response.Redirect("pvf_show_rep.aspx?Ftype=" & strFtype & "&cfund=" & strFund & "&cmonth=" & strMonth & "&cyear=" & strYear & "&cdateM=" & strFindDay & "&cyearT=" & strYearT)
        ' Response.Redirect("http://220.0.0.149/pvfapp/pvf_show_rep.aspx?Ftype=" & strFtype & "&cfund=" & strFund & "&cmonth=" & strMonth & "&cyear=" & strYear & "&cdateM=" & strFindDay & "&cyearT=" & strYearT)

        'If strFtype = "SPGF" Then   ' Specific General Fixed Income Fund
        '  Response.Redirect("pvf_prn_repform2.aspx?cfund=" & strFund & "&cmonth=" & strMonth & "&cyear=" & strYear)
        'Else
        '  Response.Redirect("pvf_prn_repform1.aspx?cfund=" & strFund & "&cmonth=" & strMonth & "&cyear=" & strYear)
        'End If
        'Response.Redirect("pvf_rep_month.aspx?print=preview")
    End Sub

    Private Sub rdlFType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlFType.SelectedIndexChanged
        GetFund()
    End Sub


End Class
