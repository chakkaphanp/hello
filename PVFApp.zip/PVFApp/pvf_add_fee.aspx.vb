Public Class pvf_add_fee
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents btCancel As System.Web.UI.WebControls.Button
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents CompareValidator1 As System.Web.UI.WebControls.CompareValidator
    Protected WithEvents tbAmount As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddDy_p As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm_p As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd_p As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lbholder As System.Web.UI.WebControls.Label
    Protected WithEvents ddDy As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Panel4 As System.Web.UI.WebControls.Panel
    Dim strsql As String
    Public Runno As Integer
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then

            ' Session("user_id") = "test"

            strsql = "select fund,fund_tname,(fund||'   '|| fund_tname)  fund_name from pv.v_fund where class_code='P' order by fund_tname"
            ds = m1.GetDataset(strsql)
            ddFund.DataSource = ds
            ddFund.DataTextField = "fund_tname"
            ddFund.DataValueField = "fund"

            Me.GetDate()

            ddFund.Items.Add("*** �ä�к� ***")
            ddFund.SelectedIndex = ddFund.Items.Count - 1

        End If
    End Sub

    Function GetRepDate() As String
        Dim strdate As String
        strdate = ddDd.SelectedItem.Value & "/" & ddDm.SelectedItem.Value & "/" & ddDy.SelectedItem.Value - 543
        Return strdate
    End Function

    Function GetPayDate() As String
        Dim strdate As String
        strdate = ddDd_p.SelectedItem.Value & "/" & ddDm_p.SelectedItem.Value & "/" & ddDy_p.SelectedItem.Value - 543
        Return strdate
    End Function

    Private Sub GetDate()
        Dim c_date As Date = Now
        Dim str_cur As String

        str_cur = c_date.Day

        Dim i As Integer
        For i = 1 To 31
            ddDd.Items.Add(i)
            ddDd_p.Items.Add(i)
        Next

        ddDd.SelectedIndex = str_cur - 1
        ddDd_p.SelectedIndex = str_cur - 1

        strsql = "select * from web. webmonth"
        ds = m1.GetDataset(strsql)
        ddDm.DataSource = ds
        ddDm.DataTextField = "mth_t_name"
        ddDm.DataValueField = "mth_code"

        ddDm_p.DataSource = ds
        ddDm_p.DataTextField = "mth_t_name"
        ddDm_p.DataValueField = "mth_code"

        Dim yy() As String = {"2546", "2547", "2548"}
        ddDy.DataSource = yy
        ddDy_p.DataSource = yy

        Me.DataBind()

        str_cur = c_date.Month
        ddDm.SelectedIndex = str_cur - 1
        ddDm_p.SelectedIndex = str_cur - 1

    End Sub

    Private Sub ddDm_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddDm.SelectedIndexChanged
        Dim strdm As String
        strdm = ddDm.SelectedItem.Value
        Dim getdm As String = DateTime.DaysInMonth(DateTime.Now.Year.ToString, strdm) ' return days in month
        If ddDd.SelectedItem.Value > getdm Then
            lbMsg.Text &= "��͹����� " & getdm & " �ѹ "
        Else
            lbMsg.Text = ""
        End If
    End Sub

    Private Sub ddFund_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddFund.SelectedIndexChanged
        Dim strfund As String = ddFund.SelectedItem.Value
        strsql = " select fund, to_char(rep_date,'dd/mm/yyyy') rep_date, to_char(pay_date,'dd/mm/yyyy') pay_date " & _
                       " ,nvl(amount,0) amount  from pv.pvmfee where fund = '" & strfund & "' "
        ds = m1.GetDataset(strsql)
        '    lbMsg.Text = strsql

        DG1.DataSource = ds
        DG1.DataBind()

        If DG1.Items.Count = 0 Then
            lbMsg.Text &= " ����բ����� ��Ҹ���������èѴ��áͧ�ع �ͧ�ͧ�ع���"
        Else
            lbMsg.Text = ""
        End If
    End Sub

    Private Sub DG1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strFund As String = ddFund.SelectedItem.Value
        Dim strRepDate As String = GetRepDate()
        Dim strPayDate As String = GetPayDate()
        Dim dbAmount As Double = tbAmount.Text

        If ChkDup(strFund) = "Y" Then
            lbMsg.Text = "���ա�úѹ�֡ ��¡�û�Ш���͹ " & ddDm_p.SelectedItem.Text & " ���º��������  ��سҵ�Ǩ�ͺ "
            Exit Sub
        End If

        strsql = "insert into pv.pvmfee(fund,rep_date,pay_date, amount ,upd_by ) " & _
                     " values ('" & strFund & "',to_date('" & strRepDate & "','dd/mm/yyyy '), to_date('" & strPayDate & "','dd/mm/yyyy ') ," & _
                     dbAmount & ", '" & Session("user_id") & "')"
        'lbMsg.Text = strsql
        m1.Execute(strsql)

        Try
            Response.Redirect("success.aspx?pagename=pvf_add_fee.aspx")
            'lbMsg.Text &= "�ѹ�֡���������º����"
        Catch x1 As Exception
            lbMsg.Text &= x1.Message
        End Try
    End Sub

    Function ChkDup(ByVal strFund As String) As String
        Dim strDate, strRet As String
        ' strdate = ddDd_p.SelectedItem.Value & "/" & ddDm_p.SelectedItem.Value & "/" & ddDy_p.SelectedItem.Value - 543
        strDate = ddDy_p.SelectedItem.Value - 543 & ddDm_p.SelectedItem.Value & ddDd_p.SelectedItem.Value

        strsql = " select fund, to_char(rep_date,'dd/mm/yyyy') rep_date, to_char(pay_date,'dd/mm/yyyy') pay_date " & _
                             " ,nvl(amount,0) amount  from pv.pvmfee " & _
                             " where fund = '" & strFund & "' and to_char(rep_date,'yyyymmdd') = '" & strDate & "'"
        ds = m1.GetDataset(strsql)
        strRet = ds.Tables(0).Rows.Count

        '        lbMsg.Text = strsql & strRet
        If strRet > 0 Then
            Return "Y"      ' Duplicate
        Else
            Return "N"
        End If

    End Function


End Class
