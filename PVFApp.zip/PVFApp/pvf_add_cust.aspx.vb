Public Class pvf_add_cust
    Inherits System.Web.UI.Page
    Protected WithEvents img1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents img2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents ddFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddFirst As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbFirst As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbName As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbSname As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddHType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddStatus As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDy As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddNatCode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddOccCode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddRefType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbRefno As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTaxid As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbEmail As System.Web.UI.WebControls.TextBox
    Protected WithEvents cbResp As System.Web.UI.WebControls.CheckBox
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents tbhouse_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbMoo_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTower_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbSoi_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbRoad_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTambon_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAmphur_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddProv_h As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbZip_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddCnt_h As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbTel1_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel2_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel3_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTelm_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFax_h As System.Web.UI.WebControls.TextBox
    Protected WithEvents cbChkAddr As System.Web.UI.WebControls.CheckBox
    Protected WithEvents tbPos As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbDept As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbHouse_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbMoo_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTower_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbSoi_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbRoad_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTambon_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAmphur_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddProv_o As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbZip_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddCnt_o As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbTel1_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel2_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTel3_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbTelm_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFax_o As System.Web.UI.WebControls.TextBox
    Protected WithEvents Panel3 As System.Web.UI.WebControls.Panel
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents tbNewCis As System.Web.UI.WebControls.TextBox
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Panel4 As System.Web.UI.WebControls.Panel
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents btCancel As System.Web.UI.WebControls.Button
    Protected WithEvents Panel5 As System.Web.UI.WebControls.Panel
    Protected WithEvents tbNewHno As System.Web.UI.WebControls.TextBox
    Protected WithEvents rdlTaxtype As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents rdlBankFlg As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents ddBkCode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddBkBran As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbAccNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAccName As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddAgent As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddMkt As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddAddrFlg As System.Web.UI.WebControls.DropDownList
    Protected WithEvents btBack2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents btNext2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim strsql As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "reg_cust") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                Panel2.Attributes.Add("style", "display:none")
                Panel3.Attributes.Add("style", "display:none")
                Panel4.Attributes.Add("style", "display:none")
                Exit Sub
            End If
            Panel2.Attributes.Add("style", "display:none")
            Panel3.Attributes.Add("style", "display:none")
            Panel4.Attributes.Add("style", "display:none")
            SetInit()
            ' SetInit_Holder()
            GetDate()
            AddItem()
        End If
    End Sub

    Sub SetInit()

        strsql = "select fund,fund_tname||' ( '||fund||' )' fund_tname from pv.v_fund where class_code='P' order by fund_tname"
        ds = m1.GetDataset(strsql)
        ddFund.DataSource = ds
        ddFund.DataTextField = "fund_tname"
        ddFund.DataValueField = "fund"

        strsql = "select first_name, first_code from cis.opnmtitc where first_code !='0' "
        ds = m1.GetDataset(strsql)
        ddFirst.DataSource = ds
        ddFirst.DataTextField = "first_name"
        ddFirst.DataValueField = "first_code"

        strsql = "select holder_type, holder_desc  from cis.opnmhtyp "
        ds = m1.GetDataset(strsql)
        ddHType.DataSource = ds
        ddHType.DataTextField = "holder_desc"
        ddHType.DataValueField = "holder_type"

        strsql = "select nat_code, nat_name  from cis.opnmnatc order by nat_name "
        ds = m1.GetDataset(strsql)
        ddNatCode.DataSource = ds
        ddNatCode.DataTextField = "nat_name"
        ddNatCode.DataValueField = "nat_code"

        strsql = "select occ_code, occ_name  from cis.opnmoccp order by occ_name"
        ds = m1.GetDataset(strsql)
        ddOccCode.DataSource = ds
        ddOccCode.DataTextField = "occ_name"
        ddOccCode.DataValueField = "occ_code"

        strsql = "select ref_type, ref_desc  from cis.opnmreft  order by ref_type "
        ds = m1.GetDataset(strsql)
        ddRefType.DataSource = ds
        ddRefType.DataTextField = "ref_desc"
        ddRefType.DataValueField = "ref_type"

        strsql = "select distinct(prov_name) prov_name  from cis.opnmprov  order by prov_name"
        ds = m1.GetDataset(strsql)
        ddProv_h.DataSource = ds
        ddProv_h.DataTextField = "prov_name"
        ddProv_h.DataValueField = "prov_name"

        ddProv_o.DataSource = ds
        ddProv_o.DataTextField = "prov_name"
        ddProv_o.DataValueField = "prov_name"

        strsql = "select *  from cis.opnmcntc order by cnt_code"
        ds = m1.GetDataset(strsql)
        ddCnt_h.DataSource = ds
        ddCnt_h.DataTextField = "cnt_name"
        ddCnt_h.DataValueField = "cnt_code"

        ddCnt_o.DataSource = ds
        ddCnt_o.DataTextField = "cnt_name"
        ddCnt_o.DataValueField = "cnt_code"

        Me.DataBind()

        ddFund.Items.Insert(0, "*** �ä�к� ***")
        'ddFund.Items.Add("*** �ä�к� ***")
        'ddFund.SelectedIndex = ddFund.Items.Count - 1
    End Sub

    Sub SetInit_Holder()

        strsql = "select bk_code,bk_name  from cis.opnmbank where bk_bran = 'XXX' order by bk_name"
        ds = m1.GetDataset(strsql)
        ddBkCode.DataSource = ds
        ddBkCode.DataTextField = "bk_name"
        ddBkCode.DataValueField = "bk_code"

        strsql = "select br_code,br_name  from cis.opnmagen where substr(br_code,4,6) = '000001' order by br_name "
        ds = m1.GetDataset(strsql)
        ddAgent.DataSource = ds
        ddAgent.DataTextField = "br_name"
        ddAgent.DataValueField = "br_code"

        strsql = "select sub_code,sub_desc  from cis.opnsubtype where sub_type = 'tax_type' order by sub_code "
        ds = m1.GetDataset(strsql)
        rdlTaxtype.DataSource = ds
        rdlTaxtype.DataTextField = "sub_desc"
        rdlTaxtype.DataValueField = "sub_code"

        strsql = "select sub_code,sub_desc  from cis.opnsubtype where sub_type = 'bank_flg' order by sub_code "
        ds = m1.GetDataset(strsql)
        rdlBankFlg.DataSource = ds
        rdlBankFlg.DataTextField = "sub_desc"
        rdlBankFlg.DataValueField = "sub_code"

        strsql = "select sub_code,sub_desc  from cis.opnsubtype where sub_type = 'addr_flg' order by sub_code "
        ds = m1.GetDataset(strsql)
        ddAddrFlg.DataSource = ds
        ddAddrFlg.DataTextField = "sub_desc"
        ddAddrFlg.DataValueField = "sub_code"

        Me.DataBind()

    End Sub

    Sub AddItem()
        ddFund.Items.Insert(0, "*** �ä�к� ***")
        ddFirst.Items.Insert(0, "*** �ä�к� ***")
        ddHType.Items.Insert(0, "*** �ä�к� ***")
        ddNatCode.Items.Insert(0, "*** �ä�к� ***")
        ddOccCode.Items.Insert(0, "*** �ä�к� ***")
        ddRefType.Items.Insert(0, "*** �ä�к� ***")


        'ddFund.Items.Add("*** �ä�к� ***")
        'ddFund.SelectedIndex = ddFund.Items.Count - 1
        'ddFirst.Items.Add("*** �ä�к� ***")
        'ddFirst.SelectedIndex = ddFirst.Items.Count - 1
        'ddHType.Items.Add("*** �ä�к� ***")
        'ddHType.SelectedIndex = ddHType.Items.Count - 1
        'ddNatCode.Items.Add("*** �ä�к� ***")
        'ddNatCode.SelectedIndex = ddNatCode.Items.Count - 1
        'ddOccCode.Items.Add("*** �ä�к� ***")
        'ddOccCode.SelectedIndex = ddOccCode.Items.Count - 1
        'ddRefType.Items.Add("*** �ä�к� ***")
        'ddRefType.SelectedIndex = ddRefType.Items.Count - 1

        rdlTaxtype.SelectedIndex = 0
        rdlBankFlg.SelectedIndex = 0

    End Sub

    Private Sub GetDate()
        Dim c_date As Date = Now
        Dim str_cur As String

        str_cur = c_date.Day

        Dim i As Integer
        For i = 1 To 31
            ddDd.Items.Add(i)
        Next

        ddDd.SelectedIndex = str_cur - 1

        strsql = "select * from web.webmonth"
        ds = m1.GetDataset(strsql)
        ddDm.DataSource = ds
        ddDm.DataTextField = "mth_t_name"
        ddDm.DataValueField = "mth_code"

        str_cur = c_date.Month
        ddDm.SelectedIndex = str_cur - 1

        Dim yy As Integer

        yy = Now.Year
        yy = yy + 543

        For i = 1 To 80
            ddDy.Items.Add(yy)
            yy = yy - 1
        Next

        Me.DataBind()

        '           Dim m2 As Class_GetDate
        '       Dim ddd As DropDownList = dddd.NamingContainer
        '            m2.Getday("dddd")
    End Sub

    Function ChkRefNo(ByVal strRefNo As String) As String
        Dim strDigit As String
        Dim liPos, liNum, liChkDigit As Integer
        Dim liSum As Integer = 0

        For liPos = 1 To 12
            liNum = CType(Mid(strRefNo, liPos, 1), Integer)
            liSum += liNum * (14 - liPos)
        Next

        liChkDigit = 11 - liSum Mod 11

        If liChkDigit > 9 Then
            liChkDigit = CType(Right(CType(liChkDigit, String), 1), Integer)
        End If

        '  Return liChkDigit

        If liChkDigit = CType(Mid(strRefNo, 13), Integer) Then
            Return "T"
        Else
            Label1.Text = ""
            Return "F"
        End If
        '        String ls_Digit
        'Integer li_Pos, li_Num, li_Sum = 0, li_ChkDigit
        '        For li_Pos = 1 To 12
        '	li_Num = Integer( Mid(ags_Number,li_Pos,1) )
        '            li_Sum += li_Num * (14 - li_Pos)
        '        Next
        'li_ChkDigit = 11 - Mod(li_Sum,11)
        '        If li_ChkDigit > 9 Then
        '	li_ChkDigit = Integer( Right( String(li_ChkDigit) ,1) )
        '        End If

        'IF li_ChkDigit = Integer(Mid(ags_Number,13)) Then
        '            Return 0
        '        Else

        '        End If
    End Function

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strBthDate As String = ddDd.SelectedItem.Value & "/" & ddDm.SelectedItem.Value & "/" & ddDy.SelectedItem.Value - 543
        Dim strFcode As String = ddFund.SelectedItem.Value
        Dim strFirst As String = ddFirst.SelectedItem.Value
        Dim strHtype As String = ddHType.SelectedItem.Value
        Dim strNat As String = ddNatCode.SelectedItem.Value
        Dim strOcc As String = ddOccCode.SelectedItem.Value
        Dim strRef As String = ddRefType.SelectedItem.Value
        Dim strStatus As String = ddStatus.SelectedItem.Value
        Dim strProv_h As String = ddProv_h.SelectedItem.Value
        Dim strProv_o As String = ddProv_o.SelectedItem.Value
        Dim strCnt_h As String = ddCnt_h.SelectedItem.Value
        Dim strCnt_o As String = ddCnt_o.SelectedItem.Value
        Dim strCisno As String
        Dim strHolder As String
        Dim strFName As String
        Dim strResp As String = "N"      ' ������ӹҨ/�Ѻ�ͺ�ӹҨ
        Dim mc As New Class_GenNo

        If ddFund.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� �ͧ�ع "
            Exit Sub
        ElseIf ddFirst.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� �ӹ�˹�Ҫ��� "
            Exit Sub
        ElseIf ddNatCode.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� �ѭ�ҵ� "
            Exit Sub
        ElseIf ddOccCode.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� �Ҫվ "
            Exit Sub
        End If

        strCisno = mc.GenCisno
        'strHolder = mc.GenHolder(strFcode)
        'Label1.Text = strHolder

        Select Case ddFirst.SelectedItem.Value
            Case "3", "7"
                strFName = Trim(tbFirst.Text)
            Case Else
                strFName = ddFirst.SelectedItem.Text
        End Select

        ' **** Insert into mCust ****
        strsql = "insert into pv.pvmcust(cis_no,first_code,first_name,name,surname,holder_type,nat_code,occ_code, " & _
                      "ref_type,ref_no,tax_id,bth_date,status,tot_share,upd_by,upd_date, first_date, email )" & _
                      "values ('" & strCisno & "','" & strFirst & "','" & strFName & "','" & Trim(tbName.Text) & "','" & Trim(tbSname.Text) & "','" & _
                      strHtype & "','" & strNat & "','" & strOcc & "','" & strRef & "','" & Trim(tbRefno.Text) & "','" & tbTaxid.Text & "', " & _
                      "to_date('" & strBthDate & "','dd/mm/yyyy'),'" & strStatus & "', 0 ,'" & Session("user_id") & "', sysdate , sysdate," & _
                      "'" & tbEmail.Text & "')"
        Try
            m1.Execute(strsql)
            ' **** Insert into mAddr ****
            strsql = "insert into pv.pvmaddr(cis_no,house_no_o, moo_o, tower_o,soi_o,road_o , tambon_o,amphur_o,province_o,zipcode_o, " & _
                            "tel1_o,tel2_o,tel3_o,telm_o ,fax_o, house_no_h,moo_h,tower_h,soi_h,road_h,tambon_h,amphur_h,province_h,zipcode_h," & _
                            "tel1_h,tel2_h,tel3_h, telm_h ,fax_h,upd_by,upd_date, position, dept ,cntcode_o,cntcode_h) " & _
                            "values ('" & strCisno & "','" & tbHouse_o.Text & "','" & tbMoo_o.Text & "','" & tbTower_o.Text & "','" & _
                            tbSoi_o.Text & "','" & tbRoad_o.Text & "','" & tbTambon_o.Text & "','" & tbAmphur_o.Text & "','" & strProv_o & "','" & _
                            tbZip_o.Text & "','" & tbTel1_o.Text & "','" & tbTel2_o.Text & "','" & tbTel3_o.Text & "','" & tbTelm_o.Text & "','" & _
                            tbFax_o.Text & "','" & tbhouse_h.Text & "','" & tbMoo_h.Text & "','" & tbTower_h.Text & "','" & _
                            tbSoi_h.Text & "','" & tbRoad_h.Text & "','" & tbTambon_h.Text & "','" & tbAmphur_h.Text & "','" & strProv_h & "','" & _
                            tbZip_h.Text & "','" & tbTel1_h.Text & "','" & tbTel2_h.Text & "','" & tbTel3_h.Text & "','" & tbTelm_h.Text & "','" & _
                            tbFax_h.Text & "','" & Session("user_id") & "', sysdate ,'" & tbPos.Text & "','" & tbDept.Text & "','" & _
                            strCnt_o & "','" & strCnt_h & "')"

            m1.Execute(strsql)

            '' **** Insert into mHold ****
            strResp = cbResp.Checked
            If strResp = True Then
                strResp = "Y"
            Else
                strResp = "N"
            End If

            strsql = "insert into pv.pvmhold(cis_no,fund,resp_flg,upd_by,upd_date ,first_date)" & _
                     "values ('" & strCisno & "','" & strFcode & "','" & strResp & "','" & Session("user_id") & "',sysdate , sysdate)"
            m1.Execute(strsql)

            '' *** Insert into History ****
            'strsql = "insert into pv.pvhcust(upd_flg,cis_no,first_code,first_name,name,surname,holder_type,nat_code,occ_code, " & _
            '                   "ref_type,ref_no,tax_id,bth_date,status,tot_share,upd_by,upd_date, first_date, acct_name,email )" & _
            '                 "values ('NEW','" & strCisno & "','" & strFirst & "','" & tbFirst.Text & "','" & tbName.Text & "','" & tbSname.Text & "','" & _
            '                 strHtype & "','" & strNat & "','" & strOcc & "','" & strRef & "','" & tbRefno.Text & "','" & tbTaxid.Text & "', " & _
            '                 "to_date('" & strBthDate & "','dd/mm/yyyy'),'" & strStatus & "', 0 ,'" & Session("userid") & "', sysdate , sysdate," & _
            '                 "'" & tbAcctName.Text & "','" & tbEmail.Text & "' )"
            '' m1.Execute(strsql)

            'strsql = "insert into pv.pvhaddr(upd_flg,cis_no,house_no_o, moo_o, tower_o, soi_o, road_o, tambon_o,amphur_o,province_o,zipcode_o," & _
            '       "tel1_o,tel2_o,tel3_o,telm_o,fax_o, house_no_h,moo_h,tower_h,soi_h,road_h,tambon_h,amphur_h,province_h,zipcode_h," & _
            '       "tel1_h,tel2_h,tel3_h, telm_h ,fax_h,upd_by,upd_date, position, dept ,cnt_code_o,cnt_code_h)" & _
            '       "values ('NEW','" & strCisno & "','" & tbHouse_o.Text & "','" & tbMoo_o.Text & "','" & tbTower_o.Text & "','" & _
            '       tbSoi_o.Text & "','" & tbRoad_o.Text & "','" & tbTambon_o.Text & "','" & tbAmphur_o.Text & "','" & strProv_o & "','" & _
            '       tbZip_o.Text & "','" & tbTel1_o.Text & "','" & tbTel2_o.Text & "','" & tbTel3_o.Text & "','" & tbTelm_o.Text & "','" & _
            '       tbFax_o.Text & "','" & tbhouse_h.Text & "','" & tbMoo_h.Text & "','" & tbTower_h.Text & "','" & _
            '       tbSoi_h.Text & "','" & tbRoad_h.Text & "','" & tbTambon_h.Text & "','" & tbAmphur_h.Text & "','" & strProv_h & "','" & _
            '       tbZip_h.Text & "','" & tbTel1_h.Text & "','" & tbTel2_h.Text & "','" & tbTel3_h.Text & "','" & tbTelm_h.Text & "','" & _
            '       tbFax_h.Text & "','" & Session("userid") & "', sysdate ,'" & tbPos.Text & "','" & tbDept.Text & "','" & _
            '        strCnt_o & "','" & strCnt_h & "')"
            ''  m1.Execute(strsql)

            'strsql = "insert into pv.pvhhold(upd_flg,cis_no,fund,resp_flg,upd_by,upd_date ,first_date)" & _
            '                    "values ('NEW', '" & strCisno & "','" & strFcode & "','" & strResp & "','" & Session("userid") & "',sysdate , sysdate)"
            ''m1.Execute(strsql)

            ' Label1.Text &= strsql

            Panel1.Attributes.Add("style", "display:none")
            Panel3.Attributes.Add("style", "display:none")
            img1.Visible = False
            img2.Visible = False
            Panel4.Attributes.Add("style", "display:")
            btSave.Visible = False
            btCancel.Visible = False
            tbNewCis.Text = strCisno

        Catch x1 As Exception
            Label1.Text &= x1.Message
            Label1.Text &= strsql
        Finally
        End Try

    End Sub

    Private Sub ddBkCode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddBkCode.SelectedIndexChanged
        strsql = "select bk_code,bk_bran, bk_name  from cis.opnmbank " & _
                       " where bk_code ='" & ddBkCode.SelectedItem.Value & "' order by bk_name "
        ds = m1.GetDataset(strsql)
        ddBkBran.DataSource = ds
        ddBkBran.DataTextField = "bk_name"
        ddBkBran.DataValueField = "bk_bran"

        Me.DataBind()

        ddBkBran.Items.Insert(0, "*** �ä�к� ***")
        'ddBkBran.Items.Add("*** �ä�к� ***")
        'ddBkBran.SelectedIndex = ddBkBran.Items.Count - 1
    End Sub

    Private Sub ddAgent_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddAgent.SelectedIndexChanged
        Dim strAgent As String = Left(ddAgent.SelectedItem.Value, 3)
        Dim strBran As String = Right(ddAgent.SelectedItem.Value, 6)

        strsql = "select mkt_code,mkt_name  from cis.opnmmakt where  mkt_agen = '" & strAgent & "' " & _
                 "and mkt_branch = '" & strBran & "' order by mkt_name "

        ds = m1.GetDataset(strsql)
        ddMkt.DataSource = ds
        ddMkt.DataTextField = "mkt_name"
        ddMkt.DataValueField = "mkt_code"
        Me.DataBind()

        ddMkt.Items.Insert(0, "*** �ä�к� ***")
        'ddMkt.Items.Add("*** �ä�к� ***")
        'ddMkt.SelectedIndex = ddMkt.Items.Count - 1
        ''Label1.Text = strsql
    End Sub

    Private Sub rdlBankFlg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Select Case rdlBankFlg.SelectedItem.Value
            Case "0"
                ddBkCode.Enabled = False
                ddBkBran.Enabled = False
                tbAccNo.Enabled = False
                tbAccName.Enabled = False
                ddBkCode.BackColor = Color.WhiteSmoke
                ddBkBran.BackColor = Color.WhiteSmoke
                tbAccNo.BackColor = Color.WhiteSmoke
                tbAccName.BackColor = Color.WhiteSmoke
            Case Else
                ddBkCode.Enabled = True
                ddBkBran.Enabled = True
                tbAccNo.Enabled = True
                tbAccName.Enabled = True
                ddBkCode.BackColor = Color.White
                ddBkBran.BackColor = Color.White
                tbAccNo.BackColor = Color.White
                tbAccName.BackColor = Color.White
        End Select
    End Sub


    Private Sub btNext2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        If ddAgent.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� ���᷹ "
            Exit Sub
        ElseIf ddMkt.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� Marketting "
            Exit Sub
        ElseIf ddAddrFlg.SelectedItem.Text = "*** �ä�к� ***" Then
            Label1.Text = "��س��к� ʶҹ����Ѻ�͡��� "
            Exit Sub
        End If

        Select Case rdlBankFlg.SelectedItem.Value
            Case "0"

            Case Else
                If ddBkCode.SelectedItem.Text = "*** �ä�к� ***" Then
                    Label1.Text = "��س��к� ��Ҥ�� "
                    Exit Sub
                ElseIf ddBkBran.SelectedItem.Text = "*** �ä�к� ***" Then
                    Label1.Text = "��س��к��ҢҸ�Ҥ��"
                    Exit Sub
                End If
        End Select
        Panel3.Attributes.Add("style", "display:")
        Panel2.Attributes.Add("style", "display:none")
        Label1.Text = ""
    End Sub

    Private Sub btBack2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Panel1.Attributes.Add("style", "display:")
        Panel2.Attributes.Add("style", "display:none")
        Label1.Text = ""
    End Sub


    Private Sub ddFirst_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddFirst.SelectedIndexChanged
        Select Case ddFirst.SelectedItem.Value
            Case "3", "7"
                tbFirst.Enabled = True
                tbFirst.Text = ""
                tbFirst.BackColor = Color.White
            Case Else
                tbFirst.Enabled = False
                tbFirst.BackColor = Color.WhiteSmoke
        End Select
    End Sub

    Private Sub ddDm_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddDm.SelectedIndexChanged
        Dim strdm As String
        strdm = ddDm.SelectedItem.Value
        Dim getdm As String = DateTime.DaysInMonth(DateTime.Now.Year.ToString, strdm) ' return days in month
        If ddDd.SelectedItem.Value > getdm Then
            Label1.Text &= "��͹����� " & getdm & " �ѹ "
        Else
            Label1.Text = ""
        End If
    End Sub

    Private Sub img1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles img1.Click
        Panel1.Attributes.Add("style", "display:")
        '  Panel2.Attributes.Add("style", "display:none")
        Panel3.Attributes.Add("style", "display:none")
        Label1.Text = ""
        img1.ImageUrl = "Images/pvf_tap_cust_b.gif"
        img2.ImageUrl = "Images/pvf_tap_addr.gif"
        btSave.Visible = True
        btCancel.Visible = True
        Panel4.Attributes.Add("style", "display:none")
    End Sub

    Private Sub img2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles img2.Click
        Panel1.Attributes.Add("style", "display:none")
        '   Panel2.Attributes.Add("style", "display:")
        Panel3.Attributes.Add("style", "display:")
        Label1.Text = ""
        img1.ImageUrl = "Images/pvf_tap_cust.gif"
        img2.ImageUrl = "Images/pvf_tap_addr_b.gif"
        btSave.Visible = True
        btCancel.Visible = True
        Panel4.Attributes.Add("style", "display:none")
    End Sub

    Private Sub cbResp_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbResp.CheckedChanged
        'Dim strResp As String
        ' strResp = cbResp.Checked
        '  Label1.Text = strResp
    End Sub

    Private Sub cbChkAddr_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbChkAddr.CheckedChanged
        If cbChkAddr.Checked Then
            tbHouse_o.Text = tbhouse_h.Text
            tbMoo_o.Text = tbMoo_h.Text
            tbTower_o.Text = tbTower_h.Text
            tbSoi_o.Text = tbSoi_h.Text
            tbRoad_o.Text = tbRoad_h.Text
            tbTambon_o.Text = tbTambon_h.Text
            tbAmphur_o.Text = tbAmphur_h.Text
            ddProv_o.SelectedIndex = ddProv_h.SelectedIndex
            tbZip_o.Text = tbZip_h.Text
            tbTel1_o.Text = tbTel1_h.Text
            tbTel2_o.Text = tbTel2_h.Text
            tbTel3_o.Text = tbTel3_h.Text
            tbTelm_o.Text = tbTelm_h.Text
            tbFax_o.Text = tbFax_h.Text
            ddCnt_o.SelectedIndex = ddCnt_h.SelectedIndex
        Else
            tbHouse_o.Text = ""
            tbMoo_o.Text = ""
            tbTower_o.Text = ""
            tbSoi_o.Text = ""
            tbRoad_o.Text = ""
            tbTambon_o.Text = ""
            tbAmphur_o.Text = ""
            ddProv_o.SelectedIndex = -1
            tbZip_o.Text = ""
            tbTel1_o.Text = ""
            tbTel2_o.Text = ""
            tbTel3_o.Text = ""
            tbTelm_o.Text = ""
            tbFax_o.Text = ""
            ddCnt_o.SelectedIndex = -1
        End If
    End Sub
End Class

'strsql = "insert into pv.pvmhold(cis_no,fund_code,holder_id,share_uni,ret_flg,ar_flg,upd_by,upd_date ," & _
'                 "first_date,tax_type,bank_flg,bk_code,bk_bran,acct_no,acct_name,addr_flg," & _
'                 "br_code,mkt_code,share_amt)" & _
'                 "values ('" & strCisno & "','" & strFcode & "','" & strHolder & "',0,'0','N','" & _
'                 Session("userid") & "',sysdate , sysdate,'" & rdlTaxtype.SelectedItem.Value & "','" & _
'                 rdlBankFlg.SelectedItem.Value & "','" & strBkCode & "','" & strBkBran & "','" & _
'                 tbAccNo.Text & "','" & tbAccName.Text & "','" & ddAddrFlg.SelectedItem.Value & "','" & _
'                 ddAgent.SelectedItem.Value & "','" & ddMkt.SelectedItem.Value & "',0 )"

'strsql = "insert into pv.pvhhold(upd_flg,cis_no,fund_code,holder_id,share_uni,ret_flg,ar_flg,upd_by,upd_date ," & _
'     "first_date,tax_type,bank_flg,bk_code,bk_bran,acct_no,acct_name,addr_flg," & _
'     "br_code,mkt_code)" & _
'     "values ('NEW','" & strCisno & "','" & strFcode & "','" & strHolder & "',0,'0','N','" & _
'     Session("userid") & "',sysdate , sysdate,'" & rdlTaxtype.SelectedItem.Value & "','" & _
'     rdlBankFlg.SelectedItem.Value & "','" & strBkCode & "','" & strBkBran & "','" & _
'     tbAccNo.Text & "','" & tbAccName.Text & "','" & ddAddrFlg.SelectedItem.Value & "','" & _
'     ddAgent.SelectedItem.Value & "','" & ddMkt.SelectedItem.Value & "' )"

''strsql = "insert into pv.pvhhold(upd_flg,cis_no,fund_code,holder_id,share_uni,addr_flg,ret_flg,bank_flg,tax_type," & _
''                    "ar_flg,br_code,upd_by,upd_date ,first_date)" & _
''                  "values ('NEW','" & strCisno & "','" & strFcode & "','" & strHolder & "',0,'1','0','0','0','N','" & Session("agent") & _
''                  "','" & Session("userid") & "',sysdate , sysdate)"

