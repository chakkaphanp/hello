Public Class pvf_show_cust_desc
    Inherits System.Web.UI.Page
    Protected WithEvents DG3 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DG2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents tbCisno As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents tbFund As System.Web.UI.WebControls.TextBox
    Protected WithEvents DG4 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim strSql As String
    Dim dv As DataView
    Dim m1 As New MyData()
    Dim ds As DataSet
    Dim ds_n As DataSet
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            Dim strCisno As String
            strCisno = Request.QueryString("cis_no")
            '            lbMsg.Text = strCisno
            If Len(strCisno) > 0 Then
                Me.MyDataBind(strCisno)
            End If
            '  strSql = "select * from webmlevel "
            ' ds = m1.GetDataset(strSql)
        End If
    End Sub

    Sub MyDataBind(ByVal strCisno As String)
        tbCisno.Text = strCisno
        Dim strNat, strOcc, strRef, strHtype As String
        Dim strTemp, strBthD As String
        Dim dr As DataRow
        Dim dr2 As DataRow

        ' **********  Get Data from PVmCust and Get Description from Table Referent ********
        strSql = "select  c.cis_no,c.first_name,c.name||'  '||c.surname name,to_char(c.bth_date,'dd/mm/yyyy') bth_date,c.ref_no,c.tax_id, " & _
                        "nvl(c.ref_type,' ') ref_type,nvl(c.nat_code,' ') nat_code,nvl(c.occ_code,' ') occ_code,  " & _
                        "nvl(c.holder_type,' ') holder_type,c.email,h.resp_flg  " & _
                        "from pv.pvmcust  c, pv.pvmhold h where c.cis_no = h.cis_no and c.cis_no = '" & strCisno & "'"
        ds = m1.GetDataset(strSql)
        Try
            Panel1.Attributes.Add("style", "display:")

            dr = ds.Tables(0).Rows(0)
            strNat = dr("nat_code")
            strOcc = dr("occ_code")
            strRef = dr("ref_type")
            strHtype = dr("holder_type")
            strBthD = dr("bth_date")
            Dim strBthDate As String = Left(strBthD, 2) & "/" & Mid(strBthD, 4, 2) & "/" & Right(strBthD, 4) + 543
            dr("bth_date") = strBthDate

            If Len(Trim(strNat)) > 0 Then
                strSql = "select  * from cis.opnmnatc  where nat_code = '" & strNat & "'"
                ds_n = m1.GetDataset(strSql)
                dr2 = ds_n.Tables(0).Rows(0)
                strTemp = dr2("nat_name")
                dr("nat_code") = strTemp     ' Set description back  into Datarow
            End If

            If Len(Trim(strOcc)) > 0 Then
                strSql = "select  * from cis.opnmoccp  where occ_code = '" & strOcc & "'"
                ds_n = m1.GetDataset(strSql)
                dr2 = ds_n.Tables(0).Rows(0)
                strTemp = dr2("occ_name")
                dr("occ_code") = strTemp ' Set description back  into Datarow
            End If

            If Len(Trim(strRef)) > 0 Then
                strSql = "select  * from cis.opnmreft where ref_type = '" & strRef & "'"
                ds_n = m1.GetDataset(strSql)
                dr2 = ds_n.Tables(0).Rows(0)
                strTemp = dr2("ref_desc")
                dr("ref_type") = strTemp ' Set description back  into Datarow
            End If

            If Len(Trim(strHtype)) > 0 Then
                strSql = "select  * from cis.opnmhtyp  where holder_type = '" & strHtype & "'"
                ds_n = m1.GetDataset(strSql)
                dr2 = ds_n.Tables(0).Rows(0)
                strTemp = dr2("holder_desc")
                dr("holder_type") = strTemp ' Set description back  into Datarow
            End If

            DG1.DataSource = ds
            DG1.DataBind()

            ' **********  Get Data from OpnmHold and Get Description from Table Referent ********
            Dim strResp As String
            strSql = "  SELECT pv.PVMHOLD.FUND fund,  pv.FUNDDESC.FUND_TNAME fund_tname " & _
                            "  FROM pv.FUNDDESC, pv.PVMHOLD " & _
                            "  WHERE(pv.FUNDDESC.FUND = pv.PVMHOLD.FUND) and pv.pvmhold.cis_no = '" & strCisno & "'"
            'strSql = "select fund,resp_flg from pv.pvmhold where cis_no = '" & strCisno & "'"
            ds = m1.GetDataset(strSql)
            dr = ds.Tables(0).Rows(0)
            'strResp = dr("resp_flg")
            tbFund.Text = dr("fund_tname")

            'Dim strTax, strBkflg, strAddr, strBkcode, strBkbran, strBrcode, strMkt As String
            'strSql = "select cis_no, holder_id,acct_no,acct_name,nvl(tax_type,' ') tax_type,  " & _
            '                "nvl(bank_flg,' ') bank_flg,nvl(addr_flg,' ') addr_flg, nvl(bk_code,' ') bk_code, " & _
            '                "nvl(bk_bran,' ') bk_bran, nvl(br_code,' ') br_code, nvl(mkt_code,' ') mkt_code" & _
            '                " from pv.pvmhold  where cis_no = '" & strCisno & "'"
            'ds = m1.GetDataset(strSql)
            'dr = ds.Tables(0).Rows(0)
            'strTax = dr("tax_type")
            'strBkflg = dr("bank_flg")
            'strAddr = dr("addr_flg")
            'strBkcode = dr("bk_code")
            'strBkbran = dr("bk_bran")
            'strBrcode = dr("br_code")
            'strMkt = dr("mkt_code")

            'If Len(Trim(strTax)) > 0 Then
            '    strSql = "select  * from cis.opnsubtype  where sub_type = 'tax_type' and sub_code = '" & strTax & "'"
            '    ds_n = m1.GetDataset(strSql)
            '    dr2 = ds_n.Tables(0).Rows(0)
            '    strTemp = dr2("sub_desc")
            '    dr("tax_type") = strTemp     ' Set description back  into Datarow
            'End If
            'If Len(Trim(strBkflg)) > 0 Then
            '    strSql = "select  * from cis.opnsubtype  where sub_type = 'bank_flg' and sub_code = '" & strBkflg & "'"
            '    ds_n = m1.GetDataset(strSql)
            '    dr2 = ds_n.Tables(0).Rows(0)
            '    strTemp = dr2("sub_desc")
            '    dr("bank_flg") = strTemp     ' Set description back  into Datarow
            'End If
            'If Len(Trim(strAddr)) > 0 Then
            '    strSql = "select  * from cis.opnsubtype  where sub_type = 'addr_flg' and sub_code = '" & strAddr & "'"
            '    ds_n = m1.GetDataset(strSql)
            '    dr2 = ds_n.Tables(0).Rows(0)
            '    strTemp = dr2("sub_desc")
            '    dr("addr_flg") = strTemp     ' Set description back  into Datarow
            'End If

            'If Len(Trim(strBkbran)) > 0 Then
            '    strSql = "select  * from cis.opnmbank  where bk_code = '" & strBkcode & "' and bk_bran='" & strBkbran & "'"
            '    ds_n = m1.GetDataset(strSql)
            '    dr2 = ds_n.Tables(0).Rows(0)
            '    strTemp = dr2("bk_name")
            '    dr("bk_bran") = strTemp ' Set description back  into Datarow
            'End If

            'If Len(Trim(strBrcode)) > 0 Then
            '    strSql = "select  * from cis.opnmagen where br_code = '" & strBrcode & "'"
            '    ds_n = m1.GetDataset(strSql)
            '    dr2 = ds_n.Tables(0).Rows(0)
            '    strTemp = dr2("br_name")
            '    dr("br_code") = strTemp ' Set description back  into Datarow
            'End If

            'If Len(Trim(strMkt)) > 0 Then
            '    strSql = "select  * from cis.opnmmakt  where mkt_agen = substr('" & strBrcode & "',1,3) and " & _
            '                    "mkt_branch = substr('" & strBrcode & "',4,6) and mkt_code = '" & strMkt & "'"
            '    ds_n = m1.GetDataset(strSql)
            '    dr2 = ds_n.Tables(0).Rows(0)
            '    strTemp = dr2("mkt_name")
            '    dr("mkt_code") = strTemp ' Set description back  into Datarow
            'End If

            'DG2.DataSource = ds
            'DG2.DataBind()

            ' **********  Get Data from PvmAddr  ********
            strSql = "select  *  from pv.pvmaddr  where cis_no = '" & strCisno & "'"
            ds = m1.GetDataset(strSql)
            DG3.DataSource = ds
            DG3.DataBind()

            DG4.DataSource = ds
            DG4.DataBind()
        Catch x1 As Exception
            lbMsg.Text = " *** ����բ������١��� ***"
            Panel1.Attributes.Add("style", "display:none")
        End Try

    End Sub

    Private Sub DG1_ItemDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs)
        'If e.Item.ItemType = ListItemType.EditItem Then
        '    Dim d1 As DropDownList
        '    d1 = CType(e.Item.FindControl("ddNatcode"), DropDownList)
        '    d1.DataSource = ds_n
        '    d1.DataTextField = "nat_name"
        '    d1.DataValueField = "nat_code"
        '    d1.DataBind()
        '    Dim drv As DataRowView = e.Item.DataItem
        '    d1.SelectedIndex = drv("nat_code") - 1
        'End If

    End Sub

    Private Sub tbCisno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbCisno.TextChanged
        'If Not IsNumeric(tbCisno.Text) Then
        '    lbMsg.Text = "��س����������繵���Ţ"
        '    Exit Sub
        'End If

        tbCisno.Text = Right("0000000000" + tbCisno.Text, 10)
        Me.MyDataBind(tbCisno.Text)
    End Sub

End Class
