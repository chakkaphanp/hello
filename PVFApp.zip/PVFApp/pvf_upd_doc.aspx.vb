Public Class pvf_upd_doc
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents rdlChksubtype As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents chbDoc As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents tbdocremk As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents rdlChkdoctype As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents lbtxt As System.Web.UI.WebControls.Label
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lbMsg2 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim mc As New ClassCheckUser
    Dim strsql As String
    Dim FlgUpd As String
    Dim ds As New DataSet
    Dim m1 As New MyData
    Dim strSubtype, strDoctype As String
    Dim dv As DataView

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "reg_upddocreg") = "F" And mc.CheckUser(Session("user_id"), "reg_upddoctrn") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                Exit Sub
            End If
            strsql = "select fund,fund_tname,(fund||' --  '|| fund_tname )  fund_name from pv.v_fund where class_code='P' order by fund"
            ds = m1.GetDataset(strsql)
            ddFund.DataSource = ds
            ddFund.DataTextField = "fund_name"
            ddFund.DataValueField = "fund"

            Me.DataBind()
            ddFund.Items.Insert(0, "�ä�кءͧ�ع")
            ddFund.SelectedIndex = 0
        End If
    End Sub

    Private Sub ddFund_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddFund.SelectedIndexChanged
        rdlChksubtype.Enabled = True
        rdlChksubtype.ClearSelection()
        rdlChkdoctype.ClearSelection()
        lbtxt.Visible = False
        rdlChkdoctype.Visible = False
        chbDoc.Visible = False
        DG1.Visible = False
        btSave.Visible = False
        lbMsg.Text = ""
        lbMsg2.Text = ""
    End Sub

    Private Sub rdlChksubtype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlChksubtype.SelectedIndexChanged
        rdlChkdoctype.ClearSelection()
        rdlChkdoctype.Visible = False
        chbDoc.Visible = True
        Chkdoc()

    End Sub

    Sub Chkdoc()
        Dim strFund As String = ddFund.SelectedItem.Value
        Dim strchksith1, strchksith2 As String
        lbMsg2.Text = ""

        strSubtype = rdlChksubtype.SelectedItem.Value()

        strsql = "select distinct(nvl(doc_type,'NULL')) doc_type from pv.pvtdocrecv " & _
                      " where fund = '" & strFund & "' and sub_type = '" & strSubtype & "' "
        ds = m1.GetDataset(strsql)
        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            strDoctype = dr("doc_type")
            Session("doctype") = strDoctype
            GetDocReg(strFund, strSubtype, strDoctype)
        Else
            rdlChkdoctype.Visible = True
            GetDocReg(strFund, strSubtype, "NULL")  ' �ó�������к���¡���͡��õ�����Դ app
        End If
        If strSubtype = "PVTRN" Then
            lbtxt.Visible = False
            rdlChkdoctype.Visible = False
            GetDocReg(strFund, "PVTRN", "TRAN")
            'chbDoc.Visible = False
            DG1.Visible = True
            GetDocTrn(strFund)
        End If
        strchksith1 = mc.CheckUser(Session("user_id"), "reg_upddocreg")
        strchksith2 = mc.CheckUser(Session("user_id"), "reg_upddoctrn")

        If strchksith1 = "T" And strchksith2 = "T" Then
            Exit Sub
        End If
        If strchksith1 = "T" Then
            If strSubtype = "PVTRN" Then
                rdlChkdoctype.Visible = False
                DG1.Visible = False
                btSave.Visible = False
                lbMsg2.Text = "*** �س������Է�Է���¡�ù��"
            End If
        End If
        If strchksith2 = "T" Then
            If strSubtype = "PVREG" Then
                chbDoc.Visible = False
                rdlChkdoctype.Visible = False
                btSave.Visible = False
                lbMsg2.Text = "*** �س������Է�Է���¡�ù��"
            End If
        End If
    End Sub

    Sub GetDocReg(ByVal strFund As String, ByVal strSubt As String, ByVal strDoct As String)

        strsql = "select a.doc_code,b.doc_desc||' ( '||a.doc_code||' )' doc_desc from pv.pvmdsubtype a, sas.sasmdocument b " & _
                      " where a.doc_code = b.doc_code " & _
                      " and a.sub_type = '" & strSubt & "' " & _
                      " and a.doc_type = '" & strDoct & "' "
        ds = m1.GetDataset(strsql)

        Dim dc2 As Integer = ds.Tables(0).Rows.Count
        chbDoc.DataSource = ds
        chbDoc.DataTextField = "doc_desc"
        chbDoc.DataValueField = "doc_code"
        Me.DataBind()

        '*** mark doc receive
        Dim Item As ListItem
        Dim strChk As String = "F"
        For Each Item In chbDoc.Items
            strChk = "T"
            strsql = "select distinct(doc_type) doc_type from pv.pvtdocrecv " & _
                    " where fund = '" & strFund & "' and sub_type = '" & strSubt & "' " & _
                    " and doc_code = '" & Item.Value & "' "
            ds = m1.GetDataset(strsql)
            Dim dc3 As Integer = ds.Tables(0).Rows.Count
            If dc3 > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                Item.Selected() = True
            End If
        Next
        If strChk = "T" Then
            btSave.Visible = True
        Else
            btSave.Visible = False
        End If

    End Sub

    Sub GetDocTrn(ByVal strFund As String)

        Dim dt As DataTable
        Dim dr As DataRow

        strsql = "select  t.trn_no,t.fund,t.share_amt,t.trn_type, to_char(t.trn_date,'dd/mm/yyyy' ) trn_date,t.trn_flg  " & _
                 " from pv.pvmtran t " & _
                 " where t.fund = '" & strFund & "' and  trn_flg = 'A' and " & _
                 " t.trn_type not in ('CD','NW') and " & _
                 " t.trn_no not in ( select trn_no from pvtdocrecv ) " & _
                 " order by trn_no "
        ds = m1.GetDataset(strsql)
        dt = ds.Tables(0)

        dv = dt.DefaultView
        DG1.DataSource = ds
        DG1.DataBind()

    End Sub

    Sub Inslog(ByVal strFund, ByVal strCis, ByVal strTrnno, ByVal strTrndate, ByVal strSubtype, ByVal strDocCode, ByVal strDoctype, ByVal strDocremk, ByVal strlogtype)
        Dim dbseq As Double
        strsql = "select nvl(max(log_seq),0)  log_seq  from pv.pvhdocrecv "
        ds = m1.GetDataset(strsql)
        Dim dr1 As DataRow = ds.Tables(0).Rows(0)
        dbseq = dr1("log_seq") + 1
        If strTrndate = "" Then
            strTrndate = "sysdate"
        Else
            strTrndate = "'" & strTrndate & "'"
        End If

        strsql = "insert into pv.pvhdocrecv (log_seq,Fund,Cis_no, Trn_no, Trn_date, Sub_type,Doc_code,Doc_type,Doc_remk,log_type,log_by,log_date) " & _
                 " values ( " & dbseq & ",'" & strFund & "','" & strCis & "','" & strTrnno & "',to_date(" & strTrndate & ",'dd/mm/yyyy'),'" & strSubtype & "','" & strDocCode & _
                 "' ,'" & strDoctype & "','" & strDocremk & " ','" & strlogtype & "','" & Session("user_id") & "',sysdate )"
        '  lbMsg2.Text = strsql
        m1.Execute(strsql)

    End Sub
    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strFund, strDocCode, strSubtype, strDocType, strRemk As String
        Dim strTrnDate As String
        Dim Item As ListItem

        strFund = ddFund.SelectedItem.Value()
        strSubtype = rdlChksubtype.SelectedItem.Value()
        strRemk = tbdocremk.Text

        If strSubtype = "PVREG" Then
            For Each Item In chbDoc.Items
                strDocCode = Item.Value
                strDocType = Session("doctype")
                If rdlChkdoctype.Visible = True Then
                    If rdlChkdoctype.SelectedItem.Selected Then
                        strDocType = rdlChkdoctype.SelectedItem.Value()
                    End If
                End If

                strsql = " select doc_code,trn_date, nvl(doc_remk,' ') doc_remk from pv.pvtdocrecv " & _
                         " where fund = '" & strFund & "' and sub_type = '" & strSubtype & "' " & _
                         " and doc_code = '" & Item.Value & "' "
                ds = m1.GetDataset(strsql)
                '    lbMsg.Text &= strsql
                Dim dc As Integer = ds.Tables(0).Rows.Count
                If dc > 0 Then
                    Dim dr As DataRow = ds.Tables(0).Rows(0)
                    strTrnDate = dr("trn_date")
                    strRemk = dr("doc_remk")

                    If Not (Item.Selected) Then
                        Inslog(strFund, "NEW", "REG", strTrnDate, strSubtype, strDocCode, strDocType, strRemk, "DEL")

                        strsql = " delete  from pv.pvtdocrecv " & _
                                 " where fund = '" & strFund & "' and sub_type = '" & strSubtype & "' " & _
                                 " and doc_code = '" & Item.Value & "' "
                        m1.Execute(strsql)
                    End If
                Else
                    If Item.Selected Then
                        strDocCode = Item.Value

                        strsql = "insert into pv.pvtdocrecv ( Fund, Cis_no, Trn_no, Trn_date,Sub_type,Doc_type,Doc_code,Doc_remk," & _
                                 " Ins_by, Ins_date ) " & _
                                 " values ( '" & strFund & "', 'NEW','REG' ,to_date(sysdate,'dd/mm/yyyy'),'" & strSubtype & "'" & _
                                 " ,'" & strDocType & "','" & strDocCode & "','" & strRemk & "','" & Session("user_id") & "',sysdate )"
                        m1.Execute(strsql)
                        Inslog(strFund, "NEW", "REG", "", strSubtype, strDocCode, strDocType, strRemk, "ADD")
                    End If
                End If

            Next
        Else
            Dim dgi As DataGridItem
            Dim strTrnNo, strTrntype As String
            Dim iChk As Integer = 0
            lbMsg.Text = ""
            strDocType = "TRAN"

            For Each Item In chbDoc.Items
                If Item.Selected Then
                    iChk = iChk + 1
                    strDocCode = Item.Value
                    For Each dgi In DG1.Items
                        Dim cb As CheckBox = dgi.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
                        If cb.Checked Then
                            strTrnNo = DG1.DataKeys(dgi.ItemIndex)
                            strTrntype = DG1.Items(dgi.ItemIndex).Cells(0).Text.ToString
                            strTrnDate = DG1.Items(dgi.ItemIndex).Cells(6).Text.ToString
                            lbMsg.Text = strTrnDate & " == "
                            strsql = "insert into pv.pvtdocrecv ( Fund, Cis_no, Trn_no, Trn_date,Sub_type,Doc_type,Doc_code,Doc_remk," & _
                                     " Ins_by, Ins_date ) " & _
                                     " values ( '" & strFund & "', '" & strTrntype & "','" & strTrnNo & "' ,to_date('" & strTrnDate & "','dd/mm/yyyy'),'" & strSubtype & "' " & _
                                     " ,'" & strDocType & "','" & strDocCode & "','" & strRemk & "','" & Session("user_id") & "',sysdate )"
                            m1.Execute(strsql)
                            Inslog(strFund, strTrntype, strTrnNo, strTrnDate, strSubtype, strDocCode, strDocType, strRemk, "ADD")
                            ' lbMsg.Text &= strsql
                        End If
                    Next
                End If
            Next
            If iChk = 0 Then
                lbMsg2.Text = "*** ��س����͡������˹ѧ����駡�÷���¡��"
            End If

        End If

        Response.Redirect("success.aspx?pagename=pvf_upd_doc.aspx")
        'lbMsg2.Text = "*** �ѹ�֡��¡��  ���º���� *** "
        'btSave.Visible = False

    End Sub

    Private Sub rdlChkdoctype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlChkdoctype.SelectedIndexChanged
        Dim strFund As String = ddFund.SelectedItem.Value
        Dim strDocType As String = rdlChkdoctype.SelectedItem.Value()
        GetDocReg(strFund, "PVREG", strDocType)
    End Sub

    Private Sub DG1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemDataBound
        ''        Dim strFlg As String = CType(DataBinder.Eval(e.Item.DataItem, "trn_type"), String)
        ''e.Item.Cells(1).ForeColor = Color.DarkGreen
        '        Dim cb As CheckBox = e.Item.Cells(1).Controls(1)    ' checkbox use control(1) , textbox use control(0)
        '       If cb.Checked Then
        '      e.Item.Cells(1).Enabled = False
        '     End If
    End Sub

End Class
