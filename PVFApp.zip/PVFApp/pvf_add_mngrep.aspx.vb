Imports System.Xml
Imports System.IO

Public Class pvf_add_mngrep
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents tbR1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbR2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbR3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents chbFund As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents imgSave As System.Web.UI.WebControls.ImageButton
    Protected WithEvents rdlUpd As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents ddDm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents ddDy As System.Web.UI.WebControls.DropDownList

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim strsql As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "mas_fund") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                imgSave.Enabled = False
                Exit Sub
            End If

            SetInit()
            GetDate()
            '  Panel2.Attributes.Add("style", "display:none")
            rdlUpd.SelectedIndex = 0
            ddFund.Items.Insert(0, "�ä�кءͧ�ع")
            ddFund.SelectedIndex = 0
        End If
    End Sub

    Sub SetInit()
        strsql = "select fund,fund_tname||' ( '||fund||' )' fund_tname from pv.v_fund where class_code='P' order by fund_tname"
        ds = m1.GetDataset(strsql)
        ddFund.DataSource = ds
        ddFund.DataTextField = "fund_tname"
        ddFund.DataValueField = "fund"

        strsql = "select fund,fund_tname||' ( '||fund||' )' fund_tname from pv.v_fund where class_code='P' order by fund"
        ds = m1.GetDataset(strsql)
        chbFund.DataSource = ds
        chbFund.DataTextField = "fund"
        chbFund.DataValueField = "fund"

        Me.DataBind()

    End Sub

    Private Sub ddFund_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddFund.SelectedIndexChanged
        tbR1.Text = ""
        tbR2.Text = ""
        tbR3.Text = ""
        Label1.Text = ""

        Dim strMonth As String = ddDm.SelectedItem.Value
        Dim strYear As String = ddDy.SelectedItem.Value
        Dim xmlDataSet As New DataSet()
        Dim strfile As String
        ' **** Get data from Oracle
        'strsql = "select nvl(rep_line1,' ') rep_line1, nvl(rep_line2,' ') rep_line2, " & _
        '            " nvl(rep_line3,' ') rep_line3 " & _
        '            " from pvrfund " & _
        '            " where fund = '" & ddFund.SelectedItem.Value & "' " & _
        '            " and rep_month = '" & strMonth & "' and rep_year = '" & strYear & "'"

        'Dim dr As DataRow
        'ds = m1.GetDataset(strsql)
        'If ds.Tables(0).Rows.Count < 1 Then
        '    tbR1.Text = "����բ�������§ҹ�ͧ�ع"
        'Else
        '    dr = ds.Tables(0).Rows(0)
        '    tbR1.Text = dr("rep_line1")
        '    tbR2.Text = dr("rep_line2")
        '    tbR3.Text = dr("rep_line3")
        'End If


        ' **** Get data from XML
        Dim strFund As String = ddFund.SelectedItem.Value & "_" & strMonth & strYear
        strfile = Server.MapPath("XML/" & strFund & ".xml")
        If File.Exists(strfile) Then
            xmlDataSet.ReadXml(Server.MapPath("XML/" & strFund & ".xml"))
            Dim dr2 As DataRow = xmlDataSet.Tables(0).Rows(0)
            Dim strNews
            tbR1.Text = dr2("News1")
            tbR2.Text = dr2("News2")
            tbR3.Text = dr2("News3")

            'tbR1.Text = Mid(dr2("News1"), 6)
            'tbR2.Text = Mid(dr2("News2"), 11)
            'tbR3.Text = Mid(dr2("News3"), 11)
            '    Label1.Text = strFund
        Else
            tbR1.Text = "����բ�������§ҹ�ͧ�ͧ�ع"
        End If

    End Sub

    Private Sub rdlUpd_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlUpd.SelectedIndexChanged
        If rdlUpd.SelectedItem.Value = "add" Then
            ddFund.Enabled = False
            chbFund.Enabled = True
        Else
            ddFund.Enabled = True
            chbFund.Enabled = False
        End If
        ddFund.SelectedIndex = 0
        'tbR1.Text = ""
        'tbR2.Text = ""
        'tbR3.Text = ""
    End Sub

    Private Sub imgSave_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgSave.Click
        'Dim strFund As String = ddFund.SelectedItem.Value
        'Dim xfile As String = Server.MapPath(strFund & ".xml")
        Dim w1 As XmlTextWriter
        Dim strFund As String
        Dim strMonth As String = ddDm.SelectedItem.Value
        Dim strYear As String = ddDy.SelectedItem.Value

        If rdlUpd.SelectedItem.Value = "add" Then
            Dim Item As ListItem
            For Each Item In chbFund.Items
                If Item.Selected Then

                    ' **** Insert to Oralcle
                    'strsql = "insert into pvrfund (fund,rep_month,rep_year, " & _
                    '" rep_line1, rep_line2, rep_line3 ) " & _
                    '" values ( '" & Item.Text & "','" & strMonth & "','" & strYear & _
                    '"','" & tbR1.Text & "','" & tbR2.Text & "','" & tbR3.Text & "' )"

                    'm1.Execute(strsql)

                    ' **** Insert to XML file
                    strFund = Item.Text & "_" & strMonth & strYear
                    Dim xfile As String = Server.MapPath("XML/" & strFund & ".xml")

                    Dim strTag1, strTag2 As String

                    'strTag1 = Chr(26) + "#09;"  '"&#38" + "#09;"
                    'strTag2 = "&#13;&#09;"

                    '   strTag1 = "<![CDATA[&#09]]>"  '"&#38" + "#09;"

                    'w1 = New XmlTextWriter(xfile, Nothing)
                    'w1.WriteStartDocument()
                    'w1.Formatting = Formatting.Indented
                    'w1.Indentation = 3
                    'w1.WriteStartElement("FundNews")
                    'w1.WriteStartElement("NewsData")
                    'w1.WriteAttributeString("Fund", "Detail")
                    'w1.WriteElementString("News1", strTag1 + tbR1.Text)
                    'w1.WriteElementString("News2", strTag2 + tbR2.Text)
                    'w1.WriteElementString("News3", strTag2 + tbR3.Text)
                    ''w1.WriteElementString("News4", "'" & tbR4.Text & "'")
                    ''w1.WriteElementString("News5", "'" & tbR5.Text & "'")
                    ''w1.WriteElementString("News6", "'" & tbR6.Text & "'")
                    '' w1.WriteEndElement()
                    'w1.WriteEndElement()
                    'w1.Close()

                    Dim t1 As New StreamWriter(xfile)
                    Dim ln As String
                    strTag1 = "&#09;"
                    strTag2 = "&#13;&#09;"
                    ln = "<?xml version='1.0'?>"
                    ln &= "<FundNews>"      ' + "<br>"
                    ln &= "<NewsData Fund='Detail'>"
                    ln &= "<News1>" & strTag1 + tbR1.Text & "</News1>"
                    ln &= "<News2>" & strTag2 + tbR2.Text & "</News2>"
                    ln &= "<News3>" & strTag2 + tbR3.Text & "</News3>"
                    ln &= " </NewsData> "
                    ln &= " </FundNews> "
                    t1.WriteLine(ln)
                    t1.Close()
                End If

            Next
        Else                   ' Update Fund Report

            ' **** Update to Oracle
            'strFund = ddFund.SelectedItem.Value

            '' **** Update Oracle
            'strsql = " update pvrfund set ( " & _
            '         " rep_line1 = '" & tbR1.Text & "', " & _
            '         " rep_line2 = '" & tbR2.Text & "', " & _
            '         " rep_line3 = '" & tbR3.Text & "' ) " & _
            '         " where fund = '" & strFund & "' " & _
            '         " and rep_month ='" & strMonth & "'" & _
            '         " and rep_year = '" & strYear & "'"

            'm1.Execute(strsql)

            ' **** Update XML file
            strFund = strFund & "_" & strMonth & strYear
            Dim xfile As String = Server.MapPath("XML/" & strFund & ".xml")

            w1 = New XmlTextWriter(xfile, Nothing)
            w1.WriteStartDocument()
            w1.Formatting = Formatting.Indented
            w1.Indentation = 3
            w1.WriteStartElement("FundNews")
            w1.WriteStartElement("NewsData")
            w1.WriteAttributeString("Fund", "Detail")
            w1.WriteElementString("News1", tbR1.Text)
            w1.WriteElementString("News2", tbR2.Text)
            w1.WriteElementString("News3", tbR3.Text)
            w1.WriteEndElement()
            w1.WriteEndElement()
            w1.Close()
        End If

        Response.Redirect("success.aspx?pagename=pvf_add_mngrep.aspx")
    End Sub

    Private Sub GetDate()
        Dim c_date As Date = Now
        Dim str_cur As String

        str_cur = c_date.Day

        strsql = "select * from web. webmonth"
        ds = m1.GetDataset(strsql)
        ddDm.DataSource = ds
        ddDm.DataTextField = "mth_t_name"
        ddDm.DataValueField = "mth_code"

        Dim i As Integer
        Dim yy(2) As String '= {"2546", "2547"}
        For i = 0 To 1
            yy(i) = Now.Year - i + 543
            ddDy.Items.Add(yy(i))
        Next

        'Dim yy() As String = {"2546", "2547"}
        'ddDy.DataSource = yy
        'str_cur = c_date.Year + 543
        'lbmsg.Text = str_cur
        'dddy.SelectedIndex = str_cur
        Me.DataBind()

        str_cur = c_date.Month
        ddDm.SelectedIndex = str_cur - 1

    End Sub

    Private Sub ddDm_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddDm.SelectedIndexChanged
        ddFund.SelectedIndex = 0
        tbR1.Text = ""
        tbR2.Text = ""
        tbR3.Text = ""
    End Sub
End Class
