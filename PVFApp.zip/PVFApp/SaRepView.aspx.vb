Imports CrystalDecisions
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Web
Public Class SaRepView
    Inherits System.Web.UI.Page
    Private Const PageName As String = "SaRepView"
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents CrystalReportViewer1 As CrystalDecisions.Web.CrystalReportViewer
    Protected WithEvents CrystalReportViewer2 As CrystalDecisions.Web.CrystalReportViewer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "Valiable"

    Private Const strServerName As String = "nassetdb"
    Private Const strUserID As String = "sao"
    Private Const strPassword As String = "sao2005"
    Private arrayParameterName As New ArrayList
    Private arrayParameterValue As New ArrayList
    Private RepType As String
    Private RepName As String
    Private StartDate As String
    Private EndDate As String
    Private FundSql As String
    Private FundCode As String
    Private FundName As String
    Private AgentID As String
    Private AgentCode As String
    Private AgentBran As String
    Private MktCode As String
    '   Private objAuthen As New clsAuthorize

#End Region

    Private Sub InitData()
        Dim strSql As String

        RepName = Request("repname")
        AgentID = Request("agentid")
        AgentBran = Request("agentbran")
        StartDate = Request("dstart")
        EndDate = Request("dend")
        RepType = Request("repid")
        MktCode = Request("mktcode")
        FundSql = " "

        '   Response.Write("repname = " & RepName & AgentID & AgentBran & StartDate & EndDate & RepType)
        If AgentID = "0" Then    ' ���͡�ء���᷹
            AgentID = Session.Item("AGENT_ID")
            Select Case RepType
                Case "001"   ' new cust
                    strSql = " or substr(agent_id,1,3) <> '" & Left(AgentID, 3) & "' " ' 
                    AddParameter("pAgentSql", strSql)
                Case "002"   ' sb
                    strSql = " or substr(sastorder.agent_id,1,3) <> '" & Left(AgentID, 3) & "' " ' 
                    AddParameter("pAgentSql", strSql)
                    AddParameter("pFundSql", FundSql)
                Case "003"   ' rd
                    strSql = " or substr(sastorder.agent_id,1,3) <> '" & Left(AgentID, 3) & "' " ' 
                    AddParameter("pAgentSql", strSql)
                    AddParameter("pFundSql", FundSql)
                Case "004"    ' sum agent
                    AgentID = Left(AgentID, 3)  ' ��੾�� 3 ���˹��
                    strSql = " or  substr(SASTORDER.AGENT_ID,1,3) <> '" & AgentBran & "' "
                    AddParameter("pAgentSql", strSql)
                Case "005"   ' ccsb
                    strSql = " or substr(sastorder.agent_id,1,3) <> '" & Left(AgentID, 3) & "' " ' 
                    AddParameter("pAgentSql", strSql)
                    AddParameter("pFundSql", FundSql)
                Case "006"   ' ccrd
                    strSql = " or substr(sastorder.agent_id,1,3) <> '" & Left(AgentID, 3) & "' " ' 
                    AddParameter("pAgentSql", strSql)
                    AddParameter("pFundSql", FundSql)
                Case "007"   ' sumSo From agent
                    strSql = " or substr(sastorder.agent_id,1,3) <> '" & Left(AgentID, 3) & "' " ' 
                    AddParameter("pAgentSql", strSql)
                Case "008"   ' sumSo To agent
                    strSql = " or substr(sastorder.agent_id,1,3) <> '" & Left(AgentID, 3) & "' " ' 
                    AddParameter("pAgentSql", strSql)
                Case "009"   ' sumSo From  �ء���᷹  ����੾�� group 1 nasset
                    'strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                    'AddParameter("pAgentSql", strSql)
                Case "010"   ' sumSo To  �ء���᷹  ����੾�� group 1 nasset
                    'strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                    'AddParameter("pAgentSql", strSql)
                Case "011"   ' sumSBtoBkAcct   �ó����͡�ء�Ң� �ͧ���᷹
                    strSql = " or substr(sastorder.agent_id,1,3) <> '" & Left(AgentID, 3) & "' " ' 
                    AddParameter("pAgentSql", strSql)
                    '      AgentBran = " "
            End Select
            AddParameter("pAgent", AgentID)  ' ��� agent ������͡ agentbran = agentid
        Else    ' ������͡�ء ���᷹ 

            If AgentBran = "0" Then   '"--------- ���͡�ء�Ң� ---------"
                'or substr(sastorder.agent_id,1,3) = 'EFS'  ' SB,RD
                'or substr(agent_id,1,3) = ''   ' new cust
                Select Case RepType
                    Case "001"   ' new cust
                        strSql = " or substr(agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        AddParameter("pAgentSql", strSql)
                    Case "002"   ' sb
                        strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        AddParameter("pAgentSql", strSql)
                        AddParameter("pFundSql", FundSql)
                    Case "003"   ' rd
                        strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        AddParameter("pAgentSql", strSql)
                        AddParameter("pFundSql", FundSql)
                    Case "004"    ' sum agent
                        AgentBran = Left(AgentID, 3)  ' ��੾�� 3 ���˹��
                        strSql = " and  substr(SASTORDER.AGENT_ID,1,3) = '" & AgentBran & "' "
                        AddParameter("pAgentSql", strSql)
                    Case "005"   ' ccsb
                        strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        AddParameter("pAgentSql", strSql)
                        AddParameter("pFundSql", FundSql)
                    Case "006"   ' ccrd
                        strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        AddParameter("pAgentSql", strSql)
                        AddParameter("pFundSql", FundSql)
                    Case "007"   ' sumSo From agent
                        strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        AddParameter("pAgentSql", strSql)
                    Case "008"   ' sumSo To agent
                        strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        AddParameter("pAgentSql", strSql)
                    Case "009"   ' sumSo From  �ء���᷹  ����੾�� group 1 nasset
                        'strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        'AddParameter("pAgentSql", strSql)
                    Case "010"   ' sumSo To  �ء���᷹  ����੾�� group 1 nasset
                        'strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        'AddParameter("pAgentSql", strSql)
                    Case "011"   ' sumSBtoBkAcct   �ó����͡�ء�Ң� �ͧ���᷹
                        strSql = " or substr(sastorder.agent_id,1,3) = '" & Left(AgentID, 3) & "' " ' 
                        AddParameter("pAgentSql", strSql)
                        AgentBran = " "
                End Select
            Else            '   �к��Ң�
                If MktCode <> "N" Then   ' �ó� mkt �������§ҹ
                    Select Case RepType
                        Case "001"
                            strSql = " and mkt_code = '" & MktCode & "' "
                        Case Else  ' 002,003
                            strSql = " and sastorder.mkt_code = '" & MktCode & "' "
                    End Select
                Else
                    strSql = " "
                End If

                Select Case RepType
                    Case "001"   ' new cust
                        AddParameter("pAgentSql", strSql)
                    Case "002"   ' sb
                        AddParameter("pAgentSql", strSql)
                        AddParameter("pFundSql", FundSql)
                    Case "003"   ' rd
                        AddParameter("pAgentSql", strSql)
                        AddParameter("pFundSql", FundSql)
                    Case "004"    ' sum agent
                        AgentBran = Left(AgentID, 3) ' ��੾�� 3 ���˹��
                        AddParameter("pAgentSql", strSql)
                        ' AgentBran = " and  substr(SASTORDER.AGENT_ID,1,3) = '" & AgentBran & "' "
                    Case "005"   ' ccsb
                        AddParameter("pAgentSql", strSql)
                        AddParameter("pFundSql", FundSql)
                    Case "006"   ' ccrd
                        AddParameter("pAgentSql", strSql)
                        AddParameter("pFundSql", FundSql)
                    Case "007"   ' sumAgentSo From
                        AddParameter("pAgentSql", strSql)
                    Case "008"   ' sumAgentSo To
                        AddParameter("pAgentSql", strSql)
                    Case "011"   ' sumSBtoBkAcct   by agentid
                        AddParameter("pAgentSql", strSql)
                        'AgentBran = " SASTORDER.AGENT_ID = '" & AgentID & "' "
                End Select
            End If
            AddParameter("pAgent", AgentBran)  ' ��� agent ������͡ agentbran = agentid
        End If
        AddParameter("pStart", StartDate)
        AddParameter("pEnd", EndDate)

        'End If
    End Sub

    Private Sub AddParameter(ByVal ParameterName As String, ByVal ParameterValue As String)
        ' �ѧ���蹹���˹�ҷ�� �����觼�ҹ����Ѻ����� Show Report
        arrayParameterName.Add(ParameterName)
        arrayParameterValue.Add(ParameterValue)
    End Sub

    Sub showReport(ByVal ReportName As String)
        Dim crTableLogonInfos As New CrystalDecisions.Shared.TableLogOnInfos
        Dim crConnectionInfo As New CrystalDecisions.Shared.ConnectionInfo
        Dim myReportdocument As New ReportDocument
        Dim crParameterFieldDefinitions As CrystalReports.Engine.ParameterFieldDefinitions
        Dim crParameterFieldDefinition As CrystalReports.Engine.ParameterFieldDefinition
        Dim crParameterValues As New CrystalDecisions.Shared.ParameterValues
        Dim crParameterDiscreteValue As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim crDiskFileDestinationOptions As DiskFileDestinationOptions

        Dim i As Int16
        myReportdocument.Load(ReportName)
        myReportdocument.SetDatabaseLogon(strUserID, strPassword, strServerName, "")

        ' ��ǹ�������ǹ�ͧ Parameter
        For i = 0 To arrayParameterName.Count - 1
            myReportdocument.SetParameterValue(arrayParameterName.Item(i), arrayParameterValue.Item(i))           'crParameterFieldDefinitions = myReportdocument.DataDefinition.ParameterFields()
        Next
        CrystalReportViewer1.DisplayGroupTree = False

        CrystalReportViewer1.ReportSource = myReportdocument

    End Sub
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '        If Not Page.IsPostBack Then
        InitData()
        showReport(Server.MapPath(RepName))
        '       End If
    End Sub

End Class
