Public Class pvf_show_updorder
    Inherits System.Web.UI.Page
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents rdlCond As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents tbCond1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents tbCond2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents IbtSeach As System.Web.UI.WebControls.ImageButton
    Protected WithEvents DG2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel
    Protected WithEvents imgCal1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents imgCal2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents myCalendar As PopUpCalendar

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public Runno As Integer
    Dim ds, ds2 As New DataSet()
    Dim m1 As New MyData()
    Dim strsql As String
    Dim strWhere As String
    Dim dv, dv2 As DataView
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            myCalendar.hideCalendar()
            If mc.CheckUser(Session("user_id"), "inq_update") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                IbtSeach.Enabled = False
                Panel2.Attributes.Add("style", "display:none")
                Exit Sub
            End If
            strWhere = "  to_Char(trn_date,'yyyymmdd') =  to_Char(sysdate,'yyyymmdd') "
            Me.MyData(strWhere)
            Me.MyData2(strWhere)
            'Else
            '    dv = Session("data")
            '    dv2 = Session("data2")
        End If
    End Sub

    Private Sub MyData(ByVal strWhere As String)
        strsql = "select p.trn_no, p.fund,p.trn_type,nvl(p.share_amt,0) share_amt , to_char(p.trn_date,'dd/mm/yyyy hh24:MI' ) trn_date" & _
                       ",f.fund_tname ,to_char(p.upd_date,'dd/mm/yyyy' ) upd_date, p.upd_by" & _
                       " from pv.pvhtran p,pv.funddesc f  " & _
                       " where p.fund = f.fund  and " & strWhere
        '  lbMsg.Text = strsql

        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView

        If dv.Count > 0 Then
            DG1.DataSource = dv  '.Tables(0).DefaultView
            '    Session("data") = dv
        Else
            DG1.DataSource = ds
            '    Session("data") = ds
        End If
        DG1.DataBind()
    End Sub

    Private Sub MyData2(ByVal strWhere As String)
        strsql = "select p.trn_no, p.fund,p.trn_type,nvl(p.share_amt,0) share_amt ,nvl(p.share_amt_bf,0) share_amt_bf , to_char(p.trn_date,'dd/mm/yyyy hh24:MI' ) trn_date" & _
                       ",f.fund_tname , p.trn_flg ,to_char(p.upd_date,'dd/mm/yyyy' ) upd_date, p.upd_by" & _
                       " from pv.pvmtran p,pv.funddesc f  " & _
                       " where p.fund = f.fund and trn_flg = 'C' and " & strWhere
        'lbMsg.Text = strsql

        ds2 = m1.GetDataset(strsql)
        dv2 = ds2.Tables(0).DefaultView

        If dv2.Count > 0 Then
            DG2.DataSource = dv2  '.Tables(0).DefaultView
            '           Session("data2") = dv2
        Else
            DG2.DataSource = ds2
            '        Session("data2") = ds2
        End If
        DG2.DataBind()
    End Sub

    Sub MyRefresh()
        dv = Session("data")
         DG1.DataSource = dv  '.Tables(0).DefaultView
        DG1.DataBind()

        dv2 = Session("data2")
        DG2.DataSource = dv2  '.Tables(0).DefaultView
        DG2.DataBind()
    End Sub

    Private Sub rdlCond_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlCond.SelectedIndexChanged
        Select Case rdlCond.SelectedItem.Value
            Case "fdate"
                tbCond2.Visible = True
                Label2.Visible = True
                Label3.Visible = True
                Label2.Text = " �֧ "
                imgCal1.Visible = True
                imgCal2.Visible = True
            Case "fname"
                tbCond2.Visible = False
                Label2.Visible = False
                Label3.Visible = False
                Label1.Text = "���ͧ͡�ع : "
                imgCal1.Visible = False
                imgCal2.Visible = False
            Case "fund"
                tbCond2.Visible = False
                Label2.Visible = False
                Label3.Visible = False
                Label1.Text = "���ʡͧ�ع : "
                imgCal1.Visible = False
                imgCal2.Visible = False
        End Select
        tbCond1.Text = ""
        tbCond2.Text = ""

    End Sub

    Private Sub DG1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub DG2_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG2.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub DG1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DG1.SortCommand
        If UCase(viewstate("field")) = UCase(e.SortExpression) Then
            If viewstate("direction") = "ASC" Then
                viewstate("direction") = "Desc"
            Else
                viewstate("direction") = "ASC"
            End If
        Else
            viewstate("field") = e.SortExpression
            viewstate("direction") = "ASC"
        End If

        dv.Sort = viewstate("field") & " " & viewstate("direction")
        DG1.CurrentPageIndex = 0
        Me.MyRefresh()
    End Sub

    Private Sub IbtSeach_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles IbtSeach.Click
        lbMsg.Text = ""
        Dim strWhere2 As String
        Dim strCond1, strCond2 As String
 
        Select Case rdlCond.SelectedItem.Value
            Case "fdate"
                'If IsDate(tbCond1.Text) And IsDate(tbCond1.Text) Then ' check mm/dd/yyyy

                Dim strYear1, strYear2 As String
                strYear1 = Right(tbCond1.Text, 4)
                strYear2 = Right(tbCond2.Text, 4)

                If CInt(strYear1) > 2500 Then
                    strYear1 = CInt(strYear1) - 543
                End If
                If CInt(strYear2) > 2500 Then
                    strYear2 = CInt(strYear2) - 543
                End If

                strCond1 = strYear1 & Mid(tbCond1.Text, 4, 2) & Left(tbCond1.Text, 2)
                strCond2 = strYear2 & Mid(tbCond2.Text, 4, 2) & Left(tbCond2.Text, 2)
                'Else
                '    Exit Sub
                'End If
                strWhere = "  (to_Char(p.upd_date,'yyyymmdd') between  '" & strCond1 & "' and '" & strCond2 & "' )"

                'dv.RowFilter = " upd_date >= '" & tbCond1.Text & "' and upd_date <= '" & tbCond2.Text & "' "
                'dv2.RowFilter = " upd_date >= '" & tbCond1.Text & "' and upd_date <= '" & tbCond2.Text & "' "
            Case "fname"
                strWhere = " f.fund_tname like '" & tbCond1.Text & "%'"
                strWhere2 = " f.fund_tname like '" & tbCond1.Text & "%'"

                'dv.RowFilter = " fund_tname like '" & tbCond1.Text & "%'"
                'dv2.RowFilter = " fund_tname like '" & tbCond1.Text & "%'"
            Case "fund"
                strWhere = " p.fund = '" & tbCond1.Text & "'"
                strWhere2 = " p.fund =  '" & tbCond1.Text & "'"

                'dv.RowFilter = " fund = '" & tbCond1.Text & "'"
                'dv2.RowFilter = " fund = '" & tbCond1.Text & "'"
        End Select

        Me.MyData(strWhere)
        Me.MyData2(strWhere)

    End Sub

    Private Sub imgCal1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgCal1.Click
        Dim dSelDate As Date

        If IsDate(tbCond1.Text) Then
            dSelDate = tbCond1.Text
        End If
        myCalendar.displayCalendar("Select a start date", dSelDate, "tbCond1", 155, 245)
    End Sub

    Private Sub imgCal2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgCal2.Click
        Dim dSelDate As Date

        If IsDate(tbCond2.Text) Then
            dSelDate = tbCond2.Text
        End If
        myCalendar.displayCalendar("Select a start date", dSelDate, "tbCond2", 155, 400)
    End Sub

End Class
