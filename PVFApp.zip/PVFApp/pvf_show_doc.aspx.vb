Public Class pvf_show_doc
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents ddFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents rdlChksubtype As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim mc As New ClassCheckUser
    Dim strsql As String
    Dim FlgUpd As String
    Dim ds As New DataSet
    Dim m1 As New MyData
    Dim strSubtype, strDoctype As String
    Dim dv As DataView

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "inq_doc") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                ddFund.Enabled = False
                Exit Sub
            End If
            strsql = "select fund,fund_tname,(fund||' --  '|| fund_tname )  fund_name from pv.v_fund where class_code='P' order by fund"
            ds = m1.GetDataset(strsql)
            ddFund.DataSource = ds
            ddFund.DataTextField = "fund_name"
            ddFund.DataValueField = "fund"

            Me.DataBind()
            ddFund.Items.Insert(0, "�ä�кءͧ�ع")
            ddFund.SelectedIndex = 0
        End If
    End Sub

    Private Sub rdlChksubtype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlChksubtype.SelectedIndexChanged
        strSubtype = rdlChksubtype.SelectedItem.Value
        GetDoc(strSubtype)
    End Sub

    Sub GetDoc(ByVal strSubtype As String)
        Dim strFund As String = ddFund.SelectedItem.Value
        Dim dt As DataTable
        Dim dr As DataRow

        strsql = " select  t.fund,t.cis_no,t.trn_no,to_char(t.trn_date,'dd/mm/yyyy') trn_date, t.sub_type, t.doc_type ,s.doc_desc||' ( '||t.doc_code||' )' doc_desc" & _
                 " from pv.pvtdocrecv t,sas.sasmdocument s " & _
                 " where t.doc_code = s.doc_code and " & _
                 " t.fund = '" & strFund & "' and t.sub_type = '" & strSubtype & "'  " & _
                 " order by trn_date "

        ds = m1.GetDataset(strsql)
        dt = ds.Tables(0)

        dv = dt.DefaultView
        DG1.DataSource = ds
        Session("data") = ds

        DG1.DataBind()

    End Sub

    Sub MyRefresh()
        dv = Session("data")
        DG1.DataSource = dv  '.Tables(0).DefaultView
        DG1.DataBind()
    End Sub

    Private Sub DG1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DG1.SortCommand
        If UCase(viewstate("field")) = UCase(e.SortExpression) Then
            If viewstate("direction") = "ASC" Then
                viewstate("direction") = "Desc"
            Else
                viewstate("direction") = "ASC"
            End If
        Else
            viewstate("field") = e.SortExpression
            viewstate("direction") = "ASC"
        End If

        dv.Sort = viewstate("field") & " " & viewstate("direction")
        DG1.CurrentPageIndex = 0
        Me.MyRefresh()
    End Sub

    Private Sub ddFund_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddFund.SelectedIndexChanged
        rdlChksubtype.Enabled = True
        rdlChksubtype.ClearSelection()
        GetDoc("")
    End Sub
End Class
