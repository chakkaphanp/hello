Imports System.Xml

Public Class pvf_add_news
    Inherits System.Web.UI.Page
    '    Inherits System.Xml

    Protected WithEvents Panel_t1 As System.Web.UI.WebControls.Panel
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents tbNews As System.Web.UI.WebControls.TextBox
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents tbNews2 As System.Web.UI.WebControls.TextBox

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "reg_news") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                Exit Sub
            End If
            '     Panel2.Attributes.Add("style", "display:none")
        End If
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim w1 As XmlTextWriter
        'Dim xfile As String = Server.MapPath("XML/" & strFund & ".xml")
        Dim xfile As String = Server.MapPath("XML/news.xml")
        '      Response.Write(xfile)
        w1 = New XmlTextWriter(xfile, Nothing)
        w1.WriteStartDocument()
        w1.Formatting = Formatting.Indented
        w1.Indentation = 3
        w1.WriteStartElement("FundNews")
        w1.WriteStartElement("NewsDate")
        w1.WriteAttributeString("Date", Now)
        w1.WriteElementString("News", tbNews.Text)
        w1.WriteElementString("News2", tbNews2.Text)
        w1.WriteEndElement()
        w1.Close()

        Response.Redirect("success.aspx?pagename=pvf_add_news.aspx")
        '        Panel1.Attributes.Add("style", "display:none")

    End Sub

End Class
