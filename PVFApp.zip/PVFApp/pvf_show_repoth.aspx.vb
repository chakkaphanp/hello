Imports System.Web
Imports CrystalDecisions
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.ReportSource

Public Class pvf_show_repoth
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents CrystalReportViewer1 As CrystalDecisions.Web.CrystalReportViewer

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


#Region "Valiable"

    Private Const strServerName As String = "nassetdb"
    Private Const strUserID As String = "pv"
    Private Const strPassword As String = "pvf2003"
    Private arrayParameterName As New ArrayList
    Private arrayParameterValue As New ArrayList
    Private RepType As String
    Private RepName As String
    Private StartDate As String
    Private EndDate As String
    Private FundSql As String
    Private FundCode As String
    Private TrnType As String
    Private Fstatus As String
    Private FundFlg As String
    '   Private objAuthen As New clsAuthorize

#End Region

    Private Sub InitData()
        Dim strSql As String

        RepName = Request("repname")
        StartDate = Request("dstart")
        EndDate = Request("dend")
        RepType = Request("repid")
        TrnType = Request("trntype")
        FundCode = Request("fund")
        Fstatus = Request("fstatus")
        FundSql = " "
        FundFlg = Request("fflg")

        '  Response.Write("repname = " & RepName & AgentID & AgentBran & StartDate & EndDate & RepType)
        Select Case RepType
            Case "001"   ' tran by parameter
                AddParameter("pType", TrnType)
                strSql = "'" & FundCode & "'"
                If FundCode = "ALL" Then
                    strSql = strSql & " or FUNDDESC.FUND <> " & strSql
                End If
                AddParameter("pFund", strSql)
            Case "002"   ' tran all
            Case "003"   ' funddesc
                AddParameter("pType", TrnType)
                If Fstatus = "All" Then
                    strSql = "A','C"
                Else
                    strSql = Fstatus
                End If
                AddParameter("pStatus", strSql)
                If FundFlg = "All" Then
                    strSql = "P','C"
                Else
                    strSql = FundFlg
                End If
                AddParameter("pFFlg", strSql)
            Case "004"      ' fund fee
                '                ("FUNDDESC"."FUND" = '{?pFund}') and
                strSql = "(FUNDDESC.FUND = '" & FundCode & "') and "
                If FundCode = "ALL" Then
                    strSql = " " ' "(" & strSql & " or FUNDDESC.FUND <> " & strSql & ") "
                End If
                AddParameter("pFundSql", strSql)
        End Select

        AddParameter("pStart", StartDate)
        AddParameter("pEnd", EndDate)

        'End If
    End Sub

    Private Sub AddParameter(ByVal ParameterName As String, ByVal ParameterValue As String)
        ' �ѧ���蹹���˹�ҷ�� �����觼�ҹ����Ѻ����� Show Report
        arrayParameterName.Add(ParameterName)
        arrayParameterValue.Add(ParameterValue)
    End Sub
    Sub showReport(ByVal ReportName As String)
        Dim myReportdocument As New ReportDocument
        Dim crParameterFieldDefinitions As CrystalReports.Engine.ParameterFieldDefinitions
        Dim crParameterFieldDefinition As CrystalReports.Engine.ParameterFieldDefinition
        Dim crParameterValues As New CrystalDecisions.Shared.ParameterValues
        Dim crParameterDiscreteValue As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim crDiskFileDestinationOptions As DiskFileDestinationOptions

        Dim i As Int16
        myReportdocument.Load(ReportName)
        myReportdocument.SetDatabaseLogon(strUserID, strPassword, strServerName, "")

        myReportdocument.DataDefinition.ParameterFields.Reset()

        '' ��ǹ�������ǹ�ͧ Parameter
        For i = 0 To arrayParameterName.Count - 1
            myReportdocument.SetParameterValue(arrayParameterName.Item(i), arrayParameterValue.Item(i))
        Next
        'Get Collection
        CrystalReportViewer1.DisplayGroupTree = False

        CrystalReportViewer1.ReportSource = myReportdocument

    End Sub

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InitData()
        showReport(Server.MapPath(RepName))
    End Sub

End Class
