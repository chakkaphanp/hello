Public Class pvf_show_order
    Inherits System.Web.UI.Page
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents rdlOrder As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents rdlCond As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents tbCond1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents tbCond2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents IbtSeach As System.Web.UI.WebControls.ImageButton
    Protected WithEvents DG_tbchq As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents imgCal2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents imgCal1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents myCalendar As PopUpCalendar

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public Runno As Integer
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Dim strsql As String
    Dim strWhere As String
    Dim dv As DataView
    Dim mc As New ClassCheckUser()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            myCalendar.hideCalendar()
            If mc.CheckUser(Session("user_id"), "inq_order") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                IbtSeach.Enabled = False
                Exit Sub
            End If
            strWhere = "  to_Char(trn_date,'yyyymmdd') >=  to_Char(sysdate,'yyyymmdd') "
            Me.MyData(strWhere)
        Else
            If DG1.Items.Count > 0 Then
                dv = Session("data")
            End If

        End If

    End Sub

    Private Sub MyData(ByVal strWhere As String)
        strsql = "select p.trn_no, p.fund,p.trn_type,nvl(p.share_amt,0) share_amt ,nvl(p.share_amt_bf,0) share_amt_bf , to_char(p.trn_date,'dd/mm/yyyy hh24:MI' ) trn_date" & _
                       ",f.fund_tname , to_char(p.trn_date,'dd/mm/yyyy' ) trn_date2, p.trn_flg " & _
                       " from pv.pvmtran p,pv.funddesc f  " & _
                       " where p.fund = f.fund and " & strWhere
        ' lbMsg.Text = strsql

        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView

        If dv.Count > 0 Then
            DG1.DataSource = dv  '.Tables(0).DefaultView
            Session("data") = dv
            'lbCount.Text = "�ӹǹ " & dv.Count & " ��¡��"

            'strsql = "select sum(buy_share) buy_share,sum(buy_money)  buy_money" & _
            '         " from v_sas_order   " & _
            '         " where " & strWhere
            ''   lb_err.Text = strsql
            'ds = m1.GetDataset(strsql)

            'Dim dr As DataRow = ds.Tables(0).Rows(0)
            'lbUnit.Text = " �ӹǹ˹��� ��� " & CType(dr("buy_share"), Double).ToString("###,###,##0.0000") & " ˹��� "
            'lbBath.Text = " �ӹǹ�Թ ��� " & CType(dr("buy_money"), Double).ToString("#,###,###,##0.00") & " �ҷ "
        Else
            DG1.DataSource = ds
            Session("data") = ds
        End If
        DG1.DataBind()
    End Sub

    Sub MyRefresh()
        dv = Session("data")
        DG1.DataSource = dv  '.Tables(0).DefaultView
        DG1.DataBind()
    End Sub

    Private Sub DG1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub DG1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DG1.SortCommand
        If UCase(viewstate("field")) = UCase(e.SortExpression) Then
            If viewstate("direction") = "ASC" Then
                viewstate("direction") = "Desc"
            Else
                viewstate("direction") = "ASC"
            End If
        Else
            viewstate("field") = e.SortExpression
            viewstate("direction") = "ASC"
        End If

        dv.Sort = viewstate("field") & " " & viewstate("direction")
        DG1.CurrentPageIndex = 0
        Me.MyRefresh()
    End Sub

    Private Sub IbtSeach_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles IbtSeach.Click
        lbMsg.Text = ""
        Dim strCond1, strCond2 As String
        Dim Year1, Year2 As Integer

        strCond1 = tbCond1.Text
        strCond2 = tbCond2.Text

        If strCond1.Length = 0 Or strCond1.Length = 0 Then
            lbMsg.Text = " ��سҡ�͡������ ����ͧ��ä��� "
            Exit Sub
        End If

        Select Case rdlCond.SelectedItem.Value
            Case "fdate"
                'If IsDate(tbCond1.Text) And IsDate(tbCond2.Text) Then ' check mm/dd/yyyy
                Dim strYear1, strYear2 As String
                strYear1 = Right(tbCond1.Text, 4)
                strYear2 = Right(tbCond2.Text, 4)

                If CInt(strYear1) > 2500 Then
                    strYear1 = CInt(strYear1) - 543
                End If
                If CInt(strYear2) > 2500 Then
                    strYear2 = CInt(strYear2) - 543
                End If

                strCond1 = strYear1 & Mid(tbCond1.Text, 4, 2) & Left(tbCond1.Text, 2)
                strCond2 = strYear2 & Mid(tbCond2.Text, 4, 2) & Left(tbCond2.Text, 2)
                'Else
                '    Exit Sub
                'End If
                strWhere = "  (to_Char(p.trn_date,'yyyymmdd') between  '" & strCond1 & "' and '" & strCond2 & "' )"
            Case "fname"
                strWhere = "  f.fund_tname like '%" & tbCond1.Text & "%'"
            Case "fund"
                strWhere = "  f.fund = '" & tbCond1.Text & "'"
        End Select

        Me.MyData(strWhere)

        'Select Case rdlCond.SelectedItem.Value
        '    Case "fdate"
        '        dv.RowFilter = " trn_date2 >= '" & tbCond1.Text & "' and trn_date2 <= '" & tbCond2.Text & "' "
        '    Case "fname"
        '        dv.RowFilter = " fund_tname like '" & tbCond1.Text & "%'"
        '    Case "fund"
        '        dv.RowFilter = " fund = '" & tbCond1.Text & "'"
        'End Select

        'If dv.Count <= 0 Then
        '    lbMsg.Text = "����բ�����"
        'End If
        'DG1.DataSource = dv
        'DG1.DataBind()

    End Sub

    Private Sub rdlOrder_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlOrder.SelectedIndexChanged
        If DG1.Items.Count > 0 Then
            dv = Session("Data")
            If rdlOrder.SelectedItem.Value = "ALL" Then
                dv.RowFilter = "  "
            Else
                dv.RowFilter = " trn_type = '" & rdlOrder.SelectedItem.Value & "'"
            End If
            'lb_err.Text = dv.Count

            DG1.DataSource = dv
            DG1.DataBind()
        End If

    End Sub

    Private Sub rdlCond_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlCond.SelectedIndexChanged
        Select Case rdlCond.SelectedItem.Value
            Case "fdate"
                tbCond2.Visible = True
                Label2.Visible = True
                Label3.Visible = True
                Label2.Text = " �֧ "
                imgCal1.Visible = True
                imgCal2.Visible = True
            Case "fname"
                tbCond2.Visible = False
                Label2.Visible = False
                Label3.Visible = False
                Label1.Text = "���ͧ͡�ع : "
                imgCal1.Visible = False
                imgCal2.Visible = False
            Case "fund"
                tbCond2.Visible = False
                Label2.Visible = False
                Label3.Visible = False
                Label1.Text = "���ʡͧ�ع : "
                imgCal1.Visible = False
                imgCal2.Visible = False
        End Select
        tbCond1.Text = ""
        tbCond2.Text = ""

    End Sub

    Private Sub DG1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemDataBound
        Dim strFlg As String = CType(DataBinder.Eval(e.Item.DataItem, "trn_type"), String)
        Dim strTrnFlg As String = CType(DataBinder.Eval(e.Item.DataItem, "trn_flg"), String)
        If strFlg = "SB" Then
            e.Item.Cells(7).BackColor = Color.DarkGreen
            e.Item.Cells(7).ForeColor = Color.GreenYellow
            e.Item.Cells(3).ForeColor = Color.DarkGreen
            e.Item.Cells(4).ForeColor = Color.DarkGreen
            e.Item.Cells(5).ForeColor = Color.DarkGreen
            e.Item.Cells(6).ForeColor = Color.DarkGreen
        ElseIf strFlg = "RD" Or strFlg = "CD" Then
            e.Item.Cells(7).BackColor = Color.Brown
            e.Item.Cells(7).ForeColor = Color.Pink
            e.Item.Cells(3).ForeColor = Color.DarkRed
            e.Item.Cells(4).ForeColor = Color.DarkRed
            e.Item.Cells(5).ForeColor = Color.DarkRed
            e.Item.Cells(6).ForeColor = Color.DarkRed
        ElseIf strFlg = "DV" Then
            e.Item.Cells(7).BackColor = Color.Lavender
        End If
        If strTrnFlg = "C" Then     ' Cancel Transaction
            e.Item.Cells(1).ForeColor = Color.Red
            e.Item.Cells(2).ForeColor = Color.Red
            e.Item.Cells(3).ForeColor = Color.Red
            e.Item.Cells(4).ForeColor = Color.Red
            e.Item.Cells(5).ForeColor = Color.Red
            e.Item.Cells(8).ForeColor = Color.Red
            e.Item.Cells(9).ForeColor = Color.Red
        End If
    End Sub

    Private Sub DG1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DG1.SelectedIndexChanged
        Dim x1 As String = DG1.DataKeys(DG1.SelectedIndex)
        Dim j As Integer = DG1.SelectedIndex
        Dim ds2 As New DataSet()

        ' *** Get Data from hidden field
        'Dim strOrdno As String = DG1.SelectedItem.Cells(0).Text
        'Dim strCisno As String = DG1.SelectedItem.Cells(1).Text
        Dim strType As String = DG1.SelectedItem.Cells(6).Text
        Dim strFund As String = DG1.SelectedItem.Cells(0).Text

        lbMsg.Text = ""
        If strType = "SB" Then
            lbMsg.Text = " �������¡���Ѻ�����Թ �ͧ����������ع "
            DG_tbchq.Visible = False
            Exit Sub
        End If
        DG_tbchq.Visible = True
        strsql = "select trn_no,rec_flg,run_no,acct_no,acct_name,bk_code,bk_bran,amount " & _
                   " from pvmpay  " & _
                   " where trn_no = '" & x1 & "'"
        'and order_no = '" & strOrdno & "' and fund = '" & strFund & "'"   ' and " & _
        ' " to_Char(tran_date,'ddmmyyyy') =  to_Char(sysdate,'ddmmyyyy') "
        '   lbMsg.Text = strsql
        ds2 = m1.GetDataset(strsql)

        Try

            If ds2.Tables(0).Rows.Count() < 1 Then
                lbMsg.Text &= " �������¡���Ѻ�����Թ ��Ң�¤׹/�Ż���ª�� ��سҵ�Ǩ�ͺ "
            End If
            DG_tbchq.DataSource = ds2  '.Tables(0).DefaultView
            DG_tbchq.DataBind()
        Catch x As Exception
            lbMsg.Text &= "����բ�����.."

        End Try
    End Sub

    Private Sub imgCal1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgCal1.Click
        Dim dSelDate As Date

        If IsDate(tbCond1.Text) Then
            dSelDate = tbCond1.Text
        End If
        myCalendar.displayCalendar("Select a start date", dSelDate, "tbCond1", 155, 360)
    End Sub

    Private Sub imgCal2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgCal2.Click
        Dim dSelDate As Date

        If IsDate(tbCond2.Text) Then
            dSelDate = tbCond2.Text
        End If
        myCalendar.displayCalendar("Select a start date", dSelDate, "tbCond2", 155, 520)
    End Sub
End Class
