Imports System.Data.OleDb

Public Class Class_GenNo
    Dim strsql As String
    Dim m1 As New MyData()
    Dim ds As DataSet

    Function GenCisno() As String
        Dim strCisno, strNewCis As String

        strsql = "Select mas_ref From cis.MasterRef Where mas_code = 'pvcis' "
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)
        strCisno = dr("mas_ref")

        Dim i_Run, i, i_Cisno As Integer
        Dim i_RunCis As Double
        Dim str1 As String

        'strCisno = Right(Left(strCisno, 9), 7)   '�Ѵ PV 
        strCisno = Right(strCisno, 8)   '�Ѵ PV 
        strCisno = Left(strCisno, 7)
        strCisno = Right("0000000000" + CType(CType(strCisno, Double) + 1, String), 9)
        i_Run = Right(Left(strCisno, 1) * 9, 1)
        i_Cisno = CType(strCisno, Integer)

        For i = 1 To 9
            i_Cisno = CType(Mid(strCisno, i, 1), Integer)
            i_Run = i_Run + Right(i_Cisno * (i - 1), 1)
        Next

        i_Run = CType(Left(i_Run, 1), Integer) + CType(Right(i_Run, 1), Integer)
        i_RunCis = 0
        i_RunCis = Right(10 - Right(i_Run, 1), 1)
        '     strNewCis = i_Run & " -- " & i_RunCis & " - "

        strCisno = strCisno + CType(i_RunCis, String)
        strNewCis = Right("0000000000" + strCisno, 10)
        strNewCis = "PV" + Right(strCisno, 8)
        strsql = "update cis.MasterRef set mas_ref ='" & strNewCis & "' where mas_code='pvcis' "
        m1.Execute(strsql)

        Return strNewCis
    End Function

    Function GenHolder(ByVal strFund As String) As String
        Dim strHno, strNewHno As String

        strsql = "Select holder From pv.FundContl where fund = '" & strFund & "' "
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)
        strHno = dr("holder")

        Dim i_Run, i, i_Hno As Integer
        Dim i_RunHno As Double = 0
        Dim str1 As String

        strHno = Left(strHno, 6)
        strHno = Right("0000000" + CType(CType(strHno, Double) + 1, String), 6)
        i_Run = Right(Left(strHno, 1), 1)
        i_Hno = CType(strHno, Integer)

        For i = 1 To 6
            i_Hno = CType(Mid(strHno, i, 1), Integer)
            i_Run = i_Run + Right(i_Hno * (i), 1)
        Next
        str1 = CType(i_Run, String)
        For i = 1 To Len(str1)
            i_RunHno = i_RunHno + CType(Mid(str1, i, 1), Integer)
        Next

        i_RunHno = Right(10 - Right(i_RunHno, 1), 1)
        ' strNewHno = i_Run & " -- " & i_RunHno & " - "

        strHno = strHno + CType(i_RunHno, String)
        strNewHno &= Right("0000000" + strHno, 7)
        ' str1 = Right("0000000" + strHno, 7)

        strsql = "update pv.FundContl set holder ='" & strNewHno & "'  where fund = '" & strFund & "'"
        m1.Execute(strsql)

        Return strNewHno
    End Function
End Class
