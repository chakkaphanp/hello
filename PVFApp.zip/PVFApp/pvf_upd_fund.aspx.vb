Public Class pvf_upd_fund
    Inherits System.Web.UI.Page
    Protected WithEvents tbFeeA As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFeeT As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFeeM As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFReturn As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFCond As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFPolicy As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAuditAddr As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbAuditBy As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddRegis As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Panel_t2 As System.Web.UI.WebControls.Panel
    Protected WithEvents cblSelect As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents tbFund As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFname As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbFname_e As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddFtype As System.Web.UI.WebControls.DropDownList
    Protected WithEvents tbRefNo As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbSignAmt As System.Web.UI.WebControls.TextBox
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents tbSign As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbDue As System.Web.UI.WebControls.TextBox
    Protected WithEvents tbResign As System.Web.UI.WebControls.TextBox
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel
    Protected WithEvents ddRisk As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lberr As System.Web.UI.WebControls.Label
    Protected WithEvents btEdit As System.Web.UI.WebControls.Button
    Protected WithEvents btCancel As System.Web.UI.WebControls.Button
    Protected WithEvents Panel3 As System.Web.UI.WebControls.Panel
    Protected WithEvents ddSelect_Hide As System.Web.UI.WebControls.DropDownList
    Protected WithEvents rdlStatus As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents rdlFundFlg As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents ddlFeeCond As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddMkt As System.Web.UI.WebControls.DropDownList

    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim FlgUpd As String
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Dim strsql As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            Dim mc As New ClassCheckUser()
            If mc.CheckUser(Session("user_id"), "reg_updfund") = "F" Then
                lberr.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                tbFund.Enabled = False
                btEdit.Enabled = False
                Exit Sub
            End If

            strsql = "select type_code, type_desc_t from pv.fundtype where type_flg = 'T' order by type_desc_t "
            ' ('EQ','GF','BL','FL','SPEQ','SPGF','SPBL','SPFL') order by type_desc_t "
            ds = m1.GetDataset(strsql)
            ddFtype.DataSource = ds
            ddFtype.DataTextField = "type_desc_t"
            ddFtype.DataValueField = "type_code"

            strsql = "select  bk_name , bk_code  from cis.opnmbank where bk_bran = 'XXX' order by bk_name "
            ds = m1.GetDataset(strsql)
            ddRegis.DataSource = ds      ' for trustee/regis
            ddRegis.DataTextField = "bk_name"
            ddRegis.DataValueField = "bk_code"

            strsql = "select  obj_desc , obj_code  from pvmobj where obj_type = 'risk_level' order by obj_desc "
            ds = m1.GetDataset(strsql)
            ddRisk.DataSource = ds
            ddRisk.DataTextField = "obj_desc"
            ddRisk.DataValueField = "obj_code"

            strsql = "select  user_id,'('||user_id||') '||user_name||' '||user_sname  as u_name " & _
                               "from sao.sawebuser where agent_id  = '000000001' and status = 'A' order by user_id "
            ds = m1.GetDataset(strsql)
            ddMkt.DataSource = ds
            ddMkt.DataTextField = "u_name"
            ddMkt.DataValueField = "user_id"

            Me.DataBind()
        End If

    End Sub

    Sub AddItem()
        ddFtype.Items.Insert(0, "�ä�к�")
        ddRegis.Items.Insert(0, "�ä�к�")
    End Sub

    Sub GetData(ByVal strFund As String)
        Dim strChk As String

        strsql = "select  fund,fund_tname, nvl(fund_ename,' ') fund_ename,nvl(fund_policy,' ') fund_policy, " & _
            "nvl(fund_cond,' ') fund_cond, nvl(fund_return,' ') fund_return, nvl(fund_amt,0) fund_amt ,nvl(to_char(sign_date,'dd/mm/yyyy'),' ') sign_date, " & _
            "nvl(to_char(due_date,'dd/mm/yyyy'),' ') due_date,nvl(to_char(resign_date,'dd/mm/yyyy'),' ') resign_date, " & _
            "nvl(to_char(regis_date,'dd/mm/yyyy'),' ') regis_date, " & _
            "nvl(balance_amt,0) balance_amt , nvl(balance_unit,0) balance_unit , fund_type, nvl(regis_name,' ') regis_name,trustee_name, nvl(mkt_agent,' ') mkt_agent,  " & _
             "nvl(mkt_code,' ') mkt_code,nvl(audit_by,' ') audit_by, nvl(audit_addr,' ') audit_addr ," & _
            " nvl(management_feetxt,' ') management_fee, nvl(trustee_feetxt,' ') trustee_fee, nvl(audit_feetxt,' ') audit_fee, nvl(ref_no,' ') ref_no ," & _
            " nvl(risk_level,' ') risk_level, fund_status, fund_flg, nvl(cond_fee,'1') as cond_fee " & _
            " from pv.funddesc where fund  = '" & strFund & "'"
        ds = m1.GetDataset(strsql)

        Dim dc As Integer = ds.Tables(0).Rows.Count
        If dc > 0 Then
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            tbFname.Text = dr("fund_tname")
            tbFname_e.Text = dr("fund_ename")
            strChk = dr("fund_status")
            If strChk = "A" Then
                rdlStatus.SelectedIndex = 0
            Else
                rdlStatus.SelectedIndex = 1
            End If
            strChk = dr("fund_flg")
            If strChk = "P" Then
                rdlFundFlg.SelectedIndex = 0
            Else
                rdlFundFlg.SelectedIndex = 1
            End If
            tbRefNo.Text = dr("ref_no")
            tbSignAmt.Text = FormatNumber(dr("fund_amt"), 2)
            tbSign.Text = dr("sign_date")
            tbDue.Text = dr("due_date")
            tbResign.Text = dr("resign_date")
            tbFPolicy.Text = dr("fund_policy")
            tbFCond.Text = dr("fund_cond")
            tbFReturn.Text = dr("fund_return")

            tbAuditBy.Text = dr("audit_by")
            tbAuditAddr.Text = dr("audit_addr")
            tbFeeM.Text = dr("management_fee")
            tbFeeT.Text = dr("trustee_fee")
            tbFeeA.Text = dr("audit_fee")

            Dim strFtype As String = dr("fund_type")
            Dim strTrustee As String = dr("regis_name")
            Dim strRisk As String = dr("risk_level")
            Dim strFeecond As String = dr("cond_fee")
            Dim strMkt As String = dr("mkt_code")

            Dim dd2 As ListItem
            Dim index1 As Integer

            dd2 = ddFtype.Items.FindByValue(strFtype)
            index1 = ddFtype.Items.IndexOf(dd2)
            ddFtype.SelectedIndex = index1

            dd2 = ddRegis.Items.FindByValue(strTrustee)
            index1 = ddRegis.Items.IndexOf(dd2)
            ddRegis.SelectedIndex = index1

            dd2 = ddRisk.Items.FindByValue(strRisk)
            index1 = ddRisk.Items.IndexOf(dd2)
            ddRisk.SelectedIndex = index1

            dd2 = ddlFeeCond.Items.FindByValue(strFeecond)
            index1 = ddlFeeCond.Items.IndexOf(dd2)
            ddlFeeCond.SelectedIndex = index1

            dd2 = ddMkt.Items.FindByValue(strmkt)
            index1 = ddMkt.Items.IndexOf(dd2)
            ddMkt.SelectedIndex = index1


            'Clear_acct()
            cblSelect.Enabled = True
            btEdit.Enabled = True
            lberr.Text = ""
        Else
            btEdit.Enabled = False
            btSave.Enabled = False
            lberr.Text = "  *** ����բ����� �ͧ�ع ��سҵ�Ǩ�ͺ ***"
            cblSelect.Enabled = False
            Clear_text()
        End If
    End Sub

    Sub Clear_text()
        tbFname.Text = ""
        tbFname_e.Text = ""
        '    ddFtype.Enabled = False
        tbRefNo.Text = ""
        tbSignAmt.Text = ""
        '   ddRisk.Enabled = False
        tbSign.Text = ""
        tbDue.Text = ""
        tbResign.Text = ""
        tbAuditBy.Text = ""
        tbAuditAddr.Text = ""
        '  ddRegis.Enabled = False
        tbFPolicy.Text = ""
        tbFCond.Text = ""
        tbFReturn.Text = ""
        tbFeeM.Text = ""
        tbFeeT.Text = ""
        tbFeeA.Text = ""
    End Sub

    Private Sub tbFund_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbFund.TextChanged
        GetData(tbFund.Text)
        SetEnable()
    End Sub

    Private Sub cblSelect_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cblSelect.SelectedIndexChanged
        Dim Item As ListItem
        Dim strUpd, strChk As String
        For Each Item In cblSelect.Items
            strUpd = Item.Value
            If Item.Selected Then
                strChk = "T"
                Select Case strUpd
                    Case "PV_F01"
                        tbFname.Enabled = True
                        tbFname_e.Enabled = True
                        ddFtype.Enabled = True
                        rdlStatus.Enabled = True
                        rdlFundFlg.Enabled = True
                    Case "PV_F02"
                        tbRefNo.Enabled = True
                        tbSignAmt.Enabled = True
                        ddRisk.Enabled = True
                    Case "PV_F03"
                        tbSign.Enabled = True
                        tbDue.Enabled = True
                        tbResign.Enabled = True
                    Case "PV_F04"
                        tbAuditBy.Enabled = True
                        tbAuditAddr.Enabled = True
                        ddRegis.Enabled = True
                    Case "PV_F05"
                        tbFPolicy.Enabled = True
                        tbFCond.Enabled = True
                        tbFReturn.Enabled = True
                    Case "PV_F06"
                        tbFeeM.Enabled = True
                        tbFeeT.Enabled = True
                        tbFeeA.Enabled = True
                        ddlFeeCond.Enabled = True
                    Case "PV_F09"
                        ddMkt.Enabled = True
                End Select
            Else
                Select Case strUpd
                    Case "PV_F01"
                        tbFname.Enabled = False
                        tbFname_e.Enabled = False
                        ddFtype.Enabled = False
                        rdlStatus.Enabled = False
                        rdlFundFlg.Enabled = False
                    Case "PV_F02"
                        tbRefNo.Enabled = False
                        tbSignAmt.Enabled = False
                        ddRisk.Enabled = False
                    Case "PV_F03"
                        tbSign.Enabled = False
                        tbDue.Enabled = False
                        tbResign.Enabled = False
                    Case "PV_F04"
                        tbAuditBy.Enabled = False
                        tbAuditAddr.Enabled = False
                        ddRegis.Enabled = False
                    Case "PV_F05"
                        tbFPolicy.Enabled = False
                        tbFCond.Enabled = False
                        tbFReturn.Enabled = False
                    Case "PV_F06"
                        tbFeeM.Enabled = False
                        tbFeeT.Enabled = False
                        tbFeeA.Enabled = False
                        ddlFeeCond.Enabled = False
                    Case "PV_F09"
                        ddMkt.Enabled = False
                End Select
            End If
        Next

        If strChk = "T" Then
            btSave.Enabled = True
        Else
            btSave.Enabled = False
        End If
    End Sub

    Private Sub btEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btEdit.Click
        Dim Item As ListItem
        Dim strUpd, strChk As String
        For Each Item In cblSelect.Items
            strUpd = Item.Value
            If Item.Selected Then
                strChk = "T"
                Select Case strUpd
                    Case "PV_F01"
                        tbFname.Enabled = True
                        tbFname_e.Enabled = True
                        ddFtype.Enabled = True
                        rdlStatus.Enabled = True
                        rdlFundFlg.Enabled = True
                    Case "PV_F02"
                        tbRefNo.Enabled = True
                        tbSignAmt.Enabled = True
                        ddRisk.Enabled = True
                    Case "PV_F03"
                        tbSign.Enabled = True
                        tbDue.Enabled = True
                        tbResign.Enabled = True
                    Case "PV_F04"
                        tbAuditBy.Enabled = True
                        tbAuditAddr.Enabled = True
                        ddRegis.Enabled = True
                    Case "PV_F05"
                        tbFPolicy.Enabled = True
                        tbFCond.Enabled = True
                        tbFReturn.Enabled = True
                    Case "PV_F06"
                        tbFeeM.Enabled = True
                        tbFeeT.Enabled = True
                        tbFeeA.Enabled = True
                        ddlFeeCond.Enabled = True
                    Case "PV_F09"
                        ddMkt.Enabled = True
                End Select
            Else
                Select Case strUpd
                    Case "PV_F01"
                        tbFname.Enabled = False
                        tbFname_e.Enabled = False
                        ddFtype.Enabled = False
                        rdlStatus.Enabled = False
                        rdlFundFlg.Enabled = False
                    Case "PV_F02"
                        tbRefNo.Enabled = False
                        tbSignAmt.Enabled = False
                        ddRisk.Enabled = False
                    Case "PV_F03"
                        tbSign.Enabled = False
                        tbDue.Enabled = False
                        tbResign.Enabled = False
                    Case "PV_F04"
                        tbAuditBy.Enabled = False
                        tbAuditAddr.Enabled = False
                        ddRegis.Enabled = False
                    Case "PV_F05"
                        tbFPolicy.Enabled = False
                        tbFCond.Enabled = False
                        tbFReturn.Enabled = False
                    Case "PV_F06"
                        tbFeeM.Enabled = False
                        tbFeeT.Enabled = False
                        tbFeeA.Enabled = False
                        ddlFeeCond.Enabled = False
                    Case "PV_F09"
                        ddMkt.Enabled = False
                End Select
            End If
        Next

        If strChk = "T" Then
            GetSelect()
            btSave.Enabled = True
            cblSelect.Enabled = False
        Else
            btSave.Enabled = False
        End If
    End Sub

    Sub GetSelect()
        Dim HashS As New Hashtable
        Dim Item As ListItem
        Dim strUpd As String
        Dim i As Integer

        For Each Item In cblSelect.Items
            strUpd = Item.Value
            If Item.Selected Then
                i += 1
                HashS.Add(i, strUpd)
            End If
        Next
        ddSelect_Hide.DataSource = HashS
        ddSelect_Hide.DataTextField = "value"
        ddSelect_Hide.DataValueField = "value"
        ddSelect_Hide.DataBind()

    End Sub

    Private Sub btCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btCancel.Click
        btSave.Enabled = False
        cblSelect.Enabled = True
        GetData(tbFund.Text)
        SetEnable()
    End Sub

    Private Sub tbSignAmt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbSignAmt.TextChanged
        If IsNumeric(tbSignAmt.Text) Then
            lberr.Text = ""
            If CType(tbSignAmt.Text, Double) Then
                tbSignAmt.Text = CType(tbSignAmt.Text, Double).ToString("#,###,###,##0.00")
            End If
        Else
            lberr.Text = "�ä�кبӹǹ�繵���Ţ"
            tbSignAmt.Text = "0"
        End If
    End Sub

    Sub SetEnable()
        tbFname.Enabled = False
        tbFname_e.Enabled = False
        rdlStatus.Enabled = False
        rdlFundFlg.Enabled = False
        ddFtype.Enabled = False
        tbRefNo.Enabled = False
        tbSignAmt.Enabled = False
        ddRisk.Enabled = False
        tbSign.Enabled = False
        tbDue.Enabled = False
        tbResign.Enabled = False
        tbAuditBy.Enabled = False
        tbAuditAddr.Enabled = False
        ddRegis.Enabled = False
        tbFPolicy.Enabled = False
        tbFCond.Enabled = False
        tbFReturn.Enabled = False
        tbFeeM.Enabled = False
        tbFeeT.Enabled = False
        tbFeeA.Enabled = False
        ddlFeeCond.Enabled = False
        ddMkt.Enabled = False
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strFund, strFnameT, strFnameE, strFType, strRefno, strSignAmt, strSignD, strDueD, strResignD As String
        Dim strAuditBy, strAuditAddr, strRegis, strFPolicy, strFCond, strFReturn, strFeeM, strFeeT, strFeeA As String
        Dim strAccno, strAccno2, strAccno3, strAccno4, strAccName, strAccName2, strAccName3, strAccName4 As String
        Dim strAcctype, strAcctype2, strAcctype3, strAcctype4 As String
        Dim strBkcode, strBkcode2, strBkcode3, strBkcode4, strBkbran, strBkbran2, strBkbran3, strBkbran4 As String
        Dim strRisk, strChk, strStatus, strFundFlg, strFeeCond As String
        Dim strMkt As String
        Dim dbRunno As Double
        Dim m1 As New MyData
        strFund = tbFund.Text

        If ddFtype.SelectedItem.Text = "*** �ä�к� ***" Then
            lberr.Text = "��س��кػ����� �ͧ�ع "
            Exit Sub
        ElseIf ddRegis.SelectedItem.Text = "*** �ä�к� ***" Then
            lberr.Text = "��س��к� ����Ѻ�ҡ��Ѿ���Թ"
            Exit Sub
        ElseIf ddMkt.SelectedItem.Text = "*** �ä�к� ***" Then
            lberr.Text = "��س��к� Marketing "
            Exit Sub
        End If
        ' check length field before save
        strStatus = rdlStatus.SelectedValue
        strFPolicy = Trim(tbFPolicy.Text)
        strFCond = Trim(tbFCond.Text)
        strFReturn = Trim(tbFReturn.Text)
        strFeeM = Trim(tbFeeM.Text)
        strFeeT = Trim(tbFeeT.Text)
        strFeeA = Trim(tbFeeA.Text)

        If Len(strFPolicy) > 500 Or Len(strFCond) > 500 Or Len(strFReturn) > 500 Or Len(strFeeM) > 500 Or Len(strFeeT) > 500 Or Len(strFeeA) > 500 Then
            lberr.Text = "*** ��ͤ��� : "
            If Len(strFPolicy) > 500 Then
                lberr.Text &= "- ��º�¡��ŧ�ع "
            ElseIf Len(strFCond) > 500 Then
                lberr.Text &= "-  ���͹䢡��ŧ�ع "
            ElseIf Len(strFReturn) > 500 Then
                lberr.Text &= "- ����Ѻ�Ż���ª�� "
            ElseIf Len(strFeeM) > 500 Then
                lberr.Text &= "-  ��Ҹ���������èѴ��� "
            ElseIf Len(strFeeT) > 500 Then
                lberr.Text &= "- ��Ҹ�����������Ѻ�ҡ��Ѿ���Թ "
            ElseIf Len(strFeeA) > 500 Then
                lberr.Text &= "-  ��Ҹ�����������ͺ�ѭ�� "
            End If
            lberr.Text &= "  �Թ����˹� ��سҵ�Ǩ�ͺ"
            Exit Sub
        Else
            strFPolicy = ""
            strFCond = ""
            strFReturn = ""
            strFeeM = ""
            strFeeT = ""
            strFeeA = ""
        End If

        strsql = "Select mas_ref From cis.MasterRef Where mas_code = 'pvhfmas' "
        ds = m1.GetDataset(strsql)
        Dim dr1 As DataRow = ds.Tables(0).Rows(0)
        dbRunno = dr1("mas_ref") + 1

        Dim Item As ListItem
        Dim strUpd As String

        For Each Item In ddSelect_Hide.Items
            strUpd = Item.Value

            ' **** Insert into hMas ****
            strsql = "insert into pv.fundhmas(run_no,fund,upd_flg,upd_by,upd_date )" & _
                          "values (" & dbRunno & ",'" & strFund & "','" & strUpd & "','" & Session("user_id") & "', sysdate )"
            'lberr.Text &= strsql
            m1.Execute(strsql)
            Select Case strUpd
                Case "PV_F01", "PV_F02", "PV_F03", "PV_F04", "PV_F05", "PV_F06", "PV_F09"
                    strChk = "T"
                Case Else
                    strChk = "Acct"    ' update fund account
            End Select

        Next

        If strChk = "T" Then

            ' *** Select data before change
            strsql = "select  fund,fund_tname, nvl(fund_ename,' ') fund_ename,nvl(fund_policy,' ') fund_policy, " & _
               "nvl(fund_cond,' ') fund_cond, nvl(fund_return,' ') fund_return, nvl(fund_amt,0) fund_amt ,nvl(to_char(sign_date,'dd/mm/yyyy'),' ') sign_date, " & _
               "nvl(to_char(due_date,'dd/mm/yyyy'),' ') due_date,nvl(to_char(resign_date,'dd/mm/yyyy'),' ') resign_date, " & _
               "nvl(to_char(regis_date,'dd/mm/yyyy'),' ') regis_date, " & _
               "nvl(balance_amt,0) balance_amt , nvl(balance_unit,0) balance_unit , fund_type, nvl(regis_name,' ') regis_name,trustee_name, nvl(mkt_agent,' ') mkt_agent,  " & _
                "nvl(mkt_code,' ') mkt_code,nvl(audit_by,' ') audit_by, nvl(audit_addr,' ') audit_addr ," & _
               " nvl(management_feetxt,' ') management_fee, nvl(trustee_feetxt,' ') trustee_fee, nvl(audit_feetxt,' ') audit_fee, nvl(ref_no,' ') ref_no ," & _
               " nvl(risk_level,' ') risk_level, fund_status, fund_flg, nvl(cond_fee,' ') cond_fee  " & _
               " from pv.funddesc where fund  = '" & strFund & "'"

            ds = m1.GetDataset(strsql)
            Dim dr As DataRow = ds.Tables(0).Rows(0)
            For Each Item In ddSelect_Hide.Items
                '            For Each Item In cblSelect.Items
                strUpd = Item.Value
                Select Case strUpd
                    Case "PV_F01"
                        strFnameT = Trim(dr("fund_tname"))
                        strFnameE = Trim(dr("fund_ename"))
                        strFType = Trim(dr("fund_type"))
                        strStatus = Trim(dr("fund_status"))
                        strFundFlg = Trim(dr("fund_flg"))
                    Case "PV_F02"
                        strRefno = Trim(dr("ref_no"))
                        strSignAmt = Trim(dr("fund_amt"))
                        strRisk = Trim(dr("risk_level"))
                    Case "PV_F03"
                        strSignD = Trim(dr("sign_date"))
                        strDueD = Trim(dr("due_date"))
                        strResignD = Trim(dr("resign_date"))
                    Case "PV_F04"
                        strAuditBy = Trim(dr("audit_by"))
                        strAuditAddr = Trim(dr("audit_addr"))
                        strRegis = Trim(dr("regis_name"))
                    Case "PV_F05"
                        strFPolicy = Trim(dr("fund_policy"))
                        strFCond = Trim(dr("fund_cond"))
                        strFReturn = Trim(dr("fund_return"))
                    Case "PV_F06"
                        strFeeM = Trim(dr("management_fee"))
                        strFeeT = Trim(dr("trustee_fee"))
                        strFeeA = Trim(dr("audit_fee"))
                        strFeeCond = Trim(dr("cond_fee"))
                    Case "PV_F09"
                        strMkt = Trim(dr("mkt_code"))
                End Select
            Next

            ' **** Insert data before change into pvHfund
            strsql = "insert into pv.pvhfund(run_no,fund,fund_tname, fund_ename, fund_type, fund_policy, " & _
                           " fund_cond,  fund_return, fund_amt ,sign_date,due_date, resign_date, " & _
                           " regis_name, audit_by,  audit_addr ,management_feetxt, trustee_feetxt, " & _
                           " audit_feetxt,  ref_no ,risk_level, upd_by, fund_status, fund_flg, cond_fee, mkt_code )" & _
                           " values (" & dbRunno & ",'" & strFund & "','" & strFnameT & "','" & strFnameE & "','" & strFType & "','" & strFPolicy & "','" & _
                                strFCond & "','" & strFReturn & "','" & strSignAmt & "',to_date('" & strSignD & "','dd/mm/yyyy')," & _
                                "to_date('" & strDueD & "','dd/mm/yyyy'),to_date('" & strResignD & "','dd/mm/yyyy'),'" & _
                               strRegis & "','" & strAuditBy & "', '" & strAuditAddr & "','" & strFeeM & "','" & strFeeT & "','" & strFeeA & _
                                "','" & strRefno & "','" & strRisk & "','" & Session("user_id") & "','" & strStatus & "','" & _
                                strFundFlg & "','" & strFeeCond & "','" & strMkt & "')"
            '  "to_date('" & strBthDate & "','dd/mm/yyyy'),'" & 
            m1.Execute(strsql)
            'lberr.Text &= strsql

            ' *** Read data from Field
            strFnameT = Trim(tbFname.Text)
            strFnameE = Trim(tbFname_e.Text)
            strStatus = rdlStatus.SelectedValue
            strFundFlg = rdlFundFlg.SelectedValue
            strFType = ddFtype.SelectedItem.Value
            strRisk = ddRisk.SelectedItem.Value
            strRefno = Trim(tbRefNo.Text)
            strSignAmt = Trim(tbSignAmt.Text)
            strSignD = Trim(tbSign.Text)
            strDueD = Trim(tbDue.Text)
            strResignD = Trim(tbResign.Text)
            strRegis = ddRegis.SelectedItem.Value
            strAuditBy = Trim(tbAuditBy.Text)
            strAuditAddr = Trim(tbAuditAddr.Text)
            strFPolicy = Trim(tbFPolicy.Text)
            strFCond = Trim(tbFCond.Text)
            strFReturn = Trim(tbFReturn.Text)
            strFeeM = Trim(tbFeeM.Text)
            strFeeT = Trim(tbFeeT.Text)
            strFeeA = Trim(tbFeeA.Text)
            strFeeCond = ddlFeeCond.SelectedValue
            strMkt = ddMkt.SelectedValue

            ' *** Update Data into PvMfund
            strsql = "update pv.funddesc set fund_tname= '" & tbFname.Text & "' , " & _
                            "fund_ename = '" & tbFname_e.Text & "'," & _
                            "fund_type = '" & strFType & "'," & _
                            "sign_date = to_date('" & strSignD & "','dd/mm/yyyy')," & _
                            "resign_date = to_date('" & strResignD & "','dd/mm/yyyy')," & _
                            "due_date = to_date('" & strDueD & "','dd/mm/yyyy')," & _
                            "regis_name= '" & strRegis & "'," & _
                            "fund_amt = " & CType(strSignAmt, Double) & ", " & _
                            "fund_policy = '" & strFPolicy & "', " & _
                            "fund_cond = '" & strFCond & "', " & _
                            "fund_return = '" & strFReturn & "', " & _
                            "audit_by = '" & strAuditBy & "' ," & _
                            "audit_addr = '" & strAuditAddr & "', " & _
                            "management_feetxt = '" & strFeeM & "', " & _
                            "trustee_feetxt = '" & strFeeT & "', " & _
                            "audit_feetxt = '" & strFeeA & "', " & _
                            "risk_level = '" & strRisk & "', " & _
                            " upd_by = '" & Session("user_id") & "', " & _
                            " upd_date = sysdate ,  " & _
                            " ref_no = '" & strRefno & "', " & _
                            " fund_status = '" & strStatus & "', " & _
                            " fund_flg = '" & strFundFlg & "', " & _
                            " cond_fee = '" & strFeeCond & "', " & _
                            " mkt_code = '" & strMkt & "' " & _
                            " where fund = '" & strFund & "'"
            'lberr.Text &= strsql
            m1.Execute(strsql)

        Else
            ' ** Update data for fund account
            'GetAcct(strFund, strrunno)
        End If

        strsql = "update cis.MasterRef set mas_ref ='" & dbRunno & "' where mas_code='pvhfmas' "
        Try
            m1.Execute(strsql)
        Catch x1 As Exception
            lberr.Text = x1.Message
        End Try

        Response.Redirect("success.aspx?pagename=pvf_upd_fund.aspx")
        'lberr.Text &= "�ѹ�֡�����䢢��������º����"
        'btSave.Visible = False

    End Sub

End Class

