Imports System.Data.OleDb

Public Class ClassDate
    Function GetThaiLongMonthName(ByVal IntMonth)
        Dim strMonth As String
        Select Case IntMonth
            Case 1 : strMonth = "���Ҥ�"
            Case 2 : strMonth = "����Ҿѹ��"
            Case 3 : strMonth = "�չҤ�"
            Case 4 : strMonth = "����¹"
            Case 5 : strMonth = "����Ҥ�"
            Case 6 : strMonth = "�Զع�¹"
            Case 7 : strMonth = "�á�Ҥ�"
            Case 8 : strMonth = "�ԧ�Ҥ�"
            Case 9 : strMonth = "�ѹ��¹"
            Case 10 : strMonth = "���Ҥ�"
            Case 11 : strMonth = "��Ȩԡ�¹"
            Case 12 : strMonth = "�ѹ�Ҥ�"
        End Select
        Return strMonth
    End Function

    Function GetThaiShortMonthName(ByVal IntMonth)
        Dim strMonth As String
        Select Case IntMonth
            Case 1 : strMonth = "�.�."
            Case 2 : strMonth = "�.�."
            Case 3 : strMonth = "��.�."
            Case 4 : strMonth = "��.�"
            Case 5 : strMonth = "�.�."
            Case 6 : strMonth = "��.�."
            Case 7 : strMonth = "�.�."
            Case 8 : strMonth = "�.�."
            Case 9 : strMonth = "�.�."
            Case 10 : strMonth = "�.�."
            Case 11 : strMonth = "�.�."
            Case 12 : strMonth = "�.�."
        End Select
        Return strMonth
    End Function
End Class
