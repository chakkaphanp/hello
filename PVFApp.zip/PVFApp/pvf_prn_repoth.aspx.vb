Public Class pvf_prn_repoth
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents ddDy2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDy As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddDd As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddlRepName As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddlFund As System.Web.UI.WebControls.DropDownList
    Protected WithEvents imgView As System.Web.UI.WebControls.ImageButton
    Protected WithEvents cblType As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents cblFType As System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents rdlStatus As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents P2 As System.Web.UI.WebControls.Panel
    Protected WithEvents P1 As System.Web.UI.WebControls.Panel
    Protected WithEvents lbDateF As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents rdlFflg As System.Web.UI.WebControls.RadioButtonList

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Dim strsql As String
    Dim ds As New DataSet
    Dim m1 As New MyData
    Dim mc As New ClassCheckUser

#Region "Function"
    Function GetTrnDate() As String
        Dim strtrndate As String
        strtrndate = ddDd.SelectedItem.Value & "/" & ddDm.SelectedItem.Value & "/" & ddDy.SelectedItem.Value - 543
        Return strtrndate
    End Function



#End Region

#Region "Procedure"
    Private Sub GetDate()
        Dim strSql As String
        Dim c_date As Date = Now
        Dim str_cur As String
        Dim ds As New DataSet
        Dim m1 As New MyData

        str_cur = c_date.Day

        Dim i As Integer
        For i = 1 To 31
            ddDd.Items.Add(i)
            ddDd2.Items.Add(i)
        Next

        ddDd.SelectedIndex = str_cur - 1
        ddDd2.SelectedIndex = str_cur - 1

        strSql = "select * from web.webmonth"
        ds = m1.GetDataset(strSql)
        ddDm.DataSource = ds
        ddDm.DataTextField = "mth_t_name"
        ddDm.DataValueField = "mth_code"

        ddDm2.DataSource = ds
        ddDm2.DataTextField = "mth_t_name"
        ddDm2.DataValueField = "mth_code"

        Dim yy(7) As String '= {"2547", "2548"}
        'ddDy.DataSource = yy
        str_cur = c_date.Year + 543
        str_cur = CInt(str_cur) - 5
        For i = 1 To 7
            yy(i) = str_cur
            ddDy.Items.Add(yy(i))
            ddDy2.Items.Add(yy(i))
            str_cur += 1
        Next

        Me.DataBind()

        str_cur = c_date.Month
        ddDm.SelectedIndex = str_cur - 1
        ddDm2.SelectedIndex = str_cur - 1

        ddDy.SelectedIndex = 5
        ddDy2.SelectedIndex = 5

    End Sub
    Private Sub GetRep()
        strsql = "select rep_id,rep_name from pv.pvmreport "
        ds = m1.GetDataset(strsql)
        ddlRepName.DataSource = ds
        ddlRepName.DataTextField = "rep_name"
        ddlRepName.DataValueField = "rep_id"

        Me.DataBind()
    End Sub
    Private Sub GetFund()
        strsql = "select fund,fund_tname||' ( '||fund||' )' fund_tname from pv.v_fund where class_code='P' order by fund_tname"
        ds = m1.GetDataset(strsql)
        ddlFund.DataSource = ds
        ddlFund.DataTextField = "fund_tname"
        ddlFund.DataValueField = "fund"

        Me.DataBind()
    End Sub
    Private Sub GetFtype()
        strsql = "select type_code, type_desc_t from pv.fundtype where type_flg = 'T' order by type_desc_t "
        ' type_code in ('EQ','GF','BL','FL','SPEQ','SPGF','SPBL','SPFL') order by type_desc_t "
        ds = m1.GetDataset(strsql)
        cblFType.DataSource = ds
        cblFType.DataTextField = "type_desc_t"
        cblFType.DataValueField = "type_code"

    End Sub
#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "rep_oth") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                imgView.Enabled = False
                Exit Sub
            End If

            Me.GetRep()
            Me.GetFtype()
            Me.GetFund()
            Me.GetDate()

            'Call subInit()

            ddlRepName.Items.Insert(0, "�ä�к���§ҹ")
            ddlRepName.SelectedIndex = 0
            ddlFund.Items.Insert(0, "���͡�ء�ͧ�ع")
            ddlFund.SelectedIndex = 0

            P1.Attributes.Add("style", "display:none")
            P2.Attributes.Add("style", "display:none")
            imgView.Enabled = False

        End If
    End Sub


    Private Sub ddDm_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddDm.SelectedIndexChanged
        Dim strdm As String
        strdm = ddDm.SelectedItem.Value
        Dim getdm As String = DateTime.DaysInMonth(DateTime.Now.Year.ToString, strdm) ' return days in month
        If ddDd.SelectedItem.Value > getdm Then
            lbMsg.Text &= "��͹����� " & getdm & " �ѹ "
        Else
            lbMsg.Text = ""
        End If
    End Sub

    Private Sub ddDm2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddDm2.SelectedIndexChanged
        Dim strdm As String
        strdm = ddDm2.SelectedItem.Value
        Dim getdm As String = DateTime.DaysInMonth(DateTime.Now.Year.ToString, strdm) ' return days in month
        If ddDd2.SelectedItem.Value > getdm Then
            lbMsg.Text &= "��͹����� " & getdm & " �ѹ "
        Else
            lbMsg.Text = ""
        End If
    End Sub

    Private Sub imgView_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgView.Click
        Dim strP, strRepFile, strRepId As String
        Dim strFund, strType, strStatus, strFflg As String
        Dim strDstart, strDend, strYear, strYear2 As String

        strStatus = ""
        strRepId = ddlRepName.SelectedValue
        strsql = "select rep_id,rep_filename from pv.pvmreport where rep_id = '" & strRepId & "' "
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow
        dr = ds.Tables(0).Rows(0)
        strRepFile = dr("rep_filename")

        strYear = ddDy.SelectedItem.Value - 543
        strYear2 = ddDy2.SelectedItem.Value - 543

        strDstart = strYear & ddDm.SelectedItem.Value & Right("00" & ddDd.SelectedItem.Value, 2)
        strDend = strYear2 & ddDm2.SelectedItem.Value & Right("00" & ddDd2.SelectedItem.Value, 2)

        Select Case strRepId
            Case "001"    ' rptpvftran
                Dim Item As ListItem
                For Each Item In cblType.Items
                    If Item.Selected Then
                        strType &= "'" & Item.Value & "',"
                        '       strFund &= Item.Text + " "
                    End If
                Next

                Dim iLen As Integer
                ' �Ѵ��Ƿ��·��  
                iLen = Len(strType)
                strType = Mid(strType, 2, iLen - 3)   ' �Ѵ �����ǵ��˹�ҷ�� and �Ѵ , �Ѻ �����ǵ����ѧ ���

                strFund = ddlFund.SelectedValue
                If ddlFund.SelectedIndex = 0 Then
                    strFund = "ALL"  ' ���͡�ء�ͧ�ع
                End If
            Case "003"
                Dim Item As ListItem
                For Each Item In cblFType.Items
                    If Item.Selected Then
                        strType &= "'" & Item.Value & "',"
                        '       strFund &= Item.Text + " "
                    End If
                Next

                Dim iLen As Integer
                ' �Ѵ��Ƿ��·��  
                iLen = Len(strType)
                strType = Mid(strType, 2, iLen - 3)   ' �Ѵ �����ǵ��˹�ҷ�� and �Ѵ , �Ѻ �����ǵ����ѧ ���
                If rdlStatus.SelectedIndex = -1 Then
                    strStatus = "All"
                Else
                    strStatus = rdlStatus.SelectedValue
                End If
                If rdlFflg.SelectedIndex = -1 Then
                    strFflg = "All"
                Else
                    strFflg = rdlFflg.SelectedValue
                End If

            Case "004"   ' rptPVFFee
                strFund = ddlFund.SelectedValue
                If ddlFund.SelectedIndex = 0 Then
                    strFund = "ALL"  ' ���͡�ء�ͧ�ع
                End If
        End Select

        strP = strRepFile & "&dstart=" & strDstart & "&dend=" & strDend & _
        "&repid=" & strRepId & "&trntype=" & strType & "&fund=" & _
        strFund & "&fstatus=" & strStatus & "&fflg=" & strFflg

        '  Response.Write(strP)

        Response.Redirect("pvf_show_repoth.aspx?repname=" & strP)

        ''  Dim strTrnDate As String = GetTrnDate()  '& " " & Now.ToString("HH:mm:ss")

        'strDstart = Right("00" & ddDd.SelectedItem.Value, 2) & "/" & ddDm.SelectedItem.Value & "/" & ddDy.SelectedItem.Value - 543
        'strDend = Right("00" & ddDd2.SelectedItem.Value, 2) & "/" & ddDm2.SelectedItem.Value & "/" & ddDy2.SelectedItem.Value - 543

        '' strP = "http://220.0.0.149/sanet/sarepview.aspx?repname=" & strRepFile & "&agentid=" & AgentID & _
        ''"&agentbran=" & AgentBranID & "&dstart=" & strDstart & _
        ''"&dend=" & strDend & "&repid=" & strRepId
    End Sub

    Private Sub ddlRepName_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlRepName.SelectedIndexChanged
        Dim strRep As String
        strRep = ddlRepName.SelectedValue
        imgView.Enabled = True
        lbDateF.Text = "��ǧ�ѹ��� :"

        Select Case strRep
            Case "001"    ' rptpvftran
                cblType.Enabled = True
                ddlFund.Enabled = True
                P1.Attributes.Add("style", "display:")
                P2.Attributes.Add("style", "display:none")
            Case "002"    ' rptpvftranall
                cblType.Enabled = False
                ddlFund.Enabled = False
                P1.Attributes.Add("style", "display:")
                P2.Attributes.Add("style", "display:none")
            Case "003"    ' rptpvffunddesc
                P1.Attributes.Add("style", "display:none")
                P2.Attributes.Add("style", "display:")
            Case "004"    ' rptpvffee
                cblType.Enabled = False
                ddlFund.Enabled = True
                P1.Attributes.Add("style", "display:")
                P2.Attributes.Add("style", "display:none")
                lbDateF.Text = "�ѹ����� �ҡ :"
            Case Else
                P1.Attributes.Add("style", "display:none")
                P2.Attributes.Add("style", "display:none")
                imgView.Enabled = False
                lbDateF.Text = "�ѹ���Ѵ��� �ҡ :"
        End Select
    End Sub
End Class
