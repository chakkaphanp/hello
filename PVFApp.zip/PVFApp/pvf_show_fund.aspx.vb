Public Class pvf_show_fund
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim dv As DataView
    Dim strsql As String
    Dim strWhere As String
    Dim m1 As New MyData()
    Dim ds As DataSet
    Public Runno As Integer
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents rdlStatus As System.Web.UI.WebControls.RadioButtonList
    Dim mc As New ClassCheckUser

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "inq_fund") = "F" Then
                lbMsg.Text = "*** �س������Է�� ����¡������ ��� ***"
                Exit Sub
            End If
            strWhere = "where fund_status = 'A' "
            Me.MyDataBind(strWhere)
            'lbMsg.Text = ""
        Else
            dv = Session("data")
        End If
    End Sub

    Sub MyDataBind(ByVal strWhere As String)
        strsql = "select  fund,fund_tname,fund_tname_short,fund_type," & _
                       " sign_date, to_char(sign_date,'dd/mm/yyyy') sign_date2 , " & _
                       " due_date, to_char(due_date,'dd/mm/yyyy') due_date2 , fund_status" & _
                       " from pv.funddesc " & strWhere & _
                       " order by fund "
        '        " where fund_flg = 'P' " & _
        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView
        Me.MyRefresh()
        Session("data") = dv
        If ds.Tables(0).Rows.Count < 1 Then
            'lbMsg.Text = "*** ����բ����� ������ ***"
        Else
            'lbMsg.Text = " �ӹǹ�����ŷ���� = " & ds.Tables(0).Rows.Count & " ��¡�� "
        End If
    End Sub

    Sub MyRefresh()
        DataGrid1.DataSource = dv
        DataGrid1.DataBind()
    End Sub

    Private Sub DataGrid1_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles DataGrid1.PageIndexChanged
        DataGrid1.CurrentPageIndex = e.NewPageIndex
        Me.MyRefresh()
    End Sub

    Private Sub DataGrid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged
        Dim x1 As String = DataGrid1.DataKeys(DataGrid1.SelectedIndex)
        Dim j As Integer = DataGrid1.SelectedIndex
        Dim dr As DataRow = dv.Table.Rows(j)   'ds.Tables(0).Rows(j) 

        Dim strFund As String = DataGrid1.SelectedItem.Cells(0).Text   ' Get from Hidden column
        Response.Redirect("pvf_show_fund_desc.aspx?fund=" & strFund)
    End Sub

    Private Sub DataGrid1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DataGrid1.SortCommand
        If UCase(viewstate("field")) = UCase(e.SortExpression) Then
            If viewstate("direction") = "ASC" Then
                viewstate("direction") = "Desc"
            Else
                viewstate("direction") = "ASC"
            End If
        Else
            viewstate("field") = e.SortExpression
            viewstate("direction") = "ASC"
        End If

        dv.Sort = viewstate("field") & " " & viewstate("direction")
        DataGrid1.CurrentPageIndex = 0
        Me.MyRefresh()
    End Sub

    Private Sub DataGrid1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DataGrid1.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub rdlStatus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdlStatus.SelectedIndexChanged
        Dim strStatus As String
        strStatus = rdlStatus.SelectedValue
        strWhere = "where fund_status = '" & strStatus & "' "
        Me.MyDataBind(strWhere)
    End Sub
End Class
