Imports System.Data.OleDb

Public Class Class_Gen_Cisno
    Dim strsql As String
    Dim m1 As New MyData()
    Dim ds As DataSet

    Function GenCisno() As String
        Dim strCisno, strNewCis As String

        strsql = "Select cisno From OpnContl Where fund = 'control' "
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)
        strCisno = dr("cisno")

        Dim i_Run, i, i_Cisno As Integer
        Dim i_RunCis As Double
        Dim str1 As String

        strCisno = Left(strCisno, 9)
        strCisno = Right("0000000000" + CType(CType(strCisno, Double) + 1, String), 9)
        i_Run = Right(Left(strCisno, 1) * 9, 1)
        i_Cisno = CType(strCisno, Integer)

        For i = 1 To 9
            i_Cisno = CType(Mid(strCisno, i, 1), Integer)
            i_Run = i_Run + Right(i_Cisno * (i - 1), 1)
        Next

        i_Run = CType(Left(i_Run, 1), Integer) + CType(Right(i_Run, 1), Integer)
        i_RunCis = 0
        i_RunCis = Right(10 - Right(i_Run, 1), 1)
        '     strNewCis = i_Run & " -- " & i_RunCis & " - "

        strCisno = strCisno + CType(i_RunCis, String)
        strNewCis &= Right("0000000000" + strCisno, 10)
        strsql = "update OpnContl set cisno ='" & strNewCis & "' where fund='control' "
        m1.Execute(strsql)

        Return strNewCis
    End Function

End Class
