Public Class pvf_upd_order
    Inherits System.Web.UI.Page
    Protected WithEvents DG1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Public Runno As Integer
    Dim ds As New DataSet()
    Dim m1 As New MyData()
    Dim strsql As String
    Dim strWhere As String
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents lbMsg2 As System.Web.UI.WebControls.Label
    Protected WithEvents lbMsg As System.Web.UI.WebControls.Label
    Protected WithEvents btMatch As System.Web.UI.WebControls.Button
    Protected WithEvents btSave As System.Web.UI.WebControls.Button
    Protected WithEvents btRefresh As System.Web.UI.WebControls.Button
    Dim dv As DataView
    Dim mc As New ClassCheckUser

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If mc.CheckUser(Session("user_id"), "trn_update") = "F" Then
                lbMsg2.Text = "*** �س������Է�� ����¡������ ��� ***"
                btSave.Enabled = False
                btRefresh.Enabled = False
                Exit Sub
            End If
            strWhere = "  to_Char(trn_date,'yyyymmdd') =  to_Char(sysdate,'yyyymmdd') "
            Me.MyData(strWhere)
        Else
            dv = Session("data")
        End If
    End Sub

    Private Sub MyData(ByVal strWhere As String)
        Dim dt As DataTable
        Dim dr As DataRow
        Dim dr2, dr3 As DataRow
        Dim ds2 As New DataSet
        Dim ds3 As New DataSet
        Dim strTrnNo, strType, strFund, strTrnDate, strTrnDateNav, strExp As String
        Dim dbAmt As Double

        strsql = "select p.trn_no, p.fund,p.trn_type,to_char(nvl(p.share_amt,0),'99,999,999,999.99')  share_amt , " & _
                       " to_char(nvl(p.share_amt_bf,0),'99,999,999,999.99')  share_amt_bf , to_char(p.trn_date,'dd/mm/yyyy' ) trn_date" & _
                       ",f.fund_tname , to_char(p.trn_date,'dd/mm/yyyy' ) trn_date2, trn_alot ,p.nav, nvl( p.dv_unit,0) dv_unit, " & _
                       " to_char(0,'99,999,999.9999') issue_stock,'1900-01-01' data_date " & _
                       " from pv.pvmtran p,pv.funddesc f  " & _
                       " where p.fund = f.fund and trn_flg = 'A' and  trn_alot ='N' " 'and " & strWhere
        'lbMsg.Text = strsql

        ds = m1.GetDataset(strsql)
        dv = ds.Tables(0).DefaultView

        If dv.Count > 0 Then
            ds = m1.GetDataset(strsql)
            dt = ds.Tables(0)
            For Each dr In dt.Rows
                strFund = dr("fund")

                strTrnDate = dr("trn_date")
                strType = dr("trn_type")
                dbAmt = dr("share_amt")
                strExp = " < "

                '*** ����¹ SQL �ͧ������ support ��� req no.P201308007 27/9/2013
                strsql = " select a.fund_code,nvl(a.data_date,sysdate) data_date,nvl(a.nav,0) nav,to_char(nvl(a.issue_stock,0),'99,999,999,999.9999') issue_stock,to_char(nvl(a.nav_amount,0),'99,999,999,999.99') nav_amount " & _
                        " FROM WARNDBA.W_NAV a, pv.fundcontl b where a.fund_code = b.fund  " & _
                        " and a.fund_code = '" & strFund & "' " & _
                        " and a.data_date = ( select max(data_date) data_date from warndba.w_nav where fund_code = '" & strFund & "' " & _
                        " and data_date " & strExp & " to_date('" & strTrnDate & "','dd/mm/yyyy')) "

                ' lbMsg.Text = strsql
                ds2 = m1.GetDataset(strsql)

                Try
                    Dim dbNav, dbNavAmt, dbDV, dbStock As Double

                    dr2 = ds2.Tables(0).Rows(0)
                    strTrnDateNav = dr2("data_date")
                    dbNav = dr2("nav")
                    dbStock = dr2("issue_stock")     ' �ӹǹ˹��¤������
                    '                   dbNavAmt = dr2("nav_amount")

                    Dim idiff As Integer
                    Dim c_date As String = Now.ToString("dd/MM/yyyy")
                    '  idiff = DateDiff(DateInterval.Day, CDate(strTrnDate), CDate(strTrnDateNav))

                    '  lbMsg2.Text &= idiff & " , "
                    ' lbMsg.Text &= strType
                    If strType = "DV" Then
                        '*** ' ���ѹ T ���ʹ֧ �ӹǹ˹����Ҥӹǳ �ѹ��   25/02/2014  ����ʴ� NAV �ѹ��� T-1 ����Ѻ DV
                        ' lbMsg.Text &= CDate(strTrnDate) & " <=" & CDate(c_date)

                        If CDate(strTrnDate) < CDate(c_date) Then
                            strsql = " select a.fund_code,nvl(a.data_date,sysdate) data_date,to_char(nvl(a.issue_stock,0),'99,999,999,999.9999') issue_stock,to_char(nvl(a.nav_amount,0),'99,999,999,999.99') nav_amount " & _
                                    " FROM WARNDBA.W_NAV a, pv.fundcontl b where a.fund_code = b.fund  " & _
                                    " and a.fund_code = '" & strFund & "' " & _
                                    " and a.data_date = ( select max(data_date) data_date from warndba.w_nav where fund_code = '" & strFund & "' " & _
                                    " and data_date = to_date('" & strTrnDate & "','dd/mm/yyyy')) "
                            '    lbMsg.Text &= strsql
                            ds3 = m1.GetDataset(strsql)
                            dr3 = ds3.Tables(0).Rows(0)
                            Try
                                dbStock = dr3("issue_stock")     ' �ӹǹ˹��¤������
                                dbDV = dbAmt / dbStock
                                dr("dv_unit") = FormatNumber(dbDV, 4)
                                '                        dr("nav_amt") = FormatNumber(dbNavAmt, 5)
                            Catch x1 As Exception
                                lbMsg.Text &= "*** ����բ����Ũӹǹ˹��� �ͧ�ͧ�ع " & strFund & " �ѹ��� " & strTrnDate & " ��سҵ�Ǩ�ͺ "
                                lbMsg.Text &= x1.Message
                                Exit Sub
                            End Try
                        End If
                    Else
                        ' dbStock = 0
                    End If
                    dr("issue_stock") = FormatNumber(dbStock, 4)
                    dr("data_date") = strTrnDateNav

                    '*** set new nav to order
                    dr("nav") = dbNav
                    '         lbMsg.Text &= dbNav

                Catch x1 As Exception
                    lbMsg.Text &= "*** ����բ����� NAV �ͧ�ͧ�ع " & strFund & " �ѹ��� " & strTrnDate & " ��سҵ�Ǩ�ͺ "
                    lbMsg.Text &= x1.Message
                    Exit Sub
                End Try

            Next

            DG1.DataSource = ds  '.Tables(0).DefaultView
            Session("data") = dv
            '  btMatch.Visible = True
        Else
            DG1.DataSource = ds
            Session("data") = dv
        End If
        DG1.DataBind()
    End Sub

    Sub MyRefresh()
        dv = Session("data")
        DG1.DataSource = dv  '.Tables(0).DefaultView
        DG1.DataBind()
    End Sub

    Private Sub DG1_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemCreated
        Runno = e.Item.DataSetIndex + 1
    End Sub

    Private Sub DG1_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles DG1.SortCommand
        If UCase(viewstate("field")) = UCase(e.SortExpression) Then
            If viewstate("direction") = "ASC" Then
                viewstate("direction") = "Desc"
            Else
                viewstate("direction") = "ASC"
            End If
        Else
            viewstate("field") = e.SortExpression
            viewstate("direction") = "ASC"
        End If

        dv.Sort = viewstate("field") & " " & viewstate("direction")
        DG1.CurrentPageIndex = 0
        Me.MyRefresh()
    End Sub

    Private Sub DG1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles DG1.ItemDataBound
        Dim strType As String = CType(DataBinder.Eval(e.Item.DataItem, "trn_type"), String)
        If strType = "SB" Then
            '      e.Item.Cells(6).BackColor = Color.DarkGreen
            '  e.Item.Cells(6).ForeColor = Color.GreenYellow
            e.Item.Cells(8).ForeColor = Color.DarkGreen
            e.Item.Cells(5).ForeColor = Color.DarkGreen
        ElseIf strType = "RD" Then
            '   e.Item.Cells(6).BackColor = Color.Brown
            ' e.Item.Cells(6).ForeColor = Color.Pink
            e.Item.Cells(8).ForeColor = Color.Red
            e.Item.Cells(5).ForeColor = Color.Red
        End If

        Dim TrnDate, TrnDateNav As Date
        Dim idiff As Integer
        Dim c_date As String = Now.ToString("dd/MM/yyyy")

        TrnDate = CType(DataBinder.Eval(e.Item.DataItem, "trn_date2"), Date)

        TrnDateNav = DataBinder.Eval(e.Item.DataItem, "data_date")
        If TrnDateNav <> "1900-01-01" Then
            TrnDateNav = CDate(TrnDateNav) 'CType(DataBinder.Eval(e.Item.DataItem, "data_date"), Date)
            idiff = DateDiff(DateInterval.Day, TrnDate, TrnDateNav)
            If idiff < -1 Then
                e.Item.Cells(7).ForeColor = Color.DodgerBlue
                e.Item.Cells(7).BackColor = Color.LightBlue
                e.Item.Cells(11).ForeColor = Color.Yellow
                e.Item.Cells(11).BackColor = Color.Red
            End If
            idiff = DateDiff(DateInterval.Day, TrnDate, Now)
            If idiff > 0 Then
                e.Item.Cells(13).Enabled = True
            Else
                e.Item.Cells(13).BackColor = Color.Red
                e.Item.Cells(13).Enabled = False
            End If
        Else
            e.Item.Cells(11).ForeColor = Color.WhiteSmoke
        End If

    End Sub

    Private Sub DG1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DG1.SelectedIndexChanged
        Dim x1 As String = DG1.DataKeys(DG1.SelectedIndex)
        Dim j As Integer = DG1.SelectedIndex
    End Sub

    Private Sub DG1_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.EditCommand
        DG1.EditItemIndex = e.Item.ItemIndex
        Me.MyRefresh()
        btSave.Enabled = False
    End Sub

    Private Sub DG1_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.CancelCommand
        DG1.EditItemIndex = -1
        Me.MyRefresh()
    End Sub

    Private Sub DG1_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DG1.UpdateCommand
        Dim strTrnNo As String
        Dim txbMoney As TextBox
        Dim txbBf As TextBox
        Dim txbType As TextBox
        Dim txbNav As TextBox
        Dim txbTrnDate As TextBox
        Dim txbDvUnit As TextBox
        Dim dbTotal, dbTotalU As Double
        Dim dbBfAmt, dbBfUnit, dbMoney, dbMoney_Old, dbSeq, dbNav, dbNav_Old As Double
        Dim dbDvUnit, dbDvUnit_Old As Double
        Dim strFund, strType As String
        Dim strTrnDate, strTrnDateUpd As String
        Dim strUpdDate, strUpdBy As String
        Dim c_date As String = Now.ToString("dd/MM/yyyy HH:mm:ss")

        '*** keep old value
        txbNav = e.Item.Cells(10).Controls(0)
        txbDvUnit = e.Item.Cells(9).Controls(0)
        txbTrnDate = e.Item.Cells(7).Controls(0)

        lbMsg.Text = ""
        strTrnNo = DG1.DataKeys(e.Item.ItemIndex)

        strsql = "select fund,share_amt, nvl(share_amt_bf,0) share_amt_bf,nvl(share_unit_bf,0) share_unit_bf, " & _
                        " trn_type,to_char(trn_date,'dd/mm/yyyy') trn_date, nvl(nav,0) nav, nvl(dv_unit,0) dv_unit, upd_by, upd_date  " & _
                       "  from pv.pvmtran " & _
                       " where trn_no = '" & strTrnNo & "'"
        ds = m1.GetDataset(strsql)
        Dim dr As DataRow = ds.Tables(0).Rows(0)

        strFund = dr("fund")
        strType = dr("trn_type")
        dbBfAmt = dr("share_amt_bf")
        dbBfUnit = dr("share_unit_bf")
        dbMoney_Old = dr("share_amt")
        strTrnDate = txbTrnDate.Text 'dr("trn_date")
        strUpdDate = dr("upd_date")
        strUpdBy = dr("upd_by")
        dbNav_Old = txbNav.Text  'FormatNumber(dr("nav"), 4)
        dbDvUnit_Old = txbDvUnit.Text ' FormatNumber(dr("dv_unit"), 4)

        txbMoney = e.Item.Cells(8).Controls(0)
        dbMoney = CType(txbMoney.Text, Double)

        txbNav = e.Item.Cells(10).Controls(0)
        dbNav = CType(txbNav.Text, Double)

        txbTrnDate = e.Item.Cells(7).Controls(0)
        '        strTrnDateUpd = CType(txbTrnDate.Text, Date)
        strTrnDateUpd = txbTrnDate.Text

        txbDvUnit = e.Item.Cells(9).Controls(0)
        dbDvUnit = CType(txbDvUnit.Text, Double)

        If strType = "SB" Then
            dbTotal = dbBfAmt + dbMoney
            dbTotalU = dbBfUnit
        Else
            dbTotal = dbBfAmt - dbMoney
            dbTotalU = dbBfUnit
        End If

        strsql = "update pv.pvmtran set share_amt = " & dbMoney & ", " & _
                     " nav = " & dbNav & _
                     ", trn_date = to_date('" & strTrnDateUpd & "','dd/mm/yyyy')" & _
                     ", dv_unit = " & dbDvUnit & _
                     "  where trn_no = '" & strTrnNo & "'"
        ' lbMsg2.Text = strsql
        m1.Execute(strsql)

        Try
            'strsql = "update pv.fundcontl set share_amt = " & dbTotal & " , share_unit =  " & dbTotalU & _
            '"  where fund = '" & strFund & "'"

            'm1.Execute(strsql)     '** ���繵�ͧ update fundcontl �������� ���е͹�Ѵ��� �� update ?

            strsql = "select nvl(max(seq),0)  seq  from pv.pvhtran "
            ds = m1.GetDataset(strsql)
            Dim dr1 As DataRow = ds.Tables(0).Rows(0)
            dbSeq = dr1("seq") + 1

            strsql = "insert into pv.pvhtran (seq,trn_no,fund,share_amt,upd_by,upd_date, trn_type, trn_date, nav,dv_unit ) " & _
                           "values (" & dbSeq & ",'" & strTrnNo & "','" & strFund & "'," & dbMoney_Old & ",'" & strUpdBy & "'," & _
                          "to_date('" & strUpdDate & "','dd/mm/yyyy HH24:MI:SS'),'" & strType & "', to_date('" & strTrnDate & "','dd/mm/yyyy') ," & _
                           dbNav_Old & "," & dbDvUnit_Old & " ) "
            m1.Execute(strsql)

            If strType = "DV" Then
                UpdMktgtdividend(strFund, strTrnDate, dbDvUnit, dbDvUnit_Old, strTrnDateUpd)
            End If

            Response.Redirect("success.aspx?pagename=pvf_upd_order.aspx")
            'lbMsg.Text &= "�ѹ�֡�����䢢����� ���º����"
        Catch x1 As Exception
            lbMsg.Text &= x1.Message
        End Try

    End Sub

    Function UpdMktgtdividend(ByVal strFund As String, ByVal strTrnDate As String, ByVal dcDVunit As Decimal, ByVal dcDVunitOld As Decimal, ByVal strTrnDateUpd As String)
        strsql = "select fund,to_char(xd_date,'dd/mm/yyyy') xd_date, dvd_amt" & _
                 "  from mktg.mktgtdividend " & _
                 " where fund = '" & strFund & "' and " & _
                 "      to_char(xd_date,'dd/mm/yyyy') = '" & strTrnDate & "'"
        ds = m1.GetDataset(strsql)
        '       Dim dr As DataRow = ds.Tables(0).Rows(0)
        dv = ds.Tables(0).DefaultView

        If dv.Count > 0 Then     ' Update Flag_up = 'F'
            strsql = "update mktg.mktgtdividend set " & _
                     "      dvd_amt = " & dcDVunit & "," & _
                     "      description = 'Auto Update'," & _
                     "      xd_date = to_date('" & strTrnDateUpd & "','dd/mm/yyyy'), " & _
                     "      upd_date = sysdate ," & _
                     "      upd_by = '" & Session("user_id") & "'," & _
                     "      flag_up = 'F' " & _
                     "where fund = '" & strFund & "' and " & _
                     "       to_char(xd_date,'dd/mm/yyyy') = '" & strTrnDate & "'"

        Else   ' Insert record and Mark Flag_up = 'T'
            strsql = "insert into mktg.mktgtdividend (comp,fund,xd_date,dvd_amt,dvd_type,description,upd_date,upd_by,flag_up ) " & _
                     "values ('THANACHART FUND','" & strFund & "',to_date('" & strTrnDate & "','dd/mm/yyyy')," & _
                     dcDVunit & ",'P','Auto Insert',sysdate,'" & Session("user_id") & "','T')"
        End If
        m1.Execute(strsql)

    End Function

    Private Sub btsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim dgi As DataGridItem
        Dim strTrnNo As String
        Dim strFund, strNav, strDV, strTrndate, strTrntype As String
        Dim txtFund, txtNav, txtDV, txtTrndate, txtType As TextBox
        Dim dbNav, dbDV As Double

        For Each dgi In DG1.Items
            Dim cb As CheckBox = dgi.Cells(13).Controls(1)
            If cb.Checked Then
                strTrnNo = DG1.DataKeys(dgi.ItemIndex)

                strFund = DG1.Items(dgi.ItemIndex).Cells(1).Text.ToString
                strTrntype = DG1.Items(dgi.ItemIndex).Cells(5).Text.ToString
                strTrndate = DG1.Items(dgi.ItemIndex).Cells(7).Text.ToString
                strNav = DG1.Items(dgi.ItemIndex).Cells(10).Text.ToString
                strDV = DG1.Items(dgi.ItemIndex).Cells(9).Text.ToString

                'txtFund = dgi.Cells(3).Controls(0)
                'txtType = dgi.Cells(5).Controls(0)   ' trn_type
                'txtNav = dgi.Cells(10).Controls(0)    ' nav
                'txtTrndate = dgi.Cells(7).Controls(0)    ' trn date
                'txtDV = dgi.Cells(9).Controls(0)    ' dv_unit

                'strFund = txtFund.Text
                'strNav = txtNav.Text
                'strDV = txtDV.Text
                'strTrndate = txtTrndate.Text

                dbNav = CType(strNav, Double)
                dbDV = CType(strDV, Double)

                strsql = "update pv.pvmtran set  nav = " & dbNav & " , dv_unit=" & dbDV & _
                         ",trn_date = to_date('" & strTrndate & "','dd/mm/yyyy'), trn_alot='C' " & _
                         " where trn_no = '" & strTrnNo & "' and fund = '" & strFund & "' "

                m1.Execute(strsql)
                lbMsg.Text &= strsql

                Try
                    'lbMsg.Text &= "�ѹ�֡��� Confirm ��¡��  ���º���� ... ��س��駼�����ӹҨ����͹��ѵ���¡�èѴ���"

                    If strTrntype = "DV" Then  'txtType.Text
                        UpdMktgtdividend(strFund, strTrndate, dbDV, 0, strTrndate)
                    End If
                Catch x1 As Exception
                    lbMsg.Text = x1.Message
                End Try
            End If
        Next
        Response.Redirect("success.aspx?pagename=pvf_upd_order.aspx")
        strWhere = "  to_Char(trn_date,'yyyymmdd') =  to_Char(sysdate,'yyyymmdd') "
        Me.MyData(strWhere)
    End Sub

    Private Sub btRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btRefresh.Click
        Response.Redirect("pvf_upd_order.aspx")
    End Sub

    '**** ���������
    Private Sub btMatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btMatch.Click
        Dim dr As DataRow
        Dim dgi As DataGridItem
        Dim strTrnNo, strType, strFund, strTrnDate, strTrnDateNav, strExp As String
        Dim dbAmt As Double

        For Each dgi In DG1.Items
            Dim cb As CheckBox = dgi.Cells(11).Controls(1)
            'Dim txb As TextBox = dgi.Cells(3).Controls(0)
            'Dim lb As Label = dgi.Cells(3).Controls(1)
            'strFund = lb.Text

            strTrnNo = DG1.DataKeys(dgi.ItemIndex)

            strsql = "select fund,share_amt, nvl(share_amt_bf,0) share_amt_bf,nvl(share_unit_bf,0) share_unit_bf, " & _
                    " trn_type,to_char(trn_date,'dd/mm/yyyy') trn_date, nvl(nav,0) nav, nvl(dv_unit,0) dv_unit  " & _
                   "  from pv.pvmtran " & _
                   " where trn_no = '" & strTrnNo & "'"
            ds = m1.GetDataset(strsql)
            dr = ds.Tables(0).Rows(0)
            strFund = dr("fund")
            strTrnDate = dr("trn_date")
            strType = dr("trn_type")
            dbAmt = dr("share_amt")
            strExp = " < "

            If strType = "DV" Then
                strExp = " = "
            End If

            '*** ����¹ SQL �ͧ������ support ��� req no.P201308007 27/9/2013
            strsql = " select a.fund_code,a.data_date,nvl(a.nav,0) nav,a.issue_stock,a.nav_amount " & _
                    " FROM WARNDBA.W_NAV a, pv.fundcontl b where a.fund_code = b.fund  " & _
                    " and a.fund_code = '" & strFund & "' " & _
                    " and a.data_date = ( select max(data_date) data_date from warndba.w_nav where fund_code = '" & strFund & "' " & _
                    " and data_date < to_date('" & strTrnDate & "','dd/mm/yyyy')) "


            lbMsg.Text = strsql
            ds = m1.GetDataset(strsql)

            Try
                Dim dbNav, dbNavAmt, dbDV As Double

                dr = ds.Tables(0).Rows(0)
                dbNav = dr("nav")
                dbNavAmt = dr("nav_amount")

                strTrnDateNav = dr("data_date")
                If strType = "DV" Then
                    strTrnDateNav = strTrnDate
                    dbDV = dbAmt / dbNavAmt
                End If

                '                strsql = "update pv.pvmtran set  nav = " & dbNav & _
                '                ", trn_date = to_date('" & strTrnDateNav & "','dd/mm/yyyy')" & _
                '                 "  where trn_no = '" & strTrnNo & "'"
                '                m1.Execute(strsql)

                DG1.Items.Item(0).DataItem = "00"


            Catch x1 As Exception
                '                lbMsg.Text = " ����բ����� NAV �ͧ�ͧ�ع��� ��سҵ�Ǩ�ͺ "
                lbMsg.Text &= x1.Message
                Exit Sub
            End Try

        Next

    End Sub

End Class

