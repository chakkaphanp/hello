Public Class Class_ClearText
    Function ClearText()
        'Dim myForm As Control = Page.FindControl("form1")
        'Dim ctl As Control
        'For Each ctl In myForm.Controls
        '    If ctl.GetType().ToString().Equals("System.Web.UI.WebControls.label") Then
        '        CType(ctl, Label).Text = ""
        '    End If
        'Next ctl
    End Function
End Class
